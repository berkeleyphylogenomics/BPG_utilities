// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "Seq.h"
#include "TextFile.h"

void DoPWID(const char *in)
    {
    TextFile fileIn(in);
    MSA msaIn;
    msaIn.FromFASTAFile(fileIn);
    msaIn.AlignByCase();

    char szStem[128];
    NameFromPath(in, szStem, sizeof(szStem));

    const unsigned uSeqCount = msaIn.GetSeqCount();
    for (unsigned uSeqIndex1 = 0; uSeqIndex1 < uSeqCount; ++uSeqIndex1)
        {
        const char *pstrName1 = msaIn.GetSeqName(uSeqIndex1);
        Seq seq1;
        msaIn.GetSeq(uSeqIndex1, seq1);
        const unsigned uLength1 = seq1.Length();

        for (unsigned uSeqIndex2 = uSeqIndex1 + 1; uSeqIndex2 < uSeqCount; ++uSeqIndex2)
            {
            const char *pstrName2 = msaIn.GetSeqName(uSeqIndex2);
            Seq seq2;
            msaIn.GetSeq(uSeqIndex2, seq2);
            const unsigned uLength2 = seq2.Length();

            double dPWID;
            unsigned uPosCount;
            msaIn.GetPWID(uSeqIndex1, uSeqIndex2, &dPWID, &uPosCount);

            List("File=%s;Seq1=%s;Seq2=%s;PWID=%.1f;LengthAln=%u;Length1=%u;Length2=%u\n",
              szStem, pstrName1, pstrName2, dPWID, uPosCount, uLength1, uLength2);

            printf("File=%s;Seq1=%s;Seq2=%s;PWID=%.1f;LengthAln=%u;Length1=%u;Length2=%u\n",
              szStem, pstrName1, pstrName2, dPWID, uPosCount, uLength1, uLength2);
            }
        }
    }
