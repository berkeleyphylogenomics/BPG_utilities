// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"

static unsigned uParamCount;
static unsigned uCommandCount;
static char *CommandNames[128];
static bool CommandHasInArg[128];
static char *ParamNames[128];
static char *ParamValues[128];
static bool IsFlag[128];
static unsigned uMaxParam = sizeof(ParamNames)/sizeof(ParamNames[0]);
char *strCommandName;
char *strInArg;

void Usage()
    {
    printf("Detailed Usage: lobster -commands\n");
    }

static void OnExit()
    {
    return;
    free(strInArg);
    free(strCommandName);
    for (unsigned i = 0; i < uCommandCount; ++i)
        free(CommandNames[i]);

    for (unsigned i = 0; i < uParamCount; ++i)
        {
        free(ParamNames[i]);
        free(ParamValues[i]);
        }
    }

static void Init()
    {
    atexit(OnExit);
    // printf ("uMaxPara %i\n", uMaxParam); 
    for (unsigned i = 0; i < uMaxParam; ++i)
        IsFlag[i] = false;
    InitCmd();
    }

void DefCommand(const char *name, bool bHasInArg)
    {
    if (uParamCount >= uMaxParam)
        Fatal("DefCommand: too many commands");
    CommandNames[uCommandCount] = strdup(name);
    if (bHasInArg)
        CommandHasInArg[uCommandCount] = true;
    ++uCommandCount;
    }

void DefParam(const char *name)
    {
    if (uParamCount >= uMaxParam)
        Fatal("DefOption: too many options");
    ParamNames[uParamCount] = strdup(name);
    ++uParamCount;
    }

void DefOption(const char *opt)
    {
    if (uParamCount >= uMaxParam)
        Fatal("DefOption: too many options");
    ParamNames[uParamCount] = strdup(opt);
    ++uParamCount;
    }

void DefFlag(const char *opt)
    {
    if (uParamCount >= uMaxParam)
        Fatal("DefFlag: too many options");
    ParamNames[uParamCount] = strdup(opt);
    IsFlag[uParamCount] = true;
    ++uParamCount;
    }

void DefDefaultedOption(const char *opt, const char *def)
    {
    if (uParamCount >= uMaxParam)
        Fatal("DefDefaultedOption: too many options");
    ParamNames[uParamCount] = strdup(opt);
    ParamValues[uParamCount] = strdup(def);
    ++uParamCount;
    }

bool CmdNameIs(const char *name)
    {
    return 0 == stricmp(name, strCommandName);
    }

static bool FindParam(const char *name, unsigned *ptruIndex)
    {
    for (unsigned i = 0; i < uParamCount; ++i)
        if (!stricmp(name, ParamNames[i]))
            {
            *ptruIndex = i;
            return true;
            }
    return false;
    }

bool GetFlag(const char *name)
    {
    unsigned uIndex;
    bool bFound = FindParam(name, &uIndex);
    if (!bFound)
        Fatal("'%s' is not a flag parameter", name);
    const char *strValue = ParamValues[uIndex];
    if (0 == strValue)
        return false;
    return 0 == stricmp(strValue, "yes");
    }

const char *GetParam(const char *name)
    {
    unsigned uIndex;
    bool bFound = FindParam(name, &uIndex);
    if (!bFound)
        CmdLineError("Required parameter '%s' not specified", name);
    const char *value = ParamValues[uIndex];
    if (0 == value)
        CmdLineError("Required parameter '%s' not specified", name);
    return value;
    }

const char *GetInArg()
    {
    if (0 == strInArg)
        CmdLineError("Command requires argument");
    return strInArg;
    }

const char *GetOptionalParam(const char *name)
    {
    unsigned uIndex;
    bool bFound = FindParam(name, &uIndex);
    if (!bFound)
        return 0;
    return ParamValues[uIndex];
    }

const char *GetOptionalParam(const char *name, const char *def)
    {
    const char *p = GetOptionalParam(name);
    return p ? p : def;
    }

static bool IsCommand(const char *name, unsigned *puIndex)
    {
    for (unsigned i = 0; i < uCommandCount; ++i)
        if (!stricmp(name, CommandNames[i]))
            {
            *puIndex = i;
            return true;
            }
    return false;
    }

static unsigned uArgCount;
static char **ArgValues;

static void SaveCommandArgs(int argc, char *argv[])
    {
    uArgCount = argc;
    ArgValues = argv;
    }

static const char *GetCmdLineArg(unsigned uArgIndex)
    {
    if (uArgIndex >= uArgCount)
        return 0;
    return ArgValues[uArgIndex];
    }

void ExecCommandLine(int argc, char *argv[])
    {
    Init();
    SaveCommandArgs(argc, argv);

    unsigned uArgIndex = 1;
    const char *strCommand = GetCmdLineArg(uArgIndex++);
    if (0 == strCommand || 0 == strcmp(strCommand, "-?") ||
      0 == strcmp(strCommand, "/?") || 0 == stricmp(strCommand, "-help") ||
      0 == stricmp(strCommand, "--help"))
        {
        Usage();
        exit(0);
        }

    ++strCommand;
    unsigned uCommandIndex;
    if (!IsCommand(strCommand, &uCommandIndex))
        CmdLineError("'%s' is not a Lobster command", strCommand);
    strCommandName = strdup(strCommand);

    if (CommandHasInArg[uCommandIndex])
        {
        const char *strArg = GetCmdLineArg(uArgIndex++);
        if (0 == strArg)
            CmdLineError("Command requires argument");
        strInArg = strdup(strArg);
        }

    for (;;)
        {
        const char *strArg = GetCmdLineArg(uArgIndex++);
        if (0 == strArg)
            break;
        if (strArg[0] != '-')
            CmdLineError("Invalid command line arg '%s', missing '-'", strArg);
        unsigned uParamIndex;
        bool bFound = FindParam(strArg+1, &uParamIndex);
        if (!bFound)
            CmdLineError("Invalid command line arg '%s'", strArg);
        if (IsFlag[uParamIndex])
            {
            ParamValues[uParamIndex] = strdup("yes");
            continue;
            }
        const char *strValue = GetCmdLineArg(uArgIndex++);
        if (0 == strValue)
            CmdLineError("Missing value for parameter '%s'", strArg);
        ParamValues[uParamIndex] = strdup(strValue);
        }

    SetLogFile();
    List("Lobster started %s ", GetTimeAsStr());
    for (int i = 0; i < argc; ++i)
        List(" %s", argv[i]);
    List("\n");
    SetGlobalFlags();
    SetGlobalOptions();
    //extern void TestYL();
    //TestYL();
    //exit(0);
    DoCmd(); 
    List("Lobster finished %s\n", GetTimeAsStr());
    }
