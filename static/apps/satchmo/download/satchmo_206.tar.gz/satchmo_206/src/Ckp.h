// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    Ckp_h
#define    Ckp_h

class DataBuffer;
class TextFile;

// Indexes to amino acid alphabet as used in PSI-BLAST
// See NCBI tool source code, posit.c(2067).
   //charOrder[0] =  1;  /*A*/
   //charOrder[1] =  16; /*R*/
   //charOrder[2] =  13; /*N*/  
   //charOrder[3] =  4;  /*D*/ 
   //charOrder[4] =  3;  /*C*/
   //charOrder[5] =  15; /*Q*/
   //charOrder[6] =  5; /*E*/ 
   //charOrder[7] =  7;  /*G*/
   //charOrder[8] =  8;  /*H*/
   //charOrder[9] =  9;  /*I*/
   //charOrder[10] = 11; /*L*/
   //charOrder[11] = 10; /*K*/
   //charOrder[12] = 12; /*M*/  
   //charOrder[13] =  6; /*F*/
   //charOrder[14] = 14; /*P*/
   //charOrder[15] = 17; /*S*/
   //charOrder[16] = 18; /*T*/
   //charOrder[17] = 20; /*W*/
   //charOrder[18] = 22; /*Y*/
   //charOrder[19] = 19; /*V*/
enum
    {
    PBA_A = 0,
    PBA_C = 4,
    PBA_D = 3,
    PBA_E = 6,
    PBA_F = 13,
    PBA_G = 7,
    PBA_H = 8,
    PBA_I = 9,
    PBA_K = 11,
    PBA_L = 10,
    PBA_M = 12,
    PBA_N = 2,
    PBA_P = 14,
    PBA_Q = 5,
    PBA_R = 1,
    PBA_S = 15,
    PBA_T = 16,
    PBA_V = 19,
    PBA_W = 17,
    PBA_Y = 18
    };

struct CkpPos
    {
    double dFreq[MAX_ALPHA];
    };

class Ckp    // PSI-BLAST profile
    {
public:
    Ckp();
    virtual ~Ckp();

    void Clear();
    void SetSize(unsigned uPosCount);
    CkpPos &GetPos(unsigned uPosIndex) const;
    void ListMe() const;
    void FromBuffer(DataBuffer &Data);
    void ToBuffer(DataBuffer &Data) const;
    const unsigned GetPosCount() const { return m_uPosCount; }
    const char *GetQuery() const { return m_pstrQuery; }
    void ToCkt(TextFile &File) const;
    void FromCkt(TextFile &File);
    unsigned GetBufferSize() const;

    static void CkpOrderToAlpha(const double dPBFreq[], double dAlphaFreq[]);
    static void AlphaToCkpOrder(const double dAlphaFreq[], double dPBFreq[]);

private:
    unsigned m_uPosCount;
    char *m_pstrQuery;
    CkpPos *m_Pos;
    };

#endif    // Ckp_h
