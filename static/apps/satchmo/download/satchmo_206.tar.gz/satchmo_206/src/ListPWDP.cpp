// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"

// Macros to simulate 2D matrices
#define DPM(PLA, PLB)    DPM_[(PLA)*uPrefixCountB + (PLB)]
#define DPD(PLA, PLB)    DPD_[(PLA)*uPrefixCountB + (PLB)]
#define DPI(PLA, PLB)    DPI_[(PLA)*uPrefixCountB + (PLB)]
#define TBM(PLA, PLB)    TBM_[(PLA)*uPrefixCountB + (PLB)]
#define TBD(PLA, PLB)    TBD_[(PLA)*uPrefixCountB + (PLB)]
#define TBI(PLA, PLB)    TBI_[(PLA)*uPrefixCountB + (PLB)]

void ListPWDP(const SCORE *DPM_, const SCORE *DPD_, const SCORE *DPI_, const char *TBM_,
  const char *TBD_, const char *TBI_, unsigned uPrefixCountA, unsigned uPrefixCountB)
    {
    List("PLB      ");
    for (unsigned uPrefixLengthB = 0; uPrefixLengthB < uPrefixCountB; ++uPrefixLengthB)
        List(" %8u", uPrefixLengthB);
    List("\n");
    List("M[]\n");
    for (unsigned uPrefixLengthA = 0; uPrefixLengthA < uPrefixCountA; ++uPrefixLengthA)
        {
        List("PLA  %u:  ", uPrefixLengthA);
        for (unsigned uPrefixLengthB = 0; uPrefixLengthB < uPrefixCountB; ++uPrefixLengthB)
            List(" %s", ScoreToStr(DPM(uPrefixLengthA, uPrefixLengthB)));
        List("\n");
        }
    List("D[]\n");
    for (unsigned uPrefixLengthA = 0; uPrefixLengthA < uPrefixCountA; ++uPrefixLengthA)
        {
        List("PLA  %u:  ", uPrefixLengthA);
        for (unsigned uPrefixLengthB = 0; uPrefixLengthB < uPrefixCountB; ++uPrefixLengthB)
            List(" %s", ScoreToStr(DPD(uPrefixLengthA, uPrefixLengthB)));
        List("\n");
        }
    List("I[]\n");
    for (unsigned uPrefixLengthA = 0; uPrefixLengthA < uPrefixCountA; ++uPrefixLengthA)
        {
        List("PLA  %u:  ", uPrefixLengthA);
        for (unsigned uPrefixLengthB = 0; uPrefixLengthB < uPrefixCountB; ++uPrefixLengthB)
            List(" %s", ScoreToStr(DPI(uPrefixLengthA, uPrefixLengthB)));
        List("\n");
        }
    List("\n");
    List("PLB      ");
    for (unsigned uPrefixLengthB = 0; uPrefixLengthB < uPrefixCountB; ++uPrefixLengthB)
        List(" %8u", uPrefixLengthB);
    List("\n");
    List("M[]\n");
    for (unsigned uPrefixLengthA = 0; uPrefixLengthA < uPrefixCountA; ++uPrefixLengthA)
        {
        List("PLA  %u:  ", uPrefixLengthA);
        for (unsigned uPrefixLengthB = 0; uPrefixLengthB < uPrefixCountB; ++uPrefixLengthB)
            List(" %8c", TBM(uPrefixLengthA, uPrefixLengthB));
        List("\n");
        }
    List("D[]\n");
    for (unsigned uPrefixLengthA = 0; uPrefixLengthA < uPrefixCountA; ++uPrefixLengthA)
        {
        List("PLA  %u:  ", uPrefixLengthA);
        for (unsigned uPrefixLengthB = 0; uPrefixLengthB < uPrefixCountB; ++uPrefixLengthB)
            List(" %8c", TBD(uPrefixLengthA, uPrefixLengthB));
        List("\n");
        }
    List("I[]\n");
    for (unsigned uPrefixLengthA = 0; uPrefixLengthA < uPrefixCountA; ++uPrefixLengthA)
        {
        List("PLA  %u:  ", uPrefixLengthA);
        for (unsigned uPrefixLengthB = 0; uPrefixLengthB < uPrefixCountB; ++uPrefixLengthB)
            List(" %8c", TBI(uPrefixLengthA, uPrefixLengthB));
        List("\n");
        }
    }
