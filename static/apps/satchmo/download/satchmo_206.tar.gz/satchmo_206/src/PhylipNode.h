// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    PhylipNode_h
#define    PhylipNode_h

class Phylip;

class PhylipNode
    {
public:
    PhylipNode(unsigned uIndex, const Phylip *ptrTree)
        {
        m_uIndex = uIndex;
        m_ptrTree = ptrTree;

        m_ptrLeft = 0;
        m_ptrRight = 0;
        m_ptrParent = 0;
        m_ptrName = 0;
        m_uClass = uInsane;
        m_uCounts = 0;
        m_dLength = g_dNAN;
        m_bHasLength = false;
        }
    virtual ~PhylipNode() { delete[] m_uCounts; }

    void SetLength(double dLength) { m_dLength = dLength; m_bHasLength = true; }
    void SetLeft(PhylipNode *ptrNode) { m_ptrLeft = ptrNode; }
    void SetRight(PhylipNode *ptrNode) { m_ptrRight = ptrNode; }
    void SetParent(PhylipNode *ptrNode) { m_ptrParent = ptrNode; }
    void SetClass(unsigned uClass) { m_uClass = uClass; }
    void SetName(const char *ptrName)
        {
        free(m_ptrName);
        if (0 == ptrName)
            m_ptrName = 0;
        else
            m_ptrName = strdup(ptrName);
        }

    unsigned GetIndex() const { return m_uIndex; }
    PhylipNode *GetLeft() const { return m_ptrLeft; }
    PhylipNode *GetRight() const { return m_ptrRight; }
    PhylipNode *GetParent() const { return m_ptrParent; }
    PhylipNode *GetUnrootedParent() const;
    unsigned GetClass() const { return m_uClass; }
    const char *GetName() const { return m_ptrName; }
    double GetLength() const { return m_dLength; }
    bool HasLength() const { return m_bHasLength; }
    void ClearLength() { m_bHasLength = false; m_dLength = g_dNAN; }

    void Validate() const;

    void AllocCounts(unsigned uClassCount)
        {
        delete[] m_uCounts;
        m_uCounts = new unsigned[uClassCount];
        memset(m_uCounts, 0, uClassCount*sizeof(uClassCount));
        m_uClassCount = uClassCount;
        }

    void CalcCounts();
    const unsigned *GetCounts() const { return m_uCounts; }
    unsigned GetCount(unsigned uClass) const;

    bool IsLeaf() const { return 0 == m_ptrLeft; }
    bool IsRoot() const { return 0 == m_ptrParent; }
    bool IsRightChild() const;
    bool IsLeftChild() const;

    unsigned GetFalseNegCount(unsigned uClass) const;
    unsigned GetFalsePosCount(unsigned uClass) const;
    unsigned GetFalsePosCount() const { return GetFalsePosCount(m_uClass); }
    unsigned GetFalseNegCount() const { return GetFalseNegCount(m_uClass); }

    bool IsZFN(unsigned uClass) const;

    bool IsNFP(unsigned N) const;
    bool IsNFP(unsigned uClass, unsigned N) const;

    void ListMe() const;

private:
    unsigned m_uIndex;
    PhylipNode *m_ptrLeft;
    PhylipNode *m_ptrRight;
    PhylipNode *m_ptrParent;
    const Phylip *m_ptrTree;
    unsigned m_uClass;
    char *m_ptrName;
    unsigned *m_uCounts;
    unsigned m_uClassCount;
    unsigned m_uMajorityClassIndex;
    double m_dLength;
    bool m_bHasLength;
    };

#endif    // PhylipNode_h
