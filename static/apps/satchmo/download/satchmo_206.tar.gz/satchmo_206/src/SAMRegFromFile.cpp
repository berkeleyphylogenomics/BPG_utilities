// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "TransPrior.h"

void SAMRegFromFile(TextFile &File, double dAlphas[9])
    {
    char szToken[1024];

// REGULARLIZER <anything> <end-of-line>
    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 != stricmp(szToken, "REGULARIZER:"))
        Quit("Invalid SAM regularizer (REGULARIZER)");
    File.SkipLine();

// alphabet protein
    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 != stricmp(szToken, "alphabet"))
        Quit("Invalid SAM regularizer (alphabet)");

    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 != stricmp(szToken, "protein"))
        Quit("Invalid SAM regularizer (protein)");

    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 != stricmp(szToken, "GENERIC"))
        Quit("Invalid SAM regularizer (protein)");

    double dSAMAlphas[9];
    for (unsigned n = 0; n < 9; ++n)
        {
        File.GetTokenXC(szToken, sizeof(szToken));
        double d = atof(szToken);
        dSAMAlphas[n] = d;
        }

// Discard match and insert probabilities
    for (unsigned n = 0; n < 40; ++n)
        File.GetTokenXC(szToken, sizeof(szToken));

    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 != stricmp(szToken, "ENDMODEL"))
        Quit("Invalid SAM regularizer (ENDMODEL)");

    dAlphas[TP_MM] = dSAMAlphas[SAMREG_MM];
    dAlphas[TP_MD] = dSAMAlphas[SAMREG_MD];
    dAlphas[TP_MI] = dSAMAlphas[SAMREG_MI];

    dAlphas[TP_DM] = dSAMAlphas[SAMREG_DM];
    dAlphas[TP_DD] = dSAMAlphas[SAMREG_DD];
    dAlphas[TP_DI] = dSAMAlphas[SAMREG_DI];

    dAlphas[TP_IM] = dSAMAlphas[SAMREG_IM];
    dAlphas[TP_ID] = dSAMAlphas[SAMREG_ID];
    dAlphas[TP_II] = dSAMAlphas[SAMREG_II];
    }
