// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.



#ifdef PARALLEL
#include "mpi.h"
#endif

#include <time.h>
#include <stdio.h>
#include "lobster.h"

long g_tStart = (long) time(0);

#ifdef PARALLEL
//MPI Global
int g_numprocs=1;
int g_my_rank=0;
char *g_processor_name="localhost";
#endif

int main(int argc, char *argv[])
    {

int namelen;
#ifdef PARALLEL
g_processor_name = (char *) malloc(sizeof(char)*MPI_MAX_PROCESSOR_NAME);
MPI::Init(argc, argv);
g_numprocs = MPI::COMM_WORLD.Get_size();
g_my_rank = MPI::COMM_WORLD.Get_rank();
MPI_Get_processor_name(g_processor_name, &namelen);

if(g_my_rank == 0){
//#endif    
    fprintf(stdout, "Lobster (C) Copyright 2002-2003 Robert C. Edgar\n");
//#ifdef PARALLEL    
    fprintf(stdout, "Parallel Edition - mtung(BPG)\n");
}
#endif
#if    TRU64
    {
    extern void SetNewHandler();
    SetNewHandler();
    }
#endif

    ExecCommandLine(argc, argv);



    return 0;
    }
