// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

class DistFunc
    {
public:
    DistFunc();
    virtual ~DistFunc();

public:
    virtual void SetCount(unsigned uCount);
    virtual void SetDist(unsigned uIndex1, unsigned uIndex2, double dDist);

    virtual double GetDist(unsigned uIndex1, unsigned uIndex2) const;
    virtual unsigned GetCount() const;

protected:
    unsigned VectorIndex(unsigned uIndex, unsigned uIndex2) const;
    unsigned VectorLength() const;

private:
    unsigned m_uCount;
    unsigned m_uCacheCount;
    double *m_Dists;
    };
