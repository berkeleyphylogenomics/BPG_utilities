// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWYLF.h"
#include "PWYL.h"

SCORE PWYLF::YLFScore(const FCOUNT fcCountsA[MAX_ALPHA],
  const FCOUNT fcCountsB[MAX_ALPHA])
    {
    PROB p[MAX_ALPHA];
    PROB q[MAX_ALPHA];

    for (int n = 0; n < MAX_ALPHA; ++n)
        {
        p[n] = (PROB) fcCountsA[n];
        q[n] = (PROB) fcCountsB[n];
        }
    return (SCORE) (PWYL::YLScore(p, q) + 0.1);
    }
