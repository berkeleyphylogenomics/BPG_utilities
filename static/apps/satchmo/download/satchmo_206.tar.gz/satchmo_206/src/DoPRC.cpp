// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWPRC.h"
#include "HMM.h"
#include "MSA.h"
#include "PWPath.h"
#include "TextFile.h"

void DoPRC(const char *hmm1, const char *hmm2, const char *tpl1, const char *tpl2,
  const char *out, const char *bounds)
    {
    const BOUNDS BoundsA = LOCAL;
    const BOUNDS BoundsB = LOCAL;
    const char *strHMMFileA = hmm1;
    const char *strHMMFileB = hmm2;
    const char *strTplFileA = tpl1;
    const char *strTplFileB = tpl2;
    const char *strOutputFastaFile = out;

    TextFile FileTA(strTplFileA);
    MSA msaA;
    msaA.FromFASTAFile(FileTA);
    msaA.AlignByCase();
    msaA.BuildPillars();
    
    TextFile FileTB(strTplFileB);
    MSA msaB;
    msaB.FromFASTAFile(FileTB);
    msaB.AlignByCase();
    msaB.BuildPillars();

    TextFile HMMFileA(strHMMFileA);
    HMM hmmA;
    hmmA.FromFile(HMMFileA);
    hmmA.SetTemplate(msaA);

    TextFile HMMFileB(strHMMFileB);
    HMM hmmB;
    hmmB.FromFile(HMMFileB);
    hmmB.SetTemplate(msaB);

    PWPRC PWS;
    PWS.Init(hmmA, BoundsA, hmmB, BoundsB);

    PWPath Path;
    PWAlign(PWS, Path);
    Path.ListMe();

    MSA msaCombined;
    AlignHMMs(hmmA, hmmB, Path, msaCombined);

    TextFile OutFile(strOutputFastaFile, true);
//    msaCombined.ListMe();
    msaCombined.ToFASTAFile(OutFile);
    }
