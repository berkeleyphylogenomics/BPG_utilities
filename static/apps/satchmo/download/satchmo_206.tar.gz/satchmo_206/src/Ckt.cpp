// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Ckp.h"
#include "TextFile.h"

void Ckp::ToCkt(TextFile &File) const
    {
    const unsigned uPosCount = GetPosCount();
    File.PutString("CKT\n");
    File.PutFormat("length %u\n", uPosCount);
    File.PutFormat("query\n");
    const unsigned uBlockCount = (uPosCount + 79)/80;
    for (unsigned uBlock = 0; uBlock < uBlockCount; ++uBlock)
        {
        unsigned uLetters = m_uPosCount - uBlock*80;
        if (uLetters > 80)
            uLetters = 80;
        for (unsigned uLetter = 0; uLetter < uLetters; ++uLetter)
            File.PutFormat("%c", m_pstrQuery[uBlock*80 + uLetter]);
        File.PutFormat("\n");
        }
    File.PutFormat("//\n\n");
    File.PutString("% Pos");
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        File.PutFormat("      %c", LetterToCharAmino(n));
    File.PutString("\n");
    for (unsigned uPosIndex = 0; uPosIndex < uPosCount; ++uPosIndex)
        {
        const CkpPos &CP = GetPos(uPosIndex);
        File.PutFormat("%5u", uPosIndex);
        for (unsigned n = 0; n < MAX_ALPHA; ++n)
            File.PutFormat(" %6.4f", CP.dFreq[n]);
        File.PutFormat("\n");
        }
    File.PutString("//\n");
    }

void Ckp::FromCkt(TextFile &File)
    {
    char szToken[1024];

    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 != stricmp(szToken, "CKT"))
        Quit("Invalid .ckt file (CKT)");

    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 != stricmp(szToken, "length"))
        Quit("Invalid .ckt file (length)");

    File.GetTokenXC(szToken, sizeof(szToken));
    const unsigned uPosCount = (unsigned) atoi(szToken);
    if (!IsValidInteger(szToken) || 0 == uPosCount)
        Quit("Invalid length '%s' in .ckt file", szToken);

    SetSize(uPosCount);

    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 != stricmp(szToken, "query"))
        Quit("Invalid .ckt file (query)");

    m_pstrQuery[0] = 0;
    const unsigned uBlockCount = (uPosCount + 79)/80;
    for (unsigned uBlock = 0; uBlock < uBlockCount; ++uBlock)
        {
        unsigned uLetters = m_uPosCount - uBlock*80;
        if (uLetters > 80)
            uLetters = 80;
        File.GetTokenXC(szToken, sizeof(szToken));
        const unsigned uBlockLength = (unsigned) strlen(szToken);
        if (uBlockLength != uLetters)
            Quit("Invalid .ckt file (block '%s' %u,%u)", szToken, uLetters, uBlockLength);
        strcat(m_pstrQuery, szToken);
        }

    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 != stricmp(szToken, "//"))
        Quit("Invalid .ckt file (// end query)");

    for (unsigned uPosIndex = 0; uPosIndex < uPosCount; ++uPosIndex)
        {
        File.GetTokenXC(szToken, sizeof(szToken));
        if (!IsValidInteger(szToken))
            Quit("Invalid .ckt file, expecting pos, got '%s'", szToken);
        const unsigned uPos = (unsigned) atoi(szToken);
        if (uPos != uPosIndex)
            Quit("Invalid .ckt file, pos %u %u", uPos, uPosIndex);
        CkpPos &CP = m_Pos[uPosIndex];

        for (unsigned n = 0; n < MAX_ALPHA; ++n)
            {
            File.GetTokenXC(szToken, sizeof(szToken));
            CP.dFreq[n] = atof(szToken);
            }
//        AssertNormalized(CP.dFreq);
        }

    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 != stricmp(szToken, "//"))
        Quit("Invalid .ckt file (// end file)");
    }
