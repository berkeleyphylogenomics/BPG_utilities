// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Bete.h"
#include "DirMix.h"
#include "Clust.h"
#include "MSA.h"

#define VERBOSE            1
#define VERY_VERBOSE    0

extern DirMix *g_ptrdirmixMatchEmitPrior;
extern SCORE LogProbCountsGivenMix(const DirMix *ptrMix, const double dCounts[]);

struct ClusterInfo
    {
    unsigned uSeqCount;
    unsigned *uSeqIndexes;
    };

static void ListCounts(const double dCounts[])
    {
    bool bAny = false;
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        {
        const double d = dCounts[n];
        if (0 == d)
            continue;
        bAny = true;
        List(" %c=%g", LetterToCharAmino(n), d);
        }
    if (!bAny)
        List(" (all zero)");
    }

static void ListCol(const MSA &msa, unsigned uColIndex, const ClusterInfo *Info,
  unsigned uClusterCount)
    {
    for (unsigned n = 0; n < uClusterCount; ++n)
        {
        const ClusterInfo &CI = Info[n];
        const unsigned uSeqCount = CI.uSeqCount;
        for (unsigned i = 0; i < uSeqCount; ++i)
            {
            const unsigned uSeqIndex = CI.uSeqIndexes[i];
            List("%c", msa.GetChar(uSeqIndex, uColIndex));
            }
        if (n != uClusterCount - 1)
            List(" | ");
        }
    }

void Bete::FreeClusterInfo(ClusterInfo *Info, unsigned uClusterCount)
    {
    for (unsigned n = 0; n < uClusterCount; ++n)
        {
        ClusterInfo *ptrCI = &Info[n];
        delete ptrCI->uSeqIndexes;
        }
    delete[] Info;
    }

ClusterInfo *Bete::BuildClusterInfo(const Clust &C)
    {
    const unsigned uSeqCount = m_ptrMSA->GetSeqCount();
    const unsigned uColCount = m_ptrMSA->GetColCount();

// Construct a convenient representation of the partition
// defined by the current state of the cluster.
    const unsigned uClusterCount = C.GetClusterCount();

// bSeqSeen[] used for assertions only
    bool *bSeqSeen = new bool[uSeqCount];
    for (unsigned n = 0; n < uSeqCount; ++n)
        bSeqSeen[n] = false;

    ClusterInfo *Info = new ClusterInfo[uClusterCount];

    unsigned uTotalSeqCount = 0;
    for (unsigned uClusterIndex = 0; uClusterIndex < uClusterCount;
      ++uClusterIndex)
        {
        ClusterInfo &CI = Info[uClusterIndex];
        const unsigned uClusterNodeIndex = C.GetNodeIndex(uClusterIndex);
        const unsigned uClusterSeqCount = C.GetClusterSize(uClusterNodeIndex);
        if (uClusterSeqCount == 0 || uClusterSeqCount > uSeqCount)
            Quit("Bete::BuildClusterInfo, internal error, cluster seq count");
        uTotalSeqCount += uClusterSeqCount;

        CI.uSeqIndexes = new unsigned[uClusterSeqCount];
        CI.uSeqCount = uClusterSeqCount;
        
        for (unsigned n = 0; n < uClusterSeqCount; ++n)
            {
            unsigned uSeqIndex = C.GetLeaf(uClusterNodeIndex, n);
            CI.uSeqIndexes[n] = uSeqIndex;

        // Assertion
            if (bSeqSeen[uSeqIndex])
                Quit("Bete::BuildClusterInfo, internal error, seq seen");
            bSeqSeen[uSeqIndex] = true;
            }
        }

    if (uTotalSeqCount != uSeqCount)
        Quit("Bete::BuildClusterInfo, internal error, seq count");
    return Info;
    }

// Compute log-probability of alignment under
// subfamily model given Dirichlet mixture.
double Bete::LogProb(const Clust &C)
    {
    const unsigned uColCount = m_ptrMSA->GetColCount();
    const unsigned uSeqCount = m_ptrMSA->GetSeqCount();
    const unsigned uClusterCount = C.GetClusterCount();

    ClusterInfo *Info = BuildClusterInfo(C);

    double *dSeqWeights = new double[uSeqCount];
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
// ******* TODO ********??
        dSeqWeights[uSeqIndex] = m_ptrMSA->GetSeqWeight(uSeqIndex)*m_wcNIC;

    double dLogProbTotal = 0;
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        if (!m_ptrMSA->IsAligned(uColIndex))
            continue;

        double dCounts[MAX_ALPHA];

        GetCountsAll(uColIndex, dSeqWeights, dCounts);
        const double dLogProbFamily = LogProbCounts(dCounts);

#if    VERY_VERBOSE
        List("All: ");
        ListCounts(dCounts);
        List("  Log prob=%g\n", dLogProbFamily);
#endif

        double dLogProbSubfamilies = 0;
        for (unsigned uClusterIndex = 0; uClusterIndex < uClusterCount; ++uClusterIndex)
            {
            const ClusterInfo &CI = Info[uClusterIndex];
            GetClusterCountsCol(uColIndex, CI, dSeqWeights, dCounts);
            const double dLogProbSubfamily = LogProbCounts(dCounts);
            dLogProbSubfamilies += dLogProbSubfamily;

#if    VERY_VERBOSE
            List("Subfam: ");
            ListCounts(dCounts);
            List("  Log prob=%g\n", dLogProbSubfamily);
#endif
            }
#if VERBOSE
        ListCol(*m_ptrMSA, uColIndex, Info, uClusterCount);
        char f;
        if (dLogProbFamily > dLogProbSubfamilies)
            f = 'f';
        else
            f = 'S';
        List("    %c  %12.6g  %12.6g\n", f, dLogProbFamily, dLogProbSubfamilies);
#endif
        if (dLogProbFamily >= dLogProbSubfamilies)
            dLogProbTotal += dLogProbFamily;
        else
            dLogProbTotal += dLogProbSubfamilies;
        }

#if VERBOSE
    List("Total log prob %g\n", dLogProbTotal);
#endif

    FreeClusterInfo(Info, uClusterCount);
    return dLogProbTotal;
    }

void Bete::GetClusterCountsCol(unsigned uColIndex, const ClusterInfo &CI,
  const double dSeqWeights[], double dCounts[])
    {
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        dCounts[uLetter] = 0;

    const unsigned uClusterSeqCount = CI.uSeqCount;
    for (unsigned n = 0; n < uClusterSeqCount; ++n)
        {
        const unsigned uSeqIndex = CI.uSeqIndexes[n];
        if (m_ptrMSA->IsGap(uSeqIndex, uColIndex))
            continue;
        const double dWeight = dSeqWeights[uSeqIndex];
        const unsigned uLetter = m_ptrMSA->GetLetter(uSeqIndex, uColIndex);
        dCounts[uLetter] += dWeight;
        }
    }

void Bete::GetCountsAll(unsigned uColIndex, const double dSeqWeights[],
  double dCounts[])
    {
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        dCounts[uLetter] = 0;

    const unsigned uSeqCount = m_ptrMSA->GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        if (m_ptrMSA->IsGap(uSeqIndex, uColIndex))
            continue;
        const double dWeight = dSeqWeights[uSeqIndex];
        const unsigned uLetter = m_ptrMSA->GetLetter(uSeqIndex, uColIndex);
        dCounts[uLetter] += dWeight;
        }
    }

double Bete::LogProbCounts(const double dCounts[])
    {
    return LogProbCountsGivenMix(g_ptrdirmixMatchEmitPrior, dCounts);
    }
