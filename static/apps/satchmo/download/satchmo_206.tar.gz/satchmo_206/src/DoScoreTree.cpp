// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Phylip.h"
#include "PhylipNode.h"
#include "TextFile.h"

#define    VERBOSE    0

void DoScoreTree(const char *strFileName)
    {
    TextFile File(strFileName);
    Phylip Tree;
    Tree.FromFile(File);
    Tree.AllocCounts();
    Tree.CalcCounts();

#if    VERBOSE
    Tree.ListMe();
    List("\n\n");

    List("\n\nListNFP(0)\n");
    Tree.ListNFPSubtrees(Tree.GetRoot(), 0);

    List("\n\nListNFP(1)\n");
    Tree.ListNFPSubtrees(Tree.GetRoot(), 1);

    List("\n\nListNFN(0)\n");
    Tree.ListZFNSubtrees();
#endif    // VERBOSE

    const unsigned FP0 = Tree.GetNFPCount(0);
    const unsigned FP1 = Tree.GetNFPCount(1);
    const unsigned uNEClassCount = Tree.GetNonEmptyClassCount();
    const unsigned uSingletonCount = Tree.GetSingletonClassCount();
    const double FP0Score = (double) (uNEClassCount - uSingletonCount)/
      (double) (FP0 - uSingletonCount);
    const double FP1Score = (double) (uNEClassCount - uSingletonCount)/
      (double) (FP1 - uSingletonCount);
    const double MMSScore = (double) uNEClassCount / (double) FP0;
    const double dPARScore = Tree.GetPARScore();
    List("tree=%s rooted=%s classes=%u singletons=%u PAR=%.3g 0FP=%u 1FP=%u 0FPScore=%.3g 1FPScore=%.3g MMS=%.3g\n",
      strFileName,
      Tree.IsRooted() ? "yes" : "no",
      uNEClassCount,
      uSingletonCount,
      dPARScore,
      FP0,
      FP1,
      FP0Score,
      FP1Score,
      MMSScore);
    printf("tree=%s rooted=%s classes=%u singletons=%u PAR=%.3g 0FP=%u 1FP=%u 0FPScore=%.3g 1FPScore=%.3g MMS=%.3g\n",
      strFileName,
      Tree.IsRooted() ? "yes" : "no",
      uNEClassCount,
      uSingletonCount,
      dPARScore,
      FP0,
      FP1,
      FP0Score,
      FP1Score,
      MMSScore);
    }
