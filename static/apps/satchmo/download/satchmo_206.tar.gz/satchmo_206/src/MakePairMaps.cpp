// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "Seq.h"

/***
A pair map is a useful representation of a pair-wise alignment.

Consider this alignment:

A>  M Q T - F
B>  M - T I F

Let the (ungapped) index into sequence A be j and the index into 
sequence B be k. We can show indexes instead of letters, like this:

A>  0 1 2 - 3
B>  0 - 1 2 3

The map from A to B is the vector:

AB = { 0, -1, 1, 3 }

and the map from B to A is the vector

BA = { 0, 2, -1, 3 }

AB[j] is the index into sequence B of the letter aligned to A[j], or -1
if there is a gap. Similarly, BA[k] is the index into A of the letter
aligned to B[k], or -1 if there is a gap.

Now consider the problem of comparing two alignments where there may be
two slightly different versions of each sequence.

Test alignment:
AT>  M Q T - F
BT>  M - T I F

Reference alignment:
AR> V M Q T F C
BR> M Q - T F C

Here, AT and BT are the versions of the seqences appearing in the test 
alignment, and AR and BR the versions in the reference alignment. We are
given the "version alignments" of both A and B, and use lower-case to
distinguish the reference version of the sequence:

AT>  - M Q T F -
AR>  v m q t f c

BT>  M - T I F -
BR>  m q t - f c

Using these alignments, we construct a multiple sequence alignment C
that keeps the "version alignments" and the test alignment intact:

AT>  - M Q T - F -
AR>  v m q t - f c

BR>  - m q t - f c
BT>  - M - T I F -

This defines an alignment between AR and BR that we can then compare
directly against the reference alignment.

Note that the pair map between two sequences does not change if you
add a gap to the same position in both sequences. Hence the pair maps
for the test and reference alignments also apply to C.

Now consider a column in C with no gaps:

    AT>        AT[i]
    AR>        AR[j]
    BR>        BR[k]
    BT>        BT[l]

Repeatedly using the definition of a pair map,

    ARBR[j] = k
            = BTBR[l]
            = BTBR[ATBT[i]]
            = BTBR[ATBT[ARAT[j]]]

This gives a fast and simple computation of the pair map between AR and BR
defined by the two version alignments and the combined alignment C.
***/

void MakePairMaps(const MSA &msaTest, unsigned uTestSeqIndexA, unsigned uTestSeqIndexB,
  const MSA &msaRef, unsigned uRefSeqIndexA, unsigned uRefSeqIndexB, int **ptriTestMapAr,
  int **ptriTestMapBr, int **ptriRefMapAr, int **ptriRefMapBr)
    {
    const int iLengthAt = (int) msaTest.GetSeqLength(uTestSeqIndexA);
    const int iLengthBt = (int) msaTest.GetSeqLength(uTestSeqIndexB);
    const int iLengthAr = (int) msaRef.GetSeqLength(uRefSeqIndexA);
    const int iLengthBr = (int) msaRef.GetSeqLength(uRefSeqIndexB);

    int *iTestMapAt = new int[iLengthAt];
    int *iTestMapBt = new int[iLengthBt];

    int *iRefMapAr = new int[iLengthAr];
    int *iRefMapBr = new int[iLengthBr];

    int *iVersionMapAr = new int[iLengthAr];
    int *iVersionMapAt = new int[iLengthAt];

    int *iVersionMapBr = new int[iLengthBr];
    int *iVersionMapBt = new int[iLengthBt];

    int *iTestMapAr = new int[iLengthAr];
    int *iTestMapBr = new int[iLengthBr];

    msaTest.GetPairMap(uTestSeqIndexA, uTestSeqIndexB, iTestMapAt, iTestMapBt);
    msaRef.GetPairMap(uRefSeqIndexA, uRefSeqIndexB, iRefMapAr, iRefMapBr);

    if (MSA::SeqsEq(msaTest, uTestSeqIndexA, msaRef, uRefSeqIndexA))
        {
    // For speed, don't align unless the sequences are different.
    // Just poke the identity map.
        for (int n = 0; n < iLengthAr; ++n)
            {
            iVersionMapAr[n] = n;
            iVersionMapAt[n] = n;
            }
        }
    else
        {
        Seq seqAt;
        Seq seqAr;

        msaTest.GetSeq(uTestSeqIndexA, seqAt);
        msaRef.GetSeq(uRefSeqIndexA, seqAr);

        QuickAlign(seqAr, seqAt, iVersionMapAr, iVersionMapAt);
        }

    if (MSA::SeqsEq(msaTest, uTestSeqIndexB, msaRef, uRefSeqIndexB))
        {
    // For speed, don't align unless the sequences are different.
    // Just poke the identity map.
        for (int n = 0; n < iLengthBr; ++n)
            {
            iVersionMapBr[n] = n;
            iVersionMapBt[n] = n;
            }
        }
    else
        {
        Seq seqBt;
        Seq seqBr;

        msaTest.GetSeq(uTestSeqIndexB, seqBt);
        msaRef.GetSeq(uRefSeqIndexB, seqBr);

        QuickAlign(seqBr, seqBt, iVersionMapBr, iVersionMapBt);
        }

    for (int n = 0; n < iLengthAr; ++n)
        {
        int iVersionPosAt = iVersionMapAr[n];
        if (-1 == iVersionPosAt)
            {
            iTestMapAr[n] = -1;
            continue;
            }
        int iTestPosBt = iTestMapAt[iVersionPosAt];
        if (-1 == iTestPosBt)
            {
            iTestMapAr[n] = -1;
            continue;
            }
        int iTestPosBr = iVersionMapBt[iTestPosBt];
        iTestMapAr[n] = iTestPosBr;
        }

    for (int n = 0; n < iLengthBr; ++n)
        {
        int iVersionPosBt = iVersionMapBr[n];
        if (-1 == iVersionPosBt)
            {
            iTestMapBr[n] = -1;
            continue;
            }
        int iTestPosAt = iTestMapBt[iVersionPosBt];
        if (-1 == iTestPosAt)
            {
            iTestMapBr[n] = -1;
            continue;
            }
        int iTestPosAr = iVersionMapAt[iTestPosAt];
        iTestMapBr[n] = iTestPosAr;
        }

    delete[] iVersionMapAr;
    delete[] iVersionMapAt;
    delete[] iVersionMapBr;
    delete[] iVersionMapBt;

    delete[] iTestMapAt;
    delete[] iTestMapBt;

    *ptriRefMapAr = iRefMapAr;
    *ptriRefMapBr = iRefMapBr;
    *ptriTestMapAr = iTestMapAr;
    *ptriTestMapBr = iTestMapBr;
    }
