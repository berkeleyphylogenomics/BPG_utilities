// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "Seq.h"

void VerboseCompareMSA(const MSA &msaTest, const MSA &msaRef, double *ptrdSP,
  double *ptrdPS, double *ptrdCS)
    {
    const unsigned uRefSeqCount = msaRef.GetSeqCount();

    double dTotalSP = 0.0;
    double dTotalPS = 0.0;
    double dTotalCS = 0.0;
    unsigned uPairCount = 0;

    for (unsigned uRefSeqIndexA = 0; uRefSeqIndexA < uRefSeqCount; ++uRefSeqIndexA)
        {
        const char *pstrSeqNameA = msaRef.GetSeqName(uRefSeqIndexA);
        unsigned uTestSeqIndexA;
        bool bFound = msaTest.GetSeqIndex(pstrSeqNameA, &uTestSeqIndexA);
        if (!bFound)
            Quit("Sequence '%s' not found in test alignment", pstrSeqNameA);

        for (unsigned uRefSeqIndexB = uRefSeqIndexA + 1; uRefSeqIndexB < uRefSeqCount;
          ++uRefSeqIndexB)
            {
            const char *pstrSeqNameB = msaRef.GetSeqName(uRefSeqIndexB);
            unsigned uTestSeqIndexB;
            bool bFound = msaTest.GetSeqIndex(pstrSeqNameB, &uTestSeqIndexB);
            if (!bFound)
                Quit("Sequence '%s' not found in test alignment", pstrSeqNameB);

            double dSP = dInsane;
            double dPS = dInsane;
            double dCS = dInsane;
            VerboseComparePair(msaTest, uTestSeqIndexA, uTestSeqIndexB, msaRef, uRefSeqIndexA,
              uRefSeqIndexB, &dSP, &dPS, &dCS);

            dTotalSP += dSP;
            dTotalPS += dPS;
            dTotalCS += dCS;
            ++uPairCount;
            }
        }
    *ptrdSP = dTotalSP / uPairCount;
    *ptrdPS = dTotalPS / uPairCount;
    *ptrdCS = dTotalCS / uPairCount;
    }

static void VerboseMakePairMaps(const MSA &msaTest, unsigned uTestSeqIndexA,
  unsigned uTestSeqIndexB, const MSA &msaRef, unsigned uRefSeqIndexA,
  unsigned uRefSeqIndexB, int **ptriTestMapAr, int **ptriTestMapBr,
  int **ptriRefMapAr, int **ptriRefMapBr)
    {
    const int iLengthAt = (int) msaTest.GetSeqLength(uTestSeqIndexA);
    const int iLengthBt = (int) msaTest.GetSeqLength(uTestSeqIndexB);
    const int iLengthAr = (int) msaRef.GetSeqLength(uRefSeqIndexA);
    const int iLengthBr = (int) msaRef.GetSeqLength(uRefSeqIndexB);

    int *iTestMapAt = new int[iLengthAt];
    int *iTestMapBt = new int[iLengthBt];

    int *iRefMapAr = new int[iLengthAr];
    int *iRefMapBr = new int[iLengthBr];

    int *iVersionMapAr = new int[iLengthAr];
    int *iVersionMapAt = new int[iLengthAt];

    int *iVersionMapBr = new int[iLengthBr];
    int *iVersionMapBt = new int[iLengthBt];

    int *iTestMapAr = new int[iLengthAr];
    int *iTestMapBr = new int[iLengthBr];

    msaTest.GetPairMap(uTestSeqIndexA, uTestSeqIndexB, iTestMapAt, iTestMapBt);
    msaRef.GetPairMap(uRefSeqIndexA, uRefSeqIndexB, iRefMapAr, iRefMapBr);

    if (MSA::SeqsEq(msaTest, uTestSeqIndexA, msaRef, uRefSeqIndexA))
        {
        List("Sequence A identical in test and reference alignments\n");
    // For speed, don't align unless the sequences are different.
    // Just poke the identity map.
        for (int n = 0; n < iLengthAr; ++n)
            {
            iVersionMapAr[n] = n;
            iVersionMapAt[n] = n;
            }
        }
    else
        {
        Seq seqAt;
        Seq seqAr;

        msaTest.GetSeq(uTestSeqIndexA, seqAt);
        msaRef.GetSeq(uRefSeqIndexA, seqAr);

        seqAt.SetName("Atest");
        seqAr.SetName("Aref");

        QuickAlign(seqAr, seqAt, iVersionMapAr, iVersionMapAt);

        
        MSA a;
        a.FromPairMap(seqAr, seqAt, iVersionMapAr, iVersionMapAt);

        List("Sequence A different in test and reference alignments\n");
        List("Alignment of Atest to Aref:\n");
        a.ListMe();
        }

    if (MSA::SeqsEq(msaTest, uTestSeqIndexB, msaRef, uRefSeqIndexB))
        {
        List("Sequence B identical in test and reference alignments\n");

    // For speed, don't align unless the sequences are different.
    // Just poke the identity map.
        for (int n = 0; n < iLengthBr; ++n)
            {
            iVersionMapBr[n] = n;
            iVersionMapBt[n] = n;
            }
        }
    else
        {
        Seq seqBt;
        Seq seqBr;

        msaTest.GetSeq(uTestSeqIndexB, seqBt);
        msaRef.GetSeq(uRefSeqIndexB, seqBr);

        seqBt.SetName("Btest");
        seqBr.SetName("Bref");

        QuickAlign(seqBr, seqBt, iVersionMapBr, iVersionMapBt);

        MSA a;
        a.FromPairMap(seqBr, seqBt, iVersionMapBr, iVersionMapBt);

        List("Sequence B different in test and reference alignments\n");
        List("Alignment of Btest to Bref:\n");
        a.ListMe();
        }

    for (int n = 0; n < iLengthAr; ++n)
        {
        int iVersionPosAt = iVersionMapAr[n];
        if (-1 == iVersionPosAt)
            {
            iTestMapAr[n] = -1;
            continue;
            }
        int iTestPosBt = iTestMapAt[iVersionPosAt];
        if (-1 == iTestPosBt)
            {
            iTestMapAr[n] = -1;
            continue;
            }
        int iTestPosBr = iVersionMapBt[iTestPosBt];
        iTestMapAr[n] = iTestPosBr;
        }

    for (int n = 0; n < iLengthBr; ++n)
        {
        int iVersionPosBt = iVersionMapBr[n];
        if (-1 == iVersionPosBt)
            {
            iTestMapBr[n] = -1;
            continue;
            }
        int iTestPosAt = iTestMapBt[iVersionPosBt];
        if (-1 == iTestPosAt)
            {
            iTestMapBr[n] = -1;
            continue;
            }
        int iTestPosAr = iVersionMapAt[iTestPosAt];
        iTestMapBr[n] = iTestPosAr;
        }

    delete[] iVersionMapAr;
    delete[] iVersionMapAt;
    delete[] iVersionMapBr;
    delete[] iVersionMapBt;

    delete[] iTestMapAt;
    delete[] iTestMapBt;

    *ptriRefMapAr = iRefMapAr;
    *ptriRefMapBr = iRefMapBr;
    *ptriTestMapAr = iTestMapAr;
    *ptriTestMapBr = iTestMapBr;
    }

void VerboseComparePair(const MSA &msaTest, unsigned uTestSeqIndexA,
  unsigned uTestSeqIndexB, const MSA &msaRef, unsigned uRefSeqIndexA,
  unsigned uRefSeqIndexB, double *ptrdSP, double *ptrdPS, double *ptrdCS)
    {
    int *iRefMapAr;
    int *iRefMapBr;
    int *iTestMapAr;
    int *iTestMapBr;

    List("Test alignment:\n");
    msaTest.ListMe();

    List("Reference alignment:\n");
    msaRef.ListMe();

    VerboseMakePairMaps(msaTest, uTestSeqIndexA, uTestSeqIndexB, msaRef, uRefSeqIndexA,
      uRefSeqIndexB, &iTestMapAr, &iTestMapBr, &iRefMapAr, &iRefMapBr);

    const int iLengthAr = (int) msaRef.GetSeqLength(uRefSeqIndexA);
    const int iLengthBr = (int) msaRef.GetSeqLength(uRefSeqIndexB);

    ComparePairMap(iTestMapAr, iTestMapBr, iRefMapAr, iRefMapBr, iLengthAr, iLengthBr,
      ptrdSP, ptrdPS, ptrdCS);

    delete[] iRefMapAr;
    delete[] iRefMapBr;
    delete[] iTestMapAr;
    delete[] iTestMapBr;
    }
