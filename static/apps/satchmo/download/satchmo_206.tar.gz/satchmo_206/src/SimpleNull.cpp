// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

/***
We define a "simple null model" following HMMer. It has two
states. An insert state, G, emits according to the background
residue probabilities. The final state is F. The model begins
in the G state. There are two transitions: a G->G self-loop,
and G->F to exit. The self-loop probability is tuned to emit
a sequence that, on average, is as long as the average protein
in SWISSPROT 34 (350 residues, giving a self-loop probability
of 350/351 = 0.99715).

The HMMer implementation exploits an interesting trick: we can
"subtract" the simple null model from the HMM parameters, giving
a non-probabilistic graph in place of an HMM. This transformation
leaves the Viterbi path unchanged, and the Viterbi score becomes
log2 (P(seq | HMM) / P(seq | Null)). It thus calculates the score
relative to the simple null model with no additional arithmetic.

Let score(Q->R) be the transition score for moving from state
Q to state R, and emit(R,a) be the emission score in state R
for residue type a.

Start with model H with probabilities expressed as log-odds scores.
We transform H into a new model h as follows:

a) Subtract emit(G,a) from every emission score for residue type a.

b) Subtract score(G->G) from the score of every transition that
results in an emission (every "emitter edge").

c) Substract score(G->F) from all exit transition scores.

Note that h is not probabilistic, so is not Markov. However, we can
consider it to be a weighted directed graph where we sum the log-odds
transition and emission scores, so we can apply the Viterbi algorithm
in log-odds space to find the highest-scoring path.

Consider a sequence S, and a subsequence s of S of length k. Now
consider a subpath p through the model that visits k emitter states
and emits s; we aim to find the difference in score for the subpath
resulting from the transformation. (Here we assume that p does
not include an exit transition). Note that p must have exactly k
emitter edges, so the difference in transition score is k*score(G->G).
The difference in emission score is determined by the composition of
s, i.e. by its residue type counts. The change in score diff(p,s) due
to the transformation is given by:

    diff(p,s)
        = score(p | H) - score(p | H)
        = k*score(G->G) + sum_a in s_ emit(G,a)

Note that diff(p,s) is independent of p. Thus the highest-scoring
subpath p that emits s is unchanged by the transformation, and the
Viterbi recursion relations will find the same path in H and h for
any sequence S. By setting s=S and requiring that p includes an exit
transition we can see that diff(p,s) becomes exactly score(S,Null),
which proves our assertion above that the Viterbi algorithm on the
transformed model subtracts the null model score from the Viterbi
score for the original model.

This can be seen as an optimization for computing the score relative
the simple null model, but in itself this gives little speed or space
improvement as the null model score can be computed very quickly
compared to the Viterbi algorithm in O(L) time and O(1) space. This
approach does allow some further optimizations which may be of more
value (though not much more, as will be explained). Suppose all
insert states in H emit with background probability distributions.
After null model subtraction, insert emission scores will then be
zero. This means that insert emission calculation can be omitted from
the Viterbi code altogether. If we further assume that the terminal
insert states (SAM FIMs, or HMMer N and C states) have a self-loop with
the same probability as the null model, then they can be eliminated
altogether -- you don't need DP matrices for them, they can replaced 
with boundary conditions on other DP matrices (similar to how boundary
conditions transform global to local alignment in Smith-Waterman vs.
Needleman-Wunsch). HMMer does not exploit this possibility, and in my
view it is probably not worth the effort to implement it -- you loose
generality and clarity, and gain only a small improvement in time and
space efficiency. The Viterbi inner loop is reduced by omitting insert
state emission calculations, which is perhaps 5-10% time at best, and
given a typical model length of 100 nodes, you reduce the number of DP
matrices by only 2%.

The same transformation can be applied to the forward-backward algorithm.
To see this, note first that all paths contributing to a given DP
matrix entry have the same length. Then note that when the scores
are added to give the posterior score, the resulting full path emits
the full sequence and thus has the effect of subtracting the null
model score. To calculate the posterior-decoded alignment, the procedure
is to compute the forward-backward score using h, add the null model
score to each entry, convert to probabilities and then peform the
Viterbi algorithm on those probabilities. Note that since the Viterbi
algorithm used in the final step maximizes the sum rather than the
product of probabilities, the values must be converted to probabilities,
this Viterbi algorithm (unlike the standard Viterbi algorithm for finding
the most probable path through H) cannot be done in the transformed
log space.
***/

#include "lobster.h"
#include "HMM.h"
#include "Seq.h"


SCORE GetNullEmitTransScore()
    {
// Rationale: average protein length
    static SCORE TransScore = ProbToScore((PROB)((double) 350 / (double) 351));
    return TransScore;
    }

static SCORE NullEmit[20] =
    {
    (SCORE) -3.727,
    (SCORE) -5.881,
    (SCORE) -4.237,
    (SCORE) -3.984,
    (SCORE) -4.617,
    (SCORE) -3.869,
    (SCORE) -5.480,
    (SCORE) -4.126,
    (SCORE) -4.073,
    (SCORE) -3.420,
    (SCORE) -5.407,
    (SCORE) -4.465,
    (SCORE) -4.343,
    (SCORE) -4.636,
    (SCORE) -4.277,
    (SCORE) -3.792,
    (SCORE) -4.121,
    (SCORE) -3.938,
    (SCORE) -6.320,
    (SCORE) -4.966
    };

PROB SumNullEmitProb()
    {
    PROB probSum = 0;
    for (unsigned n = 0; n < 20; ++n)
        probSum += ScoreToProb(NullEmit[n]);
    return probSum;
    }

SCORE GetNullEmitScore(unsigned uLetter)
    {
    assert(uLetter < 20);
    return NullEmit[uLetter];
    }

static PROB BackgroundProb[MAX_ALPHA] =
    {
    (PROB) 0.7552,    // A
    (PROB) 0.1697,    // C
    (PROB) 0.5303,    // D
    (PROB) 0.6320,    // E
    (PROB) 0.4075,    // F
    (PROB) 0.6844,    // G
    (PROB) 0.2241,    // H
    (PROB) 0.5727,    // I
    (PROB) 0.5942,    // K
    (PROB) 0.9343,    // L
    (PROB) 0.2357,    // M
    (PROB) 0.4528,    // N
    (PROB) 0.4928,    // P
    (PROB) 0.4022,    // Q
    (PROB) 0.5158,    // R
    (PROB) 0.7219,    // S
    (PROB) 0.5747,    // T
    (PROB) 0.6524,    // V
    (PROB) 0.1252,    // W
    (PROB) 0.3200    // Y
    };

PROB GetBackgroundProb(unsigned uLetter)
    {
    assert(uLetter >= 0 && uLetter < MAX_ALPHA);
    return BackgroundProb[uLetter];
    }

PROB GetNullEmitProb(unsigned uLetter)
    {
    assert(uLetter < 20);
    return ScoreToProb(NullEmit[uLetter]);
    }

SCORE GetNullEmitScoreChar(char c)
    {
    if ('x' == c || 'X' == c)
        return 0;
    if ('b' == c || 'B' == c)
        return Add2(GetNullEmitScore(AX_D)* (SCORE) 0.4606, GetNullEmitScore(AX_N)*(SCORE) 0.5394);
    if ('z' == c || 'Z' == c)
        return Add2(GetNullEmitScore(AX_E)*(SCORE) 0.6110, GetNullEmitScore(AX_Q)*(SCORE) 0.3890);
    unsigned uLetter = CharToLetterAmino(c);
    return GetNullEmitScore(uLetter);
    }

void AssertNormalizedDist(const PROB p[], unsigned N)
    {
    PROB dSum = 0.0;
    for (unsigned i = 0; i < N; ++i)
            dSum += p[i];
    if (!BTEq(dSum, 1.0))
        Quit("AssertNormalizedDist failed");
    }

void HMM::AddSimpleNull()
    {
    m_scoreFirstM += GetNullEmitTransScore();
    const unsigned uNodeCount = GetNodeCount();
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        HMMNode &Node = m_Nodes[uNodeIndex];
        AddSimpleNullNode(Node);
        }
    }

void HMM::SubtractSimpleNull()
    {
    m_scoreFirstM -= GetNullEmitTransScore();
    const unsigned uNodeCount = GetNodeCount();
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        HMMNode &Node = m_Nodes[uNodeIndex];
        SubtractSimpleNullNode(Node);
        }
    }

void HMM::AddSimpleNullNode(HMMNode &Node)
    {
    Node.m_scoreMM += GetNullEmitTransScore();
    Node.m_scoreMI += GetNullEmitTransScore();
    Node.m_scoreDM += GetNullEmitTransScore();
    Node.m_scoreDI += GetNullEmitTransScore();
    Node.m_scoreIM += GetNullEmitTransScore();
    Node.m_scoreII += GetNullEmitTransScore();
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        Node.m_scoreMatchEmit[uLetter] =
          Add2(Node.m_scoreMatchEmit[uLetter], GetNullEmitScore(uLetter));
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        Node.m_scoreInsertEmit[uLetter] =
          Add2(Node.m_scoreInsertEmit[uLetter], GetNullEmitScore(uLetter));
    }

void HMM::SubtractSimpleNullNode(HMMNode &Node)
    {
    Node.m_scoreMM -= GetNullEmitTransScore();
    Node.m_scoreMI -= GetNullEmitTransScore();
    Node.m_scoreDM -= GetNullEmitTransScore();
    Node.m_scoreDI -= GetNullEmitTransScore();
    Node.m_scoreIM -= GetNullEmitTransScore();
    Node.m_scoreII -= GetNullEmitTransScore();
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        Node.m_scoreMatchEmit[uLetter] =
          Sub2(Node.m_scoreMatchEmit[uLetter], GetNullEmitScore(uLetter));
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        Node.m_scoreInsertEmit[uLetter] =
          Sub2(Node.m_scoreInsertEmit[uLetter], GetNullEmitScore(uLetter));
    }

SCORE HMM::ScoreSimpleNullSeq(const Seq &s) const
    {
    const unsigned uLength = s.Length();
    SCORE scoreNull = 0;
    for (unsigned n = 0; n < uLength; ++n)
        {
        const char c = s[n];
        scoreNull += GetNullEmitScoreChar(c);
        }
    scoreNull += uLength*GetNullEmitTransScore();
    return scoreNull;
    }

// Adjust null model self-loop by adding scoreDelta to
// transitions into match states.
// This is a total hack -- I haven't figured out the
// full theory, but it seems clear that you can't
// add scoreDelta to all emitter transitions because
// you lose the symmetry between M->I and M->D, which
// should have the same weight (both are gap-open
// penalties), and between I->I and D->D (gap-extends).
// This presumably means that the transition priors
// must be adjusted before estimating the model.
void HMM::DeltaNullModelSelfLoop(SCORE scoreDelta)
    {
    m_scoreFirstM += scoreDelta;
    const unsigned uNodeCount = GetNodeCount();
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        HMMNode &Node = m_Nodes[uNodeIndex];
        Node.m_scoreMM += scoreDelta;
        Node.m_scoreDM += scoreDelta;
        Node.m_scoreIM += scoreDelta;
        }
    }
