#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "MSA.h"
#include "Seq.h"

#define ADD_NULL 1

SCORE HMM::FBAlign(const MSA &a, HMMPath &Route){
#if    ADD_NULL
    AddSimpleNull();
#else
    SCORE scoreSimpleNull = ScoreSimpleNullSeq(a);
#endif

#if    VERBOSE
    Model.ListMe();
    List("\n");
#endif

    List("Forward:\n");
    SCORE *DPMFwd;
    SCORE scoreFwd = ForwardAln(a, &DPMFwd);
#if    !ADD_NULL
    scoreFwd += scoreSimpleNull;
#endif
    List("Forward score %s prob %.3g\n\n", ScoreToStr(scoreFwd), ScoreToProb(scoreFwd));

    List("Backward:\n");
    SCORE *DPMBwd;
    SCORE scoreBwd = BackwardAln(a, &DPMBwd);
#if    !ADD_NULL
    scoreBwd += scoreSimpleNull;
#endif
    List("Backward score %s prob %.3g\n", ScoreToStr(scoreBwd), ScoreToProb(scoreBwd));

//    assert(BTEq(scoreFwd, scoreBwd));

    const unsigned uNodeCount = GetNodeCount();
    const unsigned uLength = a.GetColCount();

    PROB *P = new PROB[uNodeCount*uLength];
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        for (unsigned uPos = 0; uPos < uLength; ++uPos)
            {
            SCORE f = DPMFwd[uNodeIndex*(uLength + 1) + uPos + 1];
            SCORE b = DPMBwd[uNodeIndex*(uLength + 1) + uPos + 1];
            SCORE scorePD = f + b;
#if    !ADD_NULL
            scorePD += scoreSimpleNull;
#endif
            PROB p = ScoreToProb(scorePD);
            assert(p >= 0 && p <= 1);
            P[uNodeIndex*uLength + uPos] = p;
            }

    List("\nPosterior probs from Fwd/Bwd DP matrices=\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        for (unsigned uPos = 0; uPos < uLength; ++uPos)
            List("%10.3g ", P[uNodeIndex*uLength + uPos]);
        List("\n");
        }

    PDAlign(P, uLength, Route);
    SCORE Score;
    for(int i=0;i<Route.GetEdgeCount();++i){
        HMMEdge edg = Route.GetEdge(i);        
        Score = Add2(Score, P[edg.uNodeIndex*uLength + edg.uPrefixLength]);
    }
    

//    {
//    EPS_TestPD e;
//    e.Init(a, Model);
//    EnumPaths(Model.GetNodeCount(), a.Length(), GLOBAL_MODEL, GLOBAL_SEQ, e);
//    e.ListMe();
//    }

//    List("\nViterbi path:\n");
//    pathViterbi.ListMe();

    List("\nPosterior decoded path:\n");
    Route.ListMe();
    delete[] DPMFwd;
    delete[] DPMBwd;
    
    return Score;
}
