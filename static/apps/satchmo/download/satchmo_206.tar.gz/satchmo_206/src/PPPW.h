// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef PPPW_h
#define PPPW_h

#include "PWBase.h"
#include "PPDist2.h"

// PPPW is a trivial converter class.
// It transforms a PWBase object into a PPDist2 object.
// PWBase is an abstract class that represents a scoring scheme
// for pair-wise profile-profile alignment. We want to re-use
// the PWBase::ScoreProfPos function as a distance function
// for protein clustering.
// PPDist2 is an abstract class that represents a distance
// function constructed by summing over positions in two
// pre-aligned profiles.

class PPPW : public PPDist2
    {
public:
    PPPW(PWBase &PWScorer) : m_ptrPWScorer(&PWScorer)
        {
        }

public:
    virtual double PPPosDist(const ProfPos &PP1, const ProfPos &PP2)
        {
    // Note change of sign.
    // By convention, alignment /max/imizes the total score,
    // but clustering order is defined by /min/imizing distances.
    // Note that this will often result in negative distances
    // so will not be suitable for all clustering algorithms.
        return -m_ptrPWScorer->ScoreProfPos(PP1, PP2);
        }

public:
    PWBase *m_ptrPWScorer;
    };

#endif    // PPPW_h
