// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMMPath.h"
#include "HMM.h"
#include "Seq.h"
#include "SatchmoParams.h"
#include "TextFile.h"

HMMPath::HMMPath()
    {
    m_uArraySize = 0;
    m_uEdgeCount = 0;
    m_Edges = 0;
    }

HMMPath::~HMMPath()
    {
    Clear();
    }

void HMMPath::Clear()
    {
    delete[] m_Edges;
    m_Edges = 0;
    m_uArraySize = 0;
    m_uEdgeCount = 0;
//    m_ptrTarget = 0;
    }

void HMMPath::ExpandPath(unsigned uAdditionalEdgeCount)
    {
    HMMEdge *OldPath = m_Edges;
    unsigned uEdgeCount = m_uArraySize + uAdditionalEdgeCount;

    m_Edges = new HMMEdge[uEdgeCount];
    m_uArraySize = uEdgeCount;
    if (m_uEdgeCount > 0)
        memcpy(m_Edges, OldPath, m_uEdgeCount*sizeof(HMMEdge));
    delete[] OldPath;
    }

void HMMPath::AppendEdge(const HMMEdge &Edge)
    {
    if (0 == m_uArraySize || m_uEdgeCount + 1 == m_uArraySize)
        ExpandPath(200);

    m_Edges[m_uEdgeCount] = Edge;
    ++m_uEdgeCount;
    }

void HMMPath::PrependEdge(const HMMEdge &Edge)
    {
    if (0 == m_uArraySize || m_uEdgeCount + 1 == m_uArraySize)
        ExpandPath(1000);
    if (m_uEdgeCount > 0)
        memmove(m_Edges + 1, m_Edges, sizeof(HMMEdge)*m_uEdgeCount);
    m_Edges[0] = Edge;
    ++m_uEdgeCount;
    }

const HMMEdge &HMMPath::GetEdge(unsigned uEdgeIndex) const
    {
    assert(uEdgeIndex < m_uEdgeCount);
    return m_Edges[uEdgeIndex];
    }

void HMMPath::Validate(unsigned uNodeCount, unsigned uSeqLength,
  MODEL_BOUNDS ModelBounds, SEQ_BOUNDS SeqBounds) const
    {
#if    !_DEBUG
    return;
#endif

    const unsigned uEdgeCount = GetEdgeCount();
    if (0 == uEdgeCount)
        return;

// First edge is special case
    const HMMEdge &FirstEdge = GetEdge(0);
    unsigned uPrefixLength = FirstEdge.uPrefixLength;
    assert(uPrefixLength <= uSeqLength);
    unsigned uNodeIndex = FirstEdge.uNodeIndex;

    if (GLOBAL_MODEL == ModelBounds)
        assert(0 == uNodeIndex);

    if (GLOBAL_SEQ == SeqBounds)
        {
        const char cFirstState = FirstEdge.cState;
        if (('M' == cFirstState && 1 != uPrefixLength) ||
          'D' == cFirstState && 0 != uPrefixLength)
            {
            ListMe();
            assert(false);
            }
        }

// Must enter model in M or D state
    char cToState = FirstEdge.cState;
    assert('M' == cToState || 'D' == cToState);

    for (unsigned uEdgeIndex = 1; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        char cFromState = cToState;
        const HMMEdge &Edge = GetEdge(uEdgeIndex);
        cToState = Edge.cState;
        assert('M' == cToState || 'D' == cToState || 'I' == cToState);
        if ('M' == cToState || 'I' == cToState)
            ++uPrefixLength;
        assert(uPrefixLength == Edge.uPrefixLength);
        assert(uPrefixLength <= uSeqLength);
        if ('M' == cToState || 'D' == cToState)
            ++uNodeIndex;
        assert(uNodeIndex == Edge.uNodeIndex);
        assert(uNodeIndex < uNodeCount);
        }

// Last edge is special case
    const HMMEdge &LastEdge = GetEdge(uEdgeCount - 1);

// Must exit model from M or D state
    assert('M' == LastEdge.cState || 'D' == LastEdge.cState);

    if (GLOBAL_MODEL == ModelBounds)
        assert(uNodeCount == LastEdge.uNodeIndex + 1);

    if (GLOBAL_SEQ == SeqBounds)
        {
        if (uPrefixLength != uSeqLength)
            ListMe();
        assert(uPrefixLength == uSeqLength);
        }
    }

void HMMPath::ListMe() const
    {
    for (unsigned uEdgeIndex = 0; uEdgeIndex < GetEdgeCount(); ++uEdgeIndex)
        {
        const HMMEdge &Edge = GetEdge(uEdgeIndex);
        if (uEdgeIndex > 0)
            List("->");
        List("%c%d.%d", Edge.cState, Edge.uNodeIndex, Edge.uPrefixLength);
        if ((uEdgeIndex > 0 && uEdgeIndex%10 == 0) ||
         uEdgeIndex == GetEdgeCount() - 1)
            List("\n");
        }
    }

SCORE HMMPath::GetAvgAff(unsigned uEdgeIndex, unsigned uWindowLength) const
    {
    const HMMEdge &Edge = GetEdge(uEdgeIndex);

// Never aligned unless in match or delete state
    if ('M' != Edge.cState && 'D' != Edge.cState)
        return MINUS_INFINITY;

    assert(0 != uWindowLength%2);
    assert(uWindowLength >= 1);

    unsigned L2 = uWindowLength/2;
    SCORE scoreTotal = 0;
    unsigned uPosCountLeft = 0;
    for (int n = (int) uEdgeIndex; n >= 0; --n)
        {
        const HMMEdge &Edge = GetEdge((unsigned) n);
        switch (Edge.cState)
            {
        case 'M':
            scoreTotal += Edge.scoreEmit;
            break;

        case 'D':
            break;

        default:
            continue;
            }
        ++uPosCountLeft;
        if (uPosCountLeft == L2)
            break;
        }

    unsigned uPosCountRight = 0;
    for (unsigned n = uEdgeIndex + 1; n < GetEdgeCount(); ++n)
        {
        const HMMEdge &Edge = GetEdge(n);
        switch (Edge.cState)
            {
        case 'M':
            scoreTotal += Edge.scoreEmit;
            break;

        case 'D':
            break;

        default:
            continue;
            }
        ++uPosCountRight;
        if (uPosCountRight == L2)
            break;
        }

    return scoreTotal / (SCORE) (uPosCountLeft + uPosCountRight);
    }

void HMMPath::Copy(const HMMPath &Path)
    {
    Clear();
    const unsigned uEdgeCount = Path.GetEdgeCount();
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const HMMEdge &Edge = Path.GetEdge(uEdgeIndex);
        AppendEdge(Edge);
        }
    }

SCORE HMMPath::GetEdgeScore(unsigned uEdgeIndex, const HMM &Model, const Seq &s) const
    {
    const HMMEdge &Edge = GetEdge(uEdgeIndex);

// Transition score
    char cToState = Edge.cState;
    char cFromState;
    unsigned uNodeIndex;
    if (0 == uEdgeIndex)
        {
        cFromState = 'S';
        uNodeIndex = Edge.uNodeIndex;
        }
    else
        {
        const HMMEdge &PrevEdge = GetEdge(uEdgeIndex-1);
        cFromState = PrevEdge.cState;
        uNodeIndex = PrevEdge.uNodeIndex;
        }
    SCORE Score = Model.GetTransScore(uNodeIndex, cFromState, cToState);

// Emission score
    if ('M' == Edge.cState)
        {
        const unsigned uPL = Edge.uPrefixLength;
        assert(uPL > 0);
        SCORE scoreEmit = Model.GetMatchEmitScore(Edge.uNodeIndex, s[uPL-1]);
        Score = Add2(Score, scoreEmit);
        }
    else if ('I' == Edge.cState)
        {
        const unsigned uPL = Edge.uPrefixLength;
        assert(uPL > 0);
        SCORE scoreEmit = Model.GetInsertEmitScore(Edge.uNodeIndex, s[uPL-1]);
        Score = Add2(Score, scoreEmit);
        }
    return Score;
    }

SCORE HMMPath::GetTransScore(unsigned uEdgeIndex, const HMM &Model) const
    {
    const HMMEdge &Edge = GetEdge(uEdgeIndex);

// Transition score
    char cToState = Edge.cState;
    char cFromState;
    unsigned uNodeIndex;
    if (0 == uEdgeIndex)
        {
        cFromState = 'S';
        uNodeIndex = Edge.uNodeIndex;
        }
    else
        {
        const HMMEdge &PrevEdge = GetEdge(uEdgeIndex-1);
        cFromState = PrevEdge.cState;
        uNodeIndex = PrevEdge.uNodeIndex;
        }
    return Model.GetTransScore(uNodeIndex, cFromState, cToState);
    }

unsigned HMMPath::GetEmitterCount() const
    {
    unsigned uCount = 0;
    const unsigned uEdgeCount = GetEdgeCount();
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const HMMEdge &Edge = GetEdge(uEdgeIndex);
        const char cState = Edge.cState;
        if ('M' == cState || 'I' == cState)
            ++uCount;
        }
    return uCount;
    }

void HMMPath::ToFile(TextFile &File) const
    {
    const unsigned uEdgeCount = GetEdgeCount();
    File.PutString("HMMPath\n");
    File.PutString("{\n");
    File.PutFormat("edges %u\n", uEdgeCount);
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const HMMEdge &Edge = GetEdge(uEdgeIndex);
        File.PutFormat("%u %c %u %u\n",
          uEdgeIndex, Edge.cState, Edge.uNodeIndex, Edge.uPrefixLength);
        }
    File.PutString("}\n");
    }

void HMMPath::FromFile(TextFile &File)
    {
    Clear();
    char szToken[1024];
    File.GetTokenX(szToken, sizeof(szToken));
    if (0 != strcmp(szToken, "HMMPath"))
        Quit("Invalid path file");
    File.GetTokenX(szToken, sizeof(szToken));
    if (0 != strcmp(szToken, "{"))
        Quit("Invalid path file");
    File.GetTokenX(szToken, sizeof(szToken));
    if (0 != strcmp(szToken, "edges"))
        Quit("Invalid path file");
    File.GetTokenX(szToken, sizeof(szToken));
    if (!IsValidInteger(szToken))
        Quit("Invalid path file");
    const unsigned uEdgeCount = (unsigned) atoi(szToken);
    unsigned uEdgeIndex = 0;
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
    // index
        File.GetTokenX(szToken, sizeof(szToken));
        if (!IsValidInteger(szToken))
            Quit("Invalid path file, invalid index '%s'", szToken);
        unsigned n = (unsigned) atoi(szToken);
        if (n != uEdgeIndex)
            Quit("Invalid path file, expecting edge %u got %u", uEdgeIndex, n);

    // state
        File.GetTokenX(szToken, sizeof(szToken));
        if (1 != strlen(szToken))
            Quit("Invalid path file, expecting state, got '%s'", szToken);
        const char cState = szToken[0];
        if ('M' != cState && 'D' != cState && cState != 'I' && 'S' != cState)
            Quit("Invalid path file, expecting state, got '%c'", cState);

    // node
        File.GetTokenX(szToken, sizeof(szToken));
        if (!IsValidInteger(szToken))
            Quit("Invalid path file, bad node '%s'", szToken);
        const unsigned uNodeIndex = (unsigned) atoi(szToken);

    // prefix length
        File.GetTokenX(szToken, sizeof(szToken));
        if (!IsValidInteger(szToken))
            Quit("Invalid path file, bad prefix length '%s'", szToken);
        const unsigned uPrefixLength = (unsigned) atoi(szToken);

        HMMEdge Edge;
        Edge.cState = cState;
        Edge.uNodeIndex = uNodeIndex;
        Edge.uPrefixLength = uPrefixLength;
        AppendEdge(Edge);
        }
    File.GetTokenX(szToken, sizeof(szToken));
    if (0 != strcmp(szToken, "}"))
        Quit("Invalid path file");
    }
