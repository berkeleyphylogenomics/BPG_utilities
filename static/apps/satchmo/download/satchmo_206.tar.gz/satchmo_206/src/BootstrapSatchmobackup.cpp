#ifdef PARALLEL
#include "mpi++.h"
#endif
 
#include "lobster.h"
#include "GTree2.h"
#include "GNode2.h"
#include "Bete.h"
#include "Seq.h"
#include "PPPW.h"
#include "Clust.h"
#include "TextFile.h"
#include "SJPM.h"
#include <vector>
#include <iostream>
#include <string>


#ifdef PARALLEL
#include "Serialization.h"
#endif

using namespace std;

unsigned uSeqCount;
double dDistThreshold;
int gIndex = 0;
int nClusters ;
#define MIN_WORK_PER_PROC 1
//#define MAX_HMM_SIZE 50000000
//#define MAX_MSA_SIZE 100000
#define PAIR_TO_TAG(a, b) (( (a) << 2*8*sizeof(char)) + (b) )
#define TAG_TO_PAIR1(x) ( (x) >> 2*8*sizeof(char) )
#define TAG_TO_PAIR2(x) ( (x) << 2*8*sizeof(char) >> 2*8*sizeof(char))
#define SCORE_PAIR 2
#define WORK_REQUEST 1
#define WORK_UNIT 10

void split_work(const int n_proc,int numClusters,  int* off, int* n);
void Interact_local(GNode2** local_nodes, int n_local_nodes, MSA** MSAs, int n_MSAs);
void Interact_local(HMM** HMMs, int n_HMMs, MSA** MSAs, int n_MSAs);
HMM* getNodeByIndex(HMM** hmmArray, int size, int index);

void GTree2::TreeSetup(){
    for (int i=0;i<m_uNodeCount;++i){
        GNode2 * ptrNode = new GNode2;
        m_Nodes[i] = ptrNode;
        ptrNode->m_Model.SetSatchmoParams(&m_SatchmoParams);
        ptrNode->AllocDistVector(m_uNodeCount);
        ptrNode->m_uNodeIndex = i;    
    }
}
// Sets up BETE params, and initializes objects
// doesn't begin the clustering. Do C.Create(); 
void SetupBETE(Bete *S, MSA *M){
    fprintf(stderr, "Launching BETE...");
    const char *colpair = GetOptionalParam("colpair", "RE");
    const char *join = GetOptionalParam("join", "nn");

    JOINSTYLE JoinStyle = JOINSTYLE_Undefined;
    if (!stricmp(join, "nn"))
        JoinStyle = JOINSTYLE_NearestNeighbor;
    else if (!stricmp(join, "nj"))
        JoinStyle = JOINSTYLE_NeighborJoining;
    else
        Quit("Invalid -join %s", join);

    static PWBase *ptrPWScorer;
    PWSFactory(colpair, "simple", "LL", &ptrPWScorer);
    static PPPW Dist(*ptrPWScorer);
    
    S->Init(*M, Dist );
    //  fprintf(stderr, "done bete init\n");
    S->SetJoinStyle(JoinStyle);
}
// Put Node into GTree, and then it's children.
void ClustnodeToGTree(const ClustNode *clustNode, GNode2* nodes[], Bete *Set ){
    //gIndex
  //  fprintf (stderr, "clustering %u to Tree. \n",clustNode->m_uIndex);
    if (clustNode == 0 || nodes[gIndex] == 0){
        //TODO: set name?
        return; 
    }
    // process node
    GNode2 *ptrNode = nodes[gIndex];
    
    ptrNode->m_MSA.Copy(Set->m_MSAs[clustNode->m_uIndex]);

        //free memory
        Set->m_Profiles[clustNode->m_uIndex].Clear();
        Set->m_Profiles[clustNode->m_uIndex].Clear();
                        
    gIndex++;            //**** done with this node, increment index ****//
    // fprintf (stderr,"current node is node %u\n", gIndex);  
  //deal with children
    if (clustNode->m_ptrLeft != 0){
        ptrNode->m_uLeftChildIndex = gIndex;
        ptrNode->m_ptrLeft =  nodes[gIndex];                                          //ints
	//  fprintf(stderr,"clustering node %u as leftchild of %u. \n",gIndex, clustNode->m_uIndex);
        ClustnodeToGTree(clustNode->m_ptrLeft, nodes, Set);
        ptrNode->m_ptrLeft->Clear();    //dont need children
    }
    if (clustNode->m_ptrRight != 0){
        ptrNode->m_uRightChildIndex = gIndex;
        ptrNode->m_ptrRight = nodes[gIndex];                                            //ints
        //fprintf(stderr,"clustering node %u as right child of %u\n",gIndex,clustNode->m_uIndex);
         ClustnodeToGTree(clustNode->m_ptrRight, nodes, Set);

        ptrNode->m_ptrRight->Clear();   //dont need children
    } 
    
    //ptrNode->m_MSA.BuildPillars();
    //ptrNode->m_MSA.DeleteEmptyCols(false);
    //ptrNode->m_MSA.AlignByCase(); 
    
    ptrNode->m_MSA.FreePillars();
    ptrNode->m_MSA.DeleteEmptyCols(false);
    
    //ptrNode->m_MSA.Crop();  This was causing unaligned columns
    WriteNodeToSmoFile(*g_ptrSmoFile, *ptrNode, g_bSaveHMMs, g_bSaveMSS);
    
    
}
void GTree2::BeteCluster(const double dDistThreshold)
{    
    Bete Set;
    MSA msa;
    Clust C;
        TextFile msaFile(g_strBSPath, false);
        msa.FromFASTAFile(msaFile);
    SetupBETE(&Set, &msa);
    C.ClusterToThreshold(Set, dDistThreshold);
    
    // now we have partially clustered Clust obj, put it in GTree
    nClusters = C.GetClusterCount();
    //foreach cluster,LINK THE CLUSTERS, fill the tree.
    int i;
    GNode2 *prevNode = m_Nodes[gIndex]; 
    
    fprintf(stderr, "Converting to GTree2...");
    for ( i=0;i<nClusters;++i){
        fprintf(stderr, "cluster %d\n", i);
        //process cluster
        const unsigned uNodeIndex = C.GetNodeIndex(i);
        if(C.GetClusterSize(uNodeIndex) < 1)
            Quit("Error ClusterSize < 1 in Bootstrap:Betecluster");
        int clustRootIndex = gIndex;
        ClustnodeToGTree(&C.GetNode(uNodeIndex), m_Nodes, &Set);
        GNode2 *root = m_Nodes[clustRootIndex];
                            
                // root->m_MSA.AlignByCaseOrDash(); 
                //if (!(root->IsLeaf()))  //if internal node
                    root->m_MSA.DeleteEmptyCols(false);
                root->m_MSA.BuildPillars(); 
                root->m_Model.FromAln(m_Nodes[clustRootIndex]->m_MSA);                    //HMM
                //root->m_MSA.FreePillars();
                
        //link forest 
        if (clustRootIndex != 0 ){
            m_Nodes[clustRootIndex]->m_ptrPrev = prevNode;
        }
        prevNode = m_Nodes[clustRootIndex];
    } 

    //Set m_ptrNext pointers
    GNode2 *thisNode = prevNode;
    while(0 != thisNode->m_ptrPrev){ //while not at head
        GNode2 *tNode = thisNode->m_ptrPrev;
        tNode->m_ptrNext = thisNode;
        thisNode = tNode;
    }
    m_ptrDisjoints = thisNode;
    if (m_ptrDisjoints != m_Nodes[0])
        Quit("Error in setting next pointers in BootstrapSatchmo::BeteCluster\n");
    
    
    // build joins forest
    for(i=gIndex;i<m_uNodeCount;i++){
        if (i>gIndex)
            m_Nodes[i]->m_ptrPrev = m_Nodes[i-1];
        if(i != m_uNodeCount - 1)
            m_Nodes[i]->m_ptrNext = m_Nodes[i+1];
    }
    m_ptrJoins = m_Nodes[gIndex];
} 
#ifdef PARALLEL
void SetDist(GNode2 *ptrNode, int x, int y, double dist){
  while(ptrNode != 0 && ptrNode->m_uNodeIndex != x)
    ptrNode = ptrNode->m_ptrNext;
  if (ptrNode == 0)
    Quit("Error in BootstrapSatchmo:SetDist()");
  else ptrNode->m_Dist[y] = dist;
}
#endif

#ifdef PARALLEL
#if 0
void GTree2::InitializeDist(SJPM *ptrMonitor, int numClusters){ //v1
  // Insert MPI Barrier - everyone catches up
  MPI::COMM_WORLD.Barrier(); 
  if (g_my_rank == 0)
    fprintf(stderr, "Initializing distance matrix(parallel)...numClusters: %u,\n", numClusters);

  unsigned uPairCount = numClusters*(numClusters - 1);
  unsigned uPairIndex = 0;
   MPI::Status status;

//MPI Globals: g_my_rank, g_numprocs, g_processor_name
  fprintf(stderr, "Hi, am am proc %d/%d on %s\n", 
      g_my_rank, g_numprocs, g_processor_name);
  
// split among nprocs, allocate space
  MPI::COMM_WORLD.Bcast(&numClusters,1, MPI::INT, 0);
  int *node_off = (int *)malloc ( (g_numprocs + 1) * sizeof(int));
  int *n_node_split = (int *)malloc ((g_numprocs) * sizeof(int));
  split_work(g_numprocs , numClusters , node_off, n_node_split);
  GNode2 **local_nodes=(GNode2 **)malloc(sizeof(GNode2 *)*n_node_split[1]);
  unsigned n_local = n_node_split[g_my_rank];
  unsigned max_n_per = n_node_split[1];
  // node 1 has max n_per

  int tag = 1;
  if (g_my_rank == 0){
    //MASTER: Send out work
    GNode2 *ptrGNode = m_ptrDisjoints;
    for(int proc_id = 0;proc_id< g_numprocs;++proc_id){ //foreach proc
      for (int j=0; j< n_node_split[proc_id] ;++j){ //each procs workload
    char *hmmBuffer ;
    ptrGNode->m_Model.Serialize(&hmmBuffer, ptrGNode->m_uNodeIndex);    //cout << "hmmBuffer(" << strlen(hmmBuffer) << ")" << hmmBuffer << endl;
    tag = ptrGNode->m_uNodeIndex;
    
    // send the buffer, remembering the null character
    int size = strlen(hmmBuffer) + 1;
    MPI::COMM_WORLD.Send (&size, 1, MPI::INT, proc_id, tag);
    MPI::COMM_WORLD.Send (hmmBuffer, size, MPI::CHAR, 
                  proc_id,tag);
    free(hmmBuffer);
    ptrGNode = ptrGNode->m_ptrNext;
      }
    }
    if (ptrGNode != 0)
      Quit("Error in BootstrapSatchmo::InitializeDist. sending out..");
    else cout << "Finished sending" << endl;
  }
  else {
    //    fprintf(stderr, "Recieving %u units..\n", n_node_split[g_my_rank]);
    //SLAVE: Recieve work
    for (int i=0; i< n_local ;++i){ // how many I'm expecting
      GNode2 *thisNode = new GNode2;
      local_nodes[i] = thisNode;
      int size;
      MPI::COMM_WORLD.Recv(&size, 1, MPI::INT, 0, MPI::ANY_TAG, status);
      char *hmmBuffer = (char *) malloc( sizeof(char) * size);
      
      MPI::COMM_WORLD.Recv(hmmBuffer, size, MPI::CHAR, 0, MPI::ANY_TAG, status);
      thisNode->m_Model.Deserialize(&hmmBuffer);
      free (hmmBuffer);
    }
    if(n_local < max_n_per){
      local_nodes[n_local] = local_nodes[n_local-1];
    }
  }
  MPI::COMM_WORLD.Barrier();

  // IntializeDistMatrix
  if (g_my_rank == 0){int x,y;
    cout << "Expecting " << numClusters*(numClusters-1) << " scores" << endl
     << "Rotating "<< max_n_per << " MSAs " << g_numprocs-2 << " times.\n";
    //MASTER: Recieve results from all-pairs (except yourself)
    double *dists = (double *) malloc (sizeof(double)*numClusters*(numClusters-1));
    tag = 2;
    int total = numClusters*(numClusters-1);
    for(int i=0;i<total;++i){

      double d[3];
      MPI::COMM_WORLD.Recv(&d,3, MPI::DOUBLE, MPI::ANY_SOURCE,SCORE_PAIR, status);
      int rtag = status.Get_tag();
      //x =  TAG_TO_PAIR1(rtag); y= TAG_TO_PAIR2(rtag);
      //fprintf(stderr, "got %f from %d, %d : %d\n", d, TAG_TO_PAIR1(rtag),TAG_TO_PAIR2(rtag), status.Get_source());     
      ptrMonitor->OnIteration1(i, total);
      SetDist(m_ptrDisjoints, (int) d[1],(int) d[2],d[0]);
    }
  }
  else {

    //SLAVE: Generate results
    // do all local points
    // Initialize MSA Buffers
    MSA **foreign_MSA = (MSA **)malloc(max_n_per * sizeof (MSA*));
    char **msaBuffers = (char**)malloc(max_n_per * sizeof (char*));
    for(int i=0;i<max_n_per;++i){
      foreign_MSA[i] = local_nodes[i]->m_Model.GetMSA();
      StringBuffer *sb = new StringBuffer;
      MSASerialize(foreign_MSA[i], sb, WWS_Always);
      msaBuffers[i] = sb->GetData();
      delete sb;
      }
    // Intial interaction
    Interact_local(local_nodes, n_local,
           foreign_MSA, n_local);
    // rotate
    tag = 3;
    int n_foreign;
    unsigned numRotations = g_numprocs -2; int foreign_rank = g_my_rank;
    int nProcs = g_numprocs -1;
    for (int uRotateIndex = 0; uRotateIndex < numRotations; ++uRotateIndex){   
      for (int i=0;i<max_n_per;++i){
    int inRank = (g_my_rank%(nProcs))+1;
    int outRank = ((g_my_rank+nProcs-2)%(nProcs))+1;
    char* outBuffer  = msaBuffers[i];
    int outSize = strlen(outBuffer)+1;
    int inSize;
    MPI::COMM_WORLD.Sendrecv(&outSize, 1, MPI::INT, outRank, 5,
                 &inSize, 1, MPI::INT, inRank, 5, status);
    char* inBuffer = (char*) malloc(inSize*sizeof(char));
    //    cout << g_my_rank << ":sending msa "<<
    //  foreign_MSA[i]->m_uGNodeIndex <<"to " <<outRank<<endl;
    MPI::COMM_WORLD.Sendrecv(outBuffer,outSize, MPI::CHAR,
                 outRank, tag,
                 inBuffer, inSize, MPI::CHAR,
                  inRank,
                 tag, status);
    //Deserialize    
    MSA *newMSA = new MSA;
    free(msaBuffers[i]); msaBuffers[i] = inBuffer;
    StringBuffer sb2 ;
    sb2.SetData(inBuffer);
    MSADeserialize(&newMSA, &sb2);
    foreign_MSA[i] = newMSA;
      }
      foreign_rank = (foreign_rank  % nProcs) + 1;
      n_foreign = n_node_split[foreign_rank];
      Interact_local(local_nodes, n_local, foreign_MSA, n_foreign);
      //free foreignMSA
    }//end rotate
  }// end else


  MPI::COMM_WORLD.Barrier();
  if (g_my_rank == 0)
    fprintf(stderr, "Finished initialization.\n");
}
#endif
#if 0
void GTree2::InitializeDist(SJPM *ptrMonitor, int numClusters){ // v2
  // Insert MPI Barrier - everyone catches up
  MPI::COMM_WORLD.Barrier(); 
  if (g_my_rank == 0)
    fprintf(stderr, "Initializing distance matrix(parallel)...numClusters: %u,\n", numClusters);

  unsigned uPairCount = numClusters*(numClusters - 1);
  unsigned uPairIndex = 0;
   MPI::Status status;

//MPI Globals: g_my_rank, g_numprocs, g_processor_name
  fprintf(stderr, "Hi, am am proc %d/%d on %s\n", 
      g_my_rank, g_numprocs, g_processor_name);
  
// split among nprocs, allocate space
  MPI::COMM_WORLD.Bcast(&numClusters,1, MPI::INT, 0);
  int *node_off = (int *)malloc ( (g_numprocs + 1) * sizeof(int));
  int *n_node_split = (int *)malloc ((g_numprocs) * sizeof(int));
  split_work(g_numprocs , numClusters , node_off, n_node_split);
  GNode2 **local_nodes=(GNode2 **)malloc(sizeof(GNode2 *)*n_node_split[1]);
  unsigned n_local = n_node_split[g_my_rank];
  unsigned max_n_per = n_node_split[1];
  // node 1 has max n_per

  int tag = 1;
  if (g_my_rank == 0){
    //MASTER: Send out work
    GNode2 *ptrGNode = m_ptrDisjoints;
    for(int proc_id = 0;proc_id< g_numprocs;++proc_id){ //foreach proc
      for (int j=0; j< n_node_split[proc_id] ;++j){ //each procs workload
    char *hmmBuffer ;
    ptrGNode->m_Model.Serialize(&hmmBuffer, ptrGNode->m_uNodeIndex);    //cout << "hmmBuffer(" << strlen(hmmBuffer) << ")" << hmmBuffer << endl;
    tag = ptrGNode->m_uNodeIndex;
    
    // send the buffer, remembering the null character
    int size = strlen(hmmBuffer) + 1;
    MPI::COMM_WORLD.Send (&size, 1, MPI::INT, proc_id, tag);
    MPI::COMM_WORLD.Send (hmmBuffer, size, MPI::CHAR, 
                  proc_id,tag);
    free(hmmBuffer);
    ptrGNode = ptrGNode->m_ptrNext;
      }
    }
    if (ptrGNode != 0)
      Quit("Error in BootstrapSatchmo::InitializeDist. sending out..");
    else cout << "Finished sending" << endl;
  }
  else {
    //    fprintf(stderr, "Recieving %u units..\n", n_node_split[g_my_rank]);
    //SLAVE: Recieve work
    for (int i=0; i< n_local ;++i){ // how many I'm expecting
      GNode2 *thisNode = new GNode2;
      local_nodes[i] = thisNode;
      int size;
      MPI::COMM_WORLD.Recv(&size, 1, MPI::INT, 0, MPI::ANY_TAG, status);
      char *hmmBuffer = (char *) malloc( sizeof(char) * size);
      
      MPI::COMM_WORLD.Recv(hmmBuffer, size, MPI::CHAR, 0, MPI::ANY_TAG, status);
      thisNode->m_Model.Deserialize(&hmmBuffer);
      free (hmmBuffer);
    }
    if(n_local < max_n_per){
      local_nodes[n_local] = local_nodes[n_local-1];
    }
  }
  MPI::COMM_WORLD.Barrier();

  // IntializeDistMatrix
      //create sizelist, serialized msas, broadcast
      int* sizeList = (int*) malloc (numClusters*sizeof(int));
      char** msas = (char**) malloc (numClusters * sizeof (char*));
      unsigned sum = 0;
      if(g_my_rank == 0){
    fprintf(stderr, "Serializing all...");
    GNode2* ptrGNode = m_ptrDisjoints;
    for(int i=0;i<numClusters;++i){
      StringBuffer *sb = new StringBuffer;
      MSASerialize(ptrGNode->m_Model.GetMSA(), sb, WWS_Always);
      msas[i] = sb->GetData();
      delete sb;
      sizeList[i] = strlen(msas[i]) + 1;
      sum += sizeList[i];
      ptrGNode = ptrGNode->m_ptrNext;
    }//end for
    if (ptrGNode != 0)
      fprintf(stderr, "Error in Bootstrap:InitializeDist.v2");
    fprintf(stderr, "done(Total size=%d).\n", sum);
      }
      MPI::COMM_WORLD.Bcast(sizeList,numClusters, MPI::INT, 0);
    //    cout << sizeList[0]<<" " <<sizeList[1]<<" "<<sizeList[2]<<endl;
    //create allmsas, broadcast
      MPI::COMM_WORLD.Bcast(&sum, 1, MPI::INT, 0);
      char *allmsas = (char *) malloc (sum * sizeof(char));
      unsigned pos = 0;
      if (g_my_rank == 0){
    for(int i=0;i<numClusters;++i){
      strcpy(allmsas+pos, msas[i]);
      //      cout << allmsas+pos << " ";
      pos += sizeList[i];
    }
    
      }
      MPI::COMM_WORLD.Bcast(allmsas, sum, MPI::CHAR, 0);
      if(g_my_rank==0) free(allmsas); //dont' need this anymore on master
        //parse msas, deserialize, create msapointers
      if (g_my_rank !=0){
    
     MSA **local_msas = (MSA **)malloc(numClusters * sizeof (MSA*));
     unsigned pos = 0;
     for(int i=0;i<numClusters;++i){
      StringBuffer *sb2 = new StringBuffer;
     
      sb2->SetData(allmsas+pos);
      MSA *newMSA = new MSA;
      MSADeserialize(&newMSA, sb2);
      local_msas[i] = newMSA;
      delete sb2;
      pos += sizeList[i];
    }
    free(allmsas);
    //interactlocal
    Interact_local(local_nodes, n_local, local_msas, numClusters);
       } else {int x,y; //If MASTER
    cout << "Expecting " << numClusters*(numClusters-1) << " scores" << endl;
//MASTER: Recieve results from all-pairs (except yourself)
    double *dists = (double *) malloc (sizeof(double)*numClusters*(numClusters-1));
    tag = 2;
    int total = numClusters*(numClusters-1);
    for(int i=0;i<total;++i){
      double d[3];
      MPI::COMM_WORLD.Recv(&d,3, MPI::DOUBLE, MPI::ANY_SOURCE,SCORE_PAIR, status);
      int rtag = status.Get_tag();
      //x =  TAG_TO_PAIR1(rtag); y= TAG_TO_PAIR2(rtag);
      //fprintf(stderr, "got %f from %d, %d : %d\n", d, TAG_TO_PAIR1(rtag),TAG_TO_PAIR2(rtag), status.Get_source());     
      ptrMonitor->OnIteration1(i, total);
      SetDist(m_ptrDisjoints, (int)d[1],(int)d[2],d[0]);
        }
       }
      //free sizelist
      free(sizeList); 
  MPI::COMM_WORLD.Barrier();
  if (g_my_rank == 0)
    fprintf(stderr, "Finished initialization.\n");
}
#endif
#if 1

void GTree2::InitializeDist(SJPM *ptrMonitor, int numClusters){  //v3 - loadbalance
  // Insert MPI Barrier - everyone catches up
  MPI::COMM_WORLD.Barrier();  
  if (g_my_rank == 0) 
    fprintf(stderr, "Initializing distance matrix(parallel)...numClusters: %u,\n", numClusters);
  unsigned uPairCount = numClusters*(numClusters - 1);
  unsigned uPairIndex = 0;
  MPI::Status status;
  HMM** local_hmms;
  
  //MPI Globals: g_my_rank, g_numprocs, g_processor_name
  fprintf(stderr, "Hi, am am proc %d/%d on %s\n", 
      g_my_rank, g_numprocs, g_processor_name);
  
  // split among nprocs, allocate space
  MPI::COMM_WORLD.Bcast(&numClusters,1, MPI::INT, 0);

  int tag = 1;
  // IntializeDistMatrix
      //create sizelist, serialized hmms, broadcast
      int* sizeList = (int*) malloc (numClusters*sizeof(int));
      char** hmms = (char**) malloc (numClusters * sizeof (char*));
      unsigned sum = 0;
      if(g_my_rank == 0){
    fprintf(stderr, "Serializing all...");
    GNode2* ptrGNode = m_ptrDisjoints;
    for(int i=0;i<numClusters;++i){
      char *strHMM;
      ptrGNode->m_Model.Serialize(&strHMM, ptrGNode->m_uNodeIndex);
      hmms[i] = strHMM;
      sizeList[i] = strlen(hmms[i]) + 1;
      sum += sizeList[i];
      ptrGNode = ptrGNode->m_ptrNext;
    }//end for
    if (ptrGNode != 0)
      fprintf(stderr, "Error in Bootstrap:InitializeDist.v2");
    fprintf(stderr, "done(Total size=%d).\n", sum);
      }
      MPI::COMM_WORLD.Bcast(sizeList,numClusters, MPI::INT, 0);
      //create allhmms, broadcast
      MPI::COMM_WORLD.Bcast(&sum, 1, MPI::INT, 0);
      char *allhmms = (char *) malloc (sum * sizeof(char));
      unsigned pos = 0;
      if (g_my_rank == 0){
    for(int i=0;i<numClusters;++i){
      strcpy(allhmms+pos, hmms[i]);
      free(hmms[i]); // don't need this anymore
      pos += sizeList[i];
    }
      }
      MPI::COMM_WORLD.Bcast(allhmms, sum, MPI::CHAR, 0);
      if(g_my_rank==0) free(allhmms); //dont' need this anymore on master
        //parse msas, deserialize, create msapointers
      if (g_my_rank !=0){
    
     local_hmms = (HMM **)malloc(numClusters * sizeof (HMM*));
     unsigned pos = 0;
     for(int i=0;i<numClusters;++i){
      char *strHMM = allhmms+pos;
      HMM *newHMM = new HMM;
      newHMM->Deserialize(&strHMM);
      local_hmms[i] = newHMM;
      pos += sizeList[i];
    }
    free(allhmms);

       } 
      free(sizeList);
      // now all nodes have all hmms
     
      if (g_my_rank == 0){
    int x,y; //If MASTER
    cout << "Expecting " << numClusters*(numClusters-1) << " scores" << endl;
    //MASTER: Recieve results from all-pairs (except yourself)
    int total = numClusters*(numClusters-1);
    int ScoresRecieved = 0, finishedNodes = 0;
    GNode2 *ptrHMMNode = m_ptrDisjoints;
    GNode2 *ptrMSANode = m_ptrDisjoints;
        while(ScoresRecieved < total || finishedNodes < g_numprocs - 1){
      double d[3];
      MPI::COMM_WORLD.Recv(&d,3, MPI::DOUBLE, MPI::ANY_SOURCE,MPI::ANY_TAG, status);
      int rtag = status.Get_tag();
      if (rtag == WORK_REQUEST){
        //cout << "Recieved WORK_REQUEST from " <<  status.Get_source() ;
        if (ptrHMMNode == 0){ // work finished
          double response = 0;
          finishedNodes++;
          MPI::COMM_WORLD.Send(&response,1, MPI::DOUBLE, status.Get_source(), WORK_REQUEST);
        } else { // still remaining work
          double response = 1;
           MPI::COMM_WORLD.Send(&response,1,MPI::DOUBLE,status.Get_source(), WORK_REQUEST);
          // (1) Send work request
          vector <GNode2*> hmmWork;
          vector <GNode2*> msaWork;
          hmmWork.push_back(ptrHMMNode);
          int workAssigned=0; while(workAssigned < WORK_UNIT){
        if (ptrMSANode != 0 ){
          msaWork.push_back(ptrMSANode);
          workAssigned++;
          ptrMSANode = ptrMSANode->m_ptrNext;
        } else {
          ptrHMMNode = ptrHMMNode->m_ptrNext;
          ptrMSANode = m_ptrDisjoints;
          break;
        }
          }
          int* HMMindicies = (int *) malloc(sizeof(int)*hmmWork.size());
          int* MSAindicies = (int *) malloc(sizeof(int)*msaWork.size());
          //  cout << "HMM: ";
          for(int i=0;i<hmmWork.size();++i){
        HMMindicies[i] = ((GNode2*)hmmWork[i])->m_uNodeIndex;
        //    cout << ((GNode2*)hmmWork.at(i))->m_uGNodeIndex <<" ";
          }
          //   cout << endl << "MSA: ";
          for(int i=0;i<msaWork.size();++i){
        MSAindicies[i] = ((GNode2*)msaWork[i])->m_uNodeIndex;
        //    cout << ((GNode2*)msaWork.at(i))->m_uGNodeIndex << " ";
          }
          MPI::COMM_WORLD.Send(HMMindicies, hmmWork.size(),MPI::INT,
                   status.Get_source(), WORK_REQUEST);
          MPI::COMM_WORLD.Send(MSAindicies, msaWork.size(),MPI::INT,
                   status.Get_source(), WORK_REQUEST);
          free(HMMindicies); free(MSAindicies);
          // cout << "..sent work\n";

        }
      }  else if (rtag == SCORE_PAIR) { //rtag = PAIR_SCORE
        //fprintf(stderr, "got %f from %f, %f : %d\n",d[0],d[1],d[2],status.Get_source()); 
        ScoresRecieved++;
        ptrMonitor->OnIteration1(ScoresRecieved, total);
        SetDist(m_ptrDisjoints,(int) d[1],(int) d[2],d[0]);
      } else 
        cout << "Invalid tag recieved! ";
    }
    cout << "All scores recieved" << endl;
      } else { // if SLAVE
    //request work
    double work = 10;
    MPI::COMM_WORLD.Send(&work, 1, MPI::DOUBLE, 0, WORK_REQUEST);
    MPI::COMM_WORLD.Recv(&work, 1, MPI::DOUBLE, 0, WORK_REQUEST);
    while (work != 0){
    // (1) Recieve work request
    // (a) recieve hmm indicies, recieve msa indicies
      int HMMindicies[WORK_UNIT]; int MSAindicies[WORK_UNIT];
      MPI::COMM_WORLD.Recv(HMMindicies, WORK_UNIT,MPI::INT,0,WORK_REQUEST, status);
      int numHMMs = status.Get_count(MPI::INT);
      MPI::COMM_WORLD.Recv(MSAindicies, WORK_UNIT,MPI::INT,0,WORK_REQUEST, status);
      int numMSAs = status.Get_count(MPI::INT);
          
      //do interact_local()
      //cout << g_my_rank << ":" << "Got "<<numHMMs<<" HMMs and "<<numMSAs<<" MSAs.\n";
      HMM** HMMNodes = (HMM** ) malloc (sizeof(HMM*)*numHMMs);
      //  cout << g_my_rank << ":" << "HMM: ";
      for(int i=0;i<numHMMs;++i){
        HMMNodes[i] = getNodeByIndex(local_hmms,numClusters, HMMindicies[i]);
        //    cout << HMMindicies[i] << " ";
      }
      //  cout << endl << g_my_rank << ":" << "MSA: ";
      MSA** MSANodes = (MSA**) malloc (sizeof(MSA*)*numMSAs);
      for(int i=0;i<numMSAs;++i){
        MSANodes[i] = ((HMM*)getNodeByIndex(local_hmms,numClusters, MSAindicies[i]))->GetMSA();
        //    cout << MSAindicies[i] << " ";
      }
      
      Interact_local(HMMNodes, numHMMs, MSANodes, numMSAs);
      free(HMMNodes), free(MSANodes);
      
      // request more work
      MPI::COMM_WORLD.Send(&work, 1, MPI::DOUBLE, 0, WORK_REQUEST);
      MPI::COMM_WORLD.Recv(&work, 1, MPI::DOUBLE, 0, WORK_REQUEST);
    }
    //    cout << g_my_rank << ": work finished" << endl;
      }
 
       MPI::COMM_WORLD.Barrier();
  if (g_my_rank == 0)
    fprintf(stderr, "Finished initialization.\n");
}

#endif
#endif

#ifndef PARALLEL
void GTree2::InitializeDist(SJPM *ptrMonitor, int numClusters){
    fprintf(stderr, "Initializing distance matrix.\n");
    unsigned uPairCount = numClusters*(numClusters - 1);
        
    unsigned uPairIndex = 0;
    for (GNode2 *ptrDisjointA = m_ptrDisjoints; ptrDisjointA;
      ptrDisjointA = ptrDisjointA->m_ptrNext)
        for (GNode2 *ptrDisjointB = m_ptrDisjoints; ptrDisjointB;
          ptrDisjointB = ptrDisjointB->m_ptrNext)
            {
            if (ptrDisjointA != ptrDisjointB)
                {
                ++uPairIndex;
                if (0 != ptrMonitor)
                    ptrMonitor->OnIteration1(uPairIndex, uPairCount);
                //ptrDisjointB->m_MSA.BuildPillars();    
                ScoreDisjointPair(ptrDisjointA, ptrDisjointB); 
                //ptrDisjointB->m_MSA.FreePillars();
                }
            }
    
    fprintf(stderr, "Finished initialization.\n");
}
#endif

#ifdef PARALLEL
void Interact_local(GNode2** local_nodes, int n_local_nodes, MSA** MSAs, int n_MSAs){
  // int numLocal = n_node_split[g_my_rank];
  
     for(int i=0;i<n_local_nodes;++i) for(int j=0;j<n_MSAs;++j){
        HMM &modelTpl = local_nodes[i]->m_Model;
        MSA *msaTarget = MSAs[j];
    if(modelTpl.GetMSA()->m_uGNodeIndex != msaTarget->m_uGNodeIndex){
      // calculate distance
      HMMPath MPP;
      SCORE Score;
     if ( g_strAlignStyle && 0 == strcmp(g_strAlignStyle, "global" ) )
        Score = modelTpl.ViterbiAln(*msaTarget, MPP);
     else if ( g_strAlignStyle &&  0 == strcmp(g_strAlignStyle, "fb" ))
         Score = modelTpl.FBAlign(*msaTarget, MPP); 
     else
        Score = modelTpl.ViterbiAlnLL(*msaTarget, MPP);
        
      double dDist = ScoreToDouble(Score)/(double) modelTpl.GetNodeCount();
      if (0 == modelTpl.GetNodeCount()){
        dDist = VERY_NEGATIVE_DOUBLE;
       }
      // send it
      double d[3];
      d[0] = dDist; 
      d[1] = modelTpl.GetMSA()->m_uGNodeIndex; 
      d[2] = msaTarget->m_uGNodeIndex;
      //      int tag = PAIR_TO_TAG(modelTpl.GetMSA()->m_uGNodeIndex,msaTarget->m_uGNodeIndex);
      MPI::COMM_WORLD.Send(&d,3, MPI::DOUBLE, 0, SCORE_PAIR);
      // cout << "sent a dist " << endl;
    }
      }
}
void Interact_local(HMM** HMMs, int n_HMMs, MSA** MSAs, int n_MSAs){
      for(int i=0;i<n_HMMs;++i) for(int j=0;j<n_MSAs;++j){
        HMM *modelTpl = HMMs[i];
        MSA *msaTarget = MSAs[j];
    if(modelTpl->GetMSA()->m_uGNodeIndex != msaTarget->m_uGNodeIndex){
      // calculate distance
      HMMPath MPP;
      SCORE Score;
     if ( g_strAlignStyle &&  0 == strcmp(g_strAlignStyle, "global" ) )
        Score = modelTpl->ViterbiAln(*msaTarget, MPP);
    else if ( g_strAlignStyle &&  0 == strcmp(g_strAlignStyle, "fb" ))
         Score = modelTpl->FBAlign(*msaTarget, MPP); 
    else
        Score = modelTpl->ViterbiAlnLL(*msaTarget, MPP);
      double dDist = ScoreToDouble(Score)/(double) modelTpl->GetNodeCount();
      if (0 == modelTpl->GetNodeCount()){
        dDist = VERY_NEGATIVE_DOUBLE;
       }
      // send it
      double d[3];
      d[0] = dDist; 
      d[1] = modelTpl->GetMSA()->m_uGNodeIndex; 
      d[2] = msaTarget->m_uGNodeIndex;
      // cout << "sending dist "<<d[0]<<"("<<d[1]<<","<<d[2]<<")"<<endl;
      MPI::COMM_WORLD.Send(&d,3, MPI::DOUBLE, 0, SCORE_PAIR);
    }
      }
}
#endif

void GTree2::SatchmoCluster(SJPM *ptrMonitor){
    unsigned uJoinCount = nClusters-1;
    for (unsigned uJoinIndex = 0; uJoinIndex < uJoinCount; ++uJoinIndex)
        {
        
        if (0 != ptrMonitor)
	  {
	    ptrMonitor->OnIteration2(uJoinIndex+1, uJoinCount);
	  }
	    bool bContinue = Iterate();
        if (!bContinue)
            {
            fprintf(stderr, "All HMMs have zero length, quitting.\n");
            List("All HMMs have zero length, quitting.\n");
            return;
            }
        //if (HomHack())//todo
        //    {
        //    m_ptrRoot = m_ptrDisjoints;
        //    return;//todo
        //    }
        }
 
}

// Process cluster.py
// imported 3/31
#define MAX_SUMMARY_LINE 500
void GTree2::ClusterPY(){

    fprintf(stderr, "From  cluster results directory: %s\n", g_strBSPath);
    unsigned uSeqCount = m_InputSeqs.Length();
    unsigned i, j;
    unsigned g_uAvgSeqLength = 100;
    FILE *m_pFile;
    unsigned uTotalLength = 0; 
    
    // parse summary file to get ClusterNames
    char *ClusterNames[uSeqCount];  // At most N clusters
    char summaryFile[200];
    strcpy(summaryFile, g_strBSPath);
    strcat(summaryFile, "summary-partition");
    TextFile File(summaryFile, false);
    char szLine[MAX_SUMMARY_LINE];
    File.GetLine(szLine, MAX_SUMMARY_LINE); //skip header line
    i=0;
    while(true != (File.GetLine(szLine, MAX_SUMMARY_LINE))){ // while still stuff
            ClusterNames[i] = strdup(strtok(szLine, " \t"));
            ++i;
    } nClusters = i;
    fprintf(stderr, "Summary file has %d clusters.\n", nClusters);
    
    // process clusters
    gIndex = 0;
    GNode2 *prevNode = m_Nodes[0];
    char strClusAlignment[1000];
    int flag1=0;
    int flag2=0;

     for(i=0;i<nClusters;i++){
     
    strcpy(strClusAlignment, g_strBSPath);
            strcat(strClusAlignment, ClusterNames[i]);
            strcat(strClusAlignment,  "/acceptedseqs.fa.muscle.a2m");
        m_pFile = fopen(strClusAlignment, "rb");
           if (0 == m_pFile){
               strcpy(strClusAlignment, g_strBSPath);
            strcat(strClusAlignment, ClusterNames[i]);
            strcat(strClusAlignment,  "/acceptedseqs.a2m");
               m_pFile = fopen(strClusAlignment, "rb");
           
           if (0 == m_pFile){
                       printf("Error! a2m file not found in cluster folder. \n");
                      return;
	   }
	   }
	   
	   
           printf("Using %s alignment.\n", strClusAlignment);
           
           GNode2 *ptrNode = m_Nodes[gIndex];    

           if (0 == fopen(strClusAlignment,"r")){
                       printf("Ah..Error! a2m file not found in cluster folder. \n");
	   } 
           fclose(m_pFile);
	   TextFile msaFile (strClusAlignment, false); 
	  fprintf (stderr, "read file %s.\n", strClusAlignment); 
          MSA msa; 
           msa.FromFASTAFile(msaFile);
	   
    //**************** Store MSA & HMM. I think we need this stuff..    **************/
        //    ptrMonitor->OnBuildLeaf(uNodeIndex+1, nClusters);
        int clustRootIndex = gIndex; 
        if (msa.GetSeqCount() == 1){ //if singleton
	  //use original seq as MSA
          printf ("singleton.\n"); 
	  char origSeq[1000];
            strcpy(origSeq, g_strBSPath);
            strcat(origSeq, ClusterNames[i]);
            strcat(origSeq,  "/acceptedseqs.fa");
             m_pFile = fopen(origSeq, "rb");
           fclose(m_pFile);
           fprintf (stderr, "using 1 %s.\n", origSeq);
           if (0 == m_pFile){
	     fprintf (stderr, "using 2 %s.\n", origSeq);
            strcpy(origSeq, g_strBSPath);
            strcat(origSeq, ClusterNames[i]);
            strcat(origSeq,  "/acceptedseqs.a2m");
	    fprintf (stderr, "using 3 %s.\n", origSeq);	 
             if (0 == fopen(origSeq,"rb"))
	 {  fprintf (stderr, "break\n");
	    break;
	 }// modified by Xia, if can't find file, then start cluster
           }    
           fclose(m_pFile);
            TextFile origFile (origSeq,false);    
         fprintf (stderr, "using 4 %s.\n", origSeq);
	    Seq seq;
            seq.FromFASTAFile(origFile);
               seq.ToUpper();
               MSA msa;
               msa.FromSeq(seq);               
               ptrNode->m_MSA.Copy(msa);
                ptrNode->m_MSA.AlignByCaseOrDash();
            //ptrNode->m_MSA.SetAllAligned();
            ptrNode->m_MSA.BuildPillars();
            
            ptrNode->m_Model.FromAln(ptrNode->m_MSA);

            uTotalLength += ptrNode->m_MSA.GetSeqLength(0);
                
            gIndex++; // increment NodeIndex
	   
        }else  {// if multi-node cluster            
            //start BETE                   

            Bete Set;
            Clust C;
            SetupBETE(&Set, &msa);
            C.Create(Set);
            //done BETE
            fprintf (stderr, "multinodes, after bete , clustering root node %u. \n", clustRootIndex);
            ClustnodeToGTree(&C.GetRoot(), m_Nodes, &Set );
            
            GNode2 *root = m_Nodes[clustRootIndex];
            
                root->m_MSA.AlignByCaseOrDash();
                root->m_MSA.BuildPillars(); 
                root->m_Model.FromAln(m_Nodes[clustRootIndex]->m_MSA);            
            
            //root->m_MSA.FreePillars();
        }//else  
        
        //link forest 
        if (clustRootIndex != 0 ){
            m_Nodes[clustRootIndex]->m_ptrPrev = prevNode;
        }
        prevNode = m_Nodes[clustRootIndex];        
	// if two seeds sequences are included, stop here
      if (g_strPairOnlyOne && g_strPairOnlyTwo)
        {
	   if (!strcmp( ClusterNames[i],g_strPairOnlyOne))
	{
	   fprintf(stderr,"sequence one: %s visited.\n",ClusterNames[i] );
	   flag1=1;   
	}
	 if (!strcmp( ClusterNames[i],g_strPairOnlyTwo))
	{
	    fprintf(stderr,"sequence one: %s visited.\n",ClusterNames[i] );
	    flag2=1;
	}
	 if (flag1 && flag2)
	   {
            i=nClusters;
	    fprintf (stderr,"both seeds joint, stop tree joining.\n");
	   }
	} 
   
 }// done all clusters_i
    fprintf(stderr, "Done cluster alignment.\n");
    g_uAvgSeqLength = uTotalLength / uSeqCount;  //not really true   
    fprintf(stderr, "Number of nodes seen: %u\n", gIndex);
    //Set m_ptrNext pointers
    GNode2 *thisNode = prevNode;
    while(0 != thisNode->m_ptrPrev){ //while not at head
        GNode2 *tNode = thisNode->m_ptrPrev;
        tNode->m_ptrNext = thisNode;
        thisNode = tNode;
    }
    m_ptrDisjoints = thisNode;
    if (m_ptrDisjoints != m_Nodes[0])
        Quit("Error in setting next pointers in BootstrapSatchmo::ClusterPY\n");
        
   // create JoinsSet
   m_ptrJoins = m_Nodes[gIndex];
   for (j = gIndex; j < m_uNodeCount; ++j)
        { 
        if (j > gIndex)
            m_Nodes[j]->m_ptrPrev = m_Nodes[j-1];
        if (j != m_uNodeCount - 1)
            m_Nodes[j]->m_ptrNext = m_Nodes[j+1];
        }

}
void printDisjointMSAs(GNode2 *thisNode){
while(thisNode != 0){
        fprintf(stderr, "Outputting node %u\n", thisNode->m_uNodeIndex);
        
        TextFile outFile("dist.txt" , true);
        thisNode->m_MSA.ToFASTAFile(outFile, WWS_Never); 
        
        thisNode = thisNode->m_ptrNext;
}
    
}
// Bootstrap
// Input: Gtree2 with sequences
// Output: Built tree with MSAs
void GTree2::Bootstrap(const SatchmoParams &SP, SJPM *ptrMonitor)
{  
    if (GetOptionalParam("threshold") != 0)
        dDistThreshold = atof(GetOptionalParam("threshold"));
    else dDistThreshold =1;
#ifdef PARALLEL    
if (g_my_rank == 0){
#endif
    fprintf(stderr, "Bootstrapping...");
  // GTree settings 
    m_SatchmoParams = SP; 
    m_ptrSJPM = ptrMonitor;
    m_InputSeqs.StripGaps();
    m_InputSeqs.ToUpper();
    uSeqCount= m_InputSeqs.Length();
    m_uNodeCount = 2*uSeqCount - 1;    
    m_Nodes = new GNode2*[m_uNodeCount];
    
    fprintf(stderr, "SeqCount: %u, NodeCount %u\n", uSeqCount, m_uNodeCount);
    
    if (0!= g_ptrSmoFile)
        g_ptrSmoFile->PutFormat("nodes %u\n", m_uNodeCount);
        
    TreeSetup();
    //BeteCluster(dDistThreshold); //beteCluster up to threshold
    ClusterPY(); 
#ifdef PARALLEL
}//end cpu0 tasks
#endif
    //printDisjointMSAs(m_ptrDisjoints);
    InitializeDist(ptrMonitor, nClusters);
#ifdef PARALLEL
if(g_my_rank==0){ //only cpu0 outputs
#endif    
    SatchmoCluster(ptrMonitor); //finish tree, for now

    assert(0 != m_ptrDisjoints);
    //    assert(0 == m_ptrJoins); //Xia -- only use for partly joining the tree for pw alignment
    assert(0 == m_ptrDisjoints->m_ptrNext);

    m_ptrRoot = m_ptrDisjoints;

    if (0 != g_ptrSmoFile)
        {
        WriteNodeToSmoFile(*g_ptrSmoFile, *m_ptrRoot, g_bSaveHMMs, g_bSaveMSS);
        g_ptrSmoFile->PutString(".\n");
        }
    fprintf(stderr, "Finished clustering.\n");
#ifdef PARALLEL    
    }//end cpu0 tasks
    MPI::Finalize();
#endif
} // done build

/**
splits the work
n_proc number of processors(including master)
n array storing number of units per proc
off array of offsets per proc
*/
 void split_work(const int np,int nClusters,  int* off, int* n){
   int n_per, pval; // num work units per processor
   int idx, num, p; 
   int n_proc  = np - 1;

   n_per = (nClusters + n_proc -1) / n_proc ;
   if (n_per < MIN_WORK_PER_PROC) n_per = MIN_WORK_PER_PROC;

   idx = 0;
   num = n_per;
   pval = nClusters - n_proc * (nClusters/n_proc) + 1;
   if (pval == 1) pval = n_proc + 1;
   n[0]=0; off[0]=0;
   for (p = 1; p < n_proc + 1; ++p){
     if (p == pval) --num;
     n[p] = num;
     off[p] = idx;
     idx += num;
   }
   off[p] = idx;
   // fprintf(stderr, "n_per:%u, %u", nClusters, n[g_my_rank]);
 }

HMM* getNodeByIndex(HMM** hmmArray, int size, int index){
  for(int i=0;i<size;++i){
    if (hmmArray[i]->GetMSA()->m_uGNodeIndex == index)
      return hmmArray[i];
  }
  fprintf(stderr, "Error(BootstrapSatchmo::GetNodeByIndex): tried to find nonexistent node");
  exit(0);
  return NULL;
}
