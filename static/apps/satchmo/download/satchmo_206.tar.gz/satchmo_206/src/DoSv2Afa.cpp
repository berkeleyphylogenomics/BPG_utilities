// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "GTree2.h"
#include "GNode2.h"
#include "MSA.h"

void DoSv2Afa(const char *strSVFileName, const char *strFASTAFileName)
    {
    TextFile SVFile(strSVFileName);
    GTree2 SV;
    SV.FromSVFile(SVFile);
    const GNode2 *ptrRoot = SV.GetRoot();
    if (NULL == ptrRoot)
        Quit("No root node in .sv file");
    const MSA &a = ptrRoot->m_MSA;

    TextFile FASTAFile(strFASTAFileName, true);
    a.ToFASTAFile(FASTAFile);
    }
