// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMMPath.h"
#include "EnumPaths.h"

class EPS : public EnumPathsSink
    {
public:
    EPS() {}
    virtual ~EPS() {}

    virtual void OnPath(const HMMPath &Path)
        {
//        List("TestEnumPaths::OnPath\n");
        Path.ListMe();
        }
    };

// ProcessPath not used but retained in case useful for debugging later.
static void ProcessPath(unsigned uNodeCount, unsigned uSeqLength, unsigned uEmitterStateCount,
  unsigned uNLength, unsigned uMatchStateCount, unsigned MatchStates[],
  unsigned uInsertStateCount, unsigned InsertStates[], unsigned InsertStateVisits[])
    {
    char MorD[4096];
    for (unsigned n = 0; n < uNodeCount; ++n)
        MorD[n] = 'D';
    for (unsigned n = 0; n < uMatchStateCount; ++n)
        MorD[MatchStates[n]] = 'M';
    unsigned InsertStateCounts[4096];
    for (unsigned n = 0; n < uNodeCount; ++n)
        InsertStateCounts[n] = 0;
    for (unsigned n = 0; n < uInsertStateCount; ++n)
        InsertStateCounts[InsertStates[n]] = InsertStateVisits[n];
    unsigned uPos = uNLength;
    for (unsigned n = 0; n < uNodeCount; ++n)
        {
        if (n > 0)
            printf("->");
        if (MorD[n] != 'D')
            ++uPos;
        printf("%c%u/%u", MorD[n], n, uPos);
        unsigned c = InsertStateCounts[n];
        for (unsigned i = 0; i < c; ++i)
            {
            ++uPos;
            printf("->I%u/%u", n, uPos);
            }
        }
    printf("\n");
    }

void TestEnumPaths(int argc, char *argv[])
    {
    if (argc != 3)
        {
        fprintf(stderr, "Args: <nodes> <seqlength>\n");
        exit(1);
        }
    unsigned uNodeCount = (unsigned) atol(argv[1]);
    unsigned uSeqLength = (unsigned) atol(argv[2]);
    List("Test EnumPaths NodeCount=%u SeqLength=%u\n", uNodeCount, uSeqLength);
    EPS e;
    EnumPaths(uNodeCount, uSeqLength, GLOBAL_MODEL, LOCAL_SEQ, e);
    }

void TestPartitionsAndChains(int argc, char *argv[])
    {
    extern bool NextPartition(unsigned j, unsigned N, unsigned Parts[], bool &bFirst);
    extern bool NextChain(unsigned j, unsigned N, unsigned Parts[], bool &bFirst);

    if (argc != 3)
        {
        fprintf(stderr, "Args: j N\n");
        exit(1);
        }
    unsigned j = (unsigned) atol(argv[1]);
    unsigned N = (unsigned) atol(argv[2]);
    printf("j=%u N=%u\n", j, N);
    printf("Partitions:\n");
    bool bFirst = true;
    unsigned *Parts = new unsigned[j];
    while (NextPartition(j, N, Parts, bFirst))
        {
        for (unsigned i = 0; i < j; ++i)
            printf(" %u", Parts[i]);
        printf("\n");
        }

    printf("Links:\n");
    bFirst = true;
    unsigned *Links = new unsigned[j];
    while (NextChain(j, N, Links, bFirst))
        {
        for (unsigned i = 0; i < j; ++i)
            printf(" %u", Links[i]);
        printf("\n");
        }
    }
