// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "MSA.h"

#ifndef    VERBOSE
#define    VERBOSE 0
#endif

SCORE HMM::ScoreFromPaths(const HMMPath &Route, const MSA &a) const
    {
#if    VERBOSE
    List("ScoreFromPaths, Aln:\n");
    a.ListMe();
    List("Route:\n");
    Route.ListMe();
#endif
    SCORE Score = 0;
    const unsigned uSeqCount = a.GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        HMMPath Path;
        RouteToPath(Route, a, uSeqIndex, Path);
#if    VERBOSE
        List("Seq %d Path:\n", uSeqIndex);
        Path.ListMe();
#endif
        SCORE scorePath = ScorePathAlnSeq(Path, a, uSeqIndex);
        WCOUNT wcSeq = a.GetSeqWeight(uSeqIndex);
        SCORE scorePathWeighted;
        MulScoreWeight(scorePathWeighted, scorePath, wcSeq);
#if    VERBOSE
        List("Path score = %s *weight(%s) = %s\n",
          ScoreToStr(scorePath),
          WCountToStr(wcSeq),
          ScoreToStr(scorePathWeighted));
#endif
        Score += scorePathWeighted;
        }
#if    VERBOSE
    List("Total score = %s\n",
      ScoreToStr(Score));
#endif
    return Score;
    }
