// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "DataBuffer.h"

void MSA::GapInfoToDataBuffer(DataBuffer &Buffer) const
    {
    const unsigned uPillarCount = GetPillarCount();

    const WCOUNT wcNIC = GetEffectiveNIC();    // **** TODO ****

    const unsigned uBEBytes = (uPillarCount + 1)*sizeof(FCOUNT);
    const unsigned uBLBytes = (uPillarCount + 1)*sizeof(FCOUNT);
    const unsigned uBGBytes = (uPillarCount + 1)*sizeof(FCOUNT);
    const unsigned uBTBytes = uPillarCount*sizeof(FCOUNT);

    const unsigned uPillarBytes = uBEBytes + uBLBytes + uBGBytes + uBTBytes;

    const unsigned uPillarBytesTotal = uPillarBytes*uPillarCount;
    const unsigned uBytes = uPillarBytes + sizeof(uPillarCount) + sizeof(wcNIC);

    Buffer.SetSize(uBytes);

    unsigned uPos = 0;

    Buffer.Put(uPos, &uPillarCount, sizeof(uPillarCount));
    uPos += sizeof(uPillarCount);

    Buffer.Put(uPos, &wcNIC, sizeof(wcNIC));
    uPos += sizeof(wcNIC);

    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
        {
        const PILLAR &Pillar = GetPillar(uPillarIndex);

        Buffer.Put(uPos, Pillar.m_fcBL, uBLBytes);
        uPos += uBLBytes;

        Buffer.Put(uPos, Pillar.m_fcBG, uBGBytes);
        uPos += uBGBytes;

        Buffer.Put(uPos, Pillar.m_fcBG, uBGBytes);
        uPos += uBGBytes;

        Buffer.Put(uPos, Pillar.m_fcBT, uBTBytes);
        uPos += uBTBytes;
        }
    assert(uPos == uBytes);
    }

void MSA::GapInfoFromDataBuffer(const DataBuffer &Buffer)
    {
    unsigned uPos = 0;

    unsigned uPillarCount;
    Buffer.Get(uPos, &uPillarCount, sizeof(uPillarCount));
    uPos += sizeof(uPillarCount);

    unsigned wcNIC;
    Buffer.Get(uPos, &wcNIC, sizeof(wcNIC));
    uPos += sizeof(wcNIC);

    const unsigned uBEBytes = (uPillarCount + 1)*sizeof(FCOUNT);
    const unsigned uBLBytes = (uPillarCount + 1)*sizeof(FCOUNT);
    const unsigned uBGBytes = (uPillarCount + 1)*sizeof(FCOUNT);
    const unsigned uBTBytes = uPillarCount*sizeof(FCOUNT);

    m_Pillars = new PILLAR[uPillarCount];
    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
        {
        PILLAR &Pillar = m_Pillars[uPillarIndex];

        Pillar.m_fcBE = new FCOUNT[uPillarCount+1];
        Pillar.m_fcBL = new FCOUNT[uPillarCount+1];
        Pillar.m_fcBG = new FCOUNT[uPillarCount+1];
        Pillar.m_fcBT = new FCOUNT[uPillarCount];

        Pillar.m_wcBE = new WCOUNT[uPillarCount+1];
        Pillar.m_wcBL = new WCOUNT[uPillarCount+1];
        Pillar.m_wcBG = new WCOUNT[uPillarCount+1];
        Pillar.m_wcBT = new WCOUNT[uPillarCount];

        Buffer.Get(uPos, Pillar.m_fcBL, uBLBytes);
        uPos += uBLBytes;

        Buffer.Get(uPos, Pillar.m_fcBG, uBGBytes);
        uPos += uBGBytes;

        Buffer.Get(uPos, Pillar.m_fcBG, uBGBytes);
        uPos += uBGBytes;

        Buffer.Get(uPos, Pillar.m_fcBT, uBTBytes);
        uPos += uBTBytes;

        for (unsigned n = 0; n < uPillarCount; ++n)
            {
            Pillar.m_wcBE[n] *= wcNIC;
            Pillar.m_wcBL[n] *= wcNIC;
            Pillar.m_wcBG[n] *= wcNIC;
            Pillar.m_wcBT[n] *= wcNIC;
            }
        Pillar.m_wcBE[uPillarCount] *= wcNIC;
        Pillar.m_wcBL[uPillarCount] *= wcNIC;
        Pillar.m_wcBG[uPillarCount] *= wcNIC;
        }
    }
