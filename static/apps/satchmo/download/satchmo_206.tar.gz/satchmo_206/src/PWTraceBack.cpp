// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWScore.h"
#include "PWPath.h"

#define VERBOSE    0

// Macros to simulate 2D matrices
#define DPM(PLA, PLB)    DPM_[(PLA)*uPrefixCountB + (PLB)]
#define DPD(PLA, PLB)    DPD_[(PLA)*uPrefixCountB + (PLB)]
#define DPI(PLA, PLB)    DPI_[(PLA)*uPrefixCountB + (PLB)]
#define TBM(PLA, PLB)    TBM_[(PLA)*uPrefixCountB + (PLB)]
#define TBD(PLA, PLB)    TBD_[(PLA)*uPrefixCountB + (PLB)]
#define TBI(PLA, PLB)    TBI_[(PLA)*uPrefixCountB + (PLB)]

// Determine starting point in traceback -- identify
// highest-scoring entry consistent with boundary conditions.
static SCORE FindStart(const PWScore &PWS, const SCORE *DPM_, const SCORE *DPD_,
  const SCORE *DPI_, unsigned *puPrefixLengthA, unsigned *puPrefixLengthB,
  char *pcEdgeType)
    {
    const unsigned uLengthA = PWS.GetLengthA();
    const unsigned uLengthB = PWS.GetLengthB();
    const unsigned uPrefixCountA = uLengthA + 1;
    const unsigned uPrefixCountB = uLengthB + 1;
    BOUNDS boundsA = PWS.GetBoundsA();
    BOUNDS boundsB = PWS.GetBoundsB();
    SCORE scoreMax = MINUS_INFINITY;
    unsigned uPrefixLengthA = uInsane;
    unsigned uPrefixLengthB = uInsane;
    char cEdgeType = cInsane;

    for (unsigned uPLA = 0; uPLA < uPrefixCountA; ++uPLA)
        {
        if (GLOBAL == boundsA && (uPLA != 0 && uPLA != uPrefixCountA - 1))
            continue;
        for (unsigned uPLB = 0; uPLB < uPrefixCountB; ++uPLB)
            {
            if (GLOBAL == boundsB && (uPLB != 0 && uPLB != uPrefixCountB - 1))
                continue;
            SCORE ScoreI = DPI(uPLA, uPLB) + PWS.ScoreIE(uPLA, uPLB);
            if (ScoreI > scoreMax)
                {
                scoreMax = ScoreI;
                cEdgeType = 'I';
                uPrefixLengthA = uPLA;
                uPrefixLengthB = uPLB;
                }
            SCORE ScoreD = DPD(uPLA, uPLB) + PWS.ScoreDE(uPLA, uPLB);
            if (ScoreD > scoreMax)
                {
                scoreMax = ScoreD;
                cEdgeType = 'D';
                uPrefixLengthA = uPLA;
                uPrefixLengthB = uPLB;
                }
            SCORE ScoreM = DPM(uPLA, uPLB) + PWS.ScoreME(uPLA, uPLB);
            if (ScoreM >= scoreMax)
                {
                scoreMax = ScoreM;
                cEdgeType = 'M';
                uPrefixLengthA = uPLA;
                uPrefixLengthB = uPLB;
                }
            }
        }
    assert(MINUS_INFINITY != scoreMax);
    *puPrefixLengthA = uPrefixLengthA;
    *puPrefixLengthB = uPrefixLengthB;
    *pcEdgeType = cEdgeType;
    return scoreMax;
    }

SCORE PWTraceBack(const PWScore &PWS, const SCORE *DPM_, const SCORE *DPD_,
  const SCORE *DPI_, const char *TBM_, const char *TBD_, const char *TBI_,
  PWPath &Path)
    {
    const unsigned uLengthA = PWS.GetLengthA();
    const unsigned uLengthB = PWS.GetLengthB();
    assert(uLengthB > 0 && uLengthA > 0);

    const unsigned uPrefixCountA = uLengthA + 1;
    const unsigned uPrefixCountB = uLengthB + 1;

    Path.Clear();

    unsigned uPrefixLengthA = uInsane;
    unsigned uPrefixLengthB = uInsane;
    char cEdgeType = cInsane;
    SCORE scoreMax = FindStart(PWS, DPM_, DPD_, DPI_, &uPrefixLengthA,
      &uPrefixLengthB, &cEdgeType);

#if    VERBOSE
    SCORE scoreTotal = PWS.ScoreTrans(cEdgeType, 'E', uPrefixLengthA, uPrefixLengthB);
    List("\nPWTraceBack FindStart scoreMax=%s\n", ScoreToStr(scoreMax));
    List("Edge %cE%u.%u trans=%s               total=%s\n",
      cEdgeType,
      uPrefixLengthA,
      uPrefixLengthB,
      ScoreToStr(scoreTotal),
      ScoreToStr(scoreTotal));
#endif

    for (;;)
        {
        if ('S' == cEdgeType)
            break;

        PWEdge Edge;
        Edge.cType = cEdgeType;
        Edge.uPrefixLengthA = uPrefixLengthA;
        Edge.uPrefixLengthB = uPrefixLengthB;
        Path.PrependEdge(Edge);
        char cPrevEdgeType;
        unsigned uPrevPrefixLengthA = uPrefixLengthA;
        unsigned uPrevPrefixLengthB = uPrefixLengthB;
        switch (cEdgeType)
            {
        case 'M':
            cPrevEdgeType = TBM(uPrefixLengthA, uPrefixLengthB);
            --uPrevPrefixLengthA;
            --uPrevPrefixLengthB;
            break;
        case 'D':
            cPrevEdgeType = TBD(uPrefixLengthA, uPrefixLengthB);
            --uPrevPrefixLengthA;
            break;
        case 'I':
            cPrevEdgeType = TBI(uPrefixLengthA, uPrefixLengthB);
            --uPrevPrefixLengthB;
            break;
        default:
            assert(false);
            }
#if    VERBOSE
        {
        SCORE scoreTrans = PWS.ScoreTrans(cPrevEdgeType, cEdgeType,
          uPrefixLengthA, uPrefixLengthB);
        SCORE scoreEmit = PWS.ScoreEmit(cEdgeType, uPrefixLengthA, uPrefixLengthB);
        scoreTotal = Add3(scoreTotal, scoreTrans, scoreEmit);
        List("Edge %c%c%u.%u trans=%s emit=%s total=%s\n",
          cPrevEdgeType,
          cEdgeType,
          uPrefixLengthA,
          uPrefixLengthB,
          ScoreToStr(scoreTrans),
          ScoreToStr(scoreEmit),
          ScoreToStr(scoreTotal));
        }
#endif
        cEdgeType = cPrevEdgeType;
        uPrefixLengthA = uPrevPrefixLengthA;
        uPrefixLengthB = uPrevPrefixLengthB;
        }

    SCORE scoreFromPath = PWScorePath(PWS, Path);
    if (!ScoreEq(scoreFromPath, scoreMax))
        {
        List("\n***WARNING*** PWTraceBack: scoreTotal=%s scoreMax=%s\n",
          ScoreToStr(scoreFromPath),
          ScoreToStr(scoreMax));
        Path.ListMe();
        }
    return scoreMax;
    }
