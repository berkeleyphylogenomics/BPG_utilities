// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "MSA.h"
#include "DirMix.h"
#include "TransPrior.h"

void HMM::FromAln(MSA &Aln)
    {
    Clear();

    m_ptrTemplate = &Aln; 

    m_uNodeCount = Aln.GetAlignedColCount();
    if (0 == m_uNodeCount)
        return;

    m_Nodes = new HMMNode[m_uNodeCount];

// Transition distribution from initial FIM to 
// M0 or D0 is special case.
    NodeCounts Counts;
    Aln.GetNodeCounts(0, Counts);

// Add one to observed counts as ad-hoc pseudo-count prior.
    WCOUNT wcM = Counts.m_wcResidues + IntToWCount(1);
    WCOUNT wcD = Counts.m_wcGaps + IntToWCount(1);

// Convert to probability distribution.
// It's not clear that this is probabilistically correct, the distribution
// should probably be the three transitions FIM->FIM, FIM->M, FIM->D.
// However, the difference is small; given the pseudo-count hack
// we don't care that much about rigor.
    PROB probM = (PROB) wcM/(PROB) (wcM + wcD);
    PROB probD = (PROB) 1.0 - probM;
    m_scoreFirstM = ProbToScore(probM) - GetNullEmitTransScore();
    m_scoreFirstD = ProbToScore(probD);

    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        Aln.GetNodeCounts(uNodeIndex, Counts);
        NodeFromCounts(uNodeIndex, Counts);
        }
    CalcStateEntries();
    }

void HMM::NodeFromCounts(unsigned uNodeIndex, const NodeCounts &Counts)
    {
    assert(uNodeIndex < m_uNodeCount);
    HMMNode &Node = m_Nodes[uNodeIndex];
    PROB Probs[MAX_ALPHA];

    g_ptrdirmixMatchEmitPrior->CountsToProbs(Counts.m_wcMatchEmit, Probs);
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        Node.m_scoreMatchEmit[uLetter] = ProbToScore(Probs[uLetter]) -
          GetNullEmitScore(uLetter);

    if (m_uNodeCount - 1 == uNodeIndex)
        {
        Node.m_scoreMM = MINUS_INFINITY;
        Node.m_scoreMD = MINUS_INFINITY;
        Node.m_scoreMI = MINUS_INFINITY;
        Node.m_scoreDM = MINUS_INFINITY;
        Node.m_scoreDD = MINUS_INFINITY;
        Node.m_scoreDI = MINUS_INFINITY;
        Node.m_scoreIM = MINUS_INFINITY;
        Node.m_scoreID = MINUS_INFINITY;
        Node.m_scoreII = MINUS_INFINITY;
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            Node.m_scoreInsertEmit[uLetter] = MINUS_INFINITY;
        return;
        }

    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        Node.m_scoreInsertEmit[uLetter] = 0;

    WCOUNT wcTrans[3];

    wcTrans[DP_MtoM] = Counts.m_wcMM;
    wcTrans[DP_MtoD] = Counts.m_wcMD;
    wcTrans[DP_MtoI] = Counts.m_wcMI;
    g_ptrdirmixMatchTransPrior->CountsToProbs(wcTrans, Probs);
    Node.m_scoreMM = ProbToScore(Probs[DP_MtoM]) - GetNullEmitTransScore();
    Node.m_scoreMD = ProbToScore(Probs[DP_MtoD]);
    Node.m_scoreMI = ProbToScore(Probs[DP_MtoI]) - GetNullEmitTransScore();

    wcTrans[DP_DtoM] = Counts.m_wcDM;
    wcTrans[DP_DtoD] = Counts.m_wcDD;
    wcTrans[DP_DtoI] = Counts.m_wcDI;
    g_ptrdirmixDeleteTransPrior->CountsToProbs(wcTrans, Probs);
    Node.m_scoreDM = ProbToScore(Probs[DP_DtoM]) - GetNullEmitTransScore();
    Node.m_scoreDD = ProbToScore(Probs[DP_DtoD]);
    Node.m_scoreDI = ProbToScore(Probs[DP_DtoI]) - GetNullEmitTransScore();

    wcTrans[DP_ItoM] = Counts.m_wcIM;
    wcTrans[DP_ItoD] = Counts.m_wcID;
    wcTrans[DP_ItoI] = Counts.m_wcII;
    g_ptrdirmixInsertTransPrior->CountsToProbs(wcTrans, Probs);
    Node.m_scoreIM = ProbToScore(Probs[DP_ItoM]) - GetNullEmitTransScore();
    Node.m_scoreID = ProbToScore(Probs[DP_ItoD]);
    Node.m_scoreII = ProbToScore(Probs[DP_ItoI]) - GetNullEmitTransScore();
    }

void HMM::CalcStateEntries()
    {
    const unsigned uNodeCount = GetNodeCount();
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        HMMNode &Node = m_Nodes[uNodeIndex];
        {
        PROB probMM = ScoreToProb(Node.m_scoreMM + GetNullEmitTransScore());
        PROB probDM = ScoreToProb(Node.m_scoreDM + GetNullEmitTransScore());
        PROB probIM = ScoreToProb(Node.m_scoreIM + GetNullEmitTransScore());
//        Node.m_scoreXM = ProbToScore((probMM + probDM + probIM)/3) - GetNullEmitTransScore();
//        PROB probMax = Max3(probMM, probDM, probIM);
        PROB probApprox = probDM;
        Node.m_scoreXM = ProbToScore(probApprox) - GetNullEmitTransScore();
        }

        {
        PROB probMD = ScoreToProb(Node.m_scoreMD);
        PROB probDD = ScoreToProb(Node.m_scoreDD);
        PROB probID = ScoreToProb(Node.m_scoreID);
//        Node.m_scoreXD = ProbToScore((probMD + probDD + probID)/3)  - GetNullEmitTransScore();
//        PROB probMax = Max3(probMD, probDD, probID);
        PROB probApprox = probMD;
        Node.m_scoreXD = ProbToScore(probApprox) - GetNullEmitTransScore();
        }

        {
        PROB probMI = ScoreToProb(Node.m_scoreMI + GetNullEmitTransScore());
        PROB probDI = ScoreToProb(Node.m_scoreDI + GetNullEmitTransScore());
        PROB probII = ScoreToProb(Node.m_scoreII + GetNullEmitTransScore());
//        Node.m_scoreXI = ProbToScore((probMI + probDI + probII)/3) - GetNullEmitTransScore();
//        PROB probMax = Max3(probMI, probDI, probII);
        PROB probApprox = probMI;
        Node.m_scoreXI = ProbToScore(probApprox) - GetNullEmitTransScore();
        }
        }
    }
