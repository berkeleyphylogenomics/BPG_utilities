// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    GTree2_h
#define GTree2_h

#include "SeqVect.h"
#include "SatchmoParams.h"

class GNode2;
class HMM;
class HMMPath;
class SJPM;
class SeqVect;
class TextFile;

class GTree2
    {
public:
    GTree2()
        {
        m_ptrDisjoints = 0;
        m_ptrJoins = 0;
        m_ptrRoot = 0;
        m_Nodes = 0;
        m_ptrSJPM = 0;
        m_dBuildSecs = (time_t) uInsane;
        }
    virtual ~GTree2();

public:
    void Build(const SatchmoParams &SP, SJPM *ptrMonitor);
    void SetInputSeqs(const SeqVect &Seqs);

    void FromSVFile(TextFile &File);
    void ToPhylipFile(TextFile &File);

    GNode2 *GetRoot();
    GNode2 *GetNode(unsigned uNodeIndex);
    unsigned GetNodeCount() const;
    unsigned GetLeafCount() const;
    unsigned GetJoinCount() const;
    double GetDist(unsigned uNodeIndexA, unsigned uNodeIndexB);
    void Clear();

    bool HasTree() { return 0 != m_ptrRoot; }

    SatchmoParams &GetSatchmoParams() { return m_SatchmoParams; }

    void Validate() const;

    void Bootstrap(const SatchmoParams &SP, SJPM *ptrMonitor);
    void BeteCluster(const double dDistThreshold);
    void ClusterPY();
    
private:
    void ToGtreeNode(TextFile &File, GNode2 *ptrNode, bool bSaveHMMs);
    void Free();
    void FreeSubtree(GNode2 *ptrRoot);
    void ToPhylipNode(TextFile &File, GNode2 *ptrNode);

    bool Iterate();
    int Iterate2(int tgt_index, int tpt_index);// only for pairwise joining satchmo--xia
    void ScoreDisjointPair(GNode2 *ptrDisjointA, GNode2 *ptrDisjointB);
    double Distance(GNode2 *ptrDisjointTpl, GNode2 *ptrDisjointTgt);
    void Join2( MSA &msaTarget, HMM &modelTpl, MSA &msaJoined,
      HMM &modelJoined, HMMPath &MPP, double &dRawNIC);

    void FromGtreeNode(TextFile &File, GNode2 *ptrNode);
    void SetNodesTable(GNode2 *ptrNode);
//    bool HomHack();//todo

    unsigned TreeSize(const GNode2 *ptrRoot) const;
    unsigned ForestSize(const GNode2 *ptrForest) const;

    void TreeSetup();
    void InitializeDist(SJPM *ptrMonitor, int nClusters);
    void SatchmoCluster(SJPM *ptrMonitor);
private:
    GNode2 *m_ptrDisjoints;
    GNode2 *m_ptrJoins;
    GNode2 *m_ptrRoot;
    GNode2 **m_Nodes;
    unsigned m_uNodeCount;

    SatchmoParams m_SatchmoParams;

    SeqVect m_InputSeqs;
    SeqVect m_Homologs;
    SJPM *m_ptrSJPM;

    double m_dBuildSecs;
    };

#endif    // GTree_h
