// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.
#ifndef    MSA_h
#define MSA_h  

const int MAX_SEQ_NAME = 63;
enum BUILD_METHOD;
enum ALPHABET;
struct PathEdge;
class TextFile;
class Seq;
class ClusterNode;
class NodeCounts;
class DataBuffer;

enum WRITE_WEIGHT_STYLE
    {
    WWS_Undefined,
    WWS_Always,
    WWS_Never,
    WWS_IfFoundInInputFile,
    };

struct COLINFO
    {
    COLINFO()
        {
        m_bAligned = false;
        m_iTemplateColIndex = -1;
        m_iTargetColIndex = -1;
        m_iNodeIndex = -1;
        m_iPillarIndex = -1;
        m_scoreEmit = -1;
        m_scoreAvgAffinity = -1;
        }
    bool m_bAligned;
    int m_iTemplateColIndex;
    int m_iTargetColIndex;
    int m_iNodeIndex;
    int m_iPillarIndex;
    SCORE m_scoreEmit;
    SCORE m_scoreAvgAffinity;
    };

class PILLAR
    {
public:
    void Init(unsigned uPillarCount, unsigned uSeqCount)
        {
        m_wcE = 0;
        m_wcF = 0;
        m_wcFF = 0;
        m_wcEF = 0;
        m_wcFE = 0;
        m_wcEE = 0;
        m_wcT = 0;
        m_bAligned = false;

        memset(m_wcResCounts, 0, MAX_ALPHA*sizeof(WCOUNT));
        memset(m_fcResCounts, 0, MAX_ALPHA*sizeof(FCOUNT));

    // Need pauses temporarily to compute FF, EF, FE, EE
    // even if not using break matrices.
        m_Pause = new bool[uSeqCount];
        memset(m_Pause, 0, uSeqCount*sizeof(bool));

        if (g_bUseBreakMatrices)
            {
            m_wcBE = new WCOUNT[uPillarCount+1];
            m_wcBL = new WCOUNT[uPillarCount+1];
            m_wcBG = new WCOUNT[uPillarCount+1];
            m_wcBT = new WCOUNT[uPillarCount];

            memset(m_wcBE, 0, (uPillarCount+1)*sizeof(WCOUNT));
            memset(m_wcBL, 0, (uPillarCount+1)*sizeof(WCOUNT));
            memset(m_wcBG, 0, (uPillarCount+1)*sizeof(WCOUNT));
            memset(m_wcBT, 0, uPillarCount*sizeof(WCOUNT));

            m_fcBE = new FCOUNT[uPillarCount+1];
            m_fcBL = new FCOUNT[uPillarCount+1];
            m_fcBG = new FCOUNT[uPillarCount+1];
            m_fcBT = new FCOUNT[uPillarCount];

            memset(m_fcBE, 0, (uPillarCount+1)*sizeof(FCOUNT));
            memset(m_fcBL, 0, (uPillarCount+1)*sizeof(FCOUNT));
            memset(m_fcBG, 0, (uPillarCount+1)*sizeof(FCOUNT));
            memset(m_fcBT, 0, uPillarCount*sizeof(FCOUNT));
            }
        else
            {
            m_wcBE = 0;
            m_wcBL = 0;
            m_wcBG = 0;
            m_wcBT = 0;
            m_fcBE = 0;
            m_fcBL = 0;
            m_fcBG = 0;
            m_fcBT = 0;
            }
        }
    ~PILLAR()
        {
        delete[] m_Pause;
        delete[] m_fcBE;
        delete[] m_fcBL;
        delete[] m_fcBG;
        delete[] m_fcBT;
        delete[] m_wcBE;
        delete[] m_wcBL;
        delete[] m_wcBG;
        delete[] m_wcBT;
        }
    bool m_bAligned;
    unsigned m_uFromColIndex;
    unsigned m_uToColIndex;
    bool *m_Pause;

    WCOUNT m_wcE;
    WCOUNT m_wcF;
    WCOUNT m_wcFF;
    WCOUNT m_wcEF;
    WCOUNT m_wcFE;
    WCOUNT m_wcEE;
    WCOUNT m_wcT;
    WCOUNT *m_wcBE;
    WCOUNT *m_wcBL;
    WCOUNT *m_wcBG;
    WCOUNT *m_wcBT;
    WCOUNT m_wcResCounts[MAX_ALPHA];

    FCOUNT m_fcE;
    FCOUNT m_fcF;
    FCOUNT m_fcFF;
    FCOUNT m_fcEF;
    FCOUNT m_fcFE;
    FCOUNT m_fcEE;
    FCOUNT m_fcT;
    FCOUNT *m_fcBE;
    FCOUNT *m_fcBL;
    FCOUNT *m_fcBG;
    FCOUNT *m_fcBT;
    FCOUNT m_fcResCounts[MAX_ALPHA];
    };

class MSA
    {
#ifdef    WIN32
    friend void MSA::CopyReversed();
#endif

public:
    MSA();
    virtual ~MSA();

public:
// Ways to create an MSA
    void FromFile(TextFile &File, ALPHABET Alpha = ALPHABET_Amino);
    void FromFASTAFile(TextFile &File, ALPHABET Alpha = ALPHABET_Amino,
      bool bFirstOnly = false);
    void FromMSFFile(TextFile &FIle, ALPHABET Alpha = ALPHABET_Amino);
    void FromPairMap(const Seq &seqA, const Seq &seqB, int iMapA[], int iMapB[]);
    void FromSeq(const Seq &s);

    void ToFASTAFile(TextFile &File,  WRITE_WEIGHT_STYLE WWS = WWS_IfFoundInInputFile) const;
    void ToMSFFile(TextFile &File, const char *ptrComment = 0) const;
    void WeightsToFile(TextFile &File) const;
    void WeightsFromFile(TextFile &File);

    void SetSize(unsigned uSeqCount, unsigned uColCount);
    void SetSeqCount(unsigned uSeqCount);
    char GetChar(unsigned uSeqIndex, unsigned uIndex) const;
    unsigned GetLetter(unsigned uSeqIndex, unsigned uIndex) const;
    const char *GetSeqName(unsigned uSeqIndex) const;
    void GetLetterCounts(unsigned uColIndex, WCOUNT Counts[]) const;
    bool IsGap(unsigned uSeqIndex, unsigned uColIndex) const;
    bool IsWildcard(unsigned uSeqIndex, unsigned uColIndex) const;
    bool IsGapColumn(unsigned uColIndex) const;
    void SetAllAligned();
    void AlignByCase();
    void AlignByCaseOrDash();
    void AlignByGapPct(unsigned uGapPct);
    void TrimUnalignedTerminals();
    bool IsAlignedByCase(unsigned uColIndex) const;
    bool IsAlignedByCaseOrDash(unsigned uColIndex) const;
    bool IsAlignedByGapPct(unsigned uColIndex, unsigned uGapPct) const;
    void SetColInfo(unsigned uColIndex, const COLINFO &CI);
    void ColInfoToFile(TextFile &File);
    void ColInfoFromFile(TextFile &File);
    void FromAlignedColumns(const MSA &a);

    void SetChar(unsigned uSeqIndex, unsigned uColIndex, char c);
    void SetSeqName(unsigned uSeqIndex, const char szName[]);
    bool HasGap() const;
    bool IsLegalLetter(unsigned uLetter) const;
    bool IsLegalChar(char c) const;
    bool IsMatchColumn(unsigned uColIndex, BUILD_METHOD BuildMethod,
      double dGapFraction) const;
    bool IsMatchColumnKrogh(unsigned uColIndex, double dGapFraction) const;
    bool IsMatchColumnSjolander(unsigned uColIndex) const;
    bool IsDeleteColumn(unsigned uColIndex) const;
    bool IsInsertColumn(unsigned uColIndex, BUILD_METHOD BuildMethod,
      double dGapFraction) const;
    bool IsInsertColumnSjolander(unsigned uColIndex) const;
    void ExtractUnaligned(unsigned uSeqIndex, MSA &a) const;
    void GetSeq(unsigned uSeqIndex, Seq &seq) const;
    void GetAlignedSeq(unsigned uSeqIndex, Seq &seq) const;
    bool IsAligned(unsigned uColIndex) const;
    void Crop();
    void Copy(const MSA &msa);
    void CopyReversed(const MSA &msa);
    double GetCons(unsigned uColIndex) const;
    double GetAvgCons() const;
    double GetPctIdentityPair(unsigned uSeqIndex1, unsigned uSeqIndex2) const;
    const COLINFO &GetColInfo(unsigned uColIndex) const;
    unsigned GetUngappedColIndex(unsigned uSeqIndex, unsigned uColIndex) const;
    bool GetSeqIndex(const char *ptrSeqName, unsigned *ptruSeqIndex) const;
    char GetUngappedChar(unsigned uSeqIndex, unsigned uUngappedColIndex) const;
    unsigned GetGappedColIndex(unsigned uSeqIndex, unsigned uUngappedColIndex) const;
    void DeleteCol(unsigned uColIndex);
    void DeleteColumns(unsigned uColIndex, unsigned uColCount);
    bool IsAllDots(unsigned uColIndex);
    unsigned PillarPLToColPL(unsigned uPillarPL) const;
    unsigned PillarPLToSeqPL(unsigned uPillarPL, unsigned uSeqIndex) const;
    void CopySeq(unsigned uToSeqIndex, const MSA &msaFrom, unsigned uFromSeqIndex);
    void DeleteSeq(unsigned uSeqIndex);
    void DeleteEmptyCols(bool bProgress = false);
    bool IsEmptyCol(unsigned uColIndex) const;

    WEIGHT GetSeqWeight(unsigned uSeqIndex) const;
    WCOUNT GetSeqWCount(unsigned uSeqIndex) const;
    WEIGHT GetTotalSeqWeight() const;

    void UnWeight();

    void BuildPillars();
    void FreePillars();
    const PILLAR &GetPillar(unsigned uPillarIndex) const;
    unsigned AlignedColToPillarIndex(unsigned uAlignedColIndex) const;
    void GetNodeCounts(unsigned uAlignedColIndex, NodeCounts &Counts) const;
    void ValidateBreakMatrices() const;
    unsigned GetCharCount(unsigned uSeqIndex, unsigned uColIndex) const;
    const char *GetSeqBuffer(unsigned uSeqIndex) const;
    unsigned AlignedColIndexToColIndex(unsigned uAlignedColIndex) const;
    unsigned GetSeqLength(unsigned uSeqIndex) const;
    void GetPWID(unsigned uSeqIndex1, unsigned uSeqIndex2, double *ptrdPWID,
      unsigned *ptruPosCount) const;

    void GetPairMap(unsigned uSeqIndex1, unsigned uSeqIndex2, int iMap1[],
      int iMap2[]) const;

    void FreeUngapMap();

    void ListMe() const;
    void ListColInfo() const;
    void ListPillars() const;
    void ListWeights() const;

    void SanityCheckPillarCount() const;

    WCOUNT GetRawNIC() const;
    WCOUNT GetEffectiveNIC() const;
    WCOUNT CalcRawNIC() const;

    void GapInfoToDataBuffer(DataBuffer &Buffer) const;
    void GapInfoFromDataBuffer(const DataBuffer &Buffer);

    void Clear()
        {
        Free();
        }
    void SetAlphabet(ALPHABET Alpha)
        {
        m_Alphabet = Alpha;
        }
    unsigned GetSeqCount() const
        {
        return m_uSeqCount;
        }
    unsigned GetColCount() const
        {
        return m_uColCount;
        }
    unsigned GetPillarCount() const
        {
        return m_uPillarCount;
        }
    ALPHABET GetAlphabet() const
        {
        return m_Alphabet;
        }
    unsigned GetAlphabetSize() const
        {
        return ::GetAlphabetSize(m_Alphabet);
        }
    char LetterToChar(unsigned uLetter) const
        {
        return ::LetterToChar(uLetter, m_Alphabet);
        }
    char CharToLetter(char c) const
        {
        return ::CharToLetter(c, m_Alphabet);
        }
    unsigned GetAlignedColCount() const
        {
        return m_uAlignedColCount;
        }

    static bool SeqsEq(const MSA &a1, unsigned uSeqIndex1, const MSA &a2,
      unsigned uSeqIndex2);
unsigned m_uSeqCount; // I did this awful thing
private:
    void Free();
    void CalcGSCWeights() const;
    void CalcHenikoffWeights() const;
    void CalcWeights() const;
    void CalcFractionalPillarCounts(unsigned uPillarIndex);
    void GetNameFromFASTAAnnotationLine(const char szLine[],
      char szName[], unsigned uBytes);
    void CopyCol(unsigned uFromCol, unsigned uToCol);
    unsigned CalcBLOSUMWeights(ClusterTree &BlosumCluster) const;
    void SetBLOSUMSubtreeWeight(const ClusterNode *ptrNode, double dWeight) const;
    unsigned SetBLOSUMNodeWeight(const ClusterNode *ptrNode, double dMinDist) const;
    void SetSubtreeWeight2(const ClusterNode *ptrNode) const;
    void SetSubtreeGSCWeight(ClusterNode *ptrNode) const;
    void BuildPillar(unsigned uPillarIndex);
    void FillResCounts(WCOUNT wcResCounts[], unsigned uFromColIndex, unsigned uToColIndex);
    unsigned GetPillarFmtWidth(unsigned uPillarIndex) const;
    void BuildBE();
    void BuildBG();
    void BuildBL();
    void BuildBT();

    void CalcHenikoffWeightsCol(unsigned uColIndex) const;

    void ListBE() const;
    void ListBG() const;
    void ListBL() const;
    void ListBT() const;

public:
    ALPHABET m_Alphabet;
    
    unsigned m_uColCount;
    unsigned m_uPillarCount;
    unsigned m_uAlignedColCount;
    unsigned m_uCacheSeqLength;
    char **m_szSeqs;
    char **m_szNames;
    COLINFO *m_ColInfo;
    PILLAR *m_Pillars;
    unsigned *m_AlignedColToPillar;
    mutable unsigned **m_UngapMap;

    mutable bool m_bWeightsSet;
    mutable WEIGHT *m_Weights;

    mutable bool m_bRawNICSet;
    mutable WCOUNT m_wcRawNIC;
    
    mutable bool m_bEffectiveNICSet;
    mutable WCOUNT m_wcEffectiveNIC;

    bool m_bWeightsFoundInInputFile;
    
    unsigned m_uGNodeIndex;
    };

#endif    // MSA_h
