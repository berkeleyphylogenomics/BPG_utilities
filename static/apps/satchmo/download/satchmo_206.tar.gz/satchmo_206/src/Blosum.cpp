// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include <ctype.h>
#include "MSA.h"

static int Blosum62[23][23] =
    {
//   A   B   C   D   E    F   G   H   I   K    L   M   N   P   Q    R   S   T   V   W    X   Y   Z 
    +4, -2, +0, -2, -1,  -2, +0, -2, -1, -1,  -1, -1, -2, -1, -1,  -1, +1, +0, +0, -3,  -1, -2, -1,  // A
    -2, +6, -3, +6, +2,  -3, -1, -1, -3, -1,  -4, -3, +1, -1, +0,  -2, +0, -1, -3, -4,  -1, -3, +2,  // B
    +0, -3, +9, -3, -4,  -2, -3, -3, -1, -3,  -1, -1, -3, -3, -3,  -3, -1, -1, -1, -2,  -1, -2, -4,  // C
    -2, +6, -3, +6, +2,  -3, -1, -1, -3, -1,  -4, -3, +1, -1, +0,  -2, +0, -1, -3, -4,  -1, -3, +2,  // D
    -1, +2, -4, +2, +5,  -3, -2, +0, -3, +1,  -3, -2, +0, -1, +2,  +0, +0, -1, -2, -3,  -1, -2, +5,  // E
    
    -2, -3, -2, -3, -3,  +6, -3, -1, +0, -3,  +0, +0, -3, -4, -3,  -3, -2, -2, -1, +1,  -1, +3, -3,  // F
    +0, -1, -3, -1, -2,  -3, +6, -2, -4, -2,  -4, -3, +0, -2, -2,  -2, +0, -2, -3, -2,  -1, -3, -2,  // G
    -2, -1, -3, -1, +0,  -1, -2, +8, -3, -1,  -3, -2, +1, -2, +0,  +0, -1, -2, -3, -2,  -1, +2, +0,  // H
    -1, -3, -1, -3, -3,  +0, -4, -3, +4, -3,  +2, +1, -3, -3, -3,  -3, -2, -1, +3, -3,  -1, -1, -3,  // I
    -1, -1, -3, -1, +1,  -3, -2, -1, -3, +5,  -2, -1, +0, -1, +1,  +2, +0, -1, -2, -3,  -1, -2, +1,  // K
    
    -1, -4, -1, -4, -3,  +0, -4, -3, +2, -2,  +4, +2, -3, -3, -2,  -2, -2, -1, +1, -2,  -1, -1, -3,  // L
    -1, -3, -1, -3, -2,  +0, -3, -2, +1, -1,  +2, +5, -2, -2, +0,  -1, -1, -1, +1, -1,  -1, -1, -2,  // M
    -2, +1, -3, +1, +0,  -3, +0, +1, -3, +0,  -3, -2, +6, -2, +0,  +0, +1, +0, -3, -4,  -1, -2, +0,  // N
    -1, -1, -3, -1, -1,  -4, -2, -2, -3, -1,  -3, -2, -2, +7, -1,  -2, -1, -1, -2, -4,  -1, -3, -1,  // P
    -1, +0, -3, +0, +2,  -3, -2, +0, -3, +1,  -2, +0, +0, -1, +5,  +1, +0, -1, -2, -2,  -1, -1, +2,  // Q
    
    -1, -2, -3, -2, +0,  -3, -2, +0, -3, +2,  -2, -1, +0, -2, +1,  +5, -1, -1, -3, -3,  -1, -2, +0,  // R
    +1, +0, -1, +0, +0,  -2, +0, -1, -2, +0,  -2, -1, +1, -1, +0,  -1, +4, +1, -2, -3,  -1, -2, +0,  // S
    +0, -1, -1, -1, -1,  -2, -2, -2, -1, -1,  -1, -1, +0, -1, -1,  -1, +1, +5, +0, -2,  -1, -2, -1,  // T
    +0, -3, -1, -3, -2,  -1, -3, -3, +3, -2,  +1, +1, -3, -2, -2,  -3, -2, +0, +4, -3,  -1, -1, -2,  // V
    -3, -4, -2, -4, -3,  +1, -2, -2, -3, -3,  -2, -1, -4, -4, -2,  -3, -3, -2, -3,+11,  -1, +2, -3,  // W
    
    -1, -1, -1, -1, -1,  -1, -1, -1, -1, -1,  -1, -1, -1, -1, -1,  -1, -1, -1, -1, -1,  -1, -1, -1,  // X
    -2, -3, -2, -3, -2,  +3, -3, +2, -1, -2,  -1, -1, -2, -3, -1,  -2, -2, -2, -1, +2,  -1, +7, -2,  // Y
    -1, +2, -4, +2, +5,  -3, -2, +0, -3, +1,  -3, -2, +0, -1, +2,  +0, +0, -1, -2, -3,  -1, -2, +5,  // Z
    };

static int toi_tab[26] =
    {
    0,    // A
    1,    // B
    2,    // C
    3,    // D
    4,    // E
    5,    // F
    6,    // G
    7,    // H
    8,    // I
    -1,    // J
    9,    // K
    10,    // L
    11,    // M
    12,    // N
    -1,    // O
    13,    // P
    14,    // Q
    15,    // R
    16,    // S
    17,    // T
    -1,    // U
    18,    // V
    19,    // W
    20,    // X
    21,    // Y
    22,    // Z
    };

static int toi(char c)
    {
    c = toupper(c);
    return toi_tab[c - 'A'];
    }

int BlosumScore(char c1, char c2)
    {
    int i1 = toi(c1);
    int i2 = toi(c2);
    return Blosum62[i1][i2];
    }

char GetLowestScoringChar(const MSA &a, unsigned uColIndex)
    {
    const unsigned uSeqCount = a.GetSeqCount();
    char cLowestChar = 'X';
    int iLowestScore = 999999;
    for (int iLetter = 0; iLetter < 20; ++iLetter)
        {
        const char c1 = LetterToCharAmino(iLetter);
        int iScore = 0;
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
            {
            if (a.IsGap(uSeqIndex, uColIndex))
                continue;
            char c2 = a.GetChar(uSeqIndex, uColIndex);
            int iBS = BlosumScore(c1, c2);
            iScore += iBS;
            }
        if (iScore < iLowestScore)
            {
            cLowestChar = c1;
            iLowestScore = iScore;
            }
        }
    return cLowestChar;
    }

void AddOutlier(const MSA &msaIn, MSA &msaOut)
    {
    msaOut.Clear();

    const unsigned uSeqCount = msaIn.GetSeqCount();
    const unsigned uColCount = msaIn.GetColCount();

    msaOut.SetSize(uSeqCount + 1, uColCount);

    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
            {
            char c = msaIn.GetChar(uSeqIndex, uColIndex);
            msaOut.SetChar(uSeqIndex, uColIndex, c);
            }

    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        char cOutlier = GetLowestScoringChar(msaIn, uColIndex);
        msaOut.SetChar(uSeqCount, uColIndex, cOutlier);
        }

    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        const char *ptrName = msaIn.GetSeqName(uSeqIndex);
        msaOut.SetSeqName(uSeqIndex, ptrName);
        }
    msaOut.SetSeqName(uSeqCount, "$out");
    }

SCORE GetBlosum62(unsigned uLetterA, unsigned uLetterB)
    {
    char cA = LetterToCharAminoEx(uLetterA);
    char cB = LetterToCharAminoEx(uLetterB);
    return (SCORE) BlosumScore(cA, cB);
    }
