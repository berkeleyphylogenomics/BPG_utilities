// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "DataBuffer.h"
#include "unixio.h"

DataBuffer::DataBuffer()
    {
    m_ucBuffer = 0;
    m_uBytes = 0;
    }

DataBuffer::~DataBuffer()
    {
    Clear();
    }

void DataBuffer::Clear()
    {
    delete[] m_ucBuffer;
    m_uBytes = 0;
    }

void DataBuffer::FromFile(const char *strFileName)
    {
    Clear();

    int hFile = open(strFileName, O_BINARY | O_RDONLY);
    if (hFile < 0)
        Quit("Cannot open '%s'", strFileName);

    unsigned uBytes = lseek(hFile, 0, 2);
    SetSize(uBytes);
    lseek(hFile, 0, 0);
    int iBytes = read(hFile, m_ucBuffer, m_uBytes);
    if (iBytes != (int) m_uBytes)
        Quit("Read error in '%s'", strFileName);
    close(hFile);
    }

void DataBuffer::ToFile(const char *strFileName) const
    {
    int hFile = open(strFileName, O_WRONLY | O_BINARY | O_CREAT | O_TRUNC, 0777);
    if (hFile < 0)
        Quit("Cannot create '%s'", strFileName);

    int iBytes = write(hFile, m_ucBuffer, m_uBytes);
    if (iBytes != (int) m_uBytes)
        Quit("Write error in '%s'", strFileName);
    close(hFile);
    }

void DataBuffer::SetSize(unsigned uBytes)
    {
    Clear();

    m_uBytes = uBytes;
    m_ucBuffer = new unsigned char[uBytes];
    }

void DataBuffer::Get(unsigned uPos, void *ptrData, unsigned uBytes) const
    {
    if (uPos + uBytes > m_uBytes)
        Quit("Get: range error");
    memcpy(ptrData, m_ucBuffer + uPos, uBytes);
    }

void DataBuffer::Put(unsigned uPos, const void *ptrData, unsigned uBytes)
    {
    if (uPos + uBytes > m_uBytes)
        Quit("Put: range error");
    memcpy(m_ucBuffer + uPos, ptrData, uBytes);
    }
