// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "DataBuffer.h"
#include "TextFile.h"
#include "Profile.h"
#include "PWBase.h"
#include "PWPath.h"

#define    VERBOSE    0

void DoProfProf(const char *prof1, const char *prof2, const char *colpair,
  const char *gapstyle, const char *bounds, const char *out)
    {
    DataBuffer Data1;
    DataBuffer Data2;

    Data1.FromFile(prof1);
    Data2.FromFile(prof2);

    Profile Profile1;
    Profile Profile2;

    char szName[128];
    NameFromPath(prof1, szName, sizeof(szName));
    Profile1.FromBuffer(Data1, szName);

#if    VERBOSE
    List("Profile1:\n");
    Profile1.ListMe();
#endif

    NameFromPath(prof2, szName, sizeof(szName));
    Profile2.FromBuffer(Data2, szName);

#if    VERBOSE
    List("Profile2:\n");
    Profile2.ListMe();
#endif

    PWBase *ptrPWS;
    PWSFactory(colpair, gapstyle, bounds, &ptrPWS);
    ptrPWS->SetProfiles(Profile1, Profile2);

    PWPath Path;
    SCORE Score = PWAlign(*ptrPWS, Path);
    List("Score = %g\n", Score);
    printf("Score = %g\n", Score);

#if    VERBOSE
    Path.ListMe();
#endif

    MSA a;
    AlignProfiles(Profile1, Profile2, Path, a);

#if    VERBOSE
    a.ListMe();
#endif

    TextFile OutFile(out, true);
    a.ToFASTAFile(OutFile);
    }
