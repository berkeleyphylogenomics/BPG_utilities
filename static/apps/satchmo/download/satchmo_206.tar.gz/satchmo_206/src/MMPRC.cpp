// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "PWPath.h"
#include "MMPRC.h"
#include <math.h>

#define    VERBOSE    0

/***
Reverse-engineered version of Martin Madera's profile-
profile comparison algorithm PRC, v1.3.1.
    
    http://supfam.mrc-lmb.cam.ac.uk/PRC/

The goal here is to reproduce Martin's alignments /exactly/
so that we can investigate the impact of any proposed changes
to the algorithm. So we have to clone all idiosynchrasies,
arbitrary choices and alleged bugs to get a validated starting
point.

Martin's model works like this. There are 5 states in the main
model: MM, MI, IM, DM and MD. A path through the model defines
one path in each of the two HMMs A and B being aligned, with
edges implied as follows.

    Edge        A        B        dA dB
    ------        ----    ----    -----
    MM->MM        M->M    M->M    1  1
    MI->MM        M->M    I->M    1  1
    IM->MM        I->M    M->M    1  1
    MD->MM        M->M    D->M    1  1
    DM->MM        D->M    M->M    1  1

    MI->MI        M->M    I->I    1  0
    MM->MI        M->M    M->I    1  0

    IM->IM        I->I    M->M    0  1
    MM->IM        M->I    M->M    0  1

    MD->MD        (none)    D->D    0  1
    MM->MD        (none)    M->D    0  1

    DM->DM        D->D    (none)    1  0
    MM->DM        M->D    (none)    1  0

Here, dA is 1 if the path moves into the next node, 0 otherwise;
similarly for dB. The values of dA and dB follow from the destination
state; we list them here as they are needed in the code below.
***/

static double null_score;

static char *MMSTATEToStr(MMSTATE x)
    {
    switch (x)
        {
    case MMSTATE_Undefined:    return "??";
    case MMSTATE_SS:        return "SS";
    case MMSTATE_MM:        return "MM";
    case MMSTATE_MD:        return "MD";
    case MMSTATE_MI:        return "MI";
    case MMSTATE_IM:        return "IM";
    case MMSTATE_DM:        return "DM";
    case MMSTATE_TT:        return "TT";
        }
    return "!!";
    }

static RPROB EmitPair(const RPROB p1[MAX_ALPHA], const RPROB p2[MAX_ALPHA])
    {
    double dSum = 0;
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        dSum += p1[n]*p2[n];
    return dSum / null_score;
    }

static double EmitPairProb(const PROB p1[MAX_ALPHA], const PROB p2[MAX_ALPHA])
    {
    double dSum = 0;
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        dSum += p1[n]*p2[n];
    return dSum;
    }

static RPROB gSS_MM = 0;

static RPROB SS_MM(const NodePtrs &NP)
    {
    return gSS_MM;
    }

static RPROB MM_MM(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeA->m_rprobMM * NP.ptrPrevNodeB->m_rprobMM;
    }

static RPROB MM_MI(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeA->m_rprobMM * NP.ptrNodeB->m_rprobMI;
    }

static RPROB MI_MM(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeA->m_rprobMM * NP.ptrPrevNodeB->m_rprobIM;
    }

static RPROB MM_MD(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeB->m_rprobMD;
    }

static RPROB MM_IM(const NodePtrs &NP)
    {
    return NP.ptrNodeA->m_rprobMI * NP.ptrPrevNodeB->m_rprobMM;
    }

static RPROB MM_DM(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeA->m_rprobMD;
    }

static RPROB DM_DM(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeA->m_rprobDD;
    }

static RPROB DM_MM(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeA->m_rprobDM * NP.ptrPrevNodeB->m_rprobMM;
    }

static RPROB IM_IM(const NodePtrs &NP)
    {
    return NP.ptrNodeA->m_rprobII * NP.ptrPrevNodeB->m_rprobMM;
    }

static RPROB IM_MM(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeA->m_rprobIM * NP.ptrPrevNodeB->m_rprobMM;
    }

static RPROB MI_MI(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeA->m_rprobMM * NP.ptrNodeB->m_rprobII;
    }

static RPROB MD_MD(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeB->m_rprobDD;
    }

static RPROB MD_MM(const NodePtrs &NP)
    {
    return NP.ptrPrevNodeA->m_rprobMM * NP.ptrPrevNodeB->m_rprobDM;
    }

static RPROB XMax6(RPROB p1, MMSTATE m1, RPROB p2, MMSTATE m2, RPROB p3, MMSTATE m3,
  RPROB p4, MMSTATE m4, RPROB p5, MMSTATE m5, RPROB p6, MMSTATE m6, MMSTATE *ptrm)
    {
#define    x(a, b, c, d, e, f) \
    if (p##a >= p##b && p##a >= p##c && p##a >= p##d && p##a >= p##e && p##a >= p##f) \
        { *ptrm = m##a; return p##a; }

    x(1, 2, 3, 4, 5, 6)
    x(2, 3, 4, 5, 6, 1)
    x(3, 4, 5, 6, 1, 2)
    x(4, 5, 6, 1, 2, 3)
    x(5, 6, 1, 2, 3, 4)
    x(6, 1, 2, 3, 4, 5)

#undef x
    Quit("Bad algebra");
    return 0;
    }

static RPROB XMax2(RPROB p1, MMSTATE m1, RPROB p2, MMSTATE m2, MMSTATE *ptrm)
    {
    if (p1 > p2)
        {
        *ptrm = m1;
        return p1;
        }
    else
        {
        *ptrm = m2;
        return p2;
        }
    }

static void GetNullEmit(const HMM &Model, PROB probNullEmit[MAX_ALPHA])
    {
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        probNullEmit[uLetter] = GetNullEmitProb(uLetter);
    }

static void HMMNodeToPRCNodeEmits(const HMMNode &hmmNode, PRCNode &prcNode,
  PROB probNullEmit[MAX_ALPHA])
    {
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        {
        prcNode.m_rprobMatchEmit[uLetter] =
          ScoreToProb(hmmNode.m_scoreMatchEmit[uLetter] + GetNullEmitScore(uLetter));
        prcNode.m_rprobInsertEmit[uLetter] =
          ScoreToProb(hmmNode.m_scoreInsertEmit[uLetter] + GetNullEmitScore(uLetter));
        }
    }

static void HMMNodeToPRCNodeTrans(const HMMNode &hmmNode, PRCNode &prcNode)
    {
// Convert model to probabilities (some are not relative probabilities yet...).
    prcNode.m_rprobMM = ScoreToProb(hmmNode.m_scoreMM + GetNullEmitTransScore());
    prcNode.m_rprobMD = ScoreToProb(hmmNode.m_scoreMD);
    prcNode.m_rprobMI = ScoreToProb(hmmNode.m_scoreMI + GetNullEmitTransScore()); 
    prcNode.m_rprobDM = ScoreToProb(hmmNode.m_scoreDM + GetNullEmitTransScore());
    prcNode.m_rprobDD = ScoreToProb(hmmNode.m_scoreDD);
    prcNode.m_rprobDI = ScoreToProb(hmmNode.m_scoreDI + GetNullEmitTransScore());
    prcNode.m_rprobIM = ScoreToProb(hmmNode.m_scoreIM + GetNullEmitTransScore());
    prcNode.m_rprobID = ScoreToProb(hmmNode.m_scoreID);
    prcNode.m_rprobII = ScoreToProb(hmmNode.m_scoreII + GetNullEmitTransScore());

// Verify original model is normalized, allowing 1% slop for rounding errors
    {
    RPROB probMx = prcNode.m_rprobMM + prcNode.m_rprobMI + prcNode.m_rprobMD;
    RPROB probDx = prcNode.m_rprobDM + prcNode.m_rprobDI + prcNode.m_rprobDD;
    RPROB probIx = prcNode.m_rprobIM + prcNode.m_rprobII + prcNode.m_rprobID;
    if (fabs(1 - probMx) > 0.01 || fabs(1 - probDx) > 0.01 ||
      fabs(1 - probIx) > 0.01)
        Quit("HMM node not normalized");
    }

// Martin disables D->I and I->D, motivation not clear to me.
// Re-distribute and renormalize the D->x and I->x distributions.
// It's not clear if this has any benefit as the graphical "pair HMM"
// is not normalized even if the two HMMs being aligned are normalized.

// Note that probID and probDI are typically << 1, so would
// be more accurate to use ID and DI from model, but we want
// to reproduce Martin's results so we do the same as he does.
    const RPROB probID = 1 - prcNode.m_rprobIM - prcNode.m_rprobII;
    const RPROB probDI = 1 - prcNode.m_rprobDM - prcNode.m_rprobDD;

// Redistribute
// (I don't understand the logic behind the re-distribution,
// I'm just reproducing the algebra implied by Martin's code).
    const RPROB probNotII = 1 - prcNode.m_rprobII;
    const RPROB dID = probID / probNotII;

    prcNode.m_rprobDM += probDI * prcNode.m_rprobIM / probNotII;
    prcNode.m_rprobDD += dID*prcNode.m_rprobDI;
    prcNode.m_rprobMD += dID*prcNode.m_rprobMI;
    prcNode.m_rprobMI -= dID*prcNode.m_rprobMI;

// Renormalize M->x
    RPROB probMx = prcNode.m_rprobMM + prcNode.m_rprobMI + prcNode.m_rprobMD;
    prcNode.m_rprobMM /= probMx;
    prcNode.m_rprobMD /= probMx;
    prcNode.m_rprobMI /= probMx;

// Renormalize D->x
    prcNode.m_rprobDI = 0;
    RPROB probDx = prcNode.m_rprobDM + prcNode.m_rprobDD;
    prcNode.m_rprobDM /= probDx;
    prcNode.m_rprobDD /= probDx;

// Renormalize I->x
    prcNode.m_rprobID = 0;
    prcNode.m_rprobIM = probNotII;

// Verify normalization in the new model
    {
    RPROB probMx = prcNode.m_rprobMM + prcNode.m_rprobMI + prcNode.m_rprobMD;
    RPROB probDx = prcNode.m_rprobDM + prcNode.m_rprobDI + prcNode.m_rprobDD;
    RPROB probIx = prcNode.m_rprobIM + prcNode.m_rprobII + prcNode.m_rprobID;
    if (fabs(1 - probMx) > 0.001 || fabs(1 - probDx) > 0.001 ||
      fabs(1 - probIx) > 0.001)
        Quit("Bad algebra");
    }
    }

static void PRCNodeTransDivideNull(PRCNode &prcNode, PROB probNullLoop)
    {
// Convert to relative probabilities: 
// divide emitter transitions by null loop.
    prcNode.m_rprobMM /= probNullLoop;
    prcNode.m_rprobMI /= probNullLoop; 
    prcNode.m_rprobDM /= probNullLoop;
    prcNode.m_rprobIM /= probNullLoop;
    prcNode.m_rprobII /= probNullLoop;
    }

static void SetPRCFirstNodes(const HMM &hmm, PRCNode &prcTermNode,
  PRCNode &prcFirstNode)
    {
    static PRCNode prcZero;
// Convenient hack is to have a "dummy" first node with
// all zero probabilities. This saves a bunch of special
// case checking in the DP loops.
    prcTermNode = prcZero;

    const PROB probFirstD = hmm.GetSAMFirstMDProb();
    const PROB probFirstM = 1 - probFirstD;

    const HMMNode &hmmFirstNode = hmm.GetNode(0);
    const RPROB probDM = prcFirstNode.m_rprobDM;
    const RPROB probMM = prcFirstNode.m_rprobMM;
    const RPROB probMD = prcFirstNode.m_rprobMD;
    const RPROB probDD = prcFirstNode.m_rprobDD;

    prcFirstNode.m_rprobMM = probFirstD*probDM + probFirstM*probMM;
    prcFirstNode.m_rprobMD = probFirstD*probDD + probFirstM*probMD;

// Renormalize M->x
    const RPROB Mx = prcFirstNode.m_rprobMM + prcFirstNode.m_rprobMD +
      prcFirstNode.m_rprobMI;
    prcFirstNode.m_rprobMM /= Mx;
    prcFirstNode.m_rprobMD /= Mx;
    prcFirstNode.m_rprobMI /= Mx;

// Martin disables D state in first node.
    prcFirstNode.m_rprobDM = 0;
    prcFirstNode.m_rprobDD = 0;
    prcFirstNode.m_rprobDI = 0;
    }

static void SetPRCFinalNodes(const HMM &hmm, PRCNode &prcPrevNode, PRCNode &prcLastNode)
    {
// Martin disables D_M.
// Adjust D->x and M->x distributions from the next-to-last node.
    prcPrevNode.m_rprobDD = 0;
    prcPrevNode.m_rprobDM = 1;

    const RPROB d = prcPrevNode.m_rprobMM + prcPrevNode.m_rprobMI;
    prcPrevNode.m_rprobMD = 0;
    prcPrevNode.m_rprobMM /= d;
    prcPrevNode.m_rprobMI /= d;

// Can only exit to TT state from last node.
    prcLastNode.m_rprobMM = 0.0;
    prcLastNode.m_rprobMD = 0.0;
    prcLastNode.m_rprobMI = 0.0;
    prcLastNode.m_rprobDM = 0.0;
    prcLastNode.m_rprobDD = 0.0;
    prcLastNode.m_rprobDI = 0.0;
    prcLastNode.m_rprobIM = 0.0;
    prcLastNode.m_rprobID = 0.0;
    prcLastNode.m_rprobII = 0.0;
    }

static void ListPRCNodes(const PRCNode Nodes[], unsigned uNodeCount)
    {
    List("       MM    MD    MI    DM    DD    DI    IM    ID    II\n");
    for (unsigned n = 1; n < uNodeCount; ++n)
        {
        const PRCNode &Node = Nodes[n];
        List("%3u %5.3f %5.3f %5.3f %5.3f %5.3f %5.3f %5.3f %5.3f %5.3f\n",
          n,
          Node.m_rprobMM,
          Node.m_rprobMD,
          Node.m_rprobMI,
          Node.m_rprobDM,
          Node.m_rprobDD,
          Node.m_rprobDI,
          Node.m_rprobIM,
          Node.m_rprobID,
          Node.m_rprobII);
        }
    List("\nMatch:\n");
    for (unsigned n = 1; n < uNodeCount; ++n)
        {
        const PRCNode &Node = Nodes[n];
        List("%3u ", n);
        for (unsigned i = 0; i < MAX_ALPHA; ++i)
            List(" %5.3f", Node.m_rprobMatchEmit[i]);
        List("\n");
        }
    List("\nInsert:\n");
    for (unsigned n = 1; n < uNodeCount; ++n)
        {
        const PRCNode &Node = Nodes[n];
        List("%3u ", n);
        for (unsigned i = 0; i < MAX_ALPHA; ++i)
            List(" %5.3f", Node.m_rprobInsertEmit[i]);
        List("\n");
        }
    }

static char MMSTATEToEdgeType(MMSTATE State)
    {
    switch (State)
        {
    case MMSTATE_SS: return 'S';
    case MMSTATE_MM: return 'M';
    case MMSTATE_MD: return 'I';
    case MMSTATE_MI: return 'D';
    case MMSTATE_IM: return 'I';
    case MMSTATE_DM: return 'D';
    case MMSTATE_TT: return 'T';
        }

    Quit("Bad MMSTATE %d", State);
    return 0;
    }

static void TraceBack(const HMM &hmmA, const HMM &hmmB,
  const RPROB *DPMM_, const RPROB *DPMD_, const RPROB *DPMI_,
  const RPROB *DPDM_, const RPROB *DPIM_, const MMSTATE *TBMM_,
  const MMSTATE *TBMD_, const MMSTATE *TBMI_, const MMSTATE *TBDM_,
  const MMSTATE *TBIM_, BOUNDS BoundsA, BOUNDS BoundsB, PWPath &Path)
    {
// Martin truncates the last node, we do the same to reproduce his results.
    const unsigned uNodeCountA = hmmA.GetNodeCount() - 1;
    const unsigned uNodeCountB = hmmB.GetNodeCount() - 1;
    const unsigned uPrefixCountA = uNodeCountA + 1;
    const unsigned uPrefixCountB = uNodeCountB + 1;

    assert(LOCAL == BoundsA && LOCAL == BoundsB);
// Local-local alignment defined to begin and end in MM state
    RPROB rprobBest = 0;
    unsigned uPrefixLengthA = uInsane;
    unsigned uPrefixLengthB = uInsane;
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            {
            RPROB rprobMM = DPMM(uPLA, uPLB);
            if (rprobMM > rprobBest)
                {
                rprobBest = rprobMM;
                uPrefixLengthA = uPLA;
                uPrefixLengthB = uPLB;
                }
            }
    if (uInsane == uPrefixLengthA || uInsane == uPrefixLengthB)
        Quit("Failed to find start of traceback");

    Path.Clear();
    MMSTATE State = MMSTATE_MM;
    while (State != MMSTATE_SS)
        {
        PWEdge Edge;
        Edge.cType = MMSTATEToEdgeType(State);
        Edge.uPrefixLengthA = uPrefixLengthA;
        Edge.uPrefixLengthB = uPrefixLengthB;
        Path.PrependEdge(Edge);

        switch (State)
            {
        case MMSTATE_MM:
            {
            assert(uPrefixLengthA > 0);
            assert(uPrefixLengthB > 0);

            State = TBMM(uPrefixLengthA, uPrefixLengthB);
            --uPrefixLengthA;
            --uPrefixLengthB;
            break;
            }

        case MMSTATE_MD:
            {
            assert(uPrefixLengthB > 0);

            State = TBMD(uPrefixLengthA, uPrefixLengthB);
            --uPrefixLengthB;
            break;
            }

        case MMSTATE_MI:
            {
            assert(uPrefixLengthA > 0);

            State = TBMI(uPrefixLengthA, uPrefixLengthB);
            --uPrefixLengthA;
            break;
            }

        case MMSTATE_IM:
            {
            assert(uPrefixLengthB > 0);

            State = TBIM(uPrefixLengthA, uPrefixLengthB);
            --uPrefixLengthB;
            break;
            }

        case MMSTATE_DM:
            {
            assert(uPrefixLengthA > 0);

            State = TBDM(uPrefixLengthA, uPrefixLengthB);
            --uPrefixLengthA;
            break;
            }
            }
        }
    }

void MMPRC(const HMM &hmmA, const HMM &hmmB, BOUNDS BoundsA, BOUNDS BoundsB,
  PWPath &Path)
    {
    Quit("Not debugged. Suggest re-write using SAM model for reverse engineering");
#if    VERBOSE
    List("HMM A:\n");
    hmmA.ListMe();
    List("\nHMM B:\n");
    hmmA.ListMe();
#endif

// Martin truncates the last node, we do the same to reproduce his results.
    const unsigned uNodeCountA = hmmA.GetNodeCount() - 1;
    const unsigned uNodeCountB = hmmB.GetNodeCount() - 1;
    const unsigned uPrefixCountA = uNodeCountA + 1;
    const unsigned uPrefixCountB = uNodeCountB + 1;

// Allocate memory for dynamic programming matrices, one for each state.
    size_t sizeDP = uPrefixCountA*uPrefixCountB;
    RPROB *DPMM_ = new RPROB[sizeDP];
    RPROB *DPMD_ = new RPROB[sizeDP];
    RPROB *DPMI_ = new RPROB[sizeDP];
    RPROB *DPDM_ = new RPROB[sizeDP];
    RPROB *DPIM_ = new RPROB[sizeDP];

    MMSTATE *TBMM_ = new MMSTATE[sizeDP];
    MMSTATE *TBMD_ = new MMSTATE[sizeDP];
    MMSTATE *TBMI_ = new MMSTATE[sizeDP];
    MMSTATE *TBDM_ = new MMSTATE[sizeDP];
    MMSTATE *TBIM_ = new MMSTATE[sizeDP];

    for (unsigned uPLA = 0; uPLA < uPrefixCountA; ++uPLA)
        for (unsigned uPLB = 0; uPLB < uPrefixCountB; ++uPLB)
            {
            DPMM(uPLA, uPLB) = 0;
            DPMD(uPLA, uPLB) = 0;
            DPMI(uPLA, uPLB) = 0;
            DPIM(uPLA, uPLB) = 0;
            DPDM(uPLA, uPLB) = 0;

            TBMM(uPLA, uPLB) = MMSTATE_Undefined;
            TBMD(uPLA, uPLB) = MMSTATE_Undefined;
            TBMI(uPLA, uPLB) = MMSTATE_Undefined;
            TBIM(uPLA, uPLB) = MMSTATE_Undefined;
            TBDM(uPLA, uPLB) = MMSTATE_Undefined;
            }

// Allocate memory for relative probability form of the HMM parameters.
    PRCNode *ANodes = new PRCNode[uPrefixCountA];
    PRCNode *BNodes = new PRCNode[uPrefixCountB];

// Compute the null model per Martin's procedure.
    PROB probNullEmitA[MAX_ALPHA];
    PROB probNullEmitB[MAX_ALPHA];

    GetNullEmit(hmmA, probNullEmitA);
    GetNullEmit(hmmB, probNullEmitB);

    null_score = EmitPairProb(probNullEmitA, probNullEmitB);

    const PROB probNullLoopA = (PROB) (uNodeCountA - 1) / (PROB) uNodeCountA;
    const PROB probNullLoopB = (PROB) (uNodeCountB - 1) / (PROB) uNodeCountB;

#if    VERBOSE
    List("Null loop A=%g B=%g\n", probNullLoopA, probNullLoopB);
#endif

// Now have everything we need to convert from scores to relative probabilities.
    for (unsigned uNodeIndexA = 0; uNodeIndexA < uNodeCountA; ++uNodeIndexA)
        {
        const HMMNode &Node = hmmA.GetNode(uNodeIndexA);
        HMMNodeToPRCNodeEmits(Node, ANodes[uNodeIndexA+1], probNullEmitA);
        }

    for (unsigned uNodeIndexB = 0; uNodeIndexB < uNodeCountB; ++uNodeIndexB)
        {
        const HMMNode &Node = hmmB.GetNode(uNodeIndexB);
        HMMNodeToPRCNodeEmits(Node, BNodes[uNodeIndexB+1], probNullEmitB);
        }

    for (unsigned uNodeIndexA = 0; uNodeIndexA < uNodeCountA; ++uNodeIndexA)
        {
        const HMMNode &Node = hmmA.GetNode(uNodeIndexA);
        HMMNodeToPRCNodeTrans(Node, ANodes[uNodeIndexA+1]);
        }

    for (unsigned uNodeIndexB = 0; uNodeIndexB < uNodeCountB; ++uNodeIndexB)
        {
        const HMMNode &Node = hmmB.GetNode(uNodeIndexB);
        HMMNodeToPRCNodeTrans(Node, BNodes[uNodeIndexB+1]);
        }

    SetPRCFirstNodes(hmmA, ANodes[0], ANodes[1]);
    SetPRCFirstNodes(hmmB, BNodes[0], BNodes[1]);

    SetPRCFinalNodes(hmmA, ANodes[uNodeCountA - 1], ANodes[uNodeCountA]);
    SetPRCFinalNodes(hmmB, BNodes[uNodeCountB - 1], BNodes[uNodeCountB]);

    for (unsigned uNodeIndexA = 0; uNodeIndexA < uNodeCountA; ++uNodeIndexA)
        PRCNodeTransDivideNull(ANodes[uNodeIndexA], probNullLoopA);

    for (unsigned uNodeIndexB = 0; uNodeIndexB < uNodeCountB; ++uNodeIndexB)
        PRCNodeTransDivideNull(BNodes[uNodeIndexB], probNullLoopB);

#if    VERBOSE
    List("\nPRCNodesA:\n");
    ListPRCNodes(ANodes, uPrefixCountA);
    List("\nPRCNodesB:\n");
    ListPRCNodes(BNodes, uPrefixCountB);
#endif

    assert(BoundsA == LOCAL && BoundsB == LOCAL);
    gSS_MM = (1.0 / uNodeCountA) * (1.0 / uNodeCountB);

// Dynamic programming loop
    for (unsigned uPrefixLengthA = 1; uPrefixLengthA < uPrefixCountA; ++uPrefixLengthA)
        for (unsigned uPrefixLengthB = 1; uPrefixLengthB < uPrefixCountB; ++uPrefixLengthB)
            {
            NodePtrs NP;
            NP.ptrNodeA = &ANodes[uPrefixLengthA];
            NP.ptrNodeB = &BNodes[uPrefixLengthB];
            NP.ptrPrevNodeA = &ANodes[uPrefixLengthA - 1];
            NP.ptrPrevNodeB = &ANodes[uPrefixLengthB - 1];

// Ugly macro but saves repetetive typing and makes important elements more visible
#define    t(from, to, dA, dB)    RPROB rprob##from##_##to = from##_##to(NP) * \
    DP##from##_[(uPrefixCountB)*(uPrefixLengthA-(dA)) + uPrefixLengthB-(dB)];

        // Transitions into MM
            {
            assert(BoundsA == LOCAL && BoundsB == LOCAL);
            RPROB rprobSS_MM = SS_MM(NP);
            t(MM, MM, 1, 1)
            t(MI, MM, 1, 1)
            t(IM, MM, 1, 1)
            t(MD, MM, 1, 1)
            t(DM, MM, 1, 1)

            MMSTATE State;
            const RPROB rprobTrans =
              XMax6(rprobSS_MM, MMSTATE_SS, rprobMM_MM, MMSTATE_MM, rprobMI_MM, MMSTATE_MI,
                rprobIM_MM, MMSTATE_IM, rprobMD_MM, MMSTATE_MD, rprobDM_MM, MMSTATE_DM, &State);

            const RPROB rprobEmit = EmitPair(NP.ptrNodeA->m_rprobMatchEmit,
              NP.ptrNodeB->m_rprobMatchEmit);

            DPMM(uPrefixLengthA, uPrefixLengthB) = rprobTrans*rprobEmit;
            TBMM(uPrefixLengthA, uPrefixLengthB) = State;
            }

        // Transitions into MI
            {
            t(MI, MI, 1, 0)
            t(MM, MI, 1, 0)

            MMSTATE State;
            const RPROB rprobTrans =
              XMax2(rprobMI_MI, MMSTATE_MI, rprobMM_MI, MMSTATE_MM, &State);

            const RPROB rprobEmit = EmitPair(NP.ptrNodeA->m_rprobMatchEmit,
              NP.ptrNodeB->m_rprobInsertEmit);

            DPMI(uPrefixLengthA, uPrefixLengthB) = rprobTrans*rprobEmit;
            TBMI(uPrefixLengthA, uPrefixLengthB) = State;

            if (uPrefixLengthA == 1 && uPrefixLengthB == 1)
                List("");
            }

        // Transitions into IM
            {
            t(IM, IM, 0, 1)
            t(MM, IM, 0, 1)

            MMSTATE State;
            const RPROB rprobTrans =
              XMax2(rprobIM_IM, MMSTATE_IM, rprobMM_IM, MMSTATE_MM, &State);

            const RPROB rprobEmit = EmitPair(NP.ptrNodeA->m_rprobInsertEmit,
              NP.ptrNodeB->m_rprobMatchEmit);

            DPIM(uPrefixLengthA, uPrefixLengthB) = rprobTrans*rprobEmit;
            TBIM(uPrefixLengthA, uPrefixLengthB) = State;
            }

        // Transitions into MD
            {
            t(MD, MD, 0, 1)
            t(MM, MD, 0, 1)
            MMSTATE State;
            DPMD(uPrefixLengthA, uPrefixLengthB) =
              XMax2(rprobMD_MD, MMSTATE_MD, rprobMM_MD, MMSTATE_MM, &State);
            TBMD(uPrefixLengthA, uPrefixLengthB) = State;
            }

        // Transitions into DM
            {
            t(DM, DM, 1, 0)
            t(MM, DM, 1, 0)
            MMSTATE State;
            DPDM(uPrefixLengthA, uPrefixLengthB) = 
              XMax2(rprobDM_DM, MMSTATE_DM, rprobMM_DM, MMSTATE_MM, &State);
            TBDM(uPrefixLengthA, uPrefixLengthB) = State;
            }
#undef t
            }

#if    VERBOSE
    List("DP_MM:\n");
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        {
        List("%3u", uPLA);
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            List(" %7.4f", DPMM(uPLA, uPLB));
        List("\n");
        }
    List("DP_MI:\n");
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        {
        List("%3u", uPLA);
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            List(" %7.4f", DPMI(uPLA, uPLB));
        List("\n");
        }
    List("DP_IM:\n");
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        {
        List("%3u", uPLA);
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            List(" %7.4f", DPIM(uPLA, uPLB));
        List("\n");
        }
    List("DP_MD:\n");
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        {
        List("%3u", uPLA);
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            List(" %7.4f", DPMD(uPLA, uPLB));
        List("\n");
        }

    List("DP_DM:\n");
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        {
        List("%3u", uPLA);
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            List(" %7.4f", DPDM(uPLA, uPLB));
        List("\n");
        }

    List("TB_MM:\n");
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        {
        List("%3u", uPLA);
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            List(" %s", MMSTATEToStr(TBMM(uPLA, uPLB)));
        List("\n");
        }
    List("TB_MI:\n");
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        {
        List("%3u", uPLA);
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            List(" %s", MMSTATEToStr(TBMI(uPLA, uPLB)));
        List("\n");
        }
    List("TB_IM:\n");
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        {
        List("%3u", uPLA);
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            List(" %s", MMSTATEToStr(TBIM(uPLA, uPLB)));
        List("\n");
        }
    List("TB_MD:\n");
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        {
        List("%3u", uPLA);
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            List(" %s", MMSTATEToStr(TBMD(uPLA, uPLB)));
        List("\n");
        }
    List("TB_DM:\n");
    for (unsigned uPLA = 1; uPLA < uPrefixCountA; ++uPLA)
        {
        List("%3u", uPLA);
        for (unsigned uPLB = 1; uPLB < uPrefixCountB; ++uPLB)
            List(" %s", MMSTATEToStr(TBDM(uPLA, uPLB)));
        List("\n");
        }
#endif

    TraceBack(hmmA, hmmB, DPMM_, DPMD_, DPMI_, DPDM_, DPIM_, TBMM_, TBMD_,
      TBMI_, TBDM_, TBIM_, BoundsA, BoundsB, Path);

#if    VERBOSE
    Path.ListMe();
#endif

    delete[] ANodes;
    delete[] BNodes;

    delete[] DPMM_;
    delete[] DPMD_;
    delete[] DPMI_;
    delete[] DPDM_;
    delete[] DPIM_;

    delete[] TBMM_;
    delete[] TBMD_;
    delete[] TBMI_;
    delete[] TBDM_;
    delete[] TBIM_;
    }
