// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "Seq.h"
#include "TextFile.h"

static void CompareSeqs(const Seq &s1, const Seq &s2)
    {
    unsigned uLength1 = s1.Length();
    unsigned uLength2 = s2.Length();

    if (uLength1 != uLength2)
        {
        List("Lengths different (%d, %d)\n", uLength1, uLength2);
        printf("Lengths different (%d, %d)\n", uLength1, uLength2);
        return;
        }

    for (unsigned n = 0; n < uLength1; ++n)
        {
        char c1 = toupper(s1[n]);
        char c2 = toupper(s2[n]);
        if (c1 != c2)
            {
            List("Different at position %d (%c %c)\n", n, c1, c2);
            printf("Different at position %d (%c %c)\n", n, c1, c2);
            return;
            }
        }
    List("Same\n");
    printf("Same\n");
    }

void DoCompareSeqs(const char *pstrFile1, const char *pstrSeq1, const char *pstrFile2,
  const char *pstrSeq2)
    {
    List("%s;%s;%s;%s;", pstrFile1, pstrSeq1, pstrFile2, pstrSeq2);
    MSA msa1;
    TextFile File1(pstrFile1);
    msa1.FromFile(File1);

    unsigned uSeqIndex1;
    bool bFound = msa1.GetSeqIndex(pstrSeq1, &uSeqIndex1);
    if (!bFound)
        Quit("Seq '%s' not found", pstrSeq1);

    Seq s1;
    msa1.GetSeq(uSeqIndex1, s1);

    MSA msa2;
    TextFile File2(pstrFile2);
    msa2.FromFile(File2);

    unsigned uSeqIndex2;
    bFound = msa2.GetSeqIndex(pstrSeq2, &uSeqIndex2);
    if (!bFound)
        Quit("Seq '%s' not found", pstrSeq2);

    Seq s2;
    msa2.GetSeq(uSeqIndex2, s2);
    CompareSeqs(s1, s2);
    }
