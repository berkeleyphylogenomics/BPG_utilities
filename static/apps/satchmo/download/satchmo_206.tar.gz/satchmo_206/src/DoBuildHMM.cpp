// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "MSA.h"
#include "HMM.h"

void DoBuildHMM(const char *strInputFileName, const char *strModelFileName)
    {
    TextFile InputFile(strInputFileName);

    MSA msaTemplate;

    fprintf(stderr, "FromFile\n");
    msaTemplate.FromFile(InputFile, ALPHABET_Amino);

    fprintf(stderr, "AlignByCase\n");
    msaTemplate.AlignByCase();

    fprintf(stderr, "BuildPillars\n");
    msaTemplate.BuildPillars();
//    msaTemplate.ValidateBreakMatrices();

    HMM Model;
    Model.FromAlnBitSave(msaTemplate, 0.5, 10, 1.0);

    TextFile ModelFile(strModelFileName, true);
    Model.ToFile(ModelFile);
    }
