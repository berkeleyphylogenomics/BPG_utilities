// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef SAMMod_h
#define    SAMMod_h

class TextFile;
class HMM;

class SAMNode
    {
public:
    SAMNode() {}

public:
// Note: transition probabilities are INTO node,
// not out of node as in Lobster & HMMer HMMs.
    PROB m_probMM;
    PROB m_probMD;
    PROB m_probMI;
    PROB m_probDM;
    PROB m_probDD;
    PROB m_probDI;
    PROB m_probIM;
    PROB m_probID;
    PROB m_probII;
    PROB m_probMatchEmit[MAX_ALPHA];
    PROB m_probInsertEmit[MAX_ALPHA];
    };

class SAMMod
    {
public:
    SAMMod();
    virtual ~SAMMod();

public:
    unsigned GetNodeCount() const { return m_uNodeCount; }
    void FromFile(TextFile &File);
    void FromHMM(const HMM &Model);
    void ToFile(TextFile &File) const;
    void Clear();
    const SAMNode &GetNode(unsigned uNodeIndex) const;
    void Validate() const;
    void ListMe() const;

private:
    void NodeFromFile(TextFile &File, SAMNode &Node);
    void AddNode(const SAMNode &Node);
    void NodeToFile(TextFile &File, const SAMNode &Node) const;

private:
// Node count includes Begin (node index=0) and End nodes.
    unsigned m_uNodeCount;
    SAMNode *m_Nodes;
    };

#endif    // SAMMod_h
