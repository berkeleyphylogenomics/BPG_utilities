// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "Seq.h"
#include "MSA.h"

HMM::HMM()
    {
    m_Nodes = 0;
    m_uNodeCount = 0;
    m_scoreFirstM = MINUS_INFINITY;
    m_scoreFirstD = MINUS_INFINITY;
    m_ptrTemplate = 0;
    m_ptrSP = 0;
    m_probSAMFirstMD = 0;
    }

HMM::~HMM()
    {
    Clear();
    }

void HMM::Clear()
    {
    delete[] m_Nodes;
    m_Nodes = 0;
    m_uNodeCount = 0;
    m_scoreFirstM = MINUS_INFINITY;
    m_scoreFirstD = MINUS_INFINITY;
    m_ptrTemplate = 0;
    }

void HMM::ListNodeCounts(const NodeCounts &Counts) const
    {
    List(" MM %s", WCountToStr(Counts.m_wcMM));
    List(" MD %s", WCountToStr(Counts.m_wcMD));
    List(" MI %s", WCountToStr(Counts.m_wcMI));
    List(" DM %s", WCountToStr(Counts.m_wcDM));
    List(" DD %s", WCountToStr(Counts.m_wcDD));
    List(" DI %s", WCountToStr(Counts.m_wcDI));
    List(" IM %s", WCountToStr(Counts.m_wcIM));
    List(" ID %s", WCountToStr(Counts.m_wcID));
    List(" II %s", WCountToStr(Counts.m_wcII));
    List("  r %s", WCountToStr(Counts.m_wcResidues));
    List("  g %s", WCountToStr(Counts.m_wcGaps));
    List("\n");
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        {
        WCOUNT wc = Counts.m_wcMatchEmit[n];
        if (0 != wc)
            List(" %c %s", LetterToCharAmino(n), WCountToStr(wc));
        }
    List("\n");
    }

unsigned HMM::NodeIndexToTemplateColIndex(unsigned uNodeIndex) const
    {
    unsigned uPillarIndex = m_ptrTemplate->AlignedColToPillarIndex(uNodeIndex);
    const PILLAR &Pillar = m_ptrTemplate->GetPillar(uPillarIndex);
    assert(Pillar.m_bAligned);
    assert(Pillar.m_uFromColIndex == Pillar.m_uToColIndex);
    return Pillar.m_uFromColIndex;
    }

SCORE HMM::GetMatchEmitScore(unsigned uNodeIndex, char c) const
    {
    const HMMNode &Node = GetNode(uNodeIndex);
    if ('x' == c || 'X' == c)
        return 0;
    if ('b' == c || 'B' == c)
        return (SCORE) (Node.m_scoreMatchEmit[AX_D]*0.4606 +
          Node.m_scoreMatchEmit[AX_N]*0.5394);
    if ('z' == c || 'Z' == c)
        return (SCORE) (Node.m_scoreMatchEmit[AX_E]*0.6110 +
          Node.m_scoreMatchEmit[AX_Q]*0.3890);
    unsigned uLetter = CharToLetterAmino(c);
    return Node.m_scoreMatchEmit[uLetter];
    }

SCORE HMM::GetInsertEmitScore(unsigned uNodeIndex, char c) const
    {
    const HMMNode &Node = GetNode(uNodeIndex);
    if ('x' == c || 'X' == c)
        return 0;
    if ('b' == c || 'B' == c)
        return (SCORE) (Node.m_scoreInsertEmit[AX_D]*0.4606 +
          Node.m_scoreInsertEmit[AX_N]*0.5394);
    if ('z' == c || 'Z' == c)
        return (SCORE) (Node.m_scoreInsertEmit[AX_E]*0.6110 +
          Node.m_scoreInsertEmit[AX_Q]*0.3890);
    unsigned uLetter = CharToLetterAmino(c);
    return Node.m_scoreInsertEmit[uLetter];
    }

SCORE HMM::GetTransScore(unsigned uFromNodeIndex, char cFromState, char cToState) const
    {
    if ('S' == cFromState)
        {
        assert(0 == uFromNodeIndex);
        switch (cToState)
            {
        case 'M': return m_scoreFirstM;
        case 'D': return m_scoreFirstD;
            }
        assert(false);
        }

    const HMMNode &Node = GetNode(uFromNodeIndex);
#define    c2(a, b)    ((a) | ((b) << 8))
    int iStates = c2(cFromState, cToState);
    switch (iStates)
        {
    case c2('M', 'M'): return Node.m_scoreMM;
    case c2('M', 'D'): return Node.m_scoreMD;
    case c2('M', 'I'): return Node.m_scoreMI;
    case c2('D', 'M'): return Node.m_scoreDM;
    case c2('D', 'D'): return Node.m_scoreDD;
    case c2('D', 'I'): return Node.m_scoreDI;
    case c2('I', 'M'): return Node.m_scoreIM;
    case c2('I', 'D'): return Node.m_scoreID;
    case c2('I', 'I'): return Node.m_scoreII;
        }
    assert(false);
    return MINUS_INFINITY;
    }

bool HMM::IsEmitterState(char cState)
    {
    return 'M' == cState || 'I' == cState;
    }

static void PutScore(SCORE Score)
    {
    List("%9s", ScoreToStr(Score));
    }

static void PutProb(SCORE Score)
    {
    PROB Prob;
    if (MINUS_INFINITY == Score)
        Prob = 0;
    else
        Prob = ScoreToProb(Score);
    List("%9.5f", Prob);
    }

void HMM::ListMe() const
    {
    const unsigned uNodeCount = GetNodeCount();
    List("Length %u\n", uNodeCount);
    List("Entry M=");
    PutScore(m_scoreFirstM);
    List(" D=");
    PutScore(m_scoreFirstD);
    List("\n");

    List("Trans\n");
    List("; Node       MM       MD       MI       DM       DD       DI       IM       ID       II\n");
    for (unsigned uNodeIndex = 0; uNodeIndex + 1 < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        List("%6u", uNodeIndex);
        PutScore(Node.m_scoreMM);
        PutScore(Node.m_scoreMD);
        PutScore(Node.m_scoreMI);
        PutScore(Node.m_scoreDM);
        PutScore(Node.m_scoreDD);
        PutScore(Node.m_scoreDI);
        PutScore(Node.m_scoreIM);
        PutScore(Node.m_scoreID);
        PutScore(Node.m_scoreII);
        List("\n");
        }

    List("Match\n");
    List(
"; Node         A        C        D        E        F        G        H        I        K        L\n"
";              M        N        P        Q        R        S        T        V        W        Y\n");

    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        List("  %4u ", uNodeIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            {
            PutScore(Node.m_scoreMatchEmit[uLetter]);
            if (AX_L == uLetter)
                List("\n       ");
            }
        List("\n\n");
        }

#if    INSERT_EMITS
    List("Insert\n");
    List(
"; Node         A        C        D        E        F        G        H        I        K        L\n"
";              M        N        P        Q        R        S        T        V        W        Y\n");

    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        List("  %4u ", uNodeIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            {
            PutScore(Node.m_scoreInsertEmit[uLetter]);
            if (AX_L == uLetter)
                List("\n       ");
            }
        List("\n\n");
        }
#endif
    }

void HMM::ListProbs() const
    {
    const unsigned uNodeCount = GetNodeCount();
    List("Length %u\n", uNodeCount);
    List("Entry M=");
    PutProb(m_scoreFirstM + GetNullEmitTransScore());
    List(" D=");
    PutProb(m_scoreFirstD);
    List("\n");

    List("Trans\n");
    List("; Node       MM       MD       MI       DM       DD       DI       IM       ID       II\n");
    for (unsigned uNodeIndex = 0; uNodeIndex + 1 < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        List("%6u", uNodeIndex);
        PutProb(Node.m_scoreMM + GetNullEmitTransScore());
        PutProb(Node.m_scoreMD);
        PutProb(Node.m_scoreMI + GetNullEmitTransScore());
        PutProb(Node.m_scoreDM + GetNullEmitTransScore());
        PutProb(Node.m_scoreDD);
        PutProb(Node.m_scoreDI + GetNullEmitTransScore());
        PutProb(Node.m_scoreIM + GetNullEmitTransScore());
        PutProb(Node.m_scoreID);
        PutProb(Node.m_scoreII + GetNullEmitTransScore());
        List("\n");
        }

    List("Match\n");
    List(
"; Node         A        C        D        E        F        G        H        I        K        L\n"
";              M        N        P        Q        R        S        T        V        W        Y\n");

    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        List("  %4u ", uNodeIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            {
            PutProb(Node.m_scoreMatchEmit[uLetter] + GetNullEmitScore(uLetter));
            if (AX_L == uLetter)
                List("\n       ");
            }
        List("\n\n");
        }

#if    INSERT_EMITS
    List("Insert\n");
    List(
"; Node         A        C        D        E        F        G        H        I        K        L\n"
";              M        N        P        Q        R        S        T        V        W        Y\n");

    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        List("  %4u ", uNodeIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            {
            PutProb(Node.m_scoreInsertEmit[uLetter] + GetNullEmitScore(uLetter));
            if (AX_L == uLetter)
                List("\n       ");
            }
        List("\n\n");
        }
#endif
    }

void HMM::AssertNormalized() const
    {
    PROB p[2];
    p[0] = ScoreToProb(m_scoreFirstM + GetNullEmitTransScore());
    p[1] = ScoreToProb(m_scoreFirstD);
    AssertNormalizedDist(p, 2);

    const unsigned uNodeCount = GetNodeCount();
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        AssertNormalizedNode(uNodeIndex);
    }

void HMM::AssertNormalizedNode(unsigned uNodeIndex) const
    {
    const HMMNode &Node = GetNode(uNodeIndex);

    PROB p[MAX_ALPHA];

    if (uNodeIndex != GetNodeCount() - 1)
        {
        p[0] = ScoreToProb(Node.m_scoreMM + GetNullEmitTransScore());
        p[1] = ScoreToProb(Node.m_scoreMD);
        p[2] = ScoreToProb(Node.m_scoreMI + GetNullEmitTransScore());
        AssertNormalizedDist(p, 3);

        p[0] = ScoreToProb(Node.m_scoreDM + GetNullEmitTransScore());
        p[1] = ScoreToProb(Node.m_scoreDD);
        p[2] = ScoreToProb(Node.m_scoreDI + GetNullEmitTransScore());
        AssertNormalizedDist(p, 3);

        p[0] = ScoreToProb(Node.m_scoreIM + GetNullEmitTransScore());
        p[1] = ScoreToProb(Node.m_scoreID);
        p[2] = ScoreToProb(Node.m_scoreII + GetNullEmitTransScore());
        AssertNormalizedDist(p, 3);
        }

    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        p[n] = ScoreToProb(Node.m_scoreMatchEmit[n] + GetNullEmitScore(n));
    AssertNormalizedDist(p, MAX_ALPHA);

// No insert state in last node
    if (uNodeIndex != m_uNodeCount - 1)
        {
        for (unsigned n = 0; n < MAX_ALPHA; ++n)
            p[n] = ScoreToProb(Node.m_scoreInsertEmit[n] + GetNullEmitScore(n));
        AssertNormalizedDist(p, MAX_ALPHA);
        }
    }

SCORE HMM::ScoreTerminalGap(unsigned uLength) const
    {
    return 0;
//    return (SCORE) (-0.04*uLength);
    }
