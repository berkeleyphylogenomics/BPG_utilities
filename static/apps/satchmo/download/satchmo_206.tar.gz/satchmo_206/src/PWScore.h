// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    PWScore_h
#define PWScore_h

class PWScore
    {
// Suppress compiler defaults
private:
    PWScore(const PWScore &);
    PWScore &operator=(const PWScore &);

protected:
    PWScore() {}
    virtual ~PWScore() {}

public:
    virtual unsigned GetLengthA() const = 0;
    virtual unsigned GetLengthB() const = 0;
    virtual BOUNDS GetBoundsA() const = 0;
    virtual BOUNDS GetBoundsB() const = 0;

/***
Score functions compute the incremental gap score for adding one
column to the alignment. Arguments are prefix lengths /after/ 
that column has been added. Prefix lengths are used rather than
a position (e.g. the ungapped column index) so that an empty
prefix doesn't have to be special-cased. Deletions and insertions
are relative to A. The following diagrams show the new column and
its predecessor.

    MM        MD        MI
A:    X X        X X        X -
B:    X X        X -        X X

    DM        DD        DI
A:    X X        X X        X -
B:    - X        - -        - X

    IM        ID        II
A:    - X        - X        - -
B:    X X        X -        X X

Special case: first column

    SM        SD        SI
A:    X        X        -
B:    X        -        X

Special case: last column

    ME        DE        IE
A:    X        X        -
B:    X        -        X
***/
    virtual SCORE ScoreMM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreMD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreMI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreDM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreDD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreDI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreIM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreID(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreII(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;

// Special cases: scores for first (S=start) & last (E=end) column
// These determine the boundary conditions (local, global etc.)
    virtual SCORE ScoreSM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreSD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreSI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreME(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreDE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreIE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;

// Score for matching letter+letter, gap+letter and letter+gap
    virtual SCORE ScoreLL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreLG(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;
    virtual SCORE ScoreGL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const = 0;

public:
    SCORE ScoreTrans(char cFromEdgeType, char cToEdgeType, unsigned uPrefixLengthA,
      unsigned uPrefixLengthB) const;
    SCORE ScoreEmit(char cEdgeType, unsigned uPrefixLengthA,
      unsigned uPrefixLengthB) const;
    };

#endif    // PWScore_h
