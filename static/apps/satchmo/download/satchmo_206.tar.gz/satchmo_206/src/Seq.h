// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef Seq_h
#define Seq_h

#include <vector>

class TextFile;
class MSA;

typedef std::vector<char> CharVect;

class Seq : public CharVect
    {
public:
    Seq()
        {
        m_ptrName = 0;
    // Start with moderate size to avoid
    // thrashing the heap.
        reserve(200);
        }
    virtual ~Seq()
        {
        delete[] m_ptrName;
        }

private:
// Not implemented; prevent use of copy c'tor and assignment.
    Seq(const Seq &);
    Seq &operator=(const Seq &);

public:
    void Clear()
        {
        clear();
        delete[] m_ptrName;
        m_ptrName = 0;
        }
    const char *GetName() const
        {
        return m_ptrName;
        }

    bool FromFASTAFile(TextFile &File);
    void ToFASTAFile(TextFile &File) const;
    void ExtractUngapped(MSA &msa) const;

    void FromString(const char *pstrSeq, const char *pstrName);
    void Copy(const Seq &rhs);
    void CopyReversed(const Seq &rhs);
    void StripGaps();
    void ToUpper();
    void SetName(const char *ptrName);
    unsigned GetLetter(unsigned uIndex) const;
    unsigned Length() const { return (unsigned) size(); }
    bool EqIgnoreCase(const Seq &s) const;
    bool EqIgnoreCaseAndGaps(const Seq &s) const;
    bool HasGap() const;
    unsigned GetUngappedLength() const;
    void ListMe() const;
    char GetChar(unsigned uIndex) const { return operator[](uIndex); }
    void SetChar(unsigned uIndex, char c) { operator[](uIndex) = c; }

#ifndef    _WIN32
    reference at(size_type i) { return operator[](i); }
    const_reference at(size_type i) const { return operator[](i); }
#endif

private:
    char *m_ptrName;
    };

#endif    // Seq.h
