// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "TextFile.h"

void DoPctIds(const char *strFileName)
    {
    TextFile File(strFileName);

    MSA a;
    a.FromFile(File);

    double dTotalAll = 0.0;
    double dTotalAln = 0.0;
    unsigned uPairCount = 0;
    const unsigned uSeqCount = a.GetSeqCount();
    for (unsigned uSeq1 = 0; uSeq1 < uSeqCount; ++uSeq1)
        for (unsigned uSeq2 = uSeq1 + 1; uSeq2 < uSeqCount; ++uSeq2)
            {
            double dAln = PairwiseIdentityAll(a, uSeq1, uSeq2);
            double dAll = PairwiseIdentityAlignedOnly(a, uSeq1, uSeq2);
            ++uPairCount;
            dTotalAln += dAln;
            dTotalAll += dAll;
            List("%s;%s;Aln=%g%%;All=%g%%\n",
              a.GetSeqName(uSeq1),
              a.GetSeqName(uSeq2),
              dAln*100.0,
              dAll*100.0);
            }
    List("%s;Aln=%g;All=%g\n",
      strFileName,
      dTotalAln/uPairCount,
      dTotalAll/uPairCount);
    printf("%s;Aln=%g;All=%g\n",
      strFileName,
      dTotalAln/uPairCount,
      dTotalAll/uPairCount);
    }
