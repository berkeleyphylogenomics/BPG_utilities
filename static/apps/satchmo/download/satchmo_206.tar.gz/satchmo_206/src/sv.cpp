// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

/***
Satchmo view format (.sv) is as follows.
The file contains the binary tree built by Satchmo.

The file is parsed into tokens.
Curly braces "{" and "}" are special cases, they are tokens
on their own, and text between curly braces is not parsed.
All other tokens are terminated by white space. Text between
curly braces is not intended for the top-level parser, it will
have formatting rules of its own -- it might be alignment data
or HMM parameters, for example.

Each binary tree node contains an alignment, and is marked
as being a leaf or internal (i.e., non-leaf) node.

A minimal node looks like this:

    [
    <type>
    aligment
    {
    <Aligned FASTA data>
    }
    ]

<type> is leaf or internal.
An internal node must have attributes:

    leftchild <index>
    rightchild <index>

Nodes may have other attributes. An attribute is specified
as an attribute name name followed by a  value. A parser 
should ignore attributes it doesn't recognize. An attribute
value is either a single token (a "short" attribute), or is
enclosed within curly braces { ... }, e.g. alignment (a "long"
attribute). Reading and writing of long attribute values is
delegated to functions specializing in its format (e.g.,
aligned FASTA). Right square brackets "]" and curly brace
characters "}" are not permitted within long attributes (to
allow top-level parsers to skip parts of the file if desired).

The order nodes are written to the file is determined by the
progress of the Satchmo algorithm: a node is written when
it is combined with another node so that the data in that
node is not needed for future iterations. This produces
something like a tree prefix order, but unfortunately not
exactly. In prefix order, a left-to-right interpretation
using a stack can be used to reconstruct the tree. In a
.sv file, this is not possible; the leftchild and rightchild
attributes must be used to determine branching order. It
is guaranteed that a child node is always written before
its parent.
***/

#include "lobster.h"
#include "GTree2.h"
#include "GNode2.h"
#include "MSA.h"
#include "TextFile.h"

const size_t MAX_TOKEN = 1023;

void WriteNodeToSmoFile(TextFile &File, GNode2 &Node, bool bSaveHMM,
  bool bSaveMSS)
    {
    File.PutString("[\n");

// Node type
    if (Node.IsLeaf())
        File.PutString("leaf\n");
    else
        File.PutString("internal\n");

// Index of this node
    File.PutFormat("index %u\n", Node.m_uNodeIndex);

    if (!Node.IsLeaf())
        {
        File.PutFormat("target %u\n", Node.m_ptrLeft->m_uNodeIndex);
        File.PutFormat("template %u\n", Node.m_ptrRight->m_uNodeIndex);
        }

// FASTA alignment data
    File.PutString("alignment\n{\n");
    Node.m_MSA.ToFASTAFile(File);
    File.PutString("//\n");
    File.PutString("}\n");

    if (bSaveHMM)
        Node.m_Model.ToFile(File);

    if (bSaveMSS)
        Node.m_Model.MSSToFile(File);

    if (!Node.IsLeaf())
        {
        File.PutString("colinfo\n{\n");
        Node.m_MSA.ColInfoToFile(File);
        File.PutString("}\n");
        }

    File.PutString("]\n");
    }

static void NodeFromFile(TextFile &File, GNode2 &Node, bool &bLeaf)
    {
    char szToken[MAX_TOKEN+1];

// Flags for validity checking
    bLeaf = false;
    bool bInternal = false;
    bool bLeftChild = false;
    bool bRightChild = false;

    for (;;)
        {
        File.GetTokenX(szToken, sizeof(szToken));

    // Closing "]" terminates node
        if (0 == strcmp(szToken, "]"))
            break;

    // Otherwise, should have an attribute
        if (0 == strcmp(szToken, "leaf"))
            {
            bLeaf = true;
            continue;
            }
        else if (0 == strcmp(szToken, "internal"))
            {
            bInternal = true;
            continue;
            }
        if (0 == strcmp(szToken, "index"))
            {
            File.GetTokenX(szToken, sizeof(szToken));
            assert(IsValidInteger(szToken));
            Node.m_uNodeIndex = (unsigned) atoi(szToken);
            }
        else if (0 == strcmp(szToken, "template"))
            {
            bLeftChild = true;
            File.GetTokenX(szToken, sizeof(szToken));
            assert(IsValidInteger(szToken));
            Node.m_uRightChildIndex = (unsigned) atoi(szToken);
            }
        else if (0 == strcmp(szToken, "target"))
            {
            bRightChild = true;
            File.GetTokenX(szToken, sizeof(szToken));
            assert(IsValidInteger(szToken));
            Node.m_uLeftChildIndex = (unsigned) atoi(szToken);
            }
        else if (0 == strcmp(szToken, "alignment"))
            {
            File.GetTokenX(szToken, sizeof(szToken));
            assert(0 == strcmp(szToken, "{"));
            File.Skip();

            Node.m_MSA.FromFASTAFile(File, ALPHABET_Amino);

            File.GetTokenX(szToken, sizeof(szToken));
            assert(0 == strcmp(szToken, "}"));
            }
        //else if (0 == strcmp(szToken, "mss"))
        //    {
        //    File.GetTokenX(szToken, sizeof(szToken));
        //    assert(0 == strcmp(szToken, "{"));
        //    File.Skip();

        //    Node.MSSFromFile(File);

        //    File.GetTokenX(szToken, sizeof(szToken));
        //    assert(0 == strcmp(szToken, "}"));
        //    }
        else if (0 == strcmp(szToken, "colinfo"))
            {
            File.GetTokenX(szToken, sizeof(szToken));
            assert(0 == strcmp(szToken, "{"));
            File.Skip();

            Node.m_MSA.ColInfoFromFile(File);

            File.GetTokenX(szToken, sizeof(szToken));
            assert(0 == strcmp(szToken, "}"));
            }
        else
        // Unknown attribute, skip value
            {
            assert(IsValidIdentifier(szToken));
            File.GetTokenX(szToken, sizeof(szToken));
        // If long attribute, skip up to closing curly brace
            if (0 == strcmp(szToken, "{"))
                {
                for (;;)
                    {
                    File.GetTokenX(szToken, sizeof(szToken));
                    if (0 == strcmp(szToken, "}"))
                        break;
                    }
                }
            }
        }

    if (bLeaf)
        {
        if (1 != Node.m_MSA.GetSeqCount())
            Quit("Invalid .sv file line %u, leaf node must have exactly one sequence",
              File.GetLineNr());
        Node.SetName(Node.m_MSA.GetSeqName(0));
        }

    if ((int) bLeaf + (int) bInternal != 1)
        Quit("Invalid .sv file line %u, node must have"
          " be leaf or internal\n", File.GetLineNr());
    if (bLeaf && (bLeftChild || bRightChild))
        Quit("Invalid .sv file line %u, leaf not cannot have left/rightchild",
          File.GetLineNr());
    if (bInternal && (!bLeftChild || !bRightChild))
        Quit("Invalid .sv file line %u, internal node must have"
          " target and template",
          File.GetLineNr());
    }

void GTree2::FromSVFile(TextFile &File)
    {
    char szToken[MAX_TOKEN+1];

    File.GetTokenX(szToken, sizeof(szToken));
    if (0 != strcmp(szToken, "nodes"))
        Quit("Invalid .sv file, does not start with 'nodes'");
    printf("called here\n");
    File.GetTokenX(szToken, sizeof(szToken));
    assert(IsValidInteger(szToken));
    const unsigned uNodeCount = (unsigned) atoi(szToken);
    GNode2 **Nodes = new GNode2*[uNodeCount];
    unsigned leafCount = 0;
    for (;;)
        {
        File.GetTokenX(szToken, sizeof(szToken));
        if (0 == strcmp(szToken, "["))
            {
            GNode2 *ptrNode = new GNode2;
            bool bIsLeaf;
            NodeFromFile(File, *ptrNode, bIsLeaf);

            unsigned uIndex = ptrNode->m_uNodeIndex;
            Nodes[uIndex] = ptrNode;
            if (!bIsLeaf)
                {
                unsigned uLeftChildIndex = ptrNode->m_uLeftChildIndex;
                unsigned uRightChildIndex = ptrNode->m_uRightChildIndex;

                GNode2 *ptrLeftChild = Nodes[uLeftChildIndex];
                GNode2 *ptrRightChild = Nodes[uRightChildIndex];

                ptrNode->m_ptrLeft = ptrLeftChild;
                ptrNode->m_ptrRight = ptrRightChild;

                ptrLeftChild->m_ptrParent = ptrNode;
                ptrRightChild->m_ptrParent = ptrNode;
                }else {
                    leafCount++;
                }

        // Root is last node encountered, this overwrites
        // m_ptrRoot every time.
            m_ptrRoot = ptrNode;
            }
        else if (0 == strcmp(szToken, "."))
            {
            m_Nodes = Nodes; //delete[] Nodes;
            m_uNodeCount = (2*leafCount) - 2;
            return;
            }
        else
            Quit("Invalid .sv file, line %u, expecting '[', got '%s'\n",
            File.GetLineNr(), szToken);
        }
        
    }
