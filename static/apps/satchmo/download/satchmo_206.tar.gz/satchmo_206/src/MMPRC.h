// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef MMPRC_h
#define    MMPRC_h

struct PRCNode
    {
    RPROB m_rprobMM;
    RPROB m_rprobMD;
    RPROB m_rprobMI;
    RPROB m_rprobDM;
    RPROB m_rprobDD;
    RPROB m_rprobDI;
    RPROB m_rprobIM;
    RPROB m_rprobID;
    RPROB m_rprobII;
    RPROB m_rprobMatchEmit[MAX_ALPHA];
    RPROB m_rprobInsertEmit[MAX_ALPHA];
    };

struct NodePtrs
    {
    const PRCNode *ptrNodeA;
    const PRCNode *ptrNodeB;
    const PRCNode *ptrPrevNodeA;
    const PRCNode *ptrPrevNodeB;
    };

enum MMSTATE
    {
    MMSTATE_Undefined,
    MMSTATE_SS,
    MMSTATE_MM,
    MMSTATE_MD,
    MMSTATE_MI,
    MMSTATE_IM,
    MMSTATE_DM,
    MMSTATE_TT,
    };

// Macros to simulate 2D matrices
#define DPMM(PrefixLengthA, PrefixLengthB)    DPMM_[(PrefixLengthA)*(uPrefixCountB) + (PrefixLengthB)]
#define DPMD(PrefixLengthA, PrefixLengthB)    DPMD_[(PrefixLengthA)*(uPrefixCountB) + (PrefixLengthB)]
#define DPMI(PrefixLengthA, PrefixLengthB)    DPMI_[(PrefixLengthA)*(uPrefixCountB) + (PrefixLengthB)]
#define DPDM(PrefixLengthA, PrefixLengthB)    DPDM_[(PrefixLengthA)*(uPrefixCountB) + (PrefixLengthB)]
#define DPIM(PrefixLengthA, PrefixLengthB)    DPIM_[(PrefixLengthA)*(uPrefixCountB) + (PrefixLengthB)]

#define TBMM(PrefixLengthA, PrefixLengthB)    TBMM_[(PrefixLengthA)*(uPrefixCountB) + (PrefixLengthB)]
#define TBMD(PrefixLengthA, PrefixLengthB)    TBMD_[(PrefixLengthA)*(uPrefixCountB) + (PrefixLengthB)]
#define TBMI(PrefixLengthA, PrefixLengthB)    TBMI_[(PrefixLengthA)*(uPrefixCountB) + (PrefixLengthB)]
#define TBDM(PrefixLengthA, PrefixLengthB)    TBDM_[(PrefixLengthA)*(uPrefixCountB) + (PrefixLengthB)]
#define TBIM(PrefixLengthA, PrefixLengthB)    TBIM_[(PrefixLengthA)*(uPrefixCountB) + (PrefixLengthB)]

#endif    // MMPRC_h
