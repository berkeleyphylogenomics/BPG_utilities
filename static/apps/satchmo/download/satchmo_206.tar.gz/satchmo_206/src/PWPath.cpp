// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWPath.h"
#include "PWScore.h"
#include "Seq.h"
#include "TextFile.h"
#include "MSA.h"

PWPath::PWPath()
    {
    m_uArraySize = 0;
    m_uEdgeCount = 0;
    m_Edges = 0;
    }

PWPath::~PWPath()
    {
    Clear();
    }

void PWPath::Clear()
    {
    delete[] m_Edges;
    m_Edges = 0;
    m_uArraySize = 0;
    m_uEdgeCount = 0;
    }

void PWPath::ExpandPath(unsigned uAdditionalEdgeCount)
    {
    PWEdge *OldPath = m_Edges;
    unsigned uEdgeCount = m_uArraySize + uAdditionalEdgeCount;

    m_Edges = new PWEdge[uEdgeCount];
    m_uArraySize = uEdgeCount;
    if (m_uEdgeCount > 0)
        memcpy(m_Edges, OldPath, m_uEdgeCount*sizeof(PWEdge));
    delete[] OldPath;
    }

void PWPath::AppendEdge(const PWEdge &Edge)
    {
    if (0 == m_uArraySize || m_uEdgeCount + 1 == m_uArraySize)
        ExpandPath(200);

    m_Edges[m_uEdgeCount] = Edge;
    ++m_uEdgeCount;
    }

void PWPath::PrependEdge(const PWEdge &Edge)
    {
    if (0 == m_uArraySize || m_uEdgeCount + 1 == m_uArraySize)
        ExpandPath(1000);
    if (m_uEdgeCount > 0)
        memmove(m_Edges + 1, m_Edges, sizeof(PWEdge)*m_uEdgeCount);
    m_Edges[0] = Edge;
    ++m_uEdgeCount;
    }

const PWEdge &PWPath::GetEdge(unsigned uEdgeIndex) const
    {
    assert(uEdgeIndex < m_uEdgeCount);
    return m_Edges[uEdgeIndex];
    }

void PWPath::Validate(const PWScore &PWS) const
    {
    const unsigned uEdgeCount = GetEdgeCount();
    if (0 == uEdgeCount)
        return;
    const PWEdge &FirstEdge = GetEdge(0);
    const PWEdge &LastEdge = GetEdge(uEdgeCount - 1);
    const unsigned uLengthA = PWS.GetLengthA();
    const unsigned uLengthB = PWS.GetLengthB();
    unsigned uStartA = FirstEdge.uPrefixLengthA;
    unsigned uStartB = FirstEdge.uPrefixLengthB;
    if (FirstEdge.cType != 'I')
        --uStartA;
    if (FirstEdge.cType != 'D')
        --uStartB;
    if (GLOBAL == PWS.GetBoundsA())
        {
        assert(uStartA == 0);
        assert(LastEdge.uPrefixLengthA == uLengthA);
        }
    else
        {
        assert(FirstEdge.uPrefixLengthA <= uLengthA);
        assert(LastEdge.uPrefixLengthA <= uLengthA);
        }
    if (GLOBAL == PWS.GetBoundsB())
        {
        assert(uStartB == 0);
        assert(LastEdge.uPrefixLengthB == uLengthB);
        }
    else
        {
        assert(FirstEdge.uPrefixLengthB <= uLengthB);
        assert(LastEdge.uPrefixLengthB <= uLengthB);
        }

    unsigned uPrefixLengthA = FirstEdge.uPrefixLengthA;
    unsigned uPrefixLengthB = FirstEdge.uPrefixLengthB;
    for (unsigned uEdgeIndex = 1; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const PWEdge &Edge = GetEdge(uEdgeIndex);
        switch (Edge.cType)
            {
        case 'M':
            assert(uPrefixLengthA + 1 == Edge.uPrefixLengthA);
            assert(uPrefixLengthB + 1 == Edge.uPrefixLengthB);
            ++uPrefixLengthA;
            ++uPrefixLengthB;
            break;
        case 'D':
            assert(uPrefixLengthA + 1 == Edge.uPrefixLengthA);
            ++uPrefixLengthA;
            break;
        case 'I':
            assert(uPrefixLengthB + 1 == Edge.uPrefixLengthB);
            ++uPrefixLengthB;
            break;
            }
        }
    }

void PWPath::ListMe() const
    {
    for (unsigned uEdgeIndex = 0; uEdgeIndex < GetEdgeCount(); ++uEdgeIndex)
        {
        const PWEdge &Edge = GetEdge(uEdgeIndex);
        if (uEdgeIndex > 0)
            List(" ");
        List("%c%d.%d",
          Edge.cType,
          Edge.uPrefixLengthA,
          Edge.uPrefixLengthB);
        if ((uEdgeIndex > 0 && uEdgeIndex%10 == 0) ||
         uEdgeIndex == GetEdgeCount() - 1)
            List("\n");
        }
    }

void PWPath::Copy(const PWPath &Path)
    {
    Clear();
    const unsigned uEdgeCount = Path.GetEdgeCount();
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const PWEdge &Edge = Path.GetEdge(uEdgeIndex);
        AppendEdge(Edge);
        }
    }

void PWPath::FromMSA(const MSA &a)
    {
    if (a.GetSeqCount() != 2)
        Quit("PWPath::FromMSA: must be pair-wise alignment");

    Clear();
    const unsigned uColCount = a.GetColCount();
    if (0 == uColCount)
        return;

    unsigned uFirstAlignedCol = uInsane;
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        const COLINFO &CI = a.GetColInfo(uColIndex);
        if (CI.m_bAligned)
            {
            uFirstAlignedCol = uColIndex;
            break;
            }
        }

    unsigned uLastAlignedCol = uInsane;
    for (int iColIndex = (int) uColCount - 1; iColIndex >= 0; --iColIndex)
        {
        const COLINFO &CI = a.GetColInfo((unsigned) iColIndex);
        if (CI.m_bAligned)
            {
            uLastAlignedCol = (unsigned) iColIndex;
            break;
            }
        }

    unsigned uPrefixLengthA = a.GetUngappedColIndex(0, uFirstAlignedCol);
    unsigned uPrefixLengthB = a.GetUngappedColIndex(1, uFirstAlignedCol);
    for (unsigned uColIndex = uFirstAlignedCol; uColIndex <= uLastAlignedCol;
      ++uColIndex)
        {
        PWEdge Edge;
        char cType;
        if (a.IsGap(0, uColIndex))
            {
            cType = 'I';
            ++uPrefixLengthB;
            }
        else if (a.IsGap(1, uColIndex))
            {
            cType = 'D';
            ++uPrefixLengthA;
            }
        else
            {
            cType = 'M';
            ++uPrefixLengthA;
            ++uPrefixLengthB;
            }

        Edge.cType = cType;
        Edge.uPrefixLengthA = uPrefixLengthA;
        Edge.uPrefixLengthB = uPrefixLengthB;
        AppendEdge(Edge);
        }
    }

// Very similar to HMMPath::FromFile, should consolidate.
void PWPath::FromFile(TextFile &File)
    {
    Clear();
    char szToken[1024];
    File.GetTokenX(szToken, sizeof(szToken));
    if (0 != strcmp(szToken, "Path"))
        Quit("Invalid path file (Path)");

    File.GetTokenX(szToken, sizeof(szToken));
    if (0 != strcmp(szToken, "edges"))
        Quit("Invalid path file (edges)");

    File.GetTokenX(szToken, sizeof(szToken));
    if (!IsValidInteger(szToken))
        Quit("Invalid path file (edges value)");

    const unsigned uEdgeCount = (unsigned) atoi(szToken);
    unsigned uEdgeIndex = 0;
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
    // index
        File.GetTokenX(szToken, sizeof(szToken));
        if (!IsValidInteger(szToken))
            Quit("Invalid path file, invalid index '%s'", szToken);
        unsigned n = (unsigned) atoi(szToken);
        if (n != uEdgeIndex)
            Quit("Invalid path file, expecting edge %u got %u", uEdgeIndex, n);

    // type
        File.GetTokenX(szToken, sizeof(szToken));
        if (1 != strlen(szToken))
            Quit("Invalid path file, expecting state, got '%s'", szToken);
        const char cType = szToken[0];
        if ('M' != cType && 'D' != cType && cType != 'I' && 'S' != cType)
            Quit("Invalid path file, expecting state, got '%c'", cType);

    // prefix length A
        File.GetTokenX(szToken, sizeof(szToken));
        if (!IsValidInteger(szToken))
            Quit("Invalid path file, bad prefix length A '%s'", szToken);
        const unsigned uPrefixLengthA = (unsigned) atoi(szToken);

    // prefix length B
        File.GetTokenX(szToken, sizeof(szToken));
        if (!IsValidInteger(szToken))
            Quit("Invalid path file, bad prefix length B '%s'", szToken);
        const unsigned uPrefixLengthB = (unsigned) atoi(szToken);

        PWEdge Edge;
        Edge.cType = cType;
        Edge.uPrefixLengthA = uPrefixLengthA;
        Edge.uPrefixLengthB = uPrefixLengthB;
        AppendEdge(Edge);
        }
    File.GetTokenX(szToken, sizeof(szToken));
    if (0 != strcmp(szToken, "//"))
        Quit("Invalid path file (//)");
    }

void PWPath::ToFile(TextFile &File) const
    {
    const unsigned uEdgeCount = GetEdgeCount();

    File.PutString("Path\n");
    File.PutFormat("edges %u\n", uEdgeCount);
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const PWEdge &Edge = GetEdge(uEdgeIndex);
        File.PutFormat("%u %c %u %u\n",
          uEdgeIndex,
          Edge.cType,
          Edge.uPrefixLengthA,
          Edge.uPrefixLengthB);
        }
    File.PutString("//\n");
    }
