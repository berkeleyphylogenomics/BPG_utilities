// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "MSA.h"
#include "MSADistKimura.h"

#define    Set(i, j, d)    dDist[(i) + uSeqCount*(j)] = (d);
#define Get(i, j)        dDist[(i) + uSeqCount*(j)]

void DoProtDist(const char *in, const char *out)
    {
    TextFile fileIn(in);

    MSA msa;
    msa.FromFASTAFile(fileIn);
    msa.AlignByCase();

    MSADistKimura Dist;

    const unsigned uSeqCount = msa.GetSeqCount();

// Allocate memory for matrix
    double *dDist = new double[uSeqCount*uSeqCount];

// Compute matrix
    for (unsigned i = 0; i < uSeqCount; ++i)
        {
        Set(i, i, 0.0);        
        for (unsigned j = 0; j < i; ++j)
            {
            const double d = Dist.ComputeDist(msa, i, j);
            Set(i, j, d);
            Set(j, i, d);
            }
        }

// Create output file
    TextFile fileOut(out, true);

// Write matrix in Phylip-compatible format
// First line has number of sequences
    fileOut.PutFormat("  %u\n", uSeqCount);

    for (unsigned i = 0; i < uSeqCount; ++i)
        {
        const char *ptrSeqName = msa.GetSeqName(i);
        fileOut.PutFormat("%-10.10s", ptrSeqName);
        fileOut.PutString("     ");
        for (unsigned j = 0; j < uSeqCount; ++j)
            {
            const double d = Get(i, j);
            fileOut.PutFormat("  %9.6g", d);
            }
        fileOut.PutString("\n");
        }
    }
