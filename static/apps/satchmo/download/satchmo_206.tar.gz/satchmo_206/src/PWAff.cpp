// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWAff.h"
#include "Seq.h"

PWAff::PWAff()
    {
    m_ptrSeqA = 0;
    m_ptrSeqB = 0;
    }

PWAff::~PWAff()
    {
    }

void PWAff::Init(const Seq &SeqA, BOUNDS BoundsA, const Seq &SeqB, BOUNDS BoundsB)
    {
    m_ptrSeqA = &SeqA;
    m_ptrSeqB = &SeqB;

    m_scoreGapOpen = -5;
    m_scoreGapExtend = -0.5;

    m_boundsA = BoundsA;
    m_boundsB = BoundsB;

    for (unsigned i = 0; i < 23; ++i)
        for (unsigned j = 0; j < 23; ++j)
            m_scoreLL[i][j] = GetBlosum62(i, j);
    }

unsigned PWAff::GetLengthA() const
    {
    return m_ptrSeqA->Length();
    }

unsigned PWAff::GetLengthB() const
    {
    return m_ptrSeqB->Length();
    }

SCORE PWAff::ScoreMM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return 0;
    }

SCORE PWAff::ScoreMD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return m_scoreGapOpen;
    }

SCORE PWAff::ScoreMI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return m_scoreGapOpen;
    }

SCORE PWAff::ScoreDM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return 0;
    }

SCORE PWAff::ScoreDD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return m_scoreGapExtend;
    }

SCORE PWAff::ScoreDI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return m_scoreGapOpen;
    }

SCORE PWAff::ScoreIM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return 0;
    }

SCORE PWAff::ScoreID(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return m_scoreGapOpen;
    }

SCORE PWAff::ScoreII(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return m_scoreGapExtend;
    }

SCORE PWAff::ScoreSM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && 1 != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && 1 != uPrefixLengthB)
        return MINUS_INFINITY;
    return 0;
    }

SCORE PWAff::ScoreSD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && 1 != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && 0 != uPrefixLengthB)
        return MINUS_INFINITY;
    return m_scoreGapOpen;
    }

SCORE PWAff::ScoreSI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && 0 != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && 1 != uPrefixLengthB)
        return MINUS_INFINITY;
    return m_scoreGapOpen;
    }

SCORE PWAff::ScoreME(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && GetLengthA() != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && GetLengthB() != uPrefixLengthB)
        return MINUS_INFINITY;
    return 0;
    }

SCORE PWAff::ScoreDE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && GetLengthA() != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && GetLengthB() != uPrefixLengthB)
        return MINUS_INFINITY;
    return 0;
    }

SCORE PWAff::ScoreIE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && GetLengthA() != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && GetLengthB() != uPrefixLengthB)
        return MINUS_INFINITY;
    return 0;
    }

SCORE PWAff::ScoreLL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthA > 0);
    assert(uPrefixLengthB > 0);
    unsigned uLetterA = m_ptrSeqA->GetLetter(uPrefixLengthA - 1);
    unsigned uLetterB = m_ptrSeqB->GetLetter(uPrefixLengthB - 1);
    return m_scoreLL[uLetterA][uLetterB];
    }

SCORE PWAff::ScoreLG(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return 0;
    }

SCORE PWAff::ScoreGL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return 0;
    }
