// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include <math.h>

#define    VERBOSE    0

const unsigned uIters = 100000;

static void Shuffle(const unsigned uValues[], unsigned uShuffledValues[], unsigned uIter)
    {
    memcpy(uShuffledValues, uValues, uIter*sizeof(unsigned));
    unsigned k = uIter - 1;
    for (unsigned n = 0; n < uIter - 1; ++n)
        {
        unsigned uIndex = rand()%(k + 1);
        unsigned uTmp = uShuffledValues[k];
        uShuffledValues[k] = uShuffledValues[uIndex];
        uShuffledValues[uIndex] = uTmp;
        --k;
        }
    }

static double PARScorePair(const unsigned uFams[], unsigned uIter)
    {
    assert(uIter > 1);
    assert(uFams[0] == uFams[uIter-1]);
    const unsigned uFam = uFams[0];
    unsigned uSameFam = 0;
    for (unsigned n = 0; n < uIter; ++n)
        if (uFams[n] == uFam)
            ++uSameFam;
    return (double) uSameFam / (double) uIter;
    }

static double PARScore(const unsigned uFams[], unsigned uSuperFamSize)
    {
    if (uSuperFamSize < 2)
        return 1.0;

    double dSum = 0.0;
    unsigned uPairCount = 0;
    for (unsigned uSeq1 = 0; uSeq1 < uSuperFamSize; ++uSeq1)
        {
        const unsigned uFam1 = uFams[uSeq1];
        for (unsigned uSeq2 = uSeq1 + 1; uSeq2 < uSuperFamSize; ++uSeq2)
            {
            const unsigned uFam2 = uFams[uSeq2];
            if (uFam2 != uFam1)
                continue;
            ++uPairCount;
            double dPairScore = PARScorePair(uFams+uSeq1, uSeq2-uSeq1+1);
            dSum += dPairScore;
            }
        }
    return dSum / uPairCount;
    }

static unsigned ZFPCount(const unsigned uFams[], unsigned uSuperFamSize)
    {
    assert(uSuperFamSize > 1);
    unsigned uZFPCount = 0;
    for (unsigned n = 1; n < uSuperFamSize; ++n)
        {
        if (uFams[n] != uFams[n-1])
            ++uZFPCount;
        }
    return uZFPCount + 1;
    }

static void EstTreeScores(const unsigned uFamSize[], unsigned uFamCount)
    {
    unsigned uSuperFamSize = 0;
    for (unsigned n = 0; n < uFamCount; ++n)
        uSuperFamSize += uFamSize[n];
    
    unsigned *uUnshuffledFams = new unsigned[uSuperFamSize];
    unsigned *uShuffledFams = new unsigned[uSuperFamSize];

    double *dPARScores = new double[uIters];
    double *dZFPScores = new double[uIters];

    for (unsigned n = 0; n < uIters; ++n)
        {
        dPARScores[n] = 0.0;
        dZFPScores[n] = 0.0;
        }

    unsigned uIndex = 0;
    for (unsigned uFamIndex = 0; uFamIndex < uFamCount; ++uFamIndex)
        for (unsigned uMemberIndex = 0; uMemberIndex < uFamSize[uFamIndex];
          ++uMemberIndex)
            uUnshuffledFams[uIndex++] = uFamIndex;
    assert(uIndex == uSuperFamSize);
#if    0
        List("Unshuffled: ");
        for (unsigned n = 0; n < uSuperFamSize; ++n)
            List(" %u", uUnshuffledFams[n]);
        List("\n");
#endif

    const unsigned uMinZFPCount = uFamCount;
    const unsigned uMaxZFPCount = uSuperFamSize;

    unsigned *uBins = new unsigned[uSuperFamSize+1];
    memset(uBins, 0, (uSuperFamSize+1)*sizeof(unsigned));

    unsigned uMinZFP = 0;
    unsigned uMaxZFP = 0;
    double dTotalZFP = 0;
    double dTotalPAR = 0;
    for (unsigned uIter = 0; uIter < uIters; ++uIter)
        {
        Shuffle(uUnshuffledFams, uShuffledFams, uSuperFamSize);
#if    0
        List("Shuffled: ");
        for (unsigned n = 0; n < uSuperFamSize; ++n)
            List(" %u", uShuffledFams[n]);
        List("\n");
#endif
        unsigned uZFPCount = ZFPCount(uShuffledFams, uSuperFamSize);
#if    0
        List("ZFPCount=%u\n", uZFPCount);
#endif
        if (uZFPCount > uMaxZFP)
            uMaxZFP = uZFPCount;
        if (uZFPCount < uMinZFP)
            uMinZFP = uZFPCount;
        dZFPScores[uIter] = uZFPCount;
        dTotalZFP += uZFPCount;
        assert(uZFPCount >= uMinZFPCount && uZFPCount <= uMaxZFPCount);
        ++(uBins[uZFPCount]);

        double dPARScore = PARScore(uShuffledFams, uSuperFamSize);
        dPARScores[uIter] = dPARScore;
        dTotalPAR += dPARScore;
#if    0
        printf("PARScore=%g\n", dPARScore);
#endif
        if (0 == uIter%10000 && uIter > 0)
            printf("%12u  ZFP %g PAR %g          \n",
              uIter,
              dTotalZFP / uIter,
              dTotalPAR / uIter);
        }

    double dSum = 0.0;
    for (unsigned n = 1; n <= uSuperFamSize; ++n)
        {
        if (uBins[n] > 0)
            {
            double dScore = (double) uFamCount/ (double) n;
            dSum += (double) uBins[n];
            double dProb = dSum / (double) uIters;
            List("ZFP %3u  Score %10.4f  Count %11u  E-value %10.3e\n",
              n, dScore, uBins[n], dProb);
            }
        }

    double dZFPAvgTotal = dTotalZFP / uIters;
    double dZFPAvg = uFamCount / dZFPAvgTotal;
    double dPARAvg = dTotalPAR / uIters;

    double dZFPSum2 = 0.0;
    for (unsigned n = 0; n < uIters; ++n)
        {
        double d = (uFamCount / dZFPScores[n]) - dZFPAvg;
        dZFPSum2 += d*d;
        }

    double dPARSum2 = 0.0;
    for (unsigned n = 0; n < uIters; ++n)
        {
        double d = dPARScores[n] - dPARAvg;
        dPARSum2 += d*d;
        }

    double dZFPStdDev = sqrt(dZFPSum2/uIters);
    double dPARStdDev = sqrt(dPARSum2/uIters);

    printf("ZFP=%.3g ZFPStdDev=%.3g PAR=%.3g PARStdDev=%.3g ",
      dZFPAvg,
      dZFPStdDev,
      dPARAvg,
      dPARStdDev);
    List("ZFP=%.3g ZFPStdDev=%.3g PAR=%.3g PARStdDev=%.3g ",
      dZFPAvg,
      dZFPStdDev,
      dPARAvg,
      dPARStdDev);

    for (unsigned n = 0; n < uFamCount; ++n)
        {
        if (n > 0)
            {
            printf("/");
            List("/");
            }
        List("%u", uFamSize[n]);
        printf("%u", uFamSize[n]);
        }
    printf("\n");
    List("\n");
    }

void TestPhy(int argc, char *argv[])
    {
    unsigned Fams[4];
    Fams[0] = 11;
    Fams[1] = 79;
    Fams[2] = 8;
    Fams[3] = 5;
    EstTreeScores(Fams, 4);
    }

void DoRandTreeScores(const char *strETS)
    {
    char *strSizes = strdup(strETS);

    size_t n = strlen(strSizes);
    unsigned *Fams = new unsigned[n];
    unsigned uFamCount = 0;
    char *p = strSizes;
    char c;
    for (char *s = strSizes; ; ++s)
        {
        c = *s;
        if (c == 0 || c == '/')
            {
            *s = 0;
            Fams[uFamCount] = (unsigned) atoi(p);
            p = s + 1;
            ++uFamCount;
            }
        if (c == 0)
            break;
        }
    EstTreeScores(Fams, uFamCount);

    free(strSizes);
    delete[] Fams;
    }
