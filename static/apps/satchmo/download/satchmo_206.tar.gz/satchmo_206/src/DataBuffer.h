// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef DataBuffer_h
#define    DataBuffer_h

class DataBuffer
    {
public:
    DataBuffer();
    virtual ~DataBuffer();

public:
    void FromFile(const char *strFileName);
    void ToFile(const char *strFileName) const;
    void SetSize(unsigned uBytes);
    void Get(unsigned uPos, void *ptrData, unsigned uBytes) const;
    void Put(unsigned uPos, const void *ptrData, unsigned uBytes);
    void Clear();

private:
    unsigned char *m_ucBuffer;
    unsigned m_uBytes;
    };

#endif    // DataBuffer_h
