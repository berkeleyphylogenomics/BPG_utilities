// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "TextFile.h"
#include "Profile.h"
#include "PPPW.h"

static double DoPos(const MSA &msa1, const MSA &msa2, unsigned uColIndex,
  const ProfPos &PP1, const ProfPos &PP2, PPDist2 &PPD)
    {
    const unsigned uSeqCount1 = msa1.GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount1; ++uSeqIndex)
        List("%c", msa1.GetChar(uSeqIndex, uColIndex));

    List(" | ");
    const unsigned uSeqCount2 = msa2.GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount2; ++uSeqIndex)
        List("%c", msa2.GetChar(uSeqIndex, uColIndex));

    const double dDist = PPD.PPPosDist(PP1, PP2);

    List("   ");
    List("%g\n", dDist);

    return dDist;
    }

void DoBete2(const char *in1, const char *in2)
    {
    const char *colpair = GetOptionalParam("colpair", "RE");

    TextFile fileIn1(in1);
    TextFile fileIn2(in2);

    MSA msa1;
    MSA msa2;

    msa1.FromFile(fileIn1);
    msa2.FromFile(fileIn2);

    const unsigned uColCount = msa1.GetColCount();
    if (uColCount != msa2.GetColCount())
        Quit("Alignments have different lengths");

    msa1.SetAllAligned();
    msa2.SetAllAligned();

    msa1.BuildPillars();
    msa2.BuildPillars();

    if (GetFlag("unweight"))
        {
        fprintf (stderr, "unweighting ....\n");
        msa1.UnWeight();
        msa2.UnWeight();
        }

    Profile Prof1;
    Profile Prof2;

    const char *ptrSeedId1 = msa1.GetSeqName(0);
    const char *ptrSeedId2 = msa2.GetSeqName(0);

    Prof1.FromMSA(msa1, ptrSeedId1);
    Prof2.FromMSA(msa2, ptrSeedId2);

    const unsigned uPosCount = Prof1.GetPosCount();
    if (uPosCount != Prof2.GetPosCount())
        Quit("Profiles have different lengths");

    //List("Prof1=\n");
    //Prof1.ListMe();
    //List("Prof2=\n");
    //Prof2.ListMe();

    PWBase *ptrPWScorer;
    PWSFactory(colpair, "simple", "LL", &ptrPWScorer);

    PPPW Dist(*ptrPWScorer);

    double dSum = 0;
    for (unsigned uColIndex = 0; uColIndex < uPosCount; ++uColIndex)
        {
        const ProfPos &PP1 = Prof1.GetPos(uColIndex);
        const ProfPos &PP2 = Prof2.GetPos(uColIndex);
        double dDist = DoPos(msa1, msa2, uColIndex, PP1, PP2, Dist);
        dSum += dDist;
        }

    List("\n");
    List("Total    %g\n", dSum);
    List("Average  %g\n", dSum / uPosCount);
    }
