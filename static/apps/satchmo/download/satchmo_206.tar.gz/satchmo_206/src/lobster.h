// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    Lobster_h
#define    Lobster_h

#ifdef    _WIN32
#pragma once
#endif

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdarg.h>
#include <assert.h>
#include <time.h>
#include "IntMath.h"
#include "Alpha.h"
#include <math.h>

#ifndef _WIN32
#define stricmp strcasecmp
#define    _snprintf snprintf
#define _fsopen(name, mode, share)    fopen((name), (mode))
#endif

const WCOUNT DEFAULT_MAX_NIC = 9999;

class MSA;
class Seq;
class ClusterTree;
class DistFunc;
class DirMix;
class TextFile;
class GNode2;
class PWPath;
class PWScore;
class HMM;
class Profile;
class PWBase;

enum MODEL_BOUNDS
    {
    LOCAL_MODEL = 1,
    GLOBAL_MODEL = 2
    };

enum SEQ_BOUNDS
    {
    LOCAL_SEQ = 1,
    GLOBAL_SEQ = 2
    };

enum BOUNDS
    {
    BOUNDS_Undefined = 0,
    LOCAL = 1,
    GLOBAL = 2
    };

enum JOINSTYLE
    {
    JOINSTYLE_Undefined,
    JOINSTYLE_NearestNeighbor,
    JOINSTYLE_NeighborJoining
    };

enum CENTROIDSTYLE
    {
    CENTROIDSTYLE_Undefined,
    CENTROIDSTYLE_AverageLinkage,
    CENTROIDSTYLE_NeighborJoining,
    CENTROIDSTYLE_ComputedBySet
    };

// Number of elements in array a[]
#define countof(a)    (sizeof(a)/sizeof(a[0]))

// Maximum of two of any type
#define    Max2(a, b)            ((a) > (b) ? (a) : (b))

// Maximum of three of any type
#define    Max3(a, b, c)        Max2(Max2(a, b), c)

// Minimum of two of any type
#define Min2(a, b)        ((a) < (b) ? (a) : (b))

// Maximum of four of any type
#define Max4(a, b, c, d)    Max2(Max2(a, b), Max2(c, d))

enum CLUSTER_STRATEGY
    {
    CLUSTER_STRATEGY_Unknown,
    CLUSTER_STRATEGY_Min,
    CLUSTER_STRATEGY_Max,
    CLUSTER_STRATEGY_Mean,
    };

enum BUILD_METHOD
    {
    BUILD_METHOD_Unknown,
    BUILD_METHOD_Krogh,
    BUILD_METHOD_Sjolander,
    };

// Max length of an alphabet
const int MAX_ALPHA = 20;

const double VERY_NEGATIVE_DOUBLE = -9e99;

const double BLOSUM_DIST = 0.62;    // todo settable

// insane value for uninitialized variables
const unsigned uInsane = 8888888;
const int iInsane = 8888888;
const SCORE scoreInsane = 8888888;
const char cInsane = (char) 0xcd;        // int 3 instruction, used e.g. for unint. memory
const double dInsane = VERY_NEGATIVE_DOUBLE;
const char INVALID_STATE = '*';
const BASETYPE BTInsane = (BASETYPE) dInsane;
const WCOUNT wcInsane = BTInsane;

extern bool g_bUseBreakMatrices;
extern bool g_bSamePath;
extern bool g_bSaveMSS;
extern bool g_bSaveHMMs;

//MPI globals
extern int g_numprocs;
extern int g_my_rank;
extern char *g_processor_name;

extern double g_dNAN;

extern TextFile *g_ptrSmoFile;
extern const char *g_strBSPath;
extern const char *g_strAlignStyle;   // new
extern const char *g_strJoinMethod; //new
extern const char *g_strPairOnlyOne;   // new
extern const char *g_strPairOnlyTwo;   // new
extern long g_tStart;

void Quit(const char szFormat[], ...);
void TrimBlanks(char szStr[]);
void TrimLeadingBlanks(char szStr[]);
void TrimTrailingBlanks(char szStr[]);
void List(const char szFormat[], ...);
bool Verbose();
const char *ScoreToStr(SCORE Score);
const char *ScoreToStrL(SCORE Score);
const char *WCountToStr(WCOUNT WCount);
const char *WeightToStr(WCOUNT WCount);
const char *BoundsToStr(BOUNDS b);
SCORE StrToScore(const char *pszStr);
void ReadFA(const char szFileName[], char szStr[], unsigned uBytes);
unsigned short CRC(char *Data, unsigned uBytes);
void Break();

double VecSum(const double v[], unsigned n);
bool IsValidInteger(const char *Str);
bool IsValidSignedInteger(const char *Str);
bool IsValidIdentifier(const char *Str);

void StripGaps(char szStr[]);
const char *GetTimeAsStr();
unsigned CalcBLOSUMWeights(MSA &Aln, ClusterTree &BlosumCluster);
void CalcGSCWeights(MSA &Aln, const ClusterTree &BlosumCluster);
void LogNormalize(const double LogScores[], unsigned n, double Probs[]);
void LogNormalize(const float LogScores[], unsigned n, double Probs[]);
double RelativeEntropy(const PROB probA[], const PROB probB[]);
void AssertNormalized(const PROB p[]);
void AssertNormalizedOrZero(const PROB p[]);
void AssertNormalized(const double p[]);
bool IsEmitterTrans(char cFromState, char cToState);
bool VectorIsZero(const double dValues[], unsigned n);
void VectorSet(double dValues[], unsigned n, double d);
bool VectorIsZero(const float dValues[], unsigned n);
void VectorSet(float dValues[], unsigned n, float d);

#ifndef WINDOWS
double log2(double x);    // Defined in <math.h> on Linux
#endif

double LnGamma(double x);
double pow2(double x);
double lnTolog2(double ln);

double lp2(double x);
SCORE SumLog(SCORE x, SCORE y);
SCORE SumLog(SCORE x, SCORE y, SCORE z);
SCORE SumLog(SCORE w, SCORE x, SCORE y, SCORE z);

double lp2Fast(double x);
double SumLogFast(double x, double y);
double SumLogFast(double x, double y, double z);
double SumLogFast(double w, double x, double y, double z);

void chkmem();

void Normalize(PROB p[], unsigned n);
void Normalize(PROB p[], unsigned n, double dRequiredTotal);
void NormalizeUnlessZero(PROB p[], unsigned n);

SCORE GetNullEmitTransScore();
SCORE GetNullEmitScore(unsigned uLetter);
PROB GetNullEmitProb(unsigned uLetter);
PROB GetBackgroundProb(unsigned uLetter);
SCORE GetNullEmitScoreChar(char c);
void DetailedUsage();    
void DebugPrintf(const char szFormat[], ...);
void SetListFileName(const char *ptrListFileName, bool bAppend);
void ModelFromAlign(const char *strInputFileName, const char *strModelFileName,
  double dMaxNIC);
void AlignToModel(const char *strInputFileName, const char *strModelFileName, 
  const char *strTemplateFileName, const char *strOutputFastaFileName,
  const char *strOutputMsfFileName, const char *strPathFileName,
  double dMaxNIC, bool bReverseScore);
void SetMatchPriors(const char *strMatchPriorFileName);
void SetTransPriors(const char *strTransPriorFileName);
void TransPriorFromFile(TextFile &File, double dTransPrior[9]);
void BaliScore(const MSA &msaRef, const MSA &msaTest, double *ptrdSP,
  double *ptrdTC, double *ptrdPS);
void ClineScore(const MSA &msaRef, const MSA &msaTest, double dEpsilon,
  double *ptrdScore);
double ClineScorePair(const MSA &msaRef, const MSA &msaTest,  unsigned uRefSeqIndex1,
  unsigned uRefSeqIndex2, double dEpsilon);
void CompareSeqFiles(const char *pstrFile1, const char *pstrSeq1, const char *pstrFile2,
  const char *pstrSeq2);
void DoWeight(const char *strWeightFileName, const char *strOutFileName);
double PairwiseIdentityAlignedOnly(const MSA &a1, unsigned uSeqIndex1,
  unsigned uSeqIndex2);
double PairwiseIdentityAll(const MSA &a1, unsigned uSeqIndex1, unsigned uSeqIndex2);
void DoPctIds(const char *strFileName);
WCOUNT GetMaxNIC();
void SetMaxNIC(WCOUNT wcMaxNIC);
void DoClustalFilter(const char *strInFileName, const char *strOutFileName);
void DoBitsSaved(const char *strInputFileName);
void DoTotalWeight(const char *strTotalWeightName);
void DoScoreDB(const char *strDBFileName, const char *strModelFileName);
WCOUNT CharVectorToLetterCounts(const WEIGHT Weights[], const char Chars[],
  unsigned uCharCount, WCOUNT wcCounts[]);
bool CAS_HMMEmit(const WEIGHT Weights[], const char Chars[], unsigned uCharCount,
  double *pdScore);
bool CAS_DirComp(const WEIGHT Weights[], const char Chars[], unsigned uCharCount,
  double *pdScore);
void CAS_MSA(MSA &a, const char *strFileNamePrefix);
void DoCAS(const char *strMSAFileName, const char *strOutputPrefix);
void ListDP(unsigned uNodeCount, unsigned uPrefixCount, const SCORE *DPM_,
  const SCORE *DPD_, const SCORE *DPI_);
void ListDPProb(unsigned uNodeCount, unsigned uPrefixCount, const SCORE *DPM_,
  const SCORE *DPD_, const SCORE *DPI_);
void DoMSAStats(const char *strFileName);
void DoDBStats(const char *strFileName);
double GetMemUseMB();
double GetPeakMemUseMB();
void CheckMemUse();
void WriteNodeToSmoFile(TextFile &File, GNode2 &Node, bool bSaveHMM,
  bool bSaveMSS);
void ScorePathFile(const char *strPathFileName, const char *strModelFileName,
  const char *strTargetFileName);
const char *ElapsedTimeAsString();
char *SecsToHHMMSS(long lSecs, char szStr[]);
double EstMB_v2(unsigned N, unsigned L);
double EstSecs_v2(unsigned N, unsigned L, double dGHz);
double EstSecs_nobm(unsigned N, unsigned L, double dGHz);
double EstSecs_nobmv1(unsigned N, unsigned L, double dGHz);
double GetCPUGHz();
void DoScoreTree(const char *strFileName);
void DoSV2Phylip(const char *strSVFileName, const char *strPhylipFileName);
void DoRootOutlier(const char *strUnrootedFileName, const char *strRootedFileName);
void DoEstTreeScores(const char *strETS);
void DoSV2FASTA(const char *strSVFileName, const char *strFASTAFileName);
void DoDelSeq(const char *strDelSeqFileName, const char *strSeqName,
  const char *strFASTAFileName);
void AddOutlier(const MSA &msaIn, MSA &msaOut);
void DoAddOutlier(const char *strInputFileName, const char *strOutputFileName);
void ExtractCore(const MSA &alnCode, const MSA &alnInput, MSA &msaOutput);
void DoExtractCore(const char *strCoreFileName, const char *strInputFileName,
  const char *strOutputFileName);
void DoPWAlign(const char *strFile1, const char *strFile2);
void PWSeq(const Seq &seqA, const Seq &seqB, SEQ_BOUNDS BoundsA,
  SEQ_BOUNDS BoundsB, PWPath &Path);
void ListPWDP(const SCORE *DPM_, const SCORE *DPD_, const SCORE *DPI_, const char *TBM_,
  const char *TBD_, const char *TBI_, unsigned uPrefixCountA, unsigned uPrefixCountB);
SCORE PWTraceBack(const PWScore &PWS, const SCORE *DPM_, const SCORE *DPD_,
  const SCORE *DPI_, const char *TBM_, const char *TBD_, const char *TBI_,
  PWPath &Path);
SCORE PWAlign(const PWScore &PWS, PWPath &Path);
SCORE PWScorePath(const PWScore &PWS, const PWPath &Path, bool bVerbose = false);
SCORE GetBlosum62(unsigned uLetterA, unsigned uLetterB);
void TestEnumPWPaths();
void TestPWAlign(const PWScore &PWS, PWPath &Path);
void AlignHMMs(const HMM &hmmA, const HMM &hmmB, const PWPath &Path, MSA &msaCombined);
void DoPRC(const char *strHMMFileA, const char *strTplFileA, BOUNDS BoundsA,
  const char *strHMMFileB, const char *strTplFileB, BOUNDS BoundsB,
  const char *strOutputFastaFile);
void AssertNormalizedDist(const PROB p[], unsigned N);
void CmdLineError(const char *Format, ...);
void Fatal(const char *Format, ...);
void InitCmd();
void ExecCommandLine(int argc, char *argv[]);
bool GetFlag(const char *name);
const char *GetParam(const char *name);
const char *GetOptionalParam(const char *name);
const char *GetOptionalParam(const char *name, const char *def);
unsigned GetUnsignedParam(const char *name);
void SetGlobalFlags();
void SetGlobalOptions();
void DoCmd();
void SetLogFile();
void SAMRegFromFile(TextFile &File, double dAlphas[9]);
void ListTransPriors();
void AlignProfiles(const Profile &profA, const Profile &profB, const PWPath &Path,
  MSA &msaCombined);
void PWSFactory(const char *colpair, const char *gapstyle, const char *bounds,
  PWBase **ptrptrPWS);
void NameFromPath(const char szPath[], char szName[], unsigned uBytes);
void QuickAlign(const Seq &seq1, const Seq &seq2, int iMap1[], int iMap2[]);
void MSAFromSeqMap(const Seq &s1, const Seq &s2, const int iMap1[],
  const int iMap2[], MSA &a);
double SumPairs(const int iRefMap[], const int iTestMap[], unsigned uLength);
double ClineShift(const int iTestMapA[], const int iRefMapA[], unsigned uLengthA,
  const int iTestMapB[], const int iRefMapB[], unsigned LengthB,
  double dEpsilon = 0.2);
void CompareMSA(const MSA &masTest, const MSA &msaRef, double *ptrdSP,
  double *ptrdPS, double *ptrdCS);
void ComparePairMap(const int iTestMapA[], const int iTestMapB[],
  const int iRefMapA[], const int iRefMapB[], int iLengthA, int iLengthB,
  double *ptrdSP, double *ptrdPS, double *ptrdCS);
void ComparePair(const MSA &msaTest, unsigned uTestSeqIndexA,
  unsigned uTestSeqIndexB, const MSA &msaRef, unsigned uRefSeqIndexA,
  unsigned uRefSeqIndexB, double *ptrdSP, double *ptrdPS, double *ptrdCS);
void MMPRC(const HMM &hmmA, const HMM &hmmB, BOUNDS BoundsA, BOUNDS BoundsB,
  PWPath &Path);
void Consensus(const MSA &msaA, const MSA &msaB, MSA &msaConsensus);
void MakePairMaps(const MSA &msaTest, unsigned uTestSeqIndexA, unsigned uTestSeqIndexB,
  const MSA &msaRef, unsigned uRefSeqIndexA, unsigned uRefSeqIndexB, int **ptriTestMapAr,
  int **ptriTestMapBr, int **ptriRefMapAr, int **ptriRefMapBr);
void VerboseComparePair(const MSA &msaTest, unsigned uTestSeqIndexA,
  unsigned uTestSeqIndexB, const MSA &msaRef, unsigned uRefSeqIndexA,
  unsigned uRefSeqIndexB, double *ptrdSP, double *ptrdPS, double *ptrdCS);
void VerboseCompareMSA(const MSA &msaTest, const MSA &msaRef, double *ptrdSP,
  double *ptrdPS, double *ptrdCS);
double Correl(const double P[], const double Q[], unsigned uCount);
float Correl(const float P[], const float Q[], unsigned uCount);
void Rank(const float P[], float Ranks[], unsigned uCount);

void DoExtractPW(const char *in,const char *seq1,const char *seq2,const char  *out); //new
#endif    // Lobster_h
