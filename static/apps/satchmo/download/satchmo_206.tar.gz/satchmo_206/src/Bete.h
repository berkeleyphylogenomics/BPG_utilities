// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef Bete_h
#define Bete_h

class MSA;
class Profile;
class PPDist;
struct ClusterInfo;

#include "ClustSet.h"

class Bete : public ClustSet
    {
public:
    Bete();
    virtual ~Bete();

// ClustSet interface
public:
    virtual JOINSTYLE GetJoinStyle();
    virtual CENTROIDSTYLE GetCentroidStyle();
    virtual unsigned GetLeafCount();
    virtual bool IsRooted();
    virtual double ComputeDist(const Clust &C, unsigned uNodeIndex1,
      unsigned uNodeIndex2);
    virtual void JoinNodes(const Clust &C, unsigned uLeftNodeIndex,
      unsigned uRightNodeIndex, unsigned uJoinedNodeIndex,
      double *ptrdLeftLength, double *ptrdRightLength);
    virtual const char *GetLeafName(unsigned uNodeIndex);

// Bete's own interface
public:
    void Init(MSA &msa, PPDist &Dist);
    void SetJoinStyle(JOINSTYLE JoinStyle);
    void SetCentroidStyle(CENTROIDSTYLE CentroidStyle);

// Sub-family identification
    double LogProb(const Clust &C);
    ClusterInfo *BuildClusterInfo(const Clust &C);
    void FreeClusterInfo(ClusterInfo *Info, unsigned uClusterCount);
    void GetClusterCountsCol(unsigned uColIndex, const ClusterInfo &CI,
      const double dSeqWeights[], double dCounts[]);
    void GetCountsAll(unsigned uColIndex, const double dSeqWeights[],
      double dCounts[]);
    double LogProbCounts(const double dCounts[]);
    MSA *m_MSAs; 
        MSA *m_ptrMSA;
    PPDist *m_ptrPPDist;
        Profile *m_Profiles;
private:

    // MSA *m_MSAs;             // I made this public
    WCOUNT m_wcNIC;

    JOINSTYLE m_JoinStyle;
    CENTROIDSTYLE m_CentroidStyle;
    };

#endif // Bete_h
