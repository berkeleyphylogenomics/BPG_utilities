// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "MSA.h"

static bool ScoreEqPct(SCORE s1, SCORE s2, int Pct)
    {
    return BTEq(s1, s2);
    }

static bool ScoreEqLocal(SCORE s1, SCORE s2, int n)
    {
    return BTEq(s1, s2);
    }

void HMM::ListRoute(const HMMPath &Route, const MSA &a) const
    {
    List("ListRoute\n");
    if (a.GetSeqCount() <= 20)
        {
        List("Target alignment:\n");
        a.ListMe();
        a.ListPillars();
        }

    const unsigned uEdgeCount = Route.GetEdgeCount();
    if (0 == uEdgeCount)
        {
        List("ListRoute: zero edges.\n");
        return;
        }

    const unsigned uSeqCount = a.GetSeqCount();

    SCORE *SeqTrans = new SCORE[uSeqCount];
    SCORE *SeqEmit = new SCORE[uSeqCount];
    SCORE *SeqTotal = new SCORE[uSeqCount];

    memset(SeqTrans, 0, uSeqCount*sizeof(SCORE));
    memset(SeqEmit, 0, uSeqCount*sizeof(SCORE));
    memset(SeqTotal, 0, uSeqCount*sizeof(SCORE));

    SCORE scoreRoute = 0;

    List("                                         ");
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        List("    <-Seq %3u Weight %8s->", uSeqIndex, ScoreToStr(a.GetSeqWeight(uSeqIndex)));
    List("\n");

    List("Leg FTNod  PL   Trans    Emit Col   Total");
    //    123 1112312341234567812345678123412345678
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        List("    Trans    Emit Pos C   Total");
        //     12345678123456781234 112345678
    List("  SeqTotal Diff");
    List("\n");

    char cPrevStateToI = INVALID_STATE;
    unsigned uFirstIPillar = uInsane;
    char cFromState = 'S';
    for (unsigned uLegIndex = 0; uLegIndex < uEdgeCount; ++uLegIndex)
        {
        const HMMEdge &Edge = Route.GetEdge(uLegIndex);
        char cToState = Edge.cState;
        const unsigned uNodeIndex = Edge.uNodeIndex;
        const unsigned uPrefixLength = Edge.uPrefixLength;
        SCORE scoreTrans = uInsane;
        SCORE scoreEmit = 0;
#define    c2(a, b)    ((a) | ((b) << 8))
        int iStates = c2(cFromState, cToState);
        switch (iStates)
            {
        case c2('S', 'M'):
            assert(uPrefixLength > 0);
            assert(0 == uNodeIndex);
            scoreTrans = LegSM(a, uNodeIndex, uPrefixLength);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqTrans[uSeqIndex] = LegSeqSM(a, uSeqIndex, uNodeIndex, uPrefixLength);
            break;

        case c2('S', 'D'):
            assert(0 == uNodeIndex);
            scoreTrans = LegSD(a, uNodeIndex, uPrefixLength);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqTrans[uSeqIndex] = LegSeqSD(a, uSeqIndex, uNodeIndex, uPrefixLength);
            break;

        case c2('M', 'M'):
            scoreTrans = LegMM(a, uNodeIndex, uPrefixLength);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqTrans[uSeqIndex] = LegSeqMM(a, uSeqIndex, uNodeIndex, uPrefixLength);
            break;

        case c2('M', 'D'):
            scoreTrans = LegMD(a, uNodeIndex, uPrefixLength);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqTrans[uSeqIndex] = LegSeqMD(a, uSeqIndex, uNodeIndex, uPrefixLength);
            break;

        case c2('D', 'M'):
            scoreTrans = LegDM(a, uNodeIndex, uPrefixLength);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqTrans[uSeqIndex] = LegSeqDM(a, uSeqIndex, uNodeIndex, uPrefixLength);
            break;

        case c2('D', 'D'):
            scoreTrans = LegDD(a, uNodeIndex, uPrefixLength);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqTrans[uSeqIndex] = LegSeqDD(a, uSeqIndex, uNodeIndex, uPrefixLength);
            break;

        case c2('I', 'M'):
            {
            //extern int imtype;
            //extern bool bListIM;
            //static double Totals[11];
            //for (int i = 0; i < 11; ++i)
            //    Totals[i] = 0;
            //double Total = 0;
            //List(" >> IM <<\n");//@@
            //bListIM = true;
            scoreTrans = LegIM(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevStateToI);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                {
                SeqTrans[uSeqIndex] = LegSeqIM(a, uSeqIndex, uNodeIndex, uPrefixLength,
                  uFirstIPillar, cPrevStateToI);
                SCORE s = SeqTrans[uSeqIndex]*a.GetSeqWeight(uSeqIndex);
                //Totals[imtype] += s;
                //Total += s;
                }
            //List("Totals[0] = %g (error)\n", Totals[0]);
            //List("Totals[1] = %g (DD)\n", Totals[1]);
            //List("Totals[2] = %g (MD)\n", Totals[2]);
            //List("Totals[3] = %g (ID)\n", Totals[3]);
            //List("Totals[4] = %g (DM)\n", Totals[4]);
            //List("Totals[5] = %g (MM)\n", Totals[5]);
            //List("Totals[6] = %g (IM)\n", Totals[6]);
            //List("Totals[7] = %g (DD)\n", Totals[7]);
            //List("Totals[8] = %g (ID)\n", Totals[8]);
            //List("Totals[9] = %g (DM)\n", Totals[9]);
            //List("Totals[10] = %g (IM)\n", Totals[10]);
            //List("IM=%g ID=%g MM=%g MD=%g DM=%g DD=%g\n",
            //  Totals[6] + Totals[10],    // IM
            //  Totals[3] + Totals[8],    // ID
            //  Totals[5],                // MM
            //  Totals[2],                // MD
            //  Totals[4] + Totals[9],    // DM
            //  Totals[1] + Totals[7]);    // DD
            //List("Total = %g\n", Total);
            cPrevStateToI = INVALID_STATE;
            uFirstIPillar = uInsane;
            break;
            }

        case c2('I', 'D'):
            scoreTrans = LegID(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevStateToI);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqTrans[uSeqIndex] = LegSeqID(a, uSeqIndex, uNodeIndex, uPrefixLength,
                  uFirstIPillar, cPrevStateToI);
            cPrevStateToI = INVALID_STATE;
            uFirstIPillar = uInsane;
            break;

        case c2('D', 'I'):
            cPrevStateToI = 'D';
            scoreTrans = LegDI(a, uNodeIndex, uPrefixLength);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqTrans[uSeqIndex] = LegSeqDI(a, uSeqIndex, uNodeIndex, uPrefixLength);
            assert(Edge.uPrefixLength > 0);
            uFirstIPillar = uPrefixLength - 1;
            break;

        case c2('M', 'I'):
            cPrevStateToI = 'M';
            assert(Edge.uPrefixLength > 0);
            uFirstIPillar = uPrefixLength - 1;
            scoreTrans = LegMI(a, uNodeIndex, uPrefixLength);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqTrans[uSeqIndex] = LegSeqMI(a, uSeqIndex, uNodeIndex, uPrefixLength);
            break;

        case c2('I', 'I'):
            scoreTrans = LegII(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevStateToI);
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqTrans[uSeqIndex] = LegSeqII(a, uSeqIndex, uNodeIndex, uPrefixLength,
                  uFirstIPillar, cPrevStateToI);
            break;

        default:
            assert(false);
            }
        scoreRoute += scoreTrans;

        if ('M' == cToState)
            {
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqEmit[uSeqIndex] = EmitSeqM(a, uSeqIndex, uNodeIndex, uPrefixLength-1);
            }
        else
            {
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                SeqEmit[uSeqIndex] = 0;
            }

        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
            SeqTotal[uSeqIndex] += SeqTrans[uSeqIndex] + SeqEmit[uSeqIndex];

//    List("Leg FTNod  PL   Trans    Emit Col   Total");
    //    123 1112312341234567812345678123412345678
        List("%-3u %c%c%-3u%4u%8s",
          uLegIndex,
          cFromState,
          cToState,
          uNodeIndex,
          uPrefixLength,
          ScoreToStr(scoreTrans));
        if ('M' == cToState)
            {
            assert(uPrefixLength > 0);
            unsigned uPillarIndex = uPrefixLength - 1;
            scoreEmit = EmitM(a, uNodeIndex, uPillarIndex);
            const PILLAR &Pillar = a.GetPillar(uPillarIndex);
            assert(Pillar.m_bAligned);
            assert(Pillar.m_uToColIndex == Pillar.m_uFromColIndex);
            scoreRoute += scoreEmit;
            List("%8s%4u", ScoreToStr(scoreEmit), Pillar.m_uToColIndex);
            }
        else
            List("            ");
        List("%8s", ScoreToStr(scoreRoute));

        //List("    Trans    Emit Pos C   Total");
        //       12345678123456781234 112345678
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
            {
            List(" %8s", ScoreToStr(SeqTrans[uSeqIndex]));
            if ('M' == cToState || 'I' == cToState)
                {
                assert(uPrefixLength > 0);
                unsigned uPillarIndex = Edge.uPrefixLength - 1;
                const PILLAR &Pillar = a.GetPillar(uPillarIndex);
                unsigned uColIndex = Pillar.m_uToColIndex;
                if (a.IsGap(uSeqIndex, uColIndex))
                    List("             -");
                else
                    {
                    unsigned uPos = a.GetUngappedColIndex(uSeqIndex, uColIndex);
                    if ('M' == cToState)
                        List("%8s%4d %c",
                          ScoreToStr(SeqEmit[uSeqIndex]),
                          uPos,
                          a.GetChar(uSeqIndex, uColIndex));
                    else
                        List("        %4d %c",
                          uPos,
                          a.GetChar(uSeqIndex, uColIndex));
                    }
                }
            else
                List("              ");
            SCORE scoreTot = SeqTotal[uSeqIndex];
            List("%8s", ScoreToStr(scoreTot));
            }

        {
        SCORE scoreSeqTotal = 0;
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
            {
            WEIGHT w = a.GetSeqWeight(uSeqIndex);
            SCORE s = SeqTotal[uSeqIndex];
            SCORE s2;
            MulScoreWeight(s2, s, w);
            scoreSeqTotal = Add2(scoreSeqTotal, s2);
            }
        List("  %8s %8s",
          ScoreToStr(scoreSeqTotal),
          ScoreToStr(scoreSeqTotal - scoreRoute));
        }

        List("\n");

        {
        SCORE scoreSeqTransSum = 0;
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
            {
            WEIGHT w = a.GetSeqWeight(uSeqIndex);
            SCORE s = SeqTrans[uSeqIndex];
            SCORE s2;
            MulScoreWeight(s2, s, w);
            scoreSeqTransSum = Add2(scoreSeqTransSum, s2);
            }
        if (!ScoreEqPct(scoreSeqTransSum, scoreTrans, 2))
            List("*** Trans score mismatch *** Leg=%s Seqs=%s\n",
              ScoreToStr(scoreTrans),
              ScoreToStr(scoreSeqTransSum));
        }

        {
        SCORE scoreSeqEmitSum = 0;
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
            {
            WEIGHT w = a.GetSeqWeight(uSeqIndex);
            SCORE s = SeqEmit[uSeqIndex];
            SCORE s2;
            MulScoreWeight(s2, s, w);
            scoreSeqEmitSum = Add2(scoreSeqEmitSum, s2);
            }
        if (!ScoreEqPct(scoreSeqEmitSum, scoreEmit, 2))
            List("*** Emit score mismatch *** Leg=%s Seqs=%s\n",
              ScoreToStr(scoreEmit),
              ScoreToStr(scoreSeqEmitSum));
        }

        cFromState = cToState;
        }
#undef c2

    SCORE scoreSeqTotal = 0;
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        WEIGHT w = a.GetSeqWeight(uSeqIndex);
        SCORE s = SeqTotal[uSeqIndex];
        SCORE s2;
        MulScoreWeight(s2, s, w);
        scoreSeqTotal = Add2(scoreSeqTotal, s2);
        }

    int n = (a.GetSeqCount()*a.GetColCount())/5;
    if (!ScoreEqLocal(scoreSeqTotal, scoreRoute, n))
        List("*** Total score mismatch *** Route=%s Seqs=%s\n",
          ScoreToStr(scoreRoute),
          ScoreToStr(scoreSeqTotal));
    }
