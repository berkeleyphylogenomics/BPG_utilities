// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "Seq.h"

#define    VERBOSE    0

// Macros to simulate 2D matrices
#define DPM(NodeIndex, PrefixLength)    DPM_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPD(NodeIndex, PrefixLength)    DPD_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPI(NodeIndex, PrefixLength)    DPI_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]

SCORE HMM::ViterbiSeq(const Seq &s, MODEL_BOUNDS ModelBounds, SEQ_BOUNDS SeqBounds,
  HMMPath &Path) const
    {
    const unsigned uSeqLength = s.Length();
    const unsigned uPrefixCount = uSeqLength + 1;
    const unsigned uNodeCount = GetNodeCount();
    assert(uSeqLength > 0 && uNodeCount > 0);

// Allocate DP matrices
    size_t LM = uPrefixCount*uNodeCount;
    SCORE *DPM_ = new SCORE[LM];
    SCORE *DPD_ = new SCORE[LM];
    SCORE *DPI_ = new SCORE[LM];

    DPM(0, 0) = MINUS_INFINITY;
    DPI(0, 0) = MINUS_INFINITY;
    DPD(0, 0) = MINUS_INFINITY;

    for (unsigned uNodeIndex = 1; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        DPM(uNodeIndex, 0) = MINUS_INFINITY;
        if (LOCAL_MODEL == ModelBounds)
            DPD(uNodeIndex, 0) = 0;
        else
            DPD(uNodeIndex, 0) = Add2(DPD(uNodeIndex-1, 0),
              GetNode(uNodeIndex-1).m_scoreDD);
        DPI(uNodeIndex, 0) = MINUS_INFINITY;
        }

    const HMMNode &Node0 = GetNode(0);
    for (unsigned uPrefixLength = 1; uPrefixLength < uPrefixCount; ++uPrefixLength)
        {
        assert(uPrefixLength > 0);
        const unsigned uLetter = s.GetLetter(uPrefixLength-1);

    // Node 0 is special case.
        if (LOCAL_SEQ == SeqBounds)
            {
            DPM(0, uPrefixLength) = m_scoreFirstM + Node0.m_scoreMatchEmit[uLetter];
            DPD(0, uPrefixLength) = m_scoreFirstD;
            }
        else
            {
            if (1 == uPrefixLength)
                DPM(0, uPrefixLength) = m_scoreFirstM + Node0.m_scoreMatchEmit[uLetter];
            else
                DPM(0, uPrefixLength) = MINUS_INFINITY;
            DPD(0, uPrefixLength) = MINUS_INFINITY;
            }
    
        SCORE scoreEmit = Node0.m_scoreInsertEmit[uLetter];
        SCORE scoreMI = Add2(DPM(0, uPrefixLength-1), Node0.m_scoreMI);
        SCORE scoreDI = Add2(DPD(0, uPrefixLength-1), Node0.m_scoreDI);
        SCORE scoreII = Add2(DPI(0, uPrefixLength-1), Node0.m_scoreII);
        DPI(0, uPrefixLength) = Add2(Max3(scoreMI, scoreDI, scoreII), scoreEmit);

        for (unsigned uNodeIndex = 1; uNodeIndex < uNodeCount; ++uNodeIndex)
            {
            assert(uNodeIndex > 0);
            assert(uPrefixLength > 0);

            const HMMNode &Node = GetNode(uNodeIndex);
            const HMMNode &PrevNode = GetNode(uNodeIndex-1);

        // Transitions into M
            {
            SCORE scoreEmit = Node.m_scoreMatchEmit[uLetter];
            SCORE scoreMM = Add2(DPM(uNodeIndex-1, uPrefixLength-1), PrevNode.m_scoreMM);
            SCORE scoreDM = Add2(DPD(uNodeIndex-1, uPrefixLength-1), PrevNode.m_scoreDM);
            SCORE scoreIM = Add2(DPI(uNodeIndex-1, uPrefixLength-1), PrevNode.m_scoreIM);
            DPM(uNodeIndex, uPrefixLength) = Add2(Max3(scoreMM, scoreDM, scoreIM), scoreEmit);
            }

        // Transitions into D
            {
            SCORE scoreMD = Add2(DPM(uNodeIndex-1, uPrefixLength), PrevNode.m_scoreMD);
            SCORE scoreDD = Add2(DPD(uNodeIndex-1, uPrefixLength), PrevNode.m_scoreDD);
            SCORE scoreID = Add2(DPI(uNodeIndex-1, uPrefixLength), PrevNode.m_scoreID);
            DPD(uNodeIndex, uPrefixLength) = Max3(scoreMD, scoreDD, scoreID);
            }

        // Transitions into I
            {
            if (uNodeIndex == uNodeCount - 1)
            // No insert state in last node
                DPI(uNodeIndex, uPrefixLength) = MINUS_INFINITY;
            else
                {
                SCORE scoreEmit = Node.m_scoreInsertEmit[uLetter];
                SCORE scoreMI = Add2(DPM(uNodeIndex, uPrefixLength-1), Node.m_scoreMI);
                SCORE scoreDI = Add2(DPD(uNodeIndex, uPrefixLength-1), Node.m_scoreDI);
                SCORE scoreII = Add2(DPI(uNodeIndex, uPrefixLength-1), Node.m_scoreII);
                DPI(uNodeIndex, uPrefixLength) =
                  Add2(Max3(scoreMI, scoreDI, scoreII), scoreEmit);
                }
            }
            }
        }

#if VERBOSE
        {
        List("Prefix   ");
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List(" %8u", uPrefixLength);
        List("\n");
        List("M[]\n");
        for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
            {
            List("Node %u:  ", uNodeIndex);
            for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
                List(" %s", ScoreToStr(DPM(uNodeIndex, uPrefixLength)));
            List("\n");
            }
        List("D[]\n");
        for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
            {
            List("Node %u:  ", uNodeIndex);
            for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
                List(" %s", ScoreToStr(DPD(uNodeIndex, uPrefixLength)));
            List("\n");
            }
        List("I[]\n");
        for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
            {
            List("Node %u:  ", uNodeIndex);
            for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
                List(" %s", ScoreToStr(DPI(uNodeIndex, uPrefixLength)));
            List("\n");
            }
        }
#endif    // VERBOSE

    SCORE Score = TraceBackSeq(s, DPM_, DPD_, DPI_, ModelBounds, SeqBounds, Path);
//    Path.ListMe();
    Path.Validate(GetNodeCount(), uSeqLength, ModelBounds, SeqBounds);

    delete[] DPM_;
    delete[] DPD_;
    delete[] DPI_;

    return Score;
    }

SCORE HMM::TraceBackSeq(const Seq &s, const SCORE *DPM_, const SCORE *DPD_,
  const SCORE *DPI_, MODEL_BOUNDS ModelBounds, SEQ_BOUNDS SeqBounds,
  HMMPath &Path) const
    {
    const unsigned uSeqLength = s.Length();
    const unsigned uPrefixCount = uSeqLength + 1;
    const unsigned uNodeCount = GetNodeCount();
    assert(uSeqLength > 0 && uNodeCount > 0);

    Path.Clear();

    unsigned uToNodeIndex = uNodeCount - 1;
    char cToState = '?';
    unsigned uPrefixLength = uInsane;
    SCORE scoreMax = MINUS_INFINITY;

    if (GLOBAL_MODEL == ModelBounds && LOCAL_SEQ == SeqBounds)
        {
        uPrefixLength = 0;
        for (unsigned uPL = 1; uPL < uPrefixCount; ++uPL)
            {
            if (DPD(uToNodeIndex, uPL) >= scoreMax)
                {
                cToState = 'D';
                uPrefixLength = uPL;
                scoreMax = DPD(uToNodeIndex, uPL);
                }
            if (DPM(uToNodeIndex, uPL) >= scoreMax)
                {
                cToState = 'M';
                uPrefixLength = uPL;
                scoreMax = DPM(uToNodeIndex, uPL);
                }
            }
        }
    else if (GLOBAL_MODEL == ModelBounds && GLOBAL_SEQ == SeqBounds)
        {
        uPrefixLength = uSeqLength;
        SCORE scoreD = DPD(uToNodeIndex, uSeqLength);
        SCORE scoreM = DPM(uToNodeIndex, uSeqLength);
        if (scoreM >= scoreD)
            {
            cToState = 'M';
            scoreMax = DPM(uToNodeIndex, uSeqLength);
            }
        else
            {
            cToState = 'D';
            scoreMax = DPD(uToNodeIndex, uSeqLength);
            }
        }
    else
        assert(false);

    assert(MINUS_INFINITY != scoreMax);
    assert(uPrefixLength > 0);
    assert(cToState != '?');

    SCORE scoreEmit = 0;
    for (;;)
        {
        char cFromState;
        switch (cToState)
            {
        case 'M':
            {
            assert(uPrefixLength > 0);
            unsigned uLetter = s.GetLetter(uPrefixLength-1);
            assert(uToNodeIndex > 0);
            const HMMNode &Node = GetNode(uToNodeIndex);
            const HMMNode &PrevNode = GetNode(uToNodeIndex-1);
            SCORE scoreDP = DPM(uToNodeIndex, uPrefixLength);
            scoreEmit = Node.m_scoreMatchEmit[uLetter];
            SCORE scoreMove = Add2(DPM(uToNodeIndex-1, uPrefixLength-1), PrevNode.m_scoreMM);
            if (scoreMove + scoreEmit == scoreDP)
                {
                cFromState = 'M';
                break;
                }
            scoreMove = DPD(uToNodeIndex-1, uPrefixLength-1) + PrevNode.m_scoreDM;
            if (scoreMove + scoreEmit == scoreDP)
                {
                cFromState = 'D';
                break;
                }
            scoreMove = DPI(uToNodeIndex-1, uPrefixLength-1) + PrevNode.m_scoreIM;
            cFromState = 'I';
            assert(scoreMove + scoreEmit == scoreDP);
            break;
            }

        case 'D':
            {
            assert(uToNodeIndex > 0);
            const HMMNode &PrevNode = GetNode(uToNodeIndex-1);
            SCORE scoreDP = DPD(uToNodeIndex, uPrefixLength);
            SCORE scoreMove = Add2(DPM(uToNodeIndex-1, uPrefixLength), PrevNode.m_scoreMD);
            if (scoreMove == scoreDP)
                {
                cFromState = 'M';
                break;
                }
            scoreMove = Add2(DPD(uToNodeIndex-1, uPrefixLength), PrevNode.m_scoreDD);
            if (scoreMove == scoreDP)
                {
                cFromState = 'D';
                break;
                }
            scoreMove = Add2(DPI(uToNodeIndex-1, uPrefixLength), PrevNode.m_scoreID);
            assert(scoreMove == scoreDP);
            cFromState = 'I';
            break;
            }

        case 'I':
            {
            assert(uPrefixLength > 0);
            unsigned uLetter = s.GetLetter(uPrefixLength-1);
            const HMMNode &Node = GetNode(uToNodeIndex);
            SCORE scoreDP = DPI(uToNodeIndex, uPrefixLength);
            scoreEmit = Node.m_scoreInsertEmit[uLetter];
            SCORE scoreMove = Add2(DPM(uToNodeIndex, uPrefixLength-1), Node.m_scoreMI);
            if (scoreMove + scoreEmit == scoreDP)
                {
                cFromState = 'M';
                break;
                }
            scoreMove = Add2(DPD(uToNodeIndex, uPrefixLength-1), Node.m_scoreDI);
            if (scoreMove + scoreEmit == scoreDP)
                {
                cFromState = 'D';
                break;
                }
            scoreMove = Add2(DPI(uToNodeIndex, uPrefixLength-1), Node.m_scoreII);
            assert(scoreMove + scoreEmit == scoreDP);
            cFromState = 'I';
            break;
            }
        default:
            assert(false);
            }

        HMMEdge Edge;
        Edge.cState = cToState;
        Edge.uNodeIndex = uToNodeIndex;
        Edge.uPrefixLength = uPrefixLength;
        if ('M' == cToState || 'I' == cToState)
            Edge.scoreEmit = scoreEmit;
        else
            Edge.scoreEmit = 0;

        if ('M' == cToState || 'I' == cToState)
            {
            assert(uPrefixLength > 0);
            --uPrefixLength;
            }
        if ('M' == cToState || 'D' == cToState)
            {
            assert(uToNodeIndex > 0);
            --uToNodeIndex;
            }
#if    VERBOSE
        List("Edge: ->%c%d [%d]\n",
          Edge.cState,
          Edge.uNodeIndex,
          Edge.uPrefixLength);
#endif
        Path.PrependEdge(Edge);
        cToState = cFromState;
        if ('I' != cToState && 0 == uToNodeIndex)
            break;
        }
    HMMEdge Edge;
    Edge.cState = cToState;
    Edge.uNodeIndex = uToNodeIndex;
    Edge.uPrefixLength = uPrefixLength;
    Path.PrependEdge(Edge);
#if    VERBOSE
    List("Edge: ->%c%d [%d]\n",
      Edge.cState,
      Edge.uNodeIndex,
      Edge.uPrefixLength);
#endif
#if    _DEBUG
    SCORE scorePath = ScorePathSeq(Path, s);
    assert(ScoreEq(scorePath, scoreMax));
#endif
    return scoreMax;
    }
