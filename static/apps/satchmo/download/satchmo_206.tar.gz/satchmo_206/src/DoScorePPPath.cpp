// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "DataBuffer.h"
#include "TextFile.h"
#include "Profile.h"
#include "PWBase.h"
#include "PWPath.h"

#define    VERBOSE    0

void DoScorePPPath(const char *in, const char *prof1, const char *prof2,
  const char *colpair, const char *gapstyle, const char *bounds)
    {
    DataBuffer Data1;
    DataBuffer Data2;

    Data1.FromFile(prof1);
    Data2.FromFile(prof2);

    Profile Profile1;
    Profile Profile2;

    Profile1.FromBuffer(Data1);
    Profile2.FromBuffer(Data2);

    PWBase *ptrPWS;
    PWSFactory(colpair, gapstyle, bounds, &ptrPWS);
    ptrPWS->SetProfiles(Profile1, Profile2);

    TextFile PathFile(in);

    PWPath Path;
    Path.FromFile(PathFile);

    List("Path:\n");
    Path.ListMe();

    Path.Validate(*ptrPWS);

    SCORE scorePath = PWScorePath(*ptrPWS, Path, true);
    }
