// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Phylip.h"
#include "PhylipNode.h"

#define VERBOSE 0

// Przytycka, Aurora and Rose's score
// Ref.: Nature Struct. Biol. Vol.6 (1999). pp.672-682.
double Phylip::GetPARScore()
    {
    const unsigned uNodeCount = GetNodeCount();
    unsigned uPairCount = 0;
    double dSumPairScores = 0.0;
    for (unsigned uNode1 = 0; uNode1 < uNodeCount; ++uNode1)
        {
        PhylipNode *ptrNode1 = GetNode(uNode1);
        if (!ptrNode1->IsLeaf())
            continue;
        const unsigned uClass1 = ptrNode1->GetClass();
        if (0 == uClass1)
            continue;
        for (unsigned uNode2 = uNode1 + 1; uNode2 < uNodeCount; ++uNode2)
            {
            PhylipNode *ptrNode2 = GetNode(uNode2);
            if (!ptrNode2->IsLeaf())
                continue;
            const unsigned uClass2 = ptrNode2->GetClass();
            if (uClass2 != uClass1)
                continue;
            ++uPairCount;
            double dPairScore = GetPARPairScore(ptrNode1, ptrNode2);
            dSumPairScores += dPairScore;
            }
        }
    if (uPairCount < 1)
        return 0.0;
    return dSumPairScores / (double) uPairCount;
    }

double Phylip::GetPARPairScore(PhylipNode *ptrNode1, PhylipNode *ptrNode2)
    {
    PhylipNode *ptrGroup = GetCommonParent(ptrNode1, ptrNode2);
    const unsigned uClass = ptrNode1->GetClass();
    assert(uClass == ptrNode2->GetClass());
    unsigned uGroupSize;
    unsigned uClassMemberCount;
    GetMemberCount(ptrGroup, uClass, uGroupSize, uClassMemberCount);
#if    VERBOSE
    List("Pair %u,%u Group %u Class %u Class size %u Members %u\n",
      ptrNode1->GetIndex(),
      ptrNode2->GetIndex(),
      ptrGroup->GetIndex(),
      uClass,
      uGroupSize,
      uClassMemberCount);
#endif
    return (double) uClassMemberCount / (double) uGroupSize;
    }

PhylipNode *Phylip::GetCommonParent(PhylipNode *ptrNode1, PhylipNode *ptrNode2)
    {
    const int MaxNodeCount = 10000;
    int Path[MaxNodeCount];
    assert(MaxNodeCount >= m_uNodeCount);
    memset(Path, 0, MaxNodeCount*sizeof(Path[0]));

    for (PhylipNode *ptrNode = ptrNode1; ptrNode != 0;
      ptrNode = ptrNode->GetParent())
        {
        const unsigned uNodeIndex = ptrNode->GetIndex();
        assert(uNodeIndex < m_uNodeCount);
        Path[uNodeIndex] = 1;
        }

    for (PhylipNode *ptrNode = ptrNode2; ptrNode != 0;
      ptrNode = ptrNode->GetParent())
        {
        const unsigned uNodeIndex = ptrNode->GetIndex();
        assert(uNodeIndex < m_uNodeCount);
        if (Path[uNodeIndex] != 0)
            return ptrNode;
        }
    assert(false);
    return 0;
    }

void Phylip::GetMemberCount(PhylipNode *ptrGroup, unsigned uClass,
  unsigned &uGroupSize, unsigned &uClassMemberCount)
    {
    assert(!ptrGroup->IsLeaf());
    uGroupSize = 0;
    uClassMemberCount = 0;
    RecurseMemberCount(ptrGroup, uClass, uGroupSize, uClassMemberCount);
    }

void Phylip::RecurseMemberCount(PhylipNode *ptrGroup, unsigned uClass,
  unsigned &uGroupSize, unsigned &uClassMemberCount)
    {
    if (ptrGroup->IsLeaf())
        {
        ++uGroupSize;
        if (ptrGroup->GetClass() == uClass)
            ++uClassMemberCount;
        return;
        }
    RecurseMemberCount(ptrGroup->GetLeft(), uClass, uGroupSize, uClassMemberCount);
    RecurseMemberCount(ptrGroup->GetRight(), uClass, uGroupSize, uClassMemberCount);
    }
