// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "MSA.h"
#include "DirMix.h"
#include <math.h>

void HMM::FromAlnBitSave( MSA &Aln, double dBitsToSave, unsigned uMaxIter,
  double dMaxErrorPct)
    {
    double dCountScaleFactor = 1.0;
    double dBitsSaved;
    for (unsigned uIter = 0; uIter < uMaxIter; ++uIter)
        {
        dBitsSaved = FromAlnBitSaveIter(Aln, dCountScaleFactor);
        double dRatio = dBitsToSave/dBitsSaved;
        double dFractionalError = fabs(1.0 - dRatio);
        double dErrorPct = dFractionalError*100;
	/*******   
     fprintf(stderr, "HMM Iter %u Factor=%g Bits saved=%g (%g) Err = %g%% NIC=%g\n",
          uIter,
          dCountScaleFactor,
          dBitsSaved,
          dBitsToSave,
          dErrorPct,
          Aln.GetTotalSeqWeight()*dCountScaleFactor);
	****/ 
       if (dErrorPct <= dMaxErrorPct)
            return;
        dCountScaleFactor *= dBitsToSave/dBitsSaved;
        }
    fprintf(stderr, "**Warning** bits saved failed to converge, target=%g actual=%g\n",
      dBitsToSave, dBitsSaved);
    List("**Warning** bits saved failed to converge, target=%g actual=%g\n",
      dBitsToSave, dBitsSaved);
    }

void HMM::ScaleNodeCounts(NodeCounts &Counts, double dFactor) const
    {
    Counts.m_wcMM *= (WCOUNT) dFactor;
    Counts.m_wcMD *= (WCOUNT) dFactor;
    Counts.m_wcMI *= (WCOUNT) dFactor;
    Counts.m_wcDM *= (WCOUNT) dFactor;
    Counts.m_wcDD *= (WCOUNT) dFactor;
    Counts.m_wcDI *= (WCOUNT) dFactor;
    Counts.m_wcIM *= (WCOUNT) dFactor;
    Counts.m_wcID *= (WCOUNT) dFactor;
    Counts.m_wcII *= (WCOUNT) dFactor;
    Counts.m_wcResidues *= (WCOUNT)  dFactor;
    Counts.m_wcGaps *= (WCOUNT) dFactor;
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        Counts.m_wcMatchEmit[n] *= (WCOUNT) dFactor;
    }

double HMM::FromAlnBitSaveIter(MSA &Aln, double dCountScaleFactor)
    {
    PROB p[MAX_ALPHA];
    GetPriorBackground(p);

    Clear();

    m_ptrTemplate = &Aln;

    m_uNodeCount = Aln.GetAlignedColCount();
    if (0 == m_uNodeCount)
        return 0.0;
    m_Nodes = new HMMNode[m_uNodeCount];

// Transition distribution from initial FIM to 
// M0 or D0 is special case.
    NodeCounts Counts;
    Aln.GetNodeCounts(0, Counts);

// Add one to observed counts as ad-hoc pseudo-count prior.
    WCOUNT wcM = Counts.m_wcResidues + IntToWCount(20); //TODO@@
    WCOUNT wcD = Counts.m_wcGaps + IntToWCount(1);

// Convert to probability distribution.
// It's not clear that this is probabilistically correct, the distribution
// should probably be the three transitions FIM->FIM, FIM->M, FIM->D.
// However, the difference is small; given the pseudo-count hack
// we don't care that much about rigor.
    PROB probM = (PROB) wcM/(PROB) (wcM + wcD);
    PROB probD = (PROB) 1.0 - probM;
    m_scoreFirstM = ProbToScore(probM) - GetNullEmitTransScore();
    m_scoreFirstD = ProbToScore(probD);

    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        Aln.GetNodeCounts(uNodeIndex, Counts);
        ScaleNodeCounts(Counts, dCountScaleFactor);
        NodeFromCounts(uNodeIndex, Counts);
        }
    return BitsSaved();
    }
