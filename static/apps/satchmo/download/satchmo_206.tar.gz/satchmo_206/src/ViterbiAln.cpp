// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "MSA.h"
#include "TextFile.h"

#define    VERBOSE 0
#define SAVEFILES    0

// Macros to simulate 2D matrices
#define DPM(NodeIndex, PrefixLength)    DPM_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPD(NodeIndex, PrefixLength)    DPD_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPI(NodeIndex, PrefixLength)    DPI_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPN(NodeIndex, PrefixLength)    DPN_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPS(NodeIndex, PrefixLength)    DPS_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTM(NodeIndex, PrefixLength)    DPTM_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTD(NodeIndex, PrefixLength)    DPTD_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTI(NodeIndex, PrefixLength)    DPTI_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]

static bool ScoreEqLocal(SCORE s1, SCORE s2, int n)
    {
    return BTEq(s1, s2);
    }

static void ListRouteAln(const MSA &a, const HMMPath &Route)
    {
    const unsigned uEdgeCount = Route.GetEdgeCount();
    const unsigned uSeqCount = a.GetSeqCount();
    List("SNod PL FCl  TCl");
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        List("  %-3u", uSeqIndex);
    List("\n");

    if (uEdgeCount > 0)
        {
        const HMMEdge &FirstEdge = Route.GetEdge(0);
        unsigned uFirstPillar;
        if ('D' == FirstEdge.cState)
            uFirstPillar = FirstEdge.uPrefixLength;
        else
            {
            assert(FirstEdge.uPrefixLength > 0);
            uFirstPillar = FirstEdge.uPrefixLength - 1;
            }
        for (unsigned uPillarIndex = 0; uPillarIndex < uFirstPillar;
          ++uPillarIndex)
            {
            List("     %-3u", uPillarIndex);
            const PILLAR &Pillar = a.GetPillar(uPillarIndex);
            List(" %-3u %-3u", Pillar.m_uFromColIndex, Pillar.m_uToColIndex);
            for (unsigned uColIndex = Pillar.m_uFromColIndex; uColIndex <= Pillar.m_uToColIndex;
              ++uColIndex)
                {
                if (uColIndex > Pillar.m_uFromColIndex)
                    List("                ");
                for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                    {
                    unsigned n = a.GetUngappedColIndex(uSeqIndex, uColIndex);
                    char c = a.GetChar(uSeqIndex, uColIndex);
                    List(" %c%-3u", c, n);
                    }
                List("\n");
                }
            }
        }

    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const HMMEdge &Edge = Route.GetEdge(uEdgeIndex);
        List("%c%-3u %-3u", Edge.cState, Edge.uNodeIndex, Edge.uPrefixLength);
        if ('D' == Edge.cState)
            {
            List("\n");
            continue;
            }
        assert(Edge.uPrefixLength > 0);
        const unsigned uPillarIndex = Edge.uPrefixLength - 1;
        const PILLAR &Pillar = a.GetPillar(uPillarIndex);
        List(" %-3u %-3u", Pillar.m_uFromColIndex, Pillar.m_uToColIndex);
        for (unsigned uColIndex = Pillar.m_uFromColIndex; uColIndex <= Pillar.m_uToColIndex;
          ++uColIndex)
            {
            if (uColIndex > Pillar.m_uFromColIndex)
                List("                ");
            for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                {
                unsigned n = a.GetUngappedColIndex(uSeqIndex, uColIndex);
                char c = a.GetChar(uSeqIndex, uColIndex);
                List(" %c%-3u", c, n);
                }
            List("\n");
            }
        }

    if (uEdgeCount > 0)
        {
        const HMMEdge &LastEdge = Route.GetEdge(uEdgeCount-1);
        unsigned uLastPillar = LastEdge.uPrefixLength;
        unsigned uPillarCount = a.GetPillarCount();
        for (unsigned uPillarIndex = uLastPillar; uPillarIndex < uPillarCount;
          ++uPillarIndex)
            {
            List("     %-3u", uPillarIndex);
            const PILLAR &Pillar = a.GetPillar(uPillarIndex);
            List(" %-3u %-3u", Pillar.m_uFromColIndex, Pillar.m_uToColIndex);
            for (unsigned uColIndex = Pillar.m_uFromColIndex; uColIndex <= Pillar.m_uToColIndex;
              ++uColIndex)
                {
                if (uColIndex > Pillar.m_uFromColIndex)
                    List("                ");
                for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
                    {
                    unsigned n = a.GetUngappedColIndex(uSeqIndex, uColIndex);
                    char c = a.GetChar(uSeqIndex, uColIndex);
                    List(" %c%-3u", c, n);
                    }
                List("\n");
                }
            }
        }
    }

static void ListDP(unsigned uNodeCount, unsigned uPrefixCount, const SCORE *DPM_,
 const SCORE *DPD_, const SCORE *DPI_, const unsigned *DPN_, const char *DPS_,
 const char *DPTM_, const char *DPTD_, const char *DPTI_)
    {
    List("Prefix   ");
    for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
        List(" %8u", uPrefixLength);
    List("\n");
    List("M[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List(" %s", ScoreToStr(DPM(uNodeIndex, uPrefixLength)));
        List("\n");
        }
    List("D[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List(" %s", ScoreToStr(DPD(uNodeIndex, uPrefixLength)));
        List("\n");
        }
    List("I[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List(" %s", ScoreToStr(DPI(uNodeIndex, uPrefixLength)));
        List("\n");
        }
    List("N[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            {
            unsigned n = DPN(uNodeIndex, uPrefixLength);
            if (uInsane == n)
                List("        *");
            else
                List(" %8u", n);
            }
        List("\n");
        }
    List("S[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List("        %c", DPS(uNodeIndex, uPrefixLength));
        List("\n");
        }
    List("TM[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List("        %c", DPTM(uNodeIndex, uPrefixLength));
        List("\n");
        }
    List("TD[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List("        %c", DPTD(uNodeIndex, uPrefixLength));
        List("\n");
        }
    List("TI[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List("        %c", DPTI(uNodeIndex, uPrefixLength));
        List("\n");
        }
    }

SCORE HMM::ViterbiAln(const MSA &a, HMMPath &Route)
    {
    if (g_bSamePath)
        return ViterbiAln_v1(a, Route);

    a.SanityCheckPillarCount();

    const unsigned uPillarCount = a.GetPillarCount();
    const unsigned uPrefixCount = uPillarCount + 1;
    const unsigned uNodeCount = GetNodeCount();
    assert(uPillarCount > 0 && uNodeCount > 0);

#if    SAVEFILES
    TextFile ModelFile("c:\\tmp\\model.hmm", true);
    ToFile(ModelFile);
    TextFile AlnFile("c:\\tmp\\tgt.fasta", true);
    a.ToFASTAFile(AlnFile);
#endif

#if    VERBOSE
    List("Target weights:\n");
    for (unsigned n = 0; n < a.GetSeqCount(); ++n)
        List("Seq %u Weight %g\n", n, WeightToDouble(a.GetSeqWeight(n)));
#endif

// Allocate DP matrices
    size_t LM = uPrefixCount*uNodeCount;
    SCORE *DPM_ = new SCORE[LM];
    SCORE *DPD_ = new SCORE[LM];
    SCORE *DPI_ = new SCORE[LM];
    unsigned *DPN_ = new unsigned[LM];
    char *DPS_ = new char[LM];
    char *DPTM_ = new char[LM];
    char *DPTD_ = new char[LM];
    char *DPTI_ = new char[LM];

    CheckMemUse();

#if    _DEBUG
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            {
            DPM(uNodeIndex, uPrefixLength) = scoreInsane;
            DPD(uNodeIndex, uPrefixLength) = scoreInsane;
            DPI(uNodeIndex, uPrefixLength) = scoreInsane;
            DPN(uNodeIndex, uPrefixLength) = uInsane;
            DPS(uNodeIndex, uPrefixLength) = '-';
            DPTM(uNodeIndex, uPrefixLength) = '-';
            DPTD(uNodeIndex, uPrefixLength) = '-';
            DPTI(uNodeIndex, uPrefixLength) = '-';
            }
#endif

    DPM(0, 0) = MINUS_INFINITY;
    DPI(0, 0) = MINUS_INFINITY;
    DPD(0, 0) = m_scoreFirstD;
    DPN(0, 0) = uInsane;
    DPS(0, 0) = INVALID_STATE;
    DPTM(0, 0) = INVALID_STATE;
    DPTD(0, 0) = INVALID_STATE;
    DPTI(0, 0) = INVALID_STATE;

    for (unsigned uNodeIndex = 1; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        DPM(uNodeIndex, 0) = MINUS_INFINITY;
        DPTM(uNodeIndex, 0) = INVALID_STATE;

        DPD(uNodeIndex, 0) = Add2(DPD(uNodeIndex-1, 0), GetNode(uNodeIndex-1).m_scoreDD);
        DPTD(uNodeIndex, 0) = 'D';

        DPI(uNodeIndex, 0) = MINUS_INFINITY;
        DPTI(uNodeIndex, 0) = INVALID_STATE;

        DPN(uNodeIndex, 0) = uInsane;
        DPS(uNodeIndex, 0) = INVALID_STATE;
        }

    for (unsigned uPrefixLength = 1; uPrefixLength < uPrefixCount; ++uPrefixLength)
        {
    //        ListDPProb(uNodeCount, uPillarCount, DPM_, DPD_, DPI_);
        const PILLAR &Pillar = a.GetPillar(uPrefixLength-1);
        const bool bIsAligned = Pillar.m_bAligned;

    // Node 0 is special case.
        DPM(0, uPrefixLength) = LegSM(a, 0, uPrefixLength) + EmitM(a, 0, uPrefixLength-1);
        DPTM(0, uPrefixLength) = 'S';

        DPD(0, uPrefixLength) = LegSD(a, 0, uPrefixLength);
        DPTD(0, uPrefixLength) = 'S';

        SCORE scoreMI = Add2(DPM(0, uPrefixLength-1), LegMI(a, 0, uPrefixLength));
        SCORE scoreDI = Add2(DPD(0, uPrefixLength-1), LegDI(a, 0, uPrefixLength));

        if (uPrefixLength > 1)
            {
            unsigned uFirstIPillar = DPN(0, uPrefixLength-1);
            char cPrevState = DPS(0, uPrefixLength-1);
            SCORE scoreII = Add2(DPI(0, uPrefixLength-1),
              LegII(a, 0, uPrefixLength, uFirstIPillar, cPrevState));
            if (scoreMI >= scoreDI && scoreMI >= scoreII)
                {
                DPI(0, uPrefixLength) = scoreMI;
                DPN(0, uPrefixLength) = uPrefixLength-1;
                DPS(0, uPrefixLength) = 'M';
                DPTI(0, uPrefixLength) = 'M';
                }
            else if (scoreDI >= scoreMI && scoreDI >= scoreII)
                {
                DPI(0, uPrefixLength) = scoreDI;
                DPN(0, uPrefixLength) = uPrefixLength-1;
                DPS(0, uPrefixLength) = 'D';
                DPTI(0, uPrefixLength) = 'D';
                }
            else
                {
                assert(scoreII >= scoreMI && scoreII >= scoreDI);
                DPI(0, uPrefixLength) = scoreII;
                DPN(0, uPrefixLength) = DPN(0, uPrefixLength-1);
                DPS(0, uPrefixLength) = DPS(0, uPrefixLength-1);
                DPTI(0, uPrefixLength) = 'I';
                }
            }
        else
            {
            DPI(0, uPrefixLength) = scoreDI;
            DPN(0, uPrefixLength) = uPrefixLength-1;
            DPS(0, uPrefixLength) = 'D';
            DPTI(0, uPrefixLength) = 'D';
            }

        for (unsigned uNodeIndex = 1; uNodeIndex < uNodeCount; ++uNodeIndex)
            {
            assert(uNodeIndex > 0);
            assert(uPrefixLength > 0);

        // Transitions into M
            if (bIsAligned)
                {
                SCORE scoreEmit = EmitM(a, uNodeIndex, uPrefixLength-1);

            // M->M
                SCORE scoreMM;
                if (uPrefixLength > 1)
                    scoreMM = Add2(DPM(uNodeIndex-1, uPrefixLength-1), 
                      LegMM(a, uNodeIndex, uPrefixLength));
                else
                    scoreMM = MINUS_INFINITY;

            // D->M
                SCORE scoreDM = Add2(DPD(uNodeIndex-1, uPrefixLength-1), 
                LegDM(a, uNodeIndex, uPrefixLength));
            
            // I->M
                unsigned uFirstIPillar = DPN(uNodeIndex-1, uPrefixLength-1);
                char cPrevState = DPS(uNodeIndex-1, uPrefixLength-1);
                SCORE scoreIM;
                if (uPrefixLength > 1)
                    scoreIM = Add2(DPI(uNodeIndex-1, uPrefixLength-1), 
                      LegIM(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevState));
                else
                    scoreIM = MINUS_INFINITY;

            // Find max
                if (scoreMM >= scoreDM && scoreMM >= scoreIM)
                    {
                    DPM(uNodeIndex, uPrefixLength) = Add2(scoreMM, scoreEmit);
                    DPTM(uNodeIndex, uPrefixLength) = 'M';
                    }
                else if (scoreDM >= scoreMM && scoreDM >= scoreIM)
                    {
                    DPM(uNodeIndex, uPrefixLength) = Add2(scoreDM, scoreEmit);
                    DPTM(uNodeIndex, uPrefixLength) = 'D';
                    }
                else
                    {
                    assert(scoreIM >= scoreMM && scoreIM >= scoreDM);
                    DPM(uNodeIndex, uPrefixLength) = Add2(scoreIM, scoreEmit);
                    DPTM(uNodeIndex, uPrefixLength) = 'I';
                    }
                }
            else
            // Not aligned
                {
                DPM(uNodeIndex, uPrefixLength) = MINUS_INFINITY;
                DPTM(uNodeIndex, uPrefixLength) = '!';
                }

        // Transitions into I
            if (uNodeIndex < uNodeCount - 1)
                {
		  
            // M->I
                SCORE scoreMI = Add2(DPM(uNodeIndex, uPrefixLength-1),
                  LegMI(a, uNodeIndex, uPrefixLength));

            // D->I
                SCORE scoreDI = Add2(DPD(uNodeIndex, uPrefixLength-1),
                  LegDI(a, uNodeIndex, uPrefixLength));

            // I->I
                SCORE scoreII;
                if (uPrefixLength > 1)
                    {
                    unsigned uFirstIPillar = DPN(uNodeIndex, uPrefixLength-1);
                    char cPrevState = DPS(uNodeIndex, uPrefixLength-1);
                    scoreII = Add2(DPI(uNodeIndex, uPrefixLength-1),
                    LegII(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevState));
                    }
                else
                    scoreII = MINUS_INFINITY;
                if (scoreMI >= scoreDI && scoreMI >= scoreII)
                    {
                    DPI(uNodeIndex, uPrefixLength) = scoreMI;
                    DPN(uNodeIndex, uPrefixLength) = uPrefixLength-1;
                    DPS(uNodeIndex, uPrefixLength) = 'M';
                    DPTI(uNodeIndex, uPrefixLength) = 'M';
                    }
                else if (scoreDI >= scoreMI && scoreDI >= scoreII)
                    {
                    DPI(uNodeIndex, uPrefixLength) = scoreDI;
                    DPN(uNodeIndex, uPrefixLength) = uPrefixLength-1;
                    DPS(uNodeIndex, uPrefixLength) = 'D';
                    DPTI(uNodeIndex, uPrefixLength) = 'D';
                    }
                else
                    {
                    assert(scoreII >= scoreMI && scoreII >= scoreDI);
                    DPI(uNodeIndex, uPrefixLength) = scoreII;
                    DPN(uNodeIndex, uPrefixLength) = DPN(uNodeIndex, uPrefixLength-1);
                    DPS(uNodeIndex, uPrefixLength) = DPS(uNodeIndex, uPrefixLength-1);
                    DPTI(uNodeIndex, uPrefixLength) = 'I';
                    }
                }
            else
                {
            // No insert state in last node
                DPI(uNodeIndex, uPrefixLength) = MINUS_INFINITY;
                DPN(uNodeIndex, uPrefixLength) = uInsane;
                DPS(uNodeIndex, uPrefixLength) = INVALID_STATE;
                DPTI(uNodeIndex, uPrefixLength) = INVALID_STATE;
                }

        // Transitions into D
            {
        // M->D
            SCORE scoreMD = Add2(DPM(uNodeIndex-1, uPrefixLength),
              LegMD(a, uNodeIndex, uPrefixLength));

        // D->D
            SCORE scoreDD = Add2(DPD(uNodeIndex-1, uPrefixLength),
              LegDD(a, uNodeIndex, uPrefixLength));

        // I->D
            unsigned uFirstIPillar = DPN(uNodeIndex-1, uPrefixLength);
            char cPrevState = DPS(uNodeIndex-1, uPrefixLength);
            SCORE scoreID;
            if (INVALID_STATE == cPrevState)
                {
                assert(1 == uPrefixLength);
                scoreID = MINUS_INFINITY;
                }
            else
                scoreID = Add2(DPI(uNodeIndex-1, uPrefixLength),
                  LegID(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevState));
            if (scoreMD >= scoreDD && scoreMD >= scoreID)
                {
                DPD(uNodeIndex, uPrefixLength) = scoreMD;
                DPTD(uNodeIndex, uPrefixLength) = 'M';
                }
            else if (scoreDD >= scoreMD && scoreDD >= scoreID)
                {
                DPD(uNodeIndex, uPrefixLength) = scoreDD;
                DPTD(uNodeIndex, uPrefixLength) = 'D';
                }
            else
                {
                assert(scoreID >= scoreMD && scoreID >= scoreDD);
                DPD(uNodeIndex, uPrefixLength) = scoreID;
                DPTD(uNodeIndex, uPrefixLength) = 'I';
                }
            }
            }
        }

    SCORE Score = TraceBackAln(a, DPM_, DPD_, DPI_, DPN_, DPS_, DPTM_, DPTD_, DPTI_, Route);

#if    VERBOSE
    ListRouteAln(a, Route);
    Route.ListMe();
#endif

    Route.Validate(GetNodeCount(), uPrefixCount, GLOBAL_MODEL, LOCAL_SEQ);

// Cannot do this test if using approximation
    if (g_bUseBreakMatrices)
        {
        SCORE Score2 = ScoreFromPaths(Route, a);
        if (!ScoreEqLocal(Score, Score2, GetNodeCount()))
            {
            List("\n***WARNING*** Score diff TraceBack=%s FromPaths=%s\n",
            ScoreToStr(Score),
            ScoreToStr(Score2));
            ListRoute(Route, a);
            }
        }

    delete[] DPM_;
    delete[] DPD_;
    delete[] DPI_;
    delete[] DPN_;
    delete[] DPS_;
    delete[] DPTM_;
    delete[] DPTD_;
    delete[] DPTI_;

    return Score;
    }
