// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "HMM.h"
#include "MSA.h"
#include "PWPath.h"
#include "PWPRC.h"

void TestPRC(int argc, char *argv[])
    {
    TextFile FileTA("c:\\tmp\\tpla.fasta");
    MSA msaA;
    msaA.FromFASTAFile(FileTA);
    msaA.AlignByCase();
    msaA.BuildPillars();
    
    TextFile FileTB("c:\\tmp\\tplb.fasta");
    MSA msaB;
    msaB.FromFASTAFile(FileTB);
    msaB.AlignByCase();
    msaB.BuildPillars();

    HMM hmmA;
    hmmA.FromAlnBitSave(msaA, 0.5, 10, 2.0);

    HMM hmmB;
    hmmB.FromAlnBitSave(msaB, 0.5, 10, 2.0);

    PWPRC PWS;
    PWS.Init(hmmA, LOCAL, hmmB, GLOBAL);

    PWPath Path;
    TestPWAlign(PWS, Path);

    MSA msaCombined;
    AlignHMMs(hmmA, hmmB, Path, msaCombined);

    msaCombined.ListMe();
    }
