// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef PWBase_h
#define    PWBase_h

#include "PWScore.h"
#include "Profile.h"

enum PWCLASS
    {
    PWCLASS_Undefined,
    PWCLASS_YL,
    PWCLASS_YLD,
    PWCLASS_YLDF,
    PWCLASS_LA,
    PWCLASS_AL,
    PWCLASS_MdotF,
    PWCLASS_MdotM,
    PWCLASS_MdotP,
    PWCLASS_PdotP,
    PWCLASS_FdotF,
    PWCLASS_FdotP,
    PWCLASS_GdotG,
    PWCLASS_MM,
    PWCLASS_RE,
    PWCLASS_REF,
    PWCLASS_YLF,
    PWCLASS_Dir,
    PWCLASS_EuclidP,
    PWCLASS_EuclidF,
    PWCLASS_CorrelP,
    PWCLASS_CorrelF,
    PWCLASS_RankP,
    PWCLASS_RankF,
    };

enum GAPSTYLE
    {
    GAPSTYLE_Undefined = 0,
    GAPSTYLE_Simple = 1,
    GAPSTYLE_Coach = 2,
    };

struct PWPARAMS
    {
    Profile *m_profA;
    Profile *m_profB;
    BOUNDS m_BoundsA;
    BOUNDS m_BoundsB;
    SCORE m_scoreGapOpen;
    SCORE m_scoreGapExtend;
    GAPSTYLE m_GapStyle;
    };

class PWBase : public PWScore
    {
protected:
    PWBase();
    virtual ~PWBase();

public:
    void SetBounds(BOUNDS BoundsA, BOUNDS BoundsB)
        {
        m_BoundsA = BoundsA;
        m_BoundsB = BoundsB;
        }

    void SetGapStyle(GAPSTYLE GapStyle)
        {
        m_GapStyle = GapStyle;
        }

    void SetParams(SCORE scoreGapOpen, SCORE scoreGapExtend, SCORE scoreShift)
        {
        m_scoreGapOpen = scoreGapOpen;
        m_scoreGapExtend = scoreGapExtend;
        m_scoreShift = scoreShift;
        }

    void SetProfiles(Profile &ProfA, Profile &ProfB)
        {
        m_profA = &ProfA;
        m_profB = &ProfB;
        m_uLengthA = ProfA.GetAlignedPosCount();
        m_uLengthB = ProfB.GetAlignedPosCount();
        }

    SCORE GetDefaultGapOpen() const;
    SCORE GetDefaultGapExtend() const;
    SCORE GetDefaultShift() const;

    SCORE GetGapExtend() const { return m_scoreGapExtend; }
    SCORE GetGapOpen() const { return m_scoreGapOpen; }
    SCORE GetShift() const { return m_scoreShift; }
    double GetNICA() const { return (double) m_profA->GetTotalSeqWeight(); }
    double GetNICB() const { return (double) m_profB->GetTotalSeqWeight(); }

public:
    virtual unsigned GetLengthA() const { return m_uLengthA; }
    virtual unsigned GetLengthB() const { return m_uLengthB; }
    virtual BOUNDS GetBoundsA() const;
    virtual BOUNDS GetBoundsB() const;
    virtual SCORE ScoreMM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreMD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreMI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreDM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreDD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreDI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreIM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreID(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreII(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreSM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreSD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreSI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreME(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreDE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreIE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreLL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreLG(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreGL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;

public:
    virtual SCORE ScoreProfPos(const ProfPos &PPA, const ProfPos &PPB) const = 0;
    virtual PWCLASS GetClass() const = 0;

private:
    Profile *m_profA;
    Profile *m_profB;
    BOUNDS m_BoundsA;
    BOUNDS m_BoundsB;
    SCORE m_scoreGapOpen;
    SCORE m_scoreGapExtend;
    SCORE m_scoreShift;
    GAPSTYLE m_GapStyle;
    
    unsigned m_uLengthA;
    unsigned m_uLengthB;
    };

#endif    // PWBase_h
