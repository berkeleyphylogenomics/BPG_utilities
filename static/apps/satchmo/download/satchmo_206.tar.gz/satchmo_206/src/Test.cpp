// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "MSA.h"
#include "HMM.h"
#include "HMMPath.h"
#include "Seq.h"
#include <math.h>

#if    0

// Change

void TestAln(int argc, char *argv[])
    {
    SetListFileName("c:\\tmp\\satchmo.lst", false);

    TextFile ModelFile("c:\\tmp\\model.hmm");
    HMM Model;
    Model.FromFile(ModelFile);

    TextFile AlnFile("c:\\tmp\\tgt.fasta");
    MSA a;
    a.FromFASTAFile(AlnFile);

    List("msaTarget:\n");
    a.ListMe();

    List("msaTarget weights:\n");
    for (unsigned n = 0; n < a.GetSeqCount(); ++n)
        List("%7.3f %3u  %s\n", WeightToDouble(a.GetSeqWeight(n)), n, a.GetSeqName(n));
    List("\n");

    a.AlignByCase();
    a.BuildPillars();
    a.ListPillars();
    a.ValidateBreakMatrices();
    List("\n");

    HMMPath Path;
    Model.ViterbiAln(a, Path);
    }

void TestQ(int argc, char *argv[])
    {
    //TextFile File("c:\\tmp\\tpl.fasta");
    //MSA msaTemplate;
    //msaTemplate.FromFile(File, ALPHABET_Amino);
    //msaTemplate.AlignByCase();

    //List("Template:\n");
    //msaTemplate.BuildPillars();
    //msaTemplate.ListPillars();
    //msaTemplate.ValidateBreakMatrices();
    //List("\n");

    //HMM Model;
    //Model.FromAln(msaTemplate);

    //TextFile OutFile("c:\\tmp\\test.hmm", true);
    //Model.ToFile(OutFile);

    TextFile ModelFile("c:\\tmp\\test.hmm");
    HMM Model;
    Model.FromFile(ModelFile);

    TextFile SeqFile("c:\\tmp\\seq.fasta");
    Seq s;
    s.FromFASTAFile(SeqFile);

//    Model.ForwardSeq(s);
    List("\n");
//    Model.BackwardSeq(s);

    //MSA msaSeq;
    //msaSeq.FromSeq(s);

    //Path.SetTarget(msaSeq);

    //MSA msaCombined;
    //Model.Align(Path, msaCombined);

    //TextFile AlnFile("c:\\tmp\\aln.fasta", true);
    //msaCombined.ToFASTAFile(AlnFile);
    }

void Test2(int argc, char *argv[])
    {
    SetListFileName("c:\\tmp\\satchmo.lst", false);

    TextFile Template("c:\\tmp\\tpl.fasta");
    MSA msaTemplate;
    msaTemplate.FromFASTAFile(Template);
    msaTemplate.AlignByCase();
    msaTemplate.BuildPillars();

    TextFile ModelFile("c:\\tmp\\test.hmm");
    HMM Model;
    Model.FromFile(ModelFile);
    Model.SetTemplate(msaTemplate);

    TextFile TargetFile("c:\\tmp\\tgt.fasta");
    MSA msaTarget;
    msaTarget.FromFASTAFile(TargetFile);
    msaTarget.AlignByCase();
    msaTarget.BuildPillars();

    HMMPath Route;
    Model.ViterbiAln(msaTarget, Route);

    MSA msaCombined;
    Model.Align(Route, msaCombined, msaTarget);

    TextFile OutFile("c:\\tmp\\out.fasta", true);
    msaCombined.ToFASTAFile(OutFile);
    }

const double dLn2 = log(2);

// pow2(x)=2^x
static double pow2(double x)
    {
    return exp(x*dLn2);
    }

// lp2(x) = log2(1 + 2^-x), x >= 0
static double lp2(double x)
    {
    return log2(1 + pow2(-x));
    }

static double lp2L(double x)
    {
    assert(x >= 0);
    const int iTableSize = 1000;
    const double dRange = 20.0;
    const double dScale = dRange/iTableSize;
    static double dValue[iTableSize];
    static bool bInit = false;
    if (!bInit)
        {
        for (int i = 0; i < iTableSize; ++i)
            dValue[i] = lp2(i*dScale);
        bInit = true;
        }
    if (x >= dRange)
        return 0.0;
    int i = (int) (x/dScale);
    assert(i >= 0 && i < iTableSize);
    return dValue[i];
    }

static double SumLogA(double x, double y)
    {
//    return x + log2(1 + pow2(y-x));
    if (x > y)
        return x + lp2L(x-y);
    else
        return y + lp2L(y-x);
    }

// SumLog(x, y) = log2(2^x + 2^y)
static double SumLog(double x, double y)
    {
    return log2(pow2(x) + pow2(y));
    }

static double SumLog(double x, double y, double z)
    {
    return log2(pow2(x) + pow2(y) + pow2(z));
    }

static double SumLogA(double x, double y, double z)
    {
    return SumLogA(x, SumLogA(y, z));
    }

static double SumLog(double w, double x, double y, double z)
    {
    return log2(pow2(w) + pow2(x) + pow2(y) + pow2(z));
    }

static double SumLogA(double w, double x, double y, double z)
    {
    return SumLogA(SumLogA(w, x), SumLogA(y, z));
    }

static void p(double x, double y)
    {
    printf("SL(%g, %g)=%g %g %g\n", x, y, SumLog(x, y), SumLogA(x, y), SumLogA(y, x));
    }

static void q(double x, double y, double z)
    {
    printf("SL(%g, %g, %g)=%g %g\n", x, y, z, SumLog(x, y, z), SumLogA(x, y, z));
    }

static void r(double w, double x, double y, double z)
    {
    printf("SL(%g, %g, %g, %g)=%g %g\n", w, x, y, z, SumLog(w, x, y, z), SumLogA(w, x, y, z));
    }

void TestSumLog(int argc, char *argv[])
    {
    printf("log2(4)=%g\n", log2(4));
    printf("log2(1024)=%g\n", log2(1024));
    printf("pow2(4)=%g\n", pow2(4));
    printf("pow2(10)=%g\n", pow2(10));
    printf("pow2(0.5)=%g\n", pow2(0.5));
    p(0.1, 0.2);
    q(0.1, 0.2, 0.3);
    r(0.1, 0.2, 0.3, 0.4);
    //for (double x = 0; x <= 20.0; ++x)
    //    {
    //    x += 1.0/(rand() + 1);
    //    printf("lp2(%g) = %g %g\n", x, lp2(x), lp2L(x));
    //    }
    }

#endif    // 0
