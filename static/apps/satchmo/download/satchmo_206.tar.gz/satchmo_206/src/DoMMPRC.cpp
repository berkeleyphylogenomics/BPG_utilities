// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "SAMMod.h"
#include "HMM.h"
#include "MSA.h"
#include "PWPath.h"
#include "TextFile.h"

void DoMMPRC(const char *hmm1, const char *hmm2, const char *tpl1, const char *tpl2,
  const char *out, const char *bounds)
    {
    const BOUNDS BoundsA = LOCAL;
    const BOUNDS BoundsB = LOCAL;
    const char *strHMMFileA = hmm1;
    const char *strHMMFileB = hmm2;
    const char *strTplFileA = tpl1;
    const char *strTplFileB = tpl2;
    const char *strOutputFastaFile = out;

    TextFile FileTA(strTplFileA);
    MSA msaA;
    msaA.FromFASTAFile(FileTA);
    msaA.AlignByCase();
    msaA.BuildPillars();
    
    TextFile FileTB(strTplFileB);
    MSA msaB;
    msaB.FromFASTAFile(FileTB);
    msaB.AlignByCase();
    msaB.BuildPillars();

    TextFile HMMFileA(strHMMFileA);
    SAMMod samA;
    samA.FromFile(HMMFileA);

    TextFile HMMFileB(strHMMFileB);
    SAMMod samB;
    samB.FromFile(HMMFileB);

    HMM hmmA;
    hmmA.FromSAMMod(samA);
    hmmA.SetTemplate(msaA);

    HMM hmmB;
    hmmB.FromSAMMod(samB);
    hmmB.SetTemplate(msaB);

    PWPath Path;
    MMPRC(hmmA, hmmB, BoundsA, BoundsB, Path);

    MSA msaCombined;
    AlignHMMs(hmmA, hmmB, Path, msaCombined);

    TextFile OutFile(strOutputFastaFile, true);
    msaCombined.ListMe();
    msaCombined.ToFASTAFile(OutFile);
    }
