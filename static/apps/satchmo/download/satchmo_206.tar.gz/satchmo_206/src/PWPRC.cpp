// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWPRC.h"
#include "HMM.h"

PWPRC::PWPRC()
    {
    m_ptrModelA = 0;
    m_ptrModelB = 0;
    }

PWPRC::~PWPRC()
    {
    }

void PWPRC::Init(const HMM &ModelA, BOUNDS BoundsA, const HMM &ModelB, BOUNDS BoundsB)
    {
    m_ptrModelA = &ModelA;
    m_ptrModelB = &ModelB;

    m_boundsA = BoundsA;
    m_boundsB = BoundsB;
    }

unsigned PWPRC::GetLengthA() const
    {
    return m_ptrModelA->GetNodeCount();
    }

unsigned PWPRC::GetLengthB() const
    {
    return m_ptrModelB->GetNodeCount();
    }

SCORE PWPRC::ScoreMM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthA > 1);
    assert(uPrefixLengthB > 1);
    unsigned uNodeIndexA = uPrefixLengthA - 2;
    unsigned uNodeIndexB = uPrefixLengthB - 2;
    const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
    const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
    return NodeA.m_scoreMM + NodeB.m_scoreMM;
    }

SCORE PWPRC::ScoreMD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthA > 1);
    assert(uPrefixLengthB > 0);
    unsigned uNodeIndexA = uPrefixLengthA - 2;
    unsigned uNodeIndexB = uPrefixLengthB - 1;
    const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
    const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
    return NodeA.m_scoreMD + NodeB.m_scoreMI;
    }

SCORE PWPRC::ScoreMI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthA > 0);
    assert(uPrefixLengthB > 1);
    unsigned uNodeIndexA = uPrefixLengthA - 1;
    unsigned uNodeIndexB = uPrefixLengthB - 2;
    const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
    const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
    return NodeA.m_scoreMI + NodeB.m_scoreMD;
    }

SCORE PWPRC::ScoreDM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthA > 1);
    assert(uPrefixLengthB > 0);
    unsigned uNodeIndexA = uPrefixLengthA - 2;
    const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
    SCORE scoreB;
    if (uPrefixLengthB > 1)
        {
        unsigned uNodeIndexB = uPrefixLengthB - 2;
        const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
        scoreB = NodeB.m_scoreIM;
        }
    else
        scoreB = m_ptrModelB->GetFirstM();
    return NodeA.m_scoreDM + scoreB;
    }

SCORE PWPRC::ScoreDD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthA > 1);
    unsigned uNodeIndexA = uPrefixLengthA - 2;
    const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
    if (uPrefixLengthB == 0)
        return NodeA.m_scoreDD;
    unsigned uNodeIndexB = uPrefixLengthB - 1;
    const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
    return NodeA.m_scoreDD + NodeB.m_scoreII;
    }

SCORE PWPRC::ScoreDI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthA > 0);
    assert(uPrefixLengthB > 0);

    unsigned uNodeIndexA = uPrefixLengthA - 1;
    const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
    if (1 == uPrefixLengthB)
        {
        unsigned uNodeIndexA = uPrefixLengthA - 1;
        const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
        return NodeA.m_scoreID + m_ptrModelB->GetFirstM();
        }
    unsigned uNodeIndexB = uPrefixLengthB - 2;
    const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
    return NodeA.m_scoreID + NodeB.m_scoreDI;
    }

SCORE PWPRC::ScoreIM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthB > 1);
    assert(uPrefixLengthA > 0);
    unsigned uNodeIndexB = uPrefixLengthB - 2;
    const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
    SCORE scoreA;
    if (uPrefixLengthA > 1)
        {
        unsigned uNodeIndexA = uPrefixLengthA - 2;
        const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
        scoreA = NodeA.m_scoreIM;
        }
    else
        scoreA = m_ptrModelA->GetFirstM();
    return NodeB.m_scoreDM + scoreA;
    }

SCORE PWPRC::ScoreID(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthB > 0);
    assert(uPrefixLengthA > 0);

    unsigned uNodeIndexB = uPrefixLengthB - 1;
    const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
    if (1 == uPrefixLengthA)
        {
        unsigned uNodeIndexB = uPrefixLengthB - 1;
        const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
        return NodeB.m_scoreID + m_ptrModelA->GetFirstM();
        }
    unsigned uNodeIndexA = uPrefixLengthA - 2;
    const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
    return NodeB.m_scoreID + NodeA.m_scoreDI;
    }

SCORE PWPRC::ScoreII(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthB > 1);
    unsigned uNodeIndexB = uPrefixLengthB - 2;
    const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
    if (uPrefixLengthA == 0)
        return NodeB.m_scoreDD;
    unsigned uNodeIndexA = uPrefixLengthA - 1;
    const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
    return NodeB.m_scoreDD + NodeA.m_scoreII;
    }

SCORE PWPRC::ScoreSM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && 1 != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && 1 != uPrefixLengthB)
        return MINUS_INFINITY;
    return m_ptrModelA->GetFirstM() + m_ptrModelB->GetFirstM();
    }

SCORE PWPRC::ScoreSD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && 1 != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && 0 != uPrefixLengthB)
        return MINUS_INFINITY;
    return m_ptrModelA->GetFirstD() + m_ptrModelB->GetFirstM();
    }

SCORE PWPRC::ScoreSI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && 0 != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && 1 != uPrefixLengthB)
        return MINUS_INFINITY;
    return m_ptrModelA->GetFirstM() + m_ptrModelB->GetFirstD();
    }

SCORE PWPRC::ScoreME(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && GetLengthA() != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && GetLengthB() != uPrefixLengthB)
        return MINUS_INFINITY;
    return 0;
    }

SCORE PWPRC::ScoreDE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && GetLengthA() != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && GetLengthB() != uPrefixLengthB)
        return MINUS_INFINITY;
    return 0;
    }

SCORE PWPRC::ScoreIE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GLOBAL == m_boundsA && GetLengthA() != uPrefixLengthA)
        return MINUS_INFINITY;
    if (GLOBAL == m_boundsB && GetLengthB() != uPrefixLengthB)
        return MINUS_INFINITY;
    return 0;
    }

SCORE PWPRC::ScoreLL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthA > 0);
    assert(uPrefixLengthB > 0);
    unsigned uNodeIndexA = uPrefixLengthA - 1;
    unsigned uNodeIndexB = uPrefixLengthB - 1;
    const HMMNode &NodeA = m_ptrModelA->GetNode(uNodeIndexA);
    const HMMNode &NodeB = m_ptrModelB->GetNode(uNodeIndexB);
    SCORE scoreDotProduct = 0;
    for (unsigned uLetter = 0; uLetter < 20; ++uLetter)
        scoreDotProduct += NodeA.m_scoreMatchEmit[uLetter]*NodeB.m_scoreMatchEmit[uLetter];
    return scoreDotProduct;
    }

SCORE PWPRC::ScoreLG(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return 0;
    }

SCORE PWPRC::ScoreGL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return 0;
    }
