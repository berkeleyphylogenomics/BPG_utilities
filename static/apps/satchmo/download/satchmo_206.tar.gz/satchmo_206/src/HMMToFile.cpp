// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "TextFile.h"

static void PutScore(TextFile &File, SCORE Score)
    {
    if (MINUS_INFINITY == Score)
        File.PutString("        *");
    else
        File.PutFormat(" %8s", ScoreToStr(Score));
    }

void HMM::ToFile(TextFile &File) const
    {
    const unsigned uNodeCount = GetNodeCount();
    File.PutString("SatchmoHMM\n");
    File.PutString("{\n");
    File.PutFormat("length %u\n", uNodeCount);
    File.PutFormat("entry %s %s\n",
      ScoreToStr(m_scoreFirstM),
      ScoreToStr(m_scoreFirstD));

    File.PutFormat("trans\n");
    File.PutFormat("%% Node       MM       MD       MI       DM       DD       DI       IM       ID       II\n");
    for (unsigned uNodeIndex = 0; uNodeIndex + 1 < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        File.PutFormat("%6u", uNodeIndex);
        PutScore(File, Node.m_scoreMM);
        PutScore(File, Node.m_scoreMD);
        PutScore(File, Node.m_scoreMI);
        PutScore(File, Node.m_scoreDM);
        PutScore(File, Node.m_scoreDD);
        PutScore(File, Node.m_scoreDI);
        PutScore(File, Node.m_scoreIM);
        PutScore(File, Node.m_scoreID);
        PutScore(File, Node.m_scoreII);
        File.PutString("\n");
        }

    File.PutString("match\n");
    File.PutString(
"% Node         A        C        D        E        F        G        H        I        K        L        "
             "M        N        P        Q        R        S        T        V        W        Y\n");

    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        File.PutFormat("  %4u ", uNodeIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            PutScore(File, Node.m_scoreMatchEmit[uLetter]);
        File.PutString("\n");
        }

#if    INSERT_EMITS
    File.PutString("insert\n");
    File.PutString(
"% Node         A        C        D        E        F        G        H        I        K        L        "
             "M        N        P        Q        R        S        T        V        W        Y\n");

    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        File.PutFormat("  %4u ", uNodeIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            PutScore(File, Node.m_scoreInsertEmit[uLetter]);
        File.PutString("\n");
        }
#endif

    File.PutString("}\n");
    }

static void PutScore2(TextFile &File, SCORE Score)
    {
    if (MINUS_INFINITY == Score)
        File.PutString(" *");
    else
        File.PutFormat(" %.3g", Score);
    }

// Save Match State Scores (MSS) to file
void HMM::MSSToFile(TextFile &File) const
    {
    File.PutString("mss\n{\n");

    const unsigned uNodeCount = GetNodeCount();
    File.PutFormat("nodes %u\n", uNodeCount);

    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        File.PutFormat("%%u ", uNodeIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            PutScore2(File, Node.m_scoreMatchEmit[uLetter]);
        File.PutString("\n");
        }
    File.PutString("}\n");
    }
