// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWYL.h"
#include "PWYLF.h"
#include "PWYLD.h"
#include "PWYLDF.h"
#include "PWLA.h"
#include "PWLAI.h"
#include "PWAL.h"
#include "PWALI.h"
#include "PWLAP.h"
#include "PWMDotF.h"
#include "PWMDotM.h"
#include "PWMDotP.h"
#include "PWFDotF.h"
#include "PWGDotG.h"
#include "PWPDotP.h"
#include "PWFDotP.h"
#include "PWMM.h"
#include "PWRE.h"
#include "PWREF.h"
#include "PWDir.h"
#include "PWEuclidP.h"
#include "PWEuclidF.h"
#include "PWCorrelP.h"
#include "PWCorrelF.h"
#include "PWRankP.h"
#include "PWRankF.h"

void PWSFactory(const char *colpair, const char *gapstyle, const char *bounds,
  PWBase **ptrptrPWS)
    {
    PWBase *ptrPWS = 0;

    if (!stricmp(colpair, "YL"))
        ptrPWS = new PWYL;
    else if (!stricmp(colpair, "YLD"))
        ptrPWS = new PWYLD;
    else if (!stricmp(colpair, "YLDF"))
        ptrPWS = new PWYLDF;
    else if (!stricmp(colpair, "LA"))
        ptrPWS = new PWLA;
    else if (!stricmp(colpair, "AL"))
        ptrPWS = new PWAL;
    else if (!stricmp(colpair, "LAI"))
        ptrPWS = new PWLAI;
    else if (!stricmp(colpair, "ALI"))
        ptrPWS = new PWALI;
    else if (!stricmp(colpair, "MdotF"))
        ptrPWS = new PWMDotF;
    else if (!stricmp(colpair, "MdotM"))
        ptrPWS = new PWMDotM;
    else if (!stricmp(colpair, "MdotP"))
        ptrPWS = new PWMDotP;
    else if (!stricmp(colpair, "FdotF"))
        ptrPWS = new PWFDotF;
    else if (!stricmp(colpair, "GdotG"))
        ptrPWS = new PWGDotG;
    else if (!stricmp(colpair, "PdotP"))
        ptrPWS = new PWPDotP;
    else if (!stricmp(colpair, "FdotP"))
        ptrPWS = new PWFDotP;
    else if (!stricmp(colpair, "MM"))
        ptrPWS = new PWMM;
    else if (!stricmp(colpair, "RE"))
        ptrPWS = new PWRE;
    else if (!stricmp(colpair, "REF"))
        ptrPWS = new PWREF;
    else if (!stricmp(colpair, "YLF"))
        ptrPWS = new PWYLF;
    else if (!stricmp(colpair, "Dir"))
        ptrPWS = new PWDir;
    else if (!stricmp(colpair, "EuclidP"))
        ptrPWS = new PWEuclidP;
    else if (!stricmp(colpair, "EuclidF"))
        ptrPWS = new PWEuclidF;
    else if (!stricmp(colpair, "CorrelP"))
        ptrPWS = new PWCorrelP;
    else if (!stricmp(colpair, "CorrelF"))
        ptrPWS = new PWCorrelF;
    else if (!stricmp(colpair, "RankP"))
        ptrPWS = new PWRankP;
    else if (!stricmp(colpair, "RankF"))
        ptrPWS = new PWRankF;
    else
        CmdLineError("Invalid column pair score type '%s'", colpair);

    GAPSTYLE GapStyle = GAPSTYLE_Undefined;

    BOUNDS BoundsA = BOUNDS_Undefined;
    BOUNDS BoundsB = BOUNDS_Undefined;

    if (!stricmp(bounds, "GG"))
        {
        BoundsA = GLOBAL;
        BoundsB = GLOBAL;
        }
    else if (!stricmp(bounds, "GL"))
        {
        BoundsA = GLOBAL;
        BoundsB = LOCAL;
        }
    else if (!stricmp(bounds, "LG"))
        {
        BoundsA = LOCAL;
        BoundsB = GLOBAL;
        }
    else if (!stricmp(bounds, "LL"))
        {
        BoundsA = LOCAL;
        BoundsB = LOCAL;
        }
    else
        CmdLineError("Invalid bounds '%s'", bounds);

    if (!stricmp(gapstyle, "simple"))
        GapStyle = GAPSTYLE_Simple;
    else if (!stricmp(gapstyle, "Coach"))
        GapStyle = GAPSTYLE_Coach;
    else
        CmdLineError("Invalid gapstyle '%s'", gapstyle);

    SCORE scoreGapOpen = ptrPWS->GetDefaultGapOpen();
    SCORE scoreGapExtend = ptrPWS->GetDefaultGapExtend();
    SCORE scoreShift = ptrPWS->GetDefaultShift();

    const char *pstrGapOpen = GetOptionalParam("gapopen");
    const char *pstrGapExtend = GetOptionalParam("gapextend");
    const char *pstrShift = GetOptionalParam("shift");

    if (0 != pstrGapOpen)
        scoreGapOpen = (SCORE) atof(pstrGapOpen);
    if (0 != pstrGapExtend)
        scoreGapExtend = (SCORE) atof(pstrGapExtend);
    if (0 != pstrShift)
        scoreShift = (SCORE) atof(pstrShift);

    ptrPWS->SetParams(scoreGapOpen, scoreGapExtend, scoreShift);
    ptrPWS->SetBounds(BoundsA, BoundsB);
    ptrPWS->SetGapStyle(GapStyle);

    List("PWS colpair=%s;bounds=%s;gapstyle=%s;gapopen=%g;gapextend(%g)=%g;shift=%g\n",
      colpair,
      bounds,
      gapstyle,
      scoreGapOpen,
      scoreGapExtend,
      scoreGapExtend,
      scoreShift);

    *ptrptrPWS = ptrPWS;
    }
