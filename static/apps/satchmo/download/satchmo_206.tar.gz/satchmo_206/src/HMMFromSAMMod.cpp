// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "SAMMod.h"
#include <math.h>

/***
A typical model node in SAM and Lobster is essentially identical.

SAM has two more nodes than Lobster, these are called Begin and End.
Main model nodes in SAM are numbered 1 .. m, in Lobster are numbered
0 .. (m-1).

In Lobster, the last node has no insert state. In SAM, node m
(the last main model node, i.e. the node before End) has an insert
state that could serve as the N-terminal "FIM". The SAM Begin node
similarly has an insert state that could serve as the C-terminal
FIM. 

If the Begin and End nodes contain FIMs, you would expect the I->I
transition probabilities be set to the null model self-loop. However,
looking in model files built by w0.5, the I->I probabilities in the
Begin and End nodes are quite different from what one would expect for
the null model, and look in fact to be close to the typical I->I value
for the main model nodes. So I don't understand how to interpret them.
When converting from SAM to Lobster format, I can discard these values;
when converting from Lobster to SAM I try to reproduce what I'm seeing
in SAM files without fully understanding the effects.

The emission probabilities in all SAM insert states, including those in
Begin and End, appear to be set to a fixed null model distribution.

The SAM Begin node match state does not match a letter, it serves
as a silent start state, which we denote by S. Similarly, the End node
match state is a silent termination state, T.

In SAM, M1 (the first match state) can be reached directly or via I0,
the Begin node insert state:

        S->M1
        S->I0[->I0...]->M1

Similarly, D1, the first delete state, can be reached via these paths:

        S->D1
        S->I0[->I0...]->D1

In Lobster, the FIM is not explicit, the transitions into the first match
and delete states (M0 and D0 respectively) are expressed directly:

        S->M0
        S->D0

In SAM, the probability of S-> ... ->M1 by all paths is

    P(M1 | S) = P(S->M1) + P(S->I0) P(M1 | I0)

Similarly,

    P(D1 | S) = P(S->D1) + P(S->I0) P(D1 | I0)

Using:

    P(M1 | I0) = P(I0->M1) / (P(I0->M1) + P(I0->D1)
    P(D1 | I0) = P(I0->D1) / (P(I0->M1) + P(I0->D1)

We get finally:

    P(M1 | S) = P(S->M1) + P(S->I0) P(I0->M1) / (PI0->M1) + P(I0->D1))        (1)
    P(D1 | S) = P(S->D1) + P(S->I0) P(I0->D1) / (PI0->M1) + P(I0->D1))        (2)
***/

void HMM::FromSAMMod(const SAMMod &Mod)
    {
    Clear();
    Mod.Validate();

    unsigned uNodeCount = Mod.GetNodeCount();
    if (uNodeCount <= 2)
        Quit("Invalid SAM model, %u nodes", uNodeCount);

    m_uNodeCount = uNodeCount - 2;
    m_Nodes = new HMMNode[m_uNodeCount];

// Beginning of model is special case.
// See comments above re. P(M1 | S) and P(D1 | S).
    const SAMNode &samBeginNode = Mod.GetNode(0);
    const SAMNode &samFirstNode = Mod.GetNode(1);
    PROB probExitI0 = samFirstNode.m_probIM + samFirstNode.m_probID;
    PROB probFirstM = samFirstNode.m_probMM +
      samBeginNode.m_probMI*(samFirstNode.m_probIM / probExitI0);
    PROB probFirstD = samFirstNode.m_probMD +
      samBeginNode.m_probMI*(samFirstNode.m_probID / probExitI0);

// Validity checks
    assert(probFirstM >= 0.0 && probFirstM <= 1.0);
    assert(probFirstD >= 0.0 && probFirstD <= 1.0);
    PROB probSum = probFirstM + probFirstD;
    if (fabs(probSum) - 1.0 > 0.01)
        Quit("HMM::FromSAMMod, FirstX not normalized");

    m_scoreFirstM = ProbToScore(probFirstM);
    m_scoreFirstD = ProbToScore(probFirstD);

    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        const SAMNode &samNode = Mod.GetNode(uNodeIndex + 1);
        const SAMNode &samNextNode = Mod.GetNode(uNodeIndex + 2);
        HMMNode &Node = m_Nodes[uNodeIndex];

        Node.m_scoreMM = ProbToScore(samNextNode.m_probMM);
        Node.m_scoreMD = ProbToScore(samNextNode.m_probMD);
        Node.m_scoreMI = ProbToScore(samNode.m_probMI);

        Node.m_scoreIM = ProbToScore(samNextNode.m_probIM);
        Node.m_scoreID = ProbToScore(samNextNode.m_probID);
        Node.m_scoreII = ProbToScore(samNode.m_probII);

        Node.m_scoreDM = ProbToScore(samNextNode.m_probDM);
        Node.m_scoreDD = ProbToScore(samNextNode.m_probDD);
        Node.m_scoreDI = ProbToScore(samNode.m_probDI);

        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            Node.m_scoreMatchEmit[uLetter] =
              ProbToScore(samNode.m_probMatchEmit[uLetter]);

    // No insert state in last node
        if (uNodeIndex == m_uNodeCount - 1)
            for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
                Node.m_scoreInsertEmit[uLetter] = MINUS_INFINITY;
        else
        // Ignore SAM value, use null model
            for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
                Node.m_scoreInsertEmit[uLetter] = GetNullEmitScore(uLetter);
        }

    SubtractSimpleNull();
    AssertNormalized();

// Hack: save MD in node 1 for PRC
    m_probSAMFirstMD = samFirstNode.m_probMD;
    }
