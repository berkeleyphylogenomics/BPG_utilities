// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWScore.h"

SCORE PWScore::ScoreTrans(char cFromEdgeType, char cToEdgeType, unsigned uPrefixLengthA,
  unsigned uPrefixLengthB) const
    {
#define T2(c1, c2)    (((c1) << 8) | (c2))
    switch (T2(cFromEdgeType, cToEdgeType))
        {
    case T2('M', 'M'):
        return ScoreMM(uPrefixLengthA, uPrefixLengthB);
    case T2('D', 'M'):
        return ScoreDM(uPrefixLengthA, uPrefixLengthB);
    case T2('I', 'M'):
        return ScoreIM(uPrefixLengthA, uPrefixLengthB);
    case T2('M', 'D'):
        return ScoreMD(uPrefixLengthA, uPrefixLengthB);
    case T2('D', 'D'):
        return ScoreDD(uPrefixLengthA, uPrefixLengthB);
    case T2('I', 'D'):
        return ScoreID(uPrefixLengthA, uPrefixLengthB);
    case T2('M', 'I'):
        return ScoreMI(uPrefixLengthA, uPrefixLengthB);
    case T2('D', 'I'):
        return ScoreDI(uPrefixLengthA, uPrefixLengthB);
    case T2('I', 'I'):
        return ScoreII(uPrefixLengthA, uPrefixLengthB);
    case T2('S', 'M'):
        return ScoreSM(uPrefixLengthA, uPrefixLengthB);
    case T2('S', 'D'):
        return ScoreSD(uPrefixLengthA, uPrefixLengthB);
    case T2('S', 'I'):
        return ScoreSI(uPrefixLengthA, uPrefixLengthB);
    case T2('M', 'E'):
        return ScoreME(uPrefixLengthA, uPrefixLengthB);
    case T2('D', 'E'):
        return ScoreDE(uPrefixLengthA, uPrefixLengthB);
    case T2('I', 'E'):
        return ScoreIE(uPrefixLengthA, uPrefixLengthB);
        }
#undef    T2
    assert(false);
    return MINUS_INFINITY;
    }

SCORE PWScore::ScoreEmit(char cEdgeType, unsigned uPrefixLengthA,
  unsigned uPrefixLengthB) const
    {
    switch (cEdgeType)
        {
    case 'M':
        return ScoreLL(uPrefixLengthA, uPrefixLengthB);
    case 'D':
        return ScoreLG(uPrefixLengthA, uPrefixLengthB);
    case 'I':
        return ScoreGL(uPrefixLengthA, uPrefixLengthB);
        }
    assert(false);
    return MINUS_INFINITY;
    }
