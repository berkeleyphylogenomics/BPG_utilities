// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "MSA.h"

#define VERBOSE 0

#ifndef    VERBOSE
#define    VERBOSE 0
#endif

SCORE HMM::ScoreRouteAln(const HMMPath &Route, const MSA &a) const
    {
#if    VERBOSE
    List("HMM::ScoreRouteAln\n");
#endif
    SCORE Score;
    const unsigned uPillarCount = a.GetPillarCount();
    const unsigned uEdgeCount = Route.GetEdgeCount();
    assert(uEdgeCount > 0);
    const HMMEdge &FirstEdge = Route.GetEdge(0);
    const HMMEdge &LastEdge = Route.GetEdge(uEdgeCount - 1);
    char cFromState;
    if ('M' == FirstEdge.cState)
        {
        const unsigned uPrefixLength = FirstEdge.uPrefixLength;
        assert(uPrefixLength > 0);
        const PILLAR &FirstPillar = a.GetPillar(uPrefixLength - 1);
        SCORE s1;
        SCORE s2;
        FCOUNT fcF = FirstPillar.m_fcF;
        FCOUNT fcE = FirstPillar.m_fcE;
        MulFCountScore(s1, fcF, m_scoreFirstM);
        MulFCountScore(s2, fcE, m_scoreFirstD);
        Score = Add2(s1, s2);
#if    VERBOSE
        List("%7s  trans S->M%u = %s\n",
          ScoreToStr(Score),
          FirstEdge.uNodeIndex,
          ScoreToStr(Score));
#endif
        cFromState = 'M';
        }
    else
        {
        assert('D' == FirstEdge.cState);
        Score = m_scoreFirstD;
#if    VERBOSE
        List("%7s  trans S->D%u = %s\n",
          ScoreToStr(Score),
          FirstEdge.uNodeIndex,
          ScoreToStr(Score));
#endif
        cFromState = 'D';
        }
    char cPrevStateToI = INVALID_STATE;
    unsigned uFirstIPillar = uInsane;
    for (unsigned uEdgeIndex = 1; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const HMMEdge &Edge = Route.GetEdge(uEdgeIndex);
        char cToState = Edge.cState;
        const unsigned uNodeIndex = Edge.uNodeIndex;
        const unsigned uPrefixLength = Edge.uPrefixLength;
        SCORE scoreTrans;
#define    c2(a, b)    ((a) | ((b) << 8))
        int iStates = c2(cFromState, cToState);
        switch (iStates)
            {
        case c2('M', 'M'):
            scoreTrans = LegMM(a, uNodeIndex, uPrefixLength);
            break;

        case c2('M', 'D'):
            scoreTrans = LegMD(a, uNodeIndex, uPrefixLength);
            break;

        case c2('D', 'M'):
            scoreTrans = LegDM(a, uNodeIndex, uPrefixLength);
            break;

        case c2('D', 'D'):
            scoreTrans = LegDD(a, uNodeIndex, uPrefixLength);
            break;

        case c2('I', 'M'):
            scoreTrans = LegIM(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevStateToI);
            cPrevStateToI = INVALID_STATE;
            uFirstIPillar = uInsane;
            break;

        case c2('I', 'D'):
            scoreTrans = LegID(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevStateToI);
            cPrevStateToI = INVALID_STATE;
            uFirstIPillar = uInsane;
            break;

        case c2('D', 'I'):
            cPrevStateToI = 'D';
            scoreTrans = LegDI(a, uNodeIndex, uPrefixLength);
            assert(Edge.uPrefixLength > 0);
            uFirstIPillar = uPrefixLength - 1;
            break;

        case c2('M', 'I'):
            cPrevStateToI = 'M';
            assert(Edge.uPrefixLength > 0);
            uFirstIPillar = uPrefixLength - 1;
            scoreTrans = LegMI(a, uNodeIndex, uPrefixLength);
            break;

        case c2('I', 'I'):
            scoreTrans = LegII(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevStateToI);
            break;

        default:
            assert(false);
            }
        Score += scoreTrans;
#if    VERBOSE
        List("%7s  trans %c->%c%u = %s\n",
          ScoreToStr(Score),
          cFromState,
          Edge.cState,
          Edge.uNodeIndex,
          ScoreToStr(scoreTrans));
#endif
        cFromState = cToState;
        }
#undef c2
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const HMMEdge &Edge = Route.GetEdge(uEdgeIndex);
        if ('M' == Edge.cState)
            {
            assert(Edge.uPrefixLength > 0);
            SCORE scoreEmit = EmitM(a, Edge.uNodeIndex, Edge.uPrefixLength - 1);
            Score += scoreEmit;
#if    VERBOSE
            List("%7s  emitM%u(%u) = %s\n",
              ScoreToStr(Score),
              Edge.uNodeIndex,
              Edge.uPrefixLength-1,
              ScoreToStr(scoreEmit));
#endif
            }
        }
    unsigned uTerminalGapLength = uPillarCount - LastEdge.uPrefixLength;
    SCORE scoreTerminalGap = ScoreTerminalGap(uTerminalGapLength);
    return Score;
    }
