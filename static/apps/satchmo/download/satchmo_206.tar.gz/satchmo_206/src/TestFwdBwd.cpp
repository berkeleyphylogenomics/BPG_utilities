// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMMPath.h"
#include "EnumPaths.h"
#include "HMM.h"
#include "Seq.h"
#include "TextFile.h"
#include <list>

#define    VERBOSE    0

// Macros to simulate 2D matrices
#define DPM(NodeIndex, PrefixLength)    DPM_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPD(NodeIndex, PrefixLength)    DPD_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPI(NodeIndex, PrefixLength)    DPI_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]

typedef std::list<HMMPath *> PATH_BAG;
typedef PATH_BAG::iterator PATH_BAG_ITER;

class EPS_TestFwdBwd : public EnumPathsSink
    {
public:
    EPS_TestFwdBwd()
        {
        DPM_ = 0;
        DPD_ = 0;
        DPI_ = 0;
        m_ptrModel = 0;
        m_ptrSeq = 0;
        }

    virtual ~EPS_TestFwdBwd()
        {
        Clear();
        }

    void Clear()
        {
        delete[] DPM_;
        delete[] DPD_;
        delete[] DPI_;
        m_ptrModel = 0;
        m_ptrSeq = 0;
        }

    void Init(const HMM &Model, const Seq &s)
        {
        Clear();
        m_ptrModel = &Model;
        m_ptrSeq = &s;
        unsigned uSeqLength = s.Length();
        const unsigned uPrefixCount = uSeqLength + 1;
        size_t LM = m_ptrModel->GetNodeCount()*uPrefixCount;
        DPM_ = new SCORE[LM];
        DPD_ = new SCORE[LM];
        DPI_ = new SCORE[LM];
        for (unsigned n = 0; n < LM; ++n)
            {
            DPM_[n] = MINUS_INFINITY;
            DPD_[n] = MINUS_INFINITY;
            DPI_[n] = MINUS_INFINITY;
            }
        }

    virtual void OnPath(const HMMPath &Path)
        {
        const unsigned uPrefixCount = m_ptrSeq->Length() + 1;
        const unsigned uEdgeCount = Path.GetEdgeCount();
        SCORE scorePath = 0;
        for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
            {
            const HMMEdge &Edge = Path.GetEdge(uEdgeIndex);
            SCORE scoreEdge = Path.GetEdgeScore(uEdgeIndex, *m_ptrModel, *m_ptrSeq);
            scorePath = Add2(scorePath, scoreEdge);
            const unsigned uNodeIndex = Edge.uNodeIndex;
            const unsigned uPrefixLength = Edge.uPrefixLength;
            switch (Edge.cState)
                {
            case 'M':
                DPM(uNodeIndex, uPrefixLength) =
                  (SCORE) SumLog(DPM(uNodeIndex, uPrefixLength), scorePath);
                break;

            case 'D':
                DPD(uNodeIndex, uPrefixLength) =
                  (SCORE) SumLog(DPD(uNodeIndex, uPrefixLength), scorePath);
                break;

            case 'I':
                DPI(uNodeIndex, uPrefixLength) =
                  (SCORE) SumLog(DPI(uNodeIndex, uPrefixLength), scorePath);
                break;

            default:
                assert(false);
                }
            }
        }

    void ListMe()
        {
        unsigned uNodeCount = m_ptrModel->GetNodeCount();
        ListDP(uNodeCount, m_ptrSeq->Length(), DPM_, DPD_, DPI_);
        }

public:
    SCORE *DPM_;
    SCORE *DPD_;
    SCORE *DPI_;
    const HMM *m_ptrModel;
    const Seq *m_ptrSeq;
    };

void TestFwdBwd(int argc, char *argv[])
    {
    TextFile SeqFile("c:\\tmp\\seq.fasta");
    Seq s;
    s.FromFASTAFile(SeqFile);

    TextFile ModelFile("c:\\tmp\\test.hmm");
    HMM Model;
    Model.FromFile(ModelFile);

    EPS_TestFwdBwd e;
    e.Init(Model, s);
    EnumPaths(Model.GetNodeCount(), s.Length(), GLOBAL_MODEL, GLOBAL_SEQ, e);
    List("Brute force DP matrices:\n");
    e.ListMe();
    List("\n");
    SCORE *ptrDPM;
    SCORE scoreFwd = Model.ForwardSeq(s, &ptrDPM);
    List("\n");
    List("ForwardSeq = %s\n", ScoreToStr(scoreFwd));
    delete[] ptrDPM;
    }
