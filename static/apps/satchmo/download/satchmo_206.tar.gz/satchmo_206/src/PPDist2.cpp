// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PPDist2.h"
#include "Profile.h"

double PPDist2::ComputePPDist(const Profile &Prof1, const Profile &Prof2)
    {
    const unsigned uPosCount = Prof1.GetPosCount();
    assert(uPosCount == Prof2.GetPosCount());

    double dSum = 0;
    for (unsigned uPosIndex = 0; uPosIndex < uPosCount; ++uPosIndex)
        {
        const ProfPos &PP1 = Prof1.GetPos(uPosIndex);
        const ProfPos &PP2 = Prof2.GetPos(uPosIndex);
        dSum += PPPosDist(PP1, PP2);
        }
    return dSum / uPosCount;
    }
