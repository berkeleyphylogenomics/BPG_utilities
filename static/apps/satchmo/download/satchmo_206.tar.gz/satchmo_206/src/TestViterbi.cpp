// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMMPath.h"
#include "EnumPaths.h"
#include "HMM.h"
#include "Seq.h"
#include "TextFile.h"
#include <list>

#define    VERBOSE    0

typedef std::list<HMMPath *> PATH_BAG;
typedef PATH_BAG::iterator PATH_BAG_ITER;

class EPS_TestViterbi : public EnumPathsSink
    {
public:
    EPS_TestViterbi()
        {
        m_scoreHighest = MINUS_INFINITY;
        m_scoreAllPaths = MINUS_INFINITY;
        m_ptrSeq = 0;
        m_uPathCount = 0;
        }

    virtual ~EPS_TestViterbi()
        {
        ClearPathBag();
        }

    void SetSeq(Seq &s)
        {
        m_ptrSeq = &s;
        }

    void SetModel(HMM &Model)
        {
        m_ptrModel = &Model;
        }

    virtual void OnPath(const HMMPath &Path)
        {
        ++m_uPathCount;
        SCORE scorePath = m_ptrModel->ScorePathSeq(Path, *m_ptrSeq);
        m_scoreAllPaths = (SCORE) SumLog(m_scoreAllPaths, scorePath);
        if (ScoreEq(scorePath, m_scoreHighest))
            AppendPath(Path);
        else if (scorePath > m_scoreHighest)
            {
            m_scoreHighest = scorePath;
            ClearPathBag();
            AppendPath(Path);
            }
#if    VERBOSE
        Path.Validate(m_ptrModel->GetNodeCount(), m_ptrSeq->Length(),
          m_ModelBounds, m_SeqBounds);
        List("Score %s \t", ScoreToStr(scorePath));
        Path.ListMe();
#endif
        }

    void ListMe()
        {
        List("%u paths checked\n", m_uPathCount);
        List("%u highest-scoring paths\n", m_bagPaths.size());
        List("Total score for all paths %s\n", ScoreToStr(m_scoreAllPaths));
        List("\n");
        List("   Score  Path\n");
        List("   -----  ----\n");
        for (PATH_BAG_ITER p = m_bagPaths.begin(); p != m_bagPaths.end(); ++p)
            {
            const HMMPath &Path = **p;
            SCORE Score = m_ptrModel->ScorePathSeq(Path, *m_ptrSeq);
            List("%s  ", ScoreToStr(Score));
            Path.ListMe();
            }
        }
    
    void ClearPathBag()
        {
        for (PATH_BAG_ITER p = m_bagPaths.begin(); p != m_bagPaths.end(); ++p)
            delete *p;
        m_bagPaths.clear();
        }

    void AppendPath(const HMMPath &Path)
        {
        HMMPath *ptrNewPath = new HMMPath();
        ptrNewPath->Copy(Path);
        m_bagPaths.push_back(ptrNewPath);
        }

public:
    unsigned m_uPathCount;
    SCORE m_scoreHighest;
    SCORE m_scoreAllPaths;
    PATH_BAG m_bagPaths;
    Seq *m_ptrSeq;
    HMM *m_ptrModel;
    MODEL_BOUNDS m_ModelBounds;
    SEQ_BOUNDS m_SeqBounds;
    };

void TestViterbi(int argc, char *argv[])
    {
    TextFile SeqFile("c:\\tmp\\seq.fasta");
    Seq s;
    s.FromFASTAFile(SeqFile);

    TextFile ModelFile("c:\\tmp\\test.hmm");
    HMM Model;
    Model.FromFile(ModelFile);
//    Model.AddSimpleNull();

    List("Global model / local seq:\n");
    {
    EPS_TestViterbi e;
    e.SetModel(Model);
    e.SetSeq(s);
    e.m_ModelBounds = GLOBAL_MODEL;
    e.m_SeqBounds = LOCAL_SEQ;
    EnumPaths(Model.GetNodeCount(), s.Length(), GLOBAL_MODEL, LOCAL_SEQ, e);
    e.ListMe();
    }

    {
    HMMPath ViterbiPath;
    SCORE scoreViterbi = Model.ViterbiSeq(s, GLOBAL_MODEL, LOCAL_SEQ, ViterbiPath);
    List("\n");
    List("Viterbi:\n");
    List("%s  ", ScoreToStr(scoreViterbi));
    ViterbiPath.ListMe();
    List("\n");
    }

    List("Global model / global seq:\n");
    {
    EPS_TestViterbi e;
    e.SetModel(Model);
    e.SetSeq(s);
    e.m_ModelBounds = GLOBAL_MODEL;
    e.m_SeqBounds = GLOBAL_SEQ;
    EnumPaths(Model.GetNodeCount(), s.Length(), GLOBAL_MODEL, GLOBAL_SEQ, e);
    e.ListMe();
    }

    {
    HMMPath ViterbiPath;
    SCORE scoreViterbi = Model.ViterbiSeq(s, GLOBAL_MODEL, GLOBAL_SEQ, ViterbiPath);
    List("\n");
    List("Viterbi:\n");
    List("%s  ", ScoreToStr(scoreViterbi));
    ViterbiPath.ListMe();
    List("\n");
    }
    }
