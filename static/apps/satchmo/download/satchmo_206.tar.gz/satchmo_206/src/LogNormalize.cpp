// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include <math.h>

// Convert unnormalized vector of log-scores into
// a normalized probability vector.
void LogNormalize(const double LogScores[], unsigned n, double Probs[])
    {
    unsigned i;

// -9e99 is arbitrary choice of very small number
    double dMaxScore = -9.0e99;

// Find largest score
    for (i = 0; i < n; i++)
        if (LogScores[i] > dMaxScore)
            dMaxScore = LogScores[i];

// Discard very low scores to avoid underflow on exp.
// Value of 50.0 chosen to duplicate HMMer output.
    double dMinScore = dMaxScore - 50.0;

    double dDenom = 0.0;
    for (i = 0; i < n; i++)
        if (LogScores[i] > dMinScore)
            dDenom += exp(LogScores[i] - dMaxScore);

    for (i = 0; i < n; i++)
        if (LogScores[i] > dMinScore)
            Probs[i] = exp(LogScores[i] - dMaxScore) / dDenom;
        else
            Probs[i] = 0.0;
    }

void LogNormalize(const float LogScores[], unsigned n, double Probs[])
    {
    unsigned i;

// -9e99 is arbitrary choice of very small number
    float dMaxScore = (float) -9.0e37;

// Find largest score
    for (i = 0; i < n; i++)
        if (LogScores[i] > dMaxScore)
            dMaxScore = LogScores[i];

// Discard very low scores to avoid underflow on exp.
// Value of 50.0 chosen to duplicate HMMer output.
    float dMinScore = (float) (dMaxScore - 50.0);

    float dDenom = 0.0;
    for (i = 0; i < n; i++)
        if (LogScores[i] > dMinScore)
            dDenom += (float) exp(LogScores[i] - dMaxScore);

    for (i = 0; i < n; i++)
        if (LogScores[i] > dMinScore)
            Probs[i] = exp(LogScores[i] - dMaxScore) / dDenom;
        else
            Probs[i] = 0.0;
    }
