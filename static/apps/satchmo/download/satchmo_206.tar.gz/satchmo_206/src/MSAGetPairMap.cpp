// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"

/***
It is sometimes very convenient to represent a pairwise alignment
as a "pair map", which works as follows.

Let iPos1 be the index into ungapped sequence 1, similarly for iPos2.

Then if a pair of letters (iPos1, iPos2) is aligned:

    iMap1[iPos1] = iPos2 and iMap2[iPos2] = iPos1.

If iPos1 is not in an aligned column, or is aligned to a gap, then
iMap1[iPos1] = -1, and similarly for iMap2. This overloads the meaning
of the integer value, so is questionable software engineering practice;
however it's a simple and convenient solution for small applications.
***/

void MSA::GetPairMap(unsigned uSeqIndex1, unsigned uSeqIndex2, int iMap1[],
  int iMap2[]) const
    {
    assert(uSeqIndex1 < GetSeqCount());
    assert(uSeqIndex2 < GetSeqCount());

    int iPos1 = 0;
    int iPos2 = 0;
    const unsigned uColCount = GetColCount();
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        bool bIsGap1 = IsGap(uSeqIndex1, uColIndex);
        bool bIsGap2 = IsGap(uSeqIndex2, uColIndex);
        if (!bIsGap1 && !bIsGap2)
            {
            if (IsAligned(uColIndex))
                {
                iMap1[iPos1] = iPos2;
                iMap2[iPos2] = iPos1;
                }
            else
                {
                iMap1[iPos1] = -1;
                iMap2[iPos2] = -1;
                }
            ++iPos1;
            ++iPos2;
            }
        else if (!bIsGap1 && bIsGap2)
            {
            iMap1[iPos1] = -1;
            ++iPos1;
            }
        else if (bIsGap1 && !bIsGap2)
            {
            iMap2[iPos2] = -1;
            ++iPos2;
            }
        }

#if    _DEBUG
    {
    int iLength1 = iPos1;
    int iLength2 = iPos2;

    for (int iPos1 = 0; iPos1 < iLength1; ++iPos1)
        {
        int iPos2 = iMap1[iPos1];
        if (-1 == iPos2)
            continue;
        assert(iMap2[iPos2] == iPos1);
        }

    for (int iPos2 = 0; iPos2 < iLength2; ++iPos2)
        {
        int iPos1 = iMap2[iPos2];
        if (-1 == iPos1)
            continue;
        assert(iMap1[iPos1] == iPos2);
        }
    }
#endif
    }
