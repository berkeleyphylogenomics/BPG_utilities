// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    Phylip_h
#define Phylip_h

#include "PhylipNode.h"

class TextFile;
class Clust;

class Phylip
    {
public:
    Phylip()
        {
        m_ptrRoot = 0;
        m_ptrOutlier = 0;
        m_uClassCount = 0;
        m_uNodeCount = 0;
        m_uZFPCount = 0;
        }
    virtual ~Phylip();

public:
    void ToFile(TextFile &File) const;
    void ToFile(TextFile &File, PhylipNode *ptrNode) const;
    void FromFile(TextFile &File);

    PhylipNode *GetRoot() const { return m_ptrRoot; }

    void Clear();
    void ListMe() const;
    unsigned GetClassCount() const;
    Phylip *Root(PhylipNode *ptrRootChild) const;
    void AllocCounts();
    void CalcCounts();
    PhylipNode *GetOutlier() const { return m_ptrOutlier; }
    void ListFromEdge(PhylipNode *ptrNode, PhylipNode *ptrPrevNode) const;
    PhylipNode *EdgeToNode(const PhylipNode *ptrFromNode,
      const PhylipNode *ptrToNode) const;
    void SetRoot(PhylipNode *ptrRoot);

    unsigned GetNFPCount(PhylipNode *ptrNode, unsigned N) const;
    unsigned GetNFNCount(PhylipNode *ptrNode, unsigned N) const;

    void ListNFPSubtrees(PhylipNode *ptrNode, unsigned N) const;
    void ListNFNSubtrees(PhylipNode *ptrNode, unsigned N) const;
    void ListZFNSubtree(PhylipNode *ptrNode, unsigned uClass) const;
    void ListZFNSubtrees() const;

    PhylipNode *GetNode(unsigned uIndex);

    unsigned GetSingletonClassCount() const;
    unsigned GetNonEmptyClassCount() const;
    unsigned GetNFPCount(unsigned N) const;

    bool IsRooted() const { return 0 == m_ptrRoot->GetParent(); }
    unsigned GetNodeCount() const { return m_uNodeCount; }

    double GetPARScore();

    void FromClust(const Clust &C);

private:
    void ToFileNode(TextFile &File, PhylipNode *ptrNode) const;
    void ClearSubtree(PhylipNode *ptrNode);
    PhylipNode *FromFileSubtree(TextFile &File, bool bFirstNode = false);
    void ListSubtree(const PhylipNode *ptrNode) const;
    void AllocCountsNode(PhylipNode *ptrNode, unsigned uClassCount);
    void ListNodeCounts(const PhylipNode *ptrNode) const;
    PhylipNode *FindNode(unsigned uIndex, PhylipNode *ptrNode);
    double GetPARPairScore(PhylipNode *ptrNode1, PhylipNode *ptrNode2);
    PhylipNode *GetCommonParent(PhylipNode *ptrNode1, PhylipNode *ptrNode2);
    void GetMemberCount(PhylipNode *ptrGroup, unsigned uClass,
      unsigned &uGroupSize, unsigned &uClassMemberCount);
    void RecurseMemberCount(PhylipNode *ptrGroup, unsigned uClass,
      unsigned &uGroupSize, unsigned &uClassMemberCount);
    PhylipNode *FromClustNode(const Clust &C, unsigned uNodeIndex);

private:
    PhylipNode *m_ptrRoot;
    PhylipNode *m_ptrOutlier;
    unsigned m_uClassCount;
    unsigned m_uNodeCount;
    unsigned m_uZFPCount;
    unsigned m_u1FPCount;
    unsigned m_uZFNCount;
    };

#endif    // Phylip_h
