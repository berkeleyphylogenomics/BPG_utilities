// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"

#define VERBOSE    0

void ExtractCore(const MSA &msaCore, const MSA &msaInput, MSA &msaOutput)
    {
    msaOutput.Clear();

    const unsigned uCoreColCount = msaCore.GetColCount();
    const unsigned uCoreSeqCount = msaCore.GetSeqCount();
    const unsigned uInputColCount = msaInput.GetColCount();
    const unsigned uInputSeqCount = msaInput.GetSeqCount();
    unsigned *ColCounts = new unsigned[uInputColCount];

    unsigned uCoreAlignedColCount = 0;
    for (unsigned uCoreColIndex = 0; uCoreColIndex < uCoreColCount; ++uCoreColIndex)
        if (msaCore.IsAligned(uCoreColIndex))
            ++uCoreAlignedColCount;

    msaOutput.SetSize(uInputSeqCount, uCoreAlignedColCount);
    for (unsigned n = 0; n < uInputSeqCount; ++n)
        {
        const char *ptrSeqName = msaInput.GetSeqName(n);
        msaOutput.SetSeqName(n, ptrSeqName);
        }

    unsigned uOutputColIndex = 0;
    for (unsigned uCoreColIndex = 0; uCoreColIndex < uCoreColCount; ++uCoreColIndex)
        {
        if (!msaCore.IsAligned(uCoreColIndex))
            continue;
        memset(ColCounts, 0, uInputColCount*sizeof(unsigned));
        for (unsigned uCoreSeqIndex = 0; uCoreSeqIndex < uCoreSeqCount; ++uCoreSeqIndex)
            {
            if (msaCore.IsGap(uCoreSeqIndex, uCoreColIndex))
                continue;
            const unsigned uUngappedIndex = msaCore.GetUngappedColIndex(uCoreSeqIndex,
              uCoreColIndex);
            const char *ptrSeqName = msaCore.GetSeqName(uCoreSeqIndex);
            unsigned uInputSeqIndex;
            bool bFound = msaInput.GetSeqIndex(ptrSeqName, &uInputSeqIndex);
            if (!bFound)
                Quit("Seq not found '%s'", ptrSeqName);
            unsigned uInputColIndex = msaInput.GetGappedColIndex(uInputSeqIndex,
              uUngappedIndex);
            ColCounts[uInputColIndex] += 1;
            }
#if    VERBOSE
        List("Col %u ", uCoreColIndex);
        for (unsigned n = 0; n < uInputColCount; ++n)
            {
            if (ColCounts[n] > 0)
                List(" %u=%u", n, ColCounts[n]);
            }
        List("\n");
#endif

        unsigned uMaxCount = 0;
        unsigned uBestColIndex = 0;
        for (unsigned uInputColIndex = 0; uInputColIndex < uInputColCount; ++uInputColIndex)
            {
            if (ColCounts[uInputColIndex] > uMaxCount)
                {
                uMaxCount = ColCounts[uInputColIndex];
                uBestColIndex = uInputColIndex;
                }
            }
#if    VERBOSE
        List("Core col %u Best input col %u\n", uCoreColIndex, uBestColIndex);
#endif
        for (unsigned uInputSeqIndex = 0; uInputSeqIndex < uInputSeqCount; ++uInputSeqIndex)
            {
            char c = msaInput.GetChar(uInputSeqIndex, uBestColIndex);
            if (IsGap(c))
                c = '-';
            else
                c = toupper(c);
            msaOutput.SetChar(uInputSeqIndex, uOutputColIndex, c);
            }
        ++uOutputColIndex;
        }
    assert(uCoreAlignedColCount == uOutputColIndex);
    }
