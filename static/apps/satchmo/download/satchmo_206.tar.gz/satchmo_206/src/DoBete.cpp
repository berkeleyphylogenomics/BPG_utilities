// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Phylip.h"
#include "PhylipNode.h"
#include "TextFile.h"
#include "MSA.h"
#include "Clust.h"
#include "Bete.h"
#include "PWBase.h"
#include "PPPW.h"

#define    VERBOSE 0

void DoBete(const char *in, const char *out)
    {
    const char *colpair = GetOptionalParam("colpair", "RE");
    const char *join = GetOptionalParam("join", "nn");

    JOINSTYLE JoinStyle = JOINSTYLE_Undefined;
    if (!stricmp(join, "nn"))
        JoinStyle = JOINSTYLE_NearestNeighbor;
    else if (!stricmp(join, "nj"))
        JoinStyle = JOINSTYLE_NeighborJoining;
    else
        Quit("Invalid -join %s", join);

    TextFile fileIn(in);
    
    MSA msa;
    msa.FromFASTAFile(fileIn);
    msa.AlignByCase();

    PWBase *ptrPWScorer;
    PWSFactory(colpair, "simple", "LL", &ptrPWScorer);

    PPPW Dist(*ptrPWScorer);

    Bete Set;
    Set.Init(msa, Dist);
    Set.SetJoinStyle(JoinStyle);

    Clust C;
    C.Create(Set);

#if    VERBOSE
    C.ListMe();
#endif

    Phylip Tree;
    C.ToPhylip(Tree);

    TextFile fileOut(out, true);
    Tree.ToFile(fileOut);
    }
