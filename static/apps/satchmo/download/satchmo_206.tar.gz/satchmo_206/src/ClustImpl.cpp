// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
//#include "Clust.h"
//#include "ClustSet.h"
//#include <math.h>
//
//static double D[4][4];
//
//static void SetDist(int i, int j, double d)
//    {
//    D[i][j] = D[j][i] = d;
//    }
//
//class NJ : public ClustSet
//    {
//public:
//    virtual JOINSTYLE GetJoinStyle() { return JOINSTYLE_NeighborJoining; }
//    virtual CENTROIDSTYLE GetCentroidStyle() { return CENTROIDSTYLE_NeighborJoining; }
//    virtual bool IsRooted() { return false; }
//
//    virtual unsigned GetLeafCount();
//    virtual double ComputeDist(Clust &C, unsigned uNodeIndex1, unsigned uNodeIndex2);
//    };
//
//unsigned NJ::GetLeafCount()
//    {
//    return 4;
//    }
//
//double NJ::ComputeDist(Clust &C, unsigned uNodeIndex1, unsigned uNodeIndex2)
//    {
//    return D[uNodeIndex1][uNodeIndex2];
//    }
//
//void TestNJ()
//    {
//    SetListFileName("c:\\tmp\\lobster.log", false);
//
//    SetDist(0, 1, 0.1 + 0.1 + 0.4);
//    SetDist(0, 2, 0.1 + 0.4);
//    SetDist(0, 3, 0.4 + 0.4 + 0.1);
//    SetDist(1, 2, 0.1 + 0.1 + 0.1);
//    SetDist(1, 3, 0.1 + 0.4);
//    SetDist(2, 3, 0.1 + 0.1 + 0.4);
//
//    Clust C;
//    NJ Set;
//
//    C.Create(Set);
//
//    List("\n");
//    C.ListMe();
//    }
//
//class UPGMA : public ClustSet
//    {
//public:
//    virtual JOINSTYLE GetJoinStyle() { return JOINSTYLE_NearestNeighbor; }
//    virtual CENTROIDSTYLE GetCentroidStyle() { return CENTROIDSTYLE_AverageLinkage; }
//    virtual bool IsRooted() { return true; }
//
//    virtual unsigned GetLeafCount();
//    virtual double ComputeDist(Clust &C, unsigned uNodeIndex1, unsigned uNodeIndex2);
//    };
//
//static double U[5][5];
//
//unsigned UPGMA::GetLeafCount()
//    {
//    return 5;
//    }
//
//double UPGMA::ComputeDist(Clust &C, unsigned uNodeIndex1, unsigned uNodeIndex2)
//    {
//    return U[uNodeIndex1][uNodeIndex2];
//    }
//
//void PlanarToClustDist(const double x[], const double y[], unsigned N)
//    {
//    for (unsigned i = 0; i < N; ++i)
//        for (unsigned j = 0; j < i; ++j)
//        {
//        const double dx = x[i] - x[j];
//        const double dy = y[i] - y[j];
//        const double dDist = sqrt(dx*dx + dy*dy);
//        U[i][j] = U[j][i] = dDist;
//        }
//    }
//
//void TestUPGMA()
//    {
//    SetListFileName("c:\\tmp\\lobster.log", false);
//
//    static double x[] = { 2, 1, 2, 3, 1 };
//    static double y[] = { 0, 4, 4, 2, 1 };
//    static unsigned N = sizeof(x)/sizeof(x[0]);
//    assert(N == 5);
//
//    UPGMA U;
//    Clust C;
//
//    PlanarToClustDist(x, y, N);
//
//    List("\n");
//    C.Create(U);
//
//    List("\n");
//    C.ListMe();
//    }
