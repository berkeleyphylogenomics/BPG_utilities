// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"

#ifndef    WIN32
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>
#include <errno.h>

void chkmem()
    {
    //assert(_CrtCheckMemory());
    }

void Break()
    {
    //DebugBreak();
    }

static char szCmdLine[4096];

void *ptrStartBreak = sbrk(0);

const char *GetCmdLine()
    {
    return szCmdLine;
    }

double GetMemUseMB()
    {
    double  Bytes = (char *) sbrk(0) - (char *) ptrStartBreak;
    return Bytes/1000000;
    }

void SaveCmdLine(int argc, char *argv[])
    {
    for (int i = 0; i < argc; ++i)
        {
        if (i > 0)
            strcat(szCmdLine, " ");
        strcat(szCmdLine, argv[i]);
        }
    }

double dPeakMemUseMB = 0;

double GetPeakMemUseMB()
    {
    CheckMemUse();
    return dPeakMemUseMB;
    }

double GetCPUGHz()
    {
    double dGHz = 2.5;
    const char *e = getenv("CPUGHZ");
    if (0 != e)
        dGHz = atof(e);
    return dGHz;
    }

void CheckMemUse()
    {
    double dMB = GetMemUseMB();
    if (dMB > dPeakMemUseMB)
        dPeakMemUseMB = dMB;
    }

#endif    // !WIN32
