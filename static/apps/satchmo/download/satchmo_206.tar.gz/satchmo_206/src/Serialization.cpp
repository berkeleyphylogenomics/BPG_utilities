// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.
#ifdef PARALLEL

#include "lobster.h"
#include "MSA.h"
#include "HMM.h" 
#include "Serialization.h" 
#include  "string.h"

#include "TextFile.h"
const unsigned INSANE_NODE_COUNT = 99999;


/**************************       END StringBuffer     *****************************/
const char *Score2Str(SCORE Score)
    {
    if (MINUS_INFINITY >= Score)
        return "       *";
// Hack to use "circular" buffer so when called multiple
// times in a printf-like argument list it works OK.
    const int iBufferCount = 16;
    const int iBufferLength = 32;
    static char szStr[iBufferCount*iBufferLength];
    static int iBufferIndex = 0;
    iBufferIndex = (iBufferIndex + 1)%iBufferCount;
    char *pStr = szStr + iBufferIndex*iBufferLength;
    sprintf(pStr, "%f", Score);
    
    return pStr;
    }
SCORE Str2Score(const char *pszStr)
    {
    if (pszStr[0]=='*')
        return MINUS_INFINITY;
    else
        return (SCORE) atof(pszStr);
    }

static void PutScore(StringBuffer *File, SCORE Score)
    {
    if (MINUS_INFINITY == Score)
        File->PutString("        *");
    else
        File->PutFormat(" %s", Score2Str(Score));
    }

void HMM::Deserialize(char **from)
    {
    StringBuffer File;
    File.SetData(*from);
    
// begin import..
    Clear();

    char szToken[1024];

    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "SatchmoHMM"));
   
// Opening "{" 
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "{"));

// "length"
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "length"));
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(IsValidInteger(szToken));
    m_uNodeCount = (unsigned) atoi(szToken);
    assert(m_uNodeCount > 0 && m_uNodeCount < INSANE_NODE_COUNT);

    m_Nodes = new HMMNode[m_uNodeCount];

// "entry"
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "entry"));
    File.GetTokenXC(szToken, sizeof(szToken));
    m_scoreFirstM = Str2Score(szToken); 
    File.GetTokenXC(szToken, sizeof(szToken));
    m_scoreFirstD = Str2Score(szToken);

// "trans"
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "trans"));
    File.Skip();
    for (unsigned uNodeIndex = 0; uNodeIndex + 1 < m_uNodeCount; ++uNodeIndex)
        {
        HMMNode &Node = m_Nodes[uNodeIndex];
        for (unsigned i = 0; i < 10; ++i)
            {
            File.GetTokenXC(szToken, sizeof(szToken));
            SCORE n = Str2Score(szToken);
            switch (i)
                {
            case 0:    assert((unsigned) n == uNodeIndex); break;
            case 1:    Node.m_scoreMM = n; break;
            case 2:    Node.m_scoreMD = n; break;
            case 3:    Node.m_scoreMI = n; break;
            case 4:    Node.m_scoreDM = n; break;
            case 5:    Node.m_scoreDD = n; break;
            case 6:    Node.m_scoreDI = n; break;
            case 7:    Node.m_scoreIM = n; break;
            case 8:    Node.m_scoreID = n; break;
            case 9:    Node.m_scoreII = n; break;
            default: assert(false);
                }
            }
        }
    HMMNode &LastNode = m_Nodes[m_uNodeCount-1];
    LastNode.m_scoreMM = MINUS_INFINITY;
    LastNode.m_scoreMD = MINUS_INFINITY;
    LastNode.m_scoreMI = MINUS_INFINITY;
    LastNode.m_scoreDM = MINUS_INFINITY;
    LastNode.m_scoreDD = MINUS_INFINITY;
    LastNode.m_scoreDI = MINUS_INFINITY;
    LastNode.m_scoreIM = MINUS_INFINITY;
    LastNode.m_scoreID = MINUS_INFINITY;
    LastNode.m_scoreII = MINUS_INFINITY;

// "match"
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "match"));
    File.Skip();
    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        HMMNode &Node = m_Nodes[uNodeIndex];
        File.GetTokenXC(szToken, sizeof(szToken));
        assert(IsValidSignedInteger(szToken));
        unsigned n = (unsigned) atoi(szToken);
        assert(n == uNodeIndex);
        for (unsigned uLetter = 0; uLetter< MAX_ALPHA; ++uLetter)
            {
            File.GetTokenXC(szToken, sizeof(szToken));
            SCORE s = Str2Score(szToken);
            Node.m_scoreMatchEmit[uLetter] = s;
            }
        }


// "insert"
    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 == strcmp(szToken, "insert"))
        {
        File.Skip();
        for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
            {
            HMMNode &Node = m_Nodes[uNodeIndex];
            File.GetTokenXC(szToken, sizeof(szToken));
            assert(IsValidSignedInteger(szToken));
            unsigned n = (unsigned) atoi(szToken);
            assert(n == uNodeIndex);
            for (unsigned uLetter = 0; uLetter< MAX_ALPHA; ++uLetter)
                {
                File.GetTokenXC(szToken, sizeof(szToken));
                SCORE s = Str2Score(szToken);
                Node.m_scoreInsertEmit[uLetter] = s;
                }
            }
        File.GetTokenXC(szToken, sizeof(szToken));
        }
    else
        {
        for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
            {
            HMMNode &Node = m_Nodes[uNodeIndex];
            for (unsigned uLetter = 0; uLetter< MAX_ALPHA; ++uLetter)
                Node.m_scoreInsertEmit[uLetter] = 0;
            }
        }


// closing "}"
    assert(0 == strcmp(szToken, "}"));

    CalcStateEntries();
    AssertNormalized();  /*TODO: this is causing halt */
    
// end import ...
// Read MSA
 MSADeserialize(&m_ptrTemplate, &File, ALPHABET_Amino, false); 

}

    


/***********************************************************/

void HMM::Serialize(char **to, unsigned uGNodeIndex )
    {
    StringBuffer *File = new StringBuffer;
    
// begin import...
    const unsigned uNodeCount = GetNodeCount();
    File->PutString("SatchmoHMM\n");
    File->PutString("{\n");
    File->PutFormat("length %u\n", uNodeCount);
    File->PutFormat("entry %s %s\n",
      Score2Str(m_scoreFirstM),
      Score2Str(m_scoreFirstD));

    File->PutFormat("trans\n");
    File->PutFormat("%% Node       MM       MD       MI       DM       DD       DI       IM       ID       II\n");
    for (unsigned uNodeIndex = 0; uNodeIndex + 1 < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        File->PutFormat("%u", uNodeIndex);
        PutScore(File, Node.m_scoreMM);
        PutScore(File, Node.m_scoreMD);
        PutScore(File, Node.m_scoreMI);
        PutScore(File, Node.m_scoreDM);
        PutScore(File, Node.m_scoreDD);
        PutScore(File, Node.m_scoreDI);
        PutScore(File, Node.m_scoreIM);
        PutScore(File, Node.m_scoreID); 
        PutScore(File, Node.m_scoreII);
        File->PutString("\n");
        }

    File->PutString("match\n");
    File->PutString(
"% Node         A        C        D        E        F        G        H        I        K        L        "
             "M        N        P        Q        R        S        T        V        W        Y\n");

    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        File->PutFormat("  %u ", uNodeIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            PutScore(File, Node.m_scoreMatchEmit[uLetter]);
        File->PutString("\n");
        }

    File->PutString("insert\n");
    File->PutString(
"% Node         A        C        D        E        F        G        H        I        K        L        "
             "M        N        P        Q        R        S        T        V        W        Y\n");

    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        File->PutFormat("  %u ", uNodeIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA  ; ++uLetter)
            PutScore(File, Node.m_scoreInsertEmit[uLetter]);
        File->PutString("\n");
        }

    File->PutString("}\n                   ");
    
    
// end import..    

// WRITE MSA to string as well
MSASerialize(m_ptrTemplate, File, WWS_Never , uGNodeIndex);


// Write SATCHMO Params .. (opt)

File->Close();

//
//unsigned filesize = File->Tellp();
//fprintf(stderr, "\n%u", filesize);
//fprintf(stderr, "\n%u", strlen(File->GetData()));
char *danger = File->GetData();
//fprintf(stderr, danger);
// 

//*to  = strdup(File->GetData());
//*to  = (char *) malloc (filesize);
//strncpy( *to , danger, filesize);
*to = danger;
delete File;
File = 0;
}
    




/** ----------------------------- MSA Serialization -------------------------**/

static bool StripWeightFromName(char *strName, WEIGHT &w)
    {
    w = BTInsane;
    char *ptrLastBar = strrchr(strName, '|');
    if (0 == ptrLastBar)
        return false;
    if (0 != strncmp(ptrLastBar, "|weight=", 8))
        return false;
    w = (WEIGHT) atof(ptrLastBar+8);
    *ptrLastBar = 0;
    return true;
    } 

// bFirstOnly does first pass
void MSADeserialize( MSA **ptrMsa, StringBuffer *File,  ALPHABET Alpha, bool bFirstOnly)
    {
     *ptrMsa = new MSA;
     MSA *msa = *ptrMsa;

// begin import ...    
    msa->Clear();

// Arbitrary choice for longest allowed input line
    const unsigned MAX_FASTA_LINE = 16000;
    char szLine[MAX_FASTA_LINE+1];

// Make two passes through the file, one to determine the
// number of sequences and the length of the sequence so
// that we can allocate exactly the right amount of
// memory, the second pass to store the data.
    unsigned Pos = File->GetPos();

// First pass.
    unsigned uLettersPerLine;
    bool bLettersPerLineKnown = false;
    unsigned uSeqCount = 0;
    unsigned uColCount = 0;
    unsigned uCurrentSeqLength = 0;
    bool bAminoSeen = false;
    bool bGapSeen = false;
    for (;;)
        {
        bool bEOF = File->GetTrimLine(szLine, sizeof(szLine));
        if (bEOF ) //|| !strncmp(szLine, "//", 2))
            {
            if (uSeqCount > 1)
                {
    //            if (uColCount != uCurrentSeqLength)
                    //Quit("simple error");
//                    Quit("FASTA file %s, last sequence length=%d, others=%d",
//                      File.GetFileName(), uCurrentSeqLength, uColCount);
                }
            else
                uColCount = uCurrentSeqLength;
            break;
            }
        if ('>' == szLine[0])
            {
            if (uSeqCount > 1)
                {
                if (uColCount != uCurrentSeqLength)
                    Quit("simple error - name");
//                    Quit("FASTA file %s(%u), sequence %d is length=%d, others=%d",
//                      File.GetFileName(), File.GetLineNr(), uSeqCount,
//                      uCurrentSeqLength, uColCount);
                }
            else
                uColCount = uCurrentSeqLength;
            if (bFirstOnly && 1 == uSeqCount)
                goto SecondPass;
            ++uSeqCount;
            uCurrentSeqLength = 0;
            
            //skip gnodeindex line
            File->GetTrimLine(szLine, sizeof(szLine));
            } 
        else
            {
            if (!bAminoSeen)
                bAminoSeen = StrHasAmino(szLine);
            if (!bGapSeen)
                bGapSeen = StrHasGap(szLine);
            unsigned uLetterCount = (unsigned) strlen(szLine);
            if (bLettersPerLineKnown)
                {
                if (uLetterCount > uLettersPerLine)
                    Quit("simple error");
//                    Quit("FASTA file %s(%d), seq %d: Expecting <=%d letters, got %d",
//                      File.GetFileName(), File.GetLineNr(), uSeqCount,
//                      uLettersPerLine, uLetterCount);
                }
            else
                {
                uLettersPerLine = uLetterCount;
                bLettersPerLineKnown = true;
                }
            uCurrentSeqLength += uLetterCount;
            }
        }

    if (ALPHABET_AutoDetect == Alpha)
        {
        if (bAminoSeen)
            msa->m_Alphabet = ALPHABET_Amino;
        else
            msa->m_Alphabet = ALPHABET_Nucleic;
        }
    else
        msa->m_Alphabet = Alpha;

SecondPass:
    if (bFirstOnly && uSeqCount > 1)
        Quit("Bug in MSA::FromFASTAFile (bFirstOnly)");

    msa->SetSize(uSeqCount, uColCount);
    msa->m_uColCount = uColCount;

    File->SetPos(Pos);
    
    unsigned uLinesPerSeq = (uColCount - 1)/uLettersPerLine + 1;
    unsigned uSeqIndex;
    msa->m_bWeightsFoundInInputFile = false;
    //    msa->m_szSeqs = (char **)malloc (uSeqCount * sizeof(char *));
    for (uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        bool bEOF = File->GetTrimLine(szLine, sizeof(szLine));
        if (bEOF)
            Quit("simple error");
//            Quit("Unexpected EOF in FASTA file %s (first line of seq %d)",
//              File->GetFileName(), uSeqIndex);
        if ('>' != szLine[0])
            Quit("Expected annotation line");

        msa->m_szNames[uSeqIndex] = strdup(szLine+1); // dont' include the '>'
        if (0 == strlen(msa->m_szNames[uSeqIndex]))
            sprintf(msa->m_szNames[uSeqIndex], "[%d]", uSeqIndex);
        bool bFoundWeight = StripWeightFromName(msa->m_szNames[uSeqIndex],
          msa->m_Weights[uSeqIndex]);
        if (bFoundWeight)
            {
            if (uSeqIndex == 0)
                msa->m_bWeightsFoundInInputFile = true;
            else if (!msa->m_bWeightsFoundInInputFile)
                Quit("Missing weight");
            }
        else
            {
            if (msa->m_bWeightsFoundInInputFile)
                Quit("MIssing weight");
            }
        //store GNodeIndex
        File->GetTrimLine(szLine, sizeof(szLine));
        msa->m_uGNodeIndex = atoi(szLine);
        //msa->m_szSeqs[uSeqIndex] = (char *) malloc (uLinesPerSeq * uLettersPerLine * sizeof(char*));
        for (unsigned uLineIndex = 0; uLineIndex < uLinesPerSeq; ++uLineIndex)
            {
            char *pLineBase = msa->m_szSeqs[uSeqIndex] + uLineIndex*uLettersPerLine;
        // Add one to expected number of chars to
        // allow for nul byte to terminate string
            unsigned uCharCount;
            if (uLinesPerSeq - 1 == uLineIndex)
                uCharCount = (uColCount - 1)%uLettersPerLine + 2;
            else
                uCharCount = uLettersPerLine + 1;
            bEOF = File->GetTrimLine(pLineBase, uCharCount);

            if (bEOF)
                Quit("simple error");
//                Quit("Unexpected EOF in FASTA file %s, seq %d line %d",
//                  File->GetFileName(), uSeqIndex+1, uLineIndex+1);

//            if (uLinesPerSeq - 1 != uLineIndex &&
//              strlen(pLineBase) != uLettersPerLine)
//                  Quit("simple error");
//                Quit("FASTA line should be %d characters file %s seq %d line %d",
//                  uLettersPerLine, File->GetFileName(), uSeqIndex+1, uLineIndex+1);
            }
        }

    if (!bFirstOnly) 
        {
    // Should have eaten all lines in the File->..
        bool bEOF = File->GetTrimLine(szLine, sizeof(szLine));
//        if (!bEOF && 0 != strcmp("//", szLine)) 
//            Quit("simple error");
//            Quit("Expected EOF in FASTA file %s", File->GetFileName());
        }

//    for (uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
//        for (unsigned n = 0; n < msa->GetColCount(); ++n)
//            {
//            char c = msa->m_szSeqs[uSeqIndex][n];
//        // TODO: validate character!
//            msa->m_szSeqs[uSeqIndex][n] = c;
//            }

    if (msa->m_bWeightsFoundInInputFile && !bFirstOnly)
        {
        WEIGHT wTotal = 0;
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
            wTotal += msa->m_Weights[uSeqIndex];
        if (0 == wTotal)
            Quit("ScaleWeights: total = 0");

        double dFactor = 1.0 / wTotal;
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
            msa->m_Weights[uSeqIndex] = msa->m_Weights[uSeqIndex] / wTotal;

        msa->m_wcRawNIC = wTotal;
        msa->m_bRawNICSet = true;
        msa->m_bWeightsSet = true;
        }
        
        msa->AlignByCaseOrDash();
        msa->BuildPillars();
    }

void MSASerialize( MSA *msa, StringBuffer *File, WRITE_WEIGHT_STYLE WWS, unsigned uGNodeIndex) 
    {
    
//--- begin import...
    const unsigned uColCount = msa->GetColCount(); 
    assert(uColCount > 0);
    const unsigned uLettersPerLine = 69;
    const unsigned uLinesPerSeq = (msa->GetColCount() - 1)/uLettersPerLine + 1;
    const unsigned uSeqCount = msa->GetSeqCount();
    bool bWriteWeights;

    switch (WWS)
        {
    case WWS_Always:
        bWriteWeights = true;
        break;
    
    case WWS_Never:
        bWriteWeights = false;
        break;
    
    case WWS_IfFoundInInputFile:
        bWriteWeights = msa->m_bWeightsFoundInInputFile;
        }

    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        File->PutString(">");
        File->PutString(strtok((char *)msa->GetSeqName(uSeqIndex), " "));
        if (bWriteWeights)
            {
            WEIGHT w = msa->GetSeqWCount(uSeqIndex);
            if (w != BTInsane)
                File->PutFormat("|weight=%g", w);
            } 
        File->PutString("\n");
        
        // Write GNodeIndex
        if(uGNodeIndex!=uInsane)
          msa->m_uGNodeIndex = uGNodeIndex;
        else uGNodeIndex = msa->m_uGNodeIndex;

        File->PutFormat("%d", uGNodeIndex);
        File->PutString("\n");
        
        unsigned n = 0;
        for (unsigned uLine = 0; uLine < uLinesPerSeq; ++uLine)
            {
            unsigned uLetters = uColCount - uLine*uLettersPerLine;
            if (uLetters > uLettersPerLine)
                uLetters = uLettersPerLine;
            for (unsigned i = 0; i < uLetters; ++i)
                { 
                char c = msa->GetChar(uSeqIndex, n);
                File->PutChar(c);
                ++n;
                }
            File->PutString("\n");
            }
        File->PutString("\n");
        }
//        File->PutString("//\n");
        File->Flush();
//--- end import..
    }
#endif //end parallel
