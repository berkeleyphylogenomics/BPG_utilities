// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    HMM_h
#define    HMM_h

#define    INSERT_EMITS    1

class TextFile;
class MSA;
class HMMPath;
class Seq;
class SatchmoParams;
class SAMMod;

class NodeCounts
    {
public:
    void Clear()
        {
        m_wcMM = 0;
        m_wcMD = 0;
        m_wcMI = 0;
        m_wcDM = 0;
        m_wcDD = 0;
        m_wcDI = 0;
        m_wcIM = 0;
        m_wcID = 0;
        m_wcII = 0;
        m_wcResidues = 0;
        m_wcGaps = 0;
        memset(m_wcMatchEmit, 0, MAX_ALPHA*sizeof(WCOUNT));
        }
    WCOUNT m_wcMM;
    WCOUNT m_wcMD;
    WCOUNT m_wcMI;
    WCOUNT m_wcDM;
    WCOUNT m_wcDD;
    WCOUNT m_wcDI;
    WCOUNT m_wcIM;
    WCOUNT m_wcID;
    WCOUNT m_wcII;
    WCOUNT m_wcResidues;
    WCOUNT m_wcGaps;
    WCOUNT m_wcMatchEmit[MAX_ALPHA];
    };

class HMMNode
    {
public:
    SCORE m_scoreMM;
    SCORE m_scoreMD;
    SCORE m_scoreMI;
    SCORE m_scoreDM;
    SCORE m_scoreDD;
    SCORE m_scoreDI;
    SCORE m_scoreIM;
    SCORE m_scoreID;
    SCORE m_scoreII;
    SCORE m_scoreXM;
    SCORE m_scoreXD;
    SCORE m_scoreXI;
    SCORE m_scoreMatchEmit[MAX_ALPHA];
#if    INSERT_EMITS
    SCORE m_scoreInsertEmit[MAX_ALPHA];
#endif
    };

class HMM
    {
public:
    HMM();
    virtual ~HMM();

public:
    void Clear();
    MSA* GetMSA() {return m_ptrTemplate; }

    unsigned GetNodeCount() const { return m_uNodeCount; }
    const HMMNode &GetNode(unsigned uNodeIndex) const
        {
        assert(uNodeIndex < m_uNodeCount);
        return m_Nodes[uNodeIndex];
        }

    SCORE GetFirstM() const { return m_scoreFirstM; }
    SCORE GetFirstD() const { return m_scoreFirstD; }

// Serialization (saving to and restoring from a file)
    void FromFile(TextFile &File);
    void ToFile(TextFile &File) const;
    void MSSToFile(TextFile &File) const;
    void FromSAMMod(const SAMMod &Mod);
#ifdef PARALLEL
    void Serialize(char **to, unsigned uGNodeIndex = uInsane);
    void Deserialize(char **from);
#endif
// Construction from an alignment
    void FromAln( MSA &Aln);
    void FromAlnBitSave(MSA &Aln, double dBitsToSave, unsigned uMaxIter,
      double dMaxErrorPct);

// Dynamic programming algorithms
    SCORE FBAlign(const MSA &a, HMMPath &Route); // new
    SCORE ViterbiSeq(const Seq &s, MODEL_BOUNDS ModelBounds, SEQ_BOUNDS SeqBounds,
      HMMPath &Path) const;
    SCORE ViterbiAln(const MSA &a, HMMPath &Route);
    SCORE ViterbiAlnLL(const MSA &a, HMMPath &Route);
    SCORE ViterbiAln_v1(const MSA &a, HMMPath &Route);
    SCORE ForwardSeq(const Seq &s, SCORE **ptrptrDPM);
    SCORE BackwardSeq(const Seq &s, SCORE **ptrptrDPM);
    SCORE ForwardAln(const MSA &a, SCORE **ptrptrDPM);
    SCORE BackwardAln(const MSA &a, SCORE **ptrptrDPM);
    void PDAlign(const PROB *P_, unsigned uSeqLength, HMMPath &Path) const;

// Build combined alignment given a path
    void Align(const HMMPath &Path, MSA &msaCombined, const MSA &msaTarget) const;

// Debugging and trouble-shooting support
    void ListMe() const;
    void ListProbs() const;
    void ListRoute(const HMMPath &Route, const MSA &Aln) const;
    void ListNodeCounts(const NodeCounts &Counts) const;
    void AssertNormalized() const;

// Scoring
    SCORE ScoreSimpleNullSeq(const Seq &s) const;
    SCORE ScorePathSeq(const HMMPath &Path, const Seq &s) const;
    SCORE TransScorePath(const HMMPath &Path) const;
    SCORE ScoreRouteAln(const HMMPath &Route, const MSA &a) const;
    SCORE ScoreNTermSeq(const HMMPath &Path, const Seq &s) const;
    SCORE ScoreCTermSeq(const HMMPath &Path, const Seq &s) const;
    SCORE GetMatchEmitScore(unsigned uNodeIndex, char c) const;
    SCORE GetInsertEmitScore(unsigned uNodeIndex, char c) const;
    SCORE GetTransScore(unsigned uFromNodeIndex, char cFromState, char cToState) const;
    SCORE ScoreTerminalGap(unsigned uLength) const;

// Miscellaneous
    unsigned NodeIndexToTemplateColIndex(unsigned uNodeIndex) const;
    void RouteToPath(const HMMPath &Route, const MSA &Aln, unsigned uSeqIndex,
      HMMPath &Path) const;
    void SetSatchmoParams(SatchmoParams *SP) { m_ptrSP = SP; }
    void SetTemplate(MSA &msaTemplate) { m_ptrTemplate = &msaTemplate; }
    const MSA &GetTemplate() const { return *m_ptrTemplate; }
    double BitsSaved() const;
    void AddSimpleNull();
    void DeltaNullModelSelfLoop(SCORE scoreDelta);
    void SubtractSimpleNull();
    PROB GetSAMFirstMDProb() const { return m_probSAMFirstMD; }

    static bool IsEmitterState(char cState);

private:
    void NodeFromCounts(unsigned uNodeIndex, const NodeCounts &Counts);
    void ScaleNodeCounts(NodeCounts &Counts, double dFactor) const;
    double FromAlnBitSaveIter( MSA &Aln, double dCountScaleFactor);
    void CalcStateEntries();

    SCORE LegSM(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegSD(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegMM(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegMD(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegMI(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegDM(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegDD(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegDI(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegIM(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength,
      unsigned uFirstIPillar, char cPrevState) const;
    SCORE LegID(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength,
      unsigned uFirstIPillar, char cPrevState) const;
    SCORE LegII(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength,
      unsigned uFirstIPillar, char cPrevState) const;

    SCORE LegIMApprox(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegIDApprox(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegIIApprox(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const;

    SCORE LegSeqSM(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegSeqSD(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegSeqMM(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegSeqMD(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegSeqMI(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegSeqDM(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegSeqDD(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegSeqDI(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const;
    SCORE LegSeqIM(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength,
      unsigned uFirstIPillar, char cPrevState) const;
    SCORE LegSeqID(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength,
      unsigned uFirstIPillar, char cPrevState) const;
    SCORE LegSeqII(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength,
      unsigned uFirstIPillar, char cPrevState) const;

    SCORE EmitM(const MSA &Aln, unsigned uNodeIndex, unsigned uPillarIndex) const;
    SCORE EmitI(const MSA &Aln, unsigned uNodeIndex, unsigned uPillarIndex) const;
    
    SCORE EmitSeqM(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPillarIndex) const;

    SCORE ScorePathAlnSeq(const HMMPath &Path, const MSA &a, unsigned uSeqIndex) const;
    SCORE ScoreFromPaths(const HMMPath &Route, const MSA &a) const;
    SCORE TraceBackSeq(const Seq &s, const SCORE *DPM_, const SCORE *DPD_,
      const SCORE *DPI_, MODEL_BOUNDS ModelBounds, SEQ_BOUNDS SeqBounds,
      HMMPath &Path) const;
    SCORE TraceBackAln(const MSA &a, const SCORE *DPM_, const SCORE *DPD_,
      const SCORE *DPI_, const unsigned *DPN_, const char *DPS_, const char *DPTM_,
      const char *DPTD_, const char *DPTI_, HMMPath &Route) const;
    SCORE TraceBackAlnLL(const MSA &a, const SCORE *DPM_, const SCORE *DPD_,
      const SCORE *DPI_, const unsigned *DPN_, const char *DPS_, const char *DPTM_,
      const char *DPTD_, const char *DPTI_, HMMPath &Route) const;
    SCORE TraceBackAln_v1(const MSA &a, const SCORE *DPM_, const SCORE *DPD_,
      const SCORE *DPI_, const char *DPTM_, const char *DPTD_, const char *DPTI_,
      HMMPath &Route) const;
    void PDTraceBack(const PROB *P_, const PROB *DP_, unsigned uSeqLength,
      HMMPath &Path) const;

    void AppendInserts(const MSA &msaTarget, MSA &msaCombined,
      unsigned &uCombinedPos, unsigned &uTemplatePos, unsigned &uTargetPos,
      unsigned uTemplateCount, unsigned uTargetCount) const;
    void AppendMatch(const MSA &msaTarget, MSA &msaCombined,
      unsigned uNodeIndex, bool bAligned,  unsigned &uCombinedPos, unsigned &uTemplatePos,
      unsigned &uTargetPos, SCORE scoreEmit, SCORE scoreAvgAffinity) const;
    void AppendDelete(const MSA &msaTarget, MSA &msaCombined,
      unsigned uNodeIndex, bool bAligned, unsigned &uCombinedPos, unsigned &uTemplatePos,
      SCORE scoreAvgAffinity) const;
    void AddSimpleNullNode(HMMNode &Node);
    void SubtractSimpleNullNode(HMMNode &Node);
    void AssertNormalizedNode(unsigned uNodeIndex) const;
    
    

private:
    unsigned m_uNodeCount;
    SCORE m_scoreFirstM; 
    SCORE m_scoreFirstD;
    HMMNode *m_Nodes;
    MSA *m_ptrTemplate;
    const SatchmoParams *m_ptrSP;
    PROB m_probSAMFirstMD;
    };

#endif    // HMM_h
