// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "TextFile.h"

void DoVCompareMSA(const char *in, const char *ref)
    {
    TextFile fileTest(in);
    TextFile fileRef(ref);

    MSA msaTest;
    MSA msaRef;

    msaTest.FromFASTAFile(fileTest);
    msaRef.FromFASTAFile(fileRef);

    msaTest.AlignByCase();
    msaRef.AlignByCase();

    double dSP = dInsane;
    double dPS = dInsane;
    double dCS = dInsane;

    VerboseCompareMSA(msaTest, msaRef, &dSP, &dPS, &dCS);

    char szTestName[256];
    char szRefName[256];

    NameFromPath(in, szTestName, sizeof(szTestName));
    NameFromPath(ref, szRefName, sizeof(szRefName));

    List("Test=%s;Ref=%s;SP=%.3g;CS=%.3g;PS=%.3g\n",
        szTestName,
        szRefName,
        dSP,
        dCS,
        dPS);

    printf("Test=%s;Ref=%s;SP=%.3g;CS=%.3g;PS=%.3g\n",
        szTestName,
        szRefName,
        dSP,
        dCS,
        dPS);
    }
