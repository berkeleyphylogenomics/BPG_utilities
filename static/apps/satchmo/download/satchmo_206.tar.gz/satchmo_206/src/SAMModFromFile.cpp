// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "SAMMod.h"
#include "TextFile.h"

float atofloat(const char *s)
    {
    return (float) atof(s);
    }

void TestSAM(int argc, char *argv[])
    {
    TextFile File("c:\\public\\1edg.mod");
    SAMMod Mod;
    Mod.FromFile(File);

    Mod.Validate();

    TextFile Out("c:\\tmp\\out.mod", true);
    Mod.ToFile(Out);

    HMM Model;
    Model.FromSAMMod(Mod);

    TextFile Out2("c:\\tmp\\out.hmm", true);
    Model.ToFile(Out2);
    }

void SAMMod::FromFile(TextFile &File)
    {
    Clear();

    char szToken[1024];

// MODEL <anything> <end-of-line>
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == stricmp(szToken, "MODEL"));
    File.SkipLine();

// alphabet protein
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == stricmp(szToken, "alphabet"));

    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == stricmp(szToken, "protein"));

    SAMNode Node;
    unsigned uNodeIndex = 0;
    bool bLastNode = false;
    for (;;)
        {
        File.GetTokenXC(szToken, sizeof(szToken));
        if (0 == stricmp(szToken, "Begin"))
            assert(0 == uNodeIndex);
        else if (0 == stricmp(szToken, "FREQAVE"))
            {
        // Discard FREQAVE node
            NodeFromFile(File, Node);
            continue;
            }
        else if (0 == stricmp(szToken, "End"))
            bLastNode = true;
        else
            {
            unsigned u = (unsigned) atoi(szToken);
            assert(u == uNodeIndex);
            }
        NodeFromFile(File, Node);
        AddNode(Node);

        if (bLastNode)
            break;

        ++uNodeIndex;
        }
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == stricmp(szToken, "ENDMODEL"));
    Validate();
    }

void SAMMod::NodeFromFile(TextFile &File, SAMNode &Node)
    {
    char szToken[1024];
    float d;

    File.GetTokenXC(szToken, sizeof(szToken));
    d = atofloat(szToken);
    Node.m_probDD = d;

    File.GetTokenXC(szToken, sizeof(szToken));
    d = atofloat(szToken);
    Node.m_probMD = d;

    File.GetTokenXC(szToken, sizeof(szToken));
    d = atofloat(szToken);
    Node.m_probID = d;

    File.GetTokenXC(szToken, sizeof(szToken));
    d = atofloat(szToken);
    Node.m_probDM = d;

    File.GetTokenXC(szToken, sizeof(szToken));
    d = atofloat(szToken);
    Node.m_probMM = d;

    File.GetTokenXC(szToken, sizeof(szToken));
    d = atofloat(szToken);
    Node.m_probIM = d;

    File.GetTokenXC(szToken, sizeof(szToken));
    d = atofloat(szToken);
    Node.m_probDI = d;

    File.GetTokenXC(szToken, sizeof(szToken));
    d = atofloat(szToken);
    Node.m_probMI = d;

    File.GetTokenXC(szToken, sizeof(szToken));
    d = atofloat(szToken);
    Node.m_probII = d;

    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        {
        File.GetTokenXC(szToken, sizeof(szToken));
        d = atofloat(szToken);
        Node.m_probMatchEmit[uLetter] = d;
        }

    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        {
        File.GetTokenXC(szToken, sizeof(szToken));
        d = atofloat(szToken);
        Node.m_probInsertEmit[uLetter] = d;
        }
    }

void SAMMod::AddNode(const SAMNode &Node)
    {
    const unsigned uBlock = 1000;
    if (0 == m_uNodeCount%uBlock)
        {
        SAMNode *ptrNewNodes = new SAMNode[m_uNodeCount + uBlock];
        for (unsigned n = 0; n < m_uNodeCount; ++n)
            ptrNewNodes[n] = m_Nodes[n];
        delete[] m_Nodes;
        m_Nodes = ptrNewNodes;
        }
    m_Nodes[m_uNodeCount] = Node;
    ++m_uNodeCount;
    }
