// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "DataBuffer.h"
#include "Profile.h"
#include "MSA.h"
#include "Seq.h"
#include <list>

const int NAMESZ = 32;

struct POSPAIR
    {
    char szAName[NAMESZ];
    char szBName[NAMESZ];
    unsigned uAPos;
    unsigned uBPos;
    char cA;
    char cB;
    };

// A=1mhyD;APos=410;Ac=*;B=1cydA;BPos=61;Bc=*
enum FIELD_INDEX
    {
    FI_ANAME = 0,
    FI_APOS = 1,
    FI_AC = 2,
    FI_BNAME = 3,
    FI_BPOS = 4,
    FI_BC = 5
    };

static char szProfPath[256];
static Profile profMaster;
static unsigned uPosIndex;
static unsigned uPairCount;
typedef std::list<const Profile *> PBAG;
typedef std::list<const Profile *>::iterator PTR_PBAG;
static PBAG ProfBag;
static const Profile *ptrProfA;
static const Profile *ptrProfB;
static Seq seqA;
static Seq seqB;
static MSA msaA;
static MSA msaB;
static char szNameA[NAMESZ];
static char szNameB[NAMESZ];

static void ParseLine(const char szLine[], POSPAIR &PP)
    {
    char *str = strdup(szLine);
    char *Fields[6];
    char *FieldNames[6];
    int iFieldIndex = 0;
    FieldNames[0] = str;
    char c;
    for (char *p = str; c = *p; ++p)
        {
        if (';' == c)
            {
            *p = 0;
            ++iFieldIndex;
            if (iFieldIndex >= 6)
                Quit("Invalid pospair line %s", szLine);
            FieldNames[iFieldIndex] = p + 1;
            }
        else if ('=' == c)
            {
            *p = 0;
            Fields[iFieldIndex] = p + 1;
            }
        }
    if (iFieldIndex != 5)
        Quit("Expected 6 fields in pospair line %s", szLine);

    if (0 != stricmp(FieldNames[FI_ANAME], "A"))
        Quit("AName expected in pospair line %s", szLine);
    if (0 != stricmp(FieldNames[FI_BNAME], "B"))
        Quit("BName expected in pospair line %s", szLine);
    if (0 != stricmp(FieldNames[FI_APOS], "APos"))
        Quit("APos expected in pospair line %s", szLine);
    if (0 != stricmp(FieldNames[FI_BPOS], "BPos"))
        Quit("BPos expected in pospair line %s", szLine);
    if (0 != stricmp(FieldNames[FI_AC], "Ac"))
        Quit("Ac expected in pospair line %s", szLine);
    if (0 != stricmp(FieldNames[FI_BC], "Bc"))
        Quit("Bc expected in pospair line %s", szLine);

    if (strlen(Fields[FI_ANAME]) > sizeof(PP.szAName) - 1 ||
      strlen(Fields[FI_BNAME]) > sizeof(PP.szBName) - 1)
        Quit("Name too long in pospair line %s", szLine);
    if (strlen(Fields[FI_AC]) != 1 || strlen(Fields[FI_BC]) != 1)
        Quit("Ac and Bc must be exactly one character in pospair line %s", szLine);
    if (!IsValidInteger(Fields[FI_APOS]))
        Quit("Invalid APos in pospair line %s", szLine);
    if (!IsValidInteger(Fields[FI_BPOS]))
        Quit("Invalid BPos in pospair line %s", szLine);

    strcpy(PP.szAName, Fields[FI_ANAME]);
    strcpy(PP.szBName, Fields[FI_BNAME]);
    PP.uAPos = (unsigned) atoi(Fields[FI_APOS]);
    PP.uBPos = (unsigned) atoi(Fields[FI_BPOS]);
    PP.cA = Fields[FI_AC][0];
    PP.cB = Fields[FI_BC][0];
    free(str);
    }

static const Profile *GetProf(const char *strProfName)
    {
    Profile *ptrProf = new Profile;

    char szProfFileName[sizeof(szProfPath) + NAMESZ + 8];
    strcpy(szProfFileName, szProfPath);
    strcat(szProfFileName, "/");
    strcat(szProfFileName, strProfName);

    DataBuffer Data;
    Data.FromFile(szProfFileName);

    ptrProf->FromBuffer(Data, strProfName);
    ptrProf->SetName(strProfName);
    return ptrProf;
    }

static const Profile *FindProfile(const char *pstrName)
    {
    for (PTR_PBAG p = ProfBag.begin(); p != ProfBag.end(); ++p)
        {
        const Profile *ptrProf = *p;
        if (!stricmp(pstrName, ptrProf->GetName()))
            return ptrProf;
        }
    return 0;
    }

static void SetProfileA(const char *pstrNameA)
    {
    if (!stricmp(pstrNameA, szNameA))
        return;

    printf("\n%s", pstrNameA);
    ptrProfA = FindProfile(pstrNameA);
    if (0 == ptrProfA)
        {
        ptrProfA = GetProf(pstrNameA);
        ProfBag.push_back(ptrProfA);
        }
    ptrProfA->GetSeed(seqA);
    strcpy(szNameA, pstrNameA);
    msaA.FromSeq(seqA);
    msaA.AlignByCase();
//    msaA.BuildPillars();
    }

static void SetProfileB(const char *pstrNameB)
    {
    if (!stricmp(pstrNameB, szNameB))
        return;

    printf(" %s", pstrNameB);
    ptrProfB = FindProfile(pstrNameB);
    if (0 == ptrProfB)
        {
        ptrProfB = GetProf(pstrNameB);
        ProfBag.push_back(ptrProfB);
        }
    ptrProfB->GetSeed(seqB);
    strcpy(szNameB, pstrNameB);
    msaB.FromSeq(seqB);
    msaB.AlignByCase();
//    msaB.BuildPillars();
    }

static void DoPair(const POSPAIR &PP)
    {
    SetProfileA(PP.szAName);
    SetProfileB(PP.szBName);

    const unsigned uUngappedPosA = PP.uAPos;
    const unsigned uUngappedPosB = PP.uBPos;

    const unsigned uGappedPosA = msaA.GetGappedColIndex(0, uUngappedPosA);
    const unsigned uGappedPosB = msaB.GetGappedColIndex(0, uUngappedPosB);

    char cA = msaA.GetChar(0, uGappedPosA);
    char cB = msaB.GetChar(0, uGappedPosB);

    if (PP.cA != '*' && PP.cB != '*')
        if (cA != PP.cA || cB != PP.cB)
            List("*** WARNING *** Mismatch ");

    const unsigned uProfPosIndexA = ptrProfA->SeedColIndexToPosIndex(uGappedPosA);
    const unsigned uProfPosIndexB = ptrProfB->SeedColIndexToPosIndex(uGappedPosB);

    const ProfPos &PPA = ptrProfA->GetPos(uProfPosIndexA);
    const ProfPos &PPB = ptrProfB->GetPos(uProfPosIndexB);

    profMaster.SetPos(PPA, uPosIndex++);
    profMaster.SetPos(PPB, uPosIndex++);
    }

void DoMakeMasterProf(const char *in, const char *n, const char *profpath,
  const char *master)
    {
    TextFile fileIn(in);

    if (strlen(profpath) + 1 > sizeof(szProfPath))
        Quit("profpath too long");
    strcpy(szProfPath, profpath);
    uPairCount = (unsigned) atoi(n);
    profMaster.SetSize(uPairCount*2, 1);
    profMaster.SetName(in);

    for (unsigned uPairIndex = 0; uPairIndex < uPairCount; ++uPairIndex)
        {
        char szLine[256];
        bool bEOF = fileIn.GetLine(szLine, sizeof(szLine));
        if (bEOF)
            Quit("Unexpected EOF in pair file");

        POSPAIR PP;
        ParseLine(szLine, PP);
        DoPair(PP);
        }

    DataBuffer Data;
    profMaster.ToBuffer(Data);

    Data.ToFile(master);
    }
