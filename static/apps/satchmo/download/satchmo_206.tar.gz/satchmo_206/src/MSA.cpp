// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "TextFile.h"
#include "Seq.h"
#include "HMM.h"
#include <math.h>

const unsigned DEFAULT_SEQ_LENGTH = 500;

MSA::MSA()
    {
    m_Alphabet = ALPHABET_Unknown;

    m_uSeqCount = 0;
    m_uColCount = 0;
    m_uPillarCount = 0;

    m_szSeqs = 0;
    m_szNames = 0;
    m_Weights = 0;
    m_ColInfo = 0;
    m_Pillars = 0;
    m_AlignedColToPillar = 0;
    m_UngapMap = 0;

    m_bWeightsSet = false;
    m_bRawNICSet = false;
    m_bEffectiveNICSet = false;

    m_wcRawNIC = wcInsane;
    m_wcEffectiveNIC = wcInsane;

    m_bWeightsFoundInInputFile = false;
    }

MSA::~MSA()
    {
    Free();
    }

void MSA::Free()
    {
    FreePillars();
    FreeUngapMap();

    for (unsigned n = 0; n < m_uSeqCount; ++n)
        {
        delete[] m_szSeqs[n];
        free(m_szNames[n]);
        }

    delete[] m_szSeqs;
    delete[] m_szNames;
    delete[] m_ColInfo;
    delete[] m_Weights;

    m_uSeqCount = 0;
    m_uColCount = 0;

    m_szSeqs = 0;
    m_szNames = 0;
    m_Weights = 0;
    m_ColInfo = 0;
    }

void MSA::FreePillars()
    {
    delete[] m_Pillars;
    delete[] m_AlignedColToPillar;
    m_Pillars = 0;
    m_uPillarCount = 0;
    m_AlignedColToPillar = 0;
    }

void MSA::SetSize(unsigned uSeqCount, unsigned uColCount)
    {
    if (0 == uSeqCount || 0 == uColCount)
        Quit("MSA::Alloc(%u,%u)", uSeqCount, uColCount);

    Free();
    m_szSeqs = new char *[uSeqCount];
    m_szNames = new char *[uSeqCount];
    m_Weights = new WEIGHT[uSeqCount];
    m_ColInfo = new COLINFO[uColCount];
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        m_szSeqs[uSeqIndex] = new char[uColCount+1];
        m_szNames[uSeqIndex] = 0;
        m_Weights[uSeqIndex] = BTInsane;
        memset(m_szSeqs[uSeqIndex], '?', uColCount);
        m_szSeqs[uSeqIndex][uColCount] = 0;
        }
    m_uSeqCount = uSeqCount;
    m_uCacheSeqLength = uColCount;
    m_uColCount = 0;
    }

void MSA::ListMe() const
    {
    if (0 == GetColCount())
        {
        List("MSA empty\n");
        return;
        }

    const unsigned uColsPerLine = 50;
    unsigned uLinesPerSeq = (GetColCount() - 1)/uColsPerLine + 1;
    for (unsigned n = 0; n < uLinesPerSeq; ++n)
        {
        unsigned i;
        unsigned iStart = n*uColsPerLine;
        unsigned iEnd = GetColCount();
        if (iEnd - iStart + 1 > uColsPerLine)
            iEnd = iStart + uColsPerLine;
        List("                       ");
        for (i = iStart; i < iEnd; ++i)
            List("%u", i%10);
        List("\n");
        List("                       ");
        for (i = iStart; i + 9 < iEnd; i += 10)
            List("%-10u", i);
        if (n == uLinesPerSeq - 1)
            List(" %-10u", GetColCount());
        List("\n");
        for (unsigned uSeqIndex = 0; uSeqIndex < m_uSeqCount; ++uSeqIndex)
            {
            List("%20.20s   ", m_szNames[uSeqIndex]);
            for (i = iStart; i < iEnd; ++i)
                List("%c", GetChar(uSeqIndex, i));
            List("\n");
            }
        List("\n\n");
        }
    }

char MSA::GetChar(unsigned uSeqIndex, unsigned uIndex) const
    {
// TODO: Performance cost?
    if (uSeqIndex >= m_uSeqCount || uIndex >= m_uColCount)
        Quit("MSA::GetLetter(%u,%u)", uSeqIndex, uIndex);

    char c = m_szSeqs[uSeqIndex][uIndex];
//    assert(IsLegalChar(c));
    return c;
    } 

unsigned MSA::GetLetter(unsigned uSeqIndex, unsigned uIndex) const
    {
// TODO: Performance cost?
    char c = GetChar(uSeqIndex, uIndex);
    unsigned uLetter = CharToLetter(c);
    assert(IsLegalLetter(uLetter));
    return uLetter;
    }

void MSA::SetSeqName(unsigned uSeqIndex, const char szName[])
    {
      //      printf ("set sequence name %s \n", szName);
    if (uSeqIndex >= m_uSeqCount)
        Quit("MSA::SetSeqName(%u, %s), count=%u", uSeqIndex, m_uSeqCount);
    free(m_szNames[uSeqIndex]);
    m_szNames[uSeqIndex] = strdup(szName);
    }

const char *MSA::GetSeqName(unsigned uSeqIndex) const
    {
    if (uSeqIndex >= m_uSeqCount)
        Quit("MSA::GetSeqName(%u), count=%u", uSeqIndex, m_uSeqCount);
    if ('>' == m_szNames[uSeqIndex][0])
        return &m_szNames[uSeqIndex][1];
    return m_szNames[uSeqIndex];
    }

void MSA::GetLetterCounts(unsigned uColIndex, WCOUNT wCounts[]) const
    {
//#pragma message("TODO: weights")
    assert(false);
    return;
    unsigned uAlphaSize = ::GetAlphabetSize(m_Alphabet);
    memset(wCounts, 0, uAlphaSize*sizeof(WCOUNT));

    for (unsigned uSeqIndex = 0; uSeqIndex < GetSeqCount(); ++uSeqIndex)
        {
        unsigned uLetter = GetLetter(uSeqIndex, uColIndex);
        ++wCounts[uLetter];
        }
    }

bool MSA::IsGap(unsigned uSeqIndex, unsigned uIndex) const
    {
    char c = GetChar(uSeqIndex, uIndex);
    return ::IsGap(c);
    }

bool MSA::IsWildcard(unsigned uSeqIndex, unsigned uIndex) const
    {
    char c = GetChar(uSeqIndex, uIndex);
    return ::IsWildcard(c);
    }

void MSA::SetChar(unsigned uSeqIndex, unsigned uIndex, char c)
    {
    if (uSeqIndex >= m_uSeqCount || uIndex > m_uCacheSeqLength)
        Quit("MSA::SetChar(%u,%u)", uSeqIndex, uIndex);

    if (uIndex == m_uCacheSeqLength)
        {
        const unsigned uNewCacheSeqLength = m_uCacheSeqLength + DEFAULT_SEQ_LENGTH;
        for (unsigned n = 0; n < m_uSeqCount; ++n)
            {
            char *ptrNewSeq = new char[uNewCacheSeqLength+1];
            memcpy(ptrNewSeq, m_szSeqs[n], m_uCacheSeqLength);
            memset(ptrNewSeq + m_uCacheSeqLength, '?', DEFAULT_SEQ_LENGTH);
            ptrNewSeq[uNewCacheSeqLength] = 0;
            delete[] m_szSeqs[n];
            m_szSeqs[n] = ptrNewSeq;
            }

        COLINFO *ptrNewColSource = new COLINFO[uNewCacheSeqLength+1];
        memcpy(ptrNewColSource, m_ColInfo, m_uCacheSeqLength*sizeof(COLINFO));
        delete[] m_ColInfo;
        m_ColInfo = ptrNewColSource;

        m_uColCount = uIndex;
        m_uCacheSeqLength = uNewCacheSeqLength;
        }

    if (uIndex >= m_uColCount)
        m_uColCount = uIndex + 1;
    m_szSeqs[uSeqIndex][uIndex] = c;
    }

void MSA::ExtractUnaligned(unsigned uSeqIndex, MSA &a) const
    {
    unsigned n;
    unsigned uSeqLengthWithGaps = GetColCount();
    unsigned uSeqLengthNoGaps = 0;
    for (n = 0; n < uSeqLengthWithGaps; ++n)
        if (!IsGap(uSeqIndex, n))
            ++uSeqLengthNoGaps;

    a.SetSize(1, uSeqLengthNoGaps);
    unsigned uPos = 0;
    for (n = 0; n < uSeqLengthWithGaps; ++n)
        {
        if (!IsGap(uSeqIndex, n))
            {
            char c = GetChar(uSeqIndex, n);
            assert(isalpha(c));
            c = toupper(c);
            a.SetChar(0, uPos, c);
            ++uPos;
            }
        }
    assert(uPos == uSeqLengthNoGaps);
    a.SetSeqName(0, GetSeqName(uSeqIndex));
    a.SetAlphabet(GetAlphabet());
    }

void MSA::GetSeq(unsigned uSeqIndex, Seq &seq) const
    {
    assert(uSeqIndex < m_uSeqCount);

    seq.Clear();

    for (unsigned n = 0; n < m_uColCount; ++n)
        if (!IsGap(uSeqIndex, n))
            {
            char c = GetChar(uSeqIndex, n);
            assert(isalpha(c));
            c = toupper(c);
            seq.push_back(c);
            }
    const char *ptrName = GetSeqName(uSeqIndex);
    seq.SetName(ptrName);
    }

void MSA::GetAlignedSeq(unsigned uSeqIndex, Seq &seq) const
    {
    assert(uSeqIndex < m_uSeqCount);

    seq.Clear();

    for (unsigned n = 0; n < m_uColCount; ++n)
        {
        char c = GetChar(uSeqIndex, n);
        seq.push_back(c);
        }
    const char *ptrName = GetSeqName(uSeqIndex);
    seq.SetName(ptrName);
    }

bool MSA::HasGap() const
    {
    for (unsigned uSeqIndex = 0; uSeqIndex < GetSeqCount(); ++uSeqIndex)
        for (unsigned n = 0; n < GetColCount(); ++n)
            if (IsGap(uSeqIndex, n))
                return true;
    return false;
    }

bool MSA::IsLegalChar(char c) const
    {
    if (::IsGap(c))
        return true;

    unsigned uLetter = CharToLetter(c);
    return uLetter < GetAlphabetSize();
    }

bool MSA::IsLegalLetter(unsigned uLetter) const
    {
    return uLetter < GetAlphabetSize();
    }

void MSA::SetSeqCount(unsigned uSeqCount)
    {
    Free();
    SetSize(uSeqCount, DEFAULT_SEQ_LENGTH);
    }

// Assuming convention that upper case means aligned,
// check that the entire column is upper case.
bool MSA::IsAligned(unsigned uColIndex) const
    {
    if (0 == m_ColInfo)
        return IsAlignedByCase(uColIndex);
    const COLINFO &CI = GetColInfo(uColIndex);
    return CI.m_bAligned;
    }

// Delete all columns that are not aligned.
void MSA::Crop()
    {
    unsigned uToCol = 0;
    for (unsigned uFromCol = 0; uFromCol < GetColCount(); ++uFromCol)
        {
        if (IsAligned(uFromCol))
            {
            CopyCol(uFromCol, uToCol);
            ++uToCol;
            }
        }
    assert(uToCol <= m_uColCount);
    m_uColCount = uToCol;
    }

void MSA::CopyCol(unsigned uFromCol, unsigned uToCol)
    {
    assert(uFromCol < GetColCount());
    assert(uToCol < GetColCount());
    if (uFromCol == uToCol)
        return;

    for (unsigned uSeqIndex = 0; uSeqIndex < GetSeqCount(); ++uSeqIndex)
        {
        const char c = GetChar(uSeqIndex, uFromCol);
        SetChar(uSeqIndex, uToCol, c);
        }
    }

bool MSA::IsMatchColumn(unsigned uColIndex, BUILD_METHOD BuildMethod,
  double dGapFraction) const
    {
    switch (BuildMethod)
        {
    case BUILD_METHOD_Krogh:
        return IsMatchColumnKrogh(uColIndex, dGapFraction);

    case BUILD_METHOD_Sjolander:
        return IsMatchColumnSjolander(uColIndex);
        }
    assert(false);
    return false;
    }

bool MSA::IsInsertColumnSjolander(unsigned uColIndex) const
    {
    return !IsMatchColumnSjolander(uColIndex) || !IsDeleteColumn(uColIndex);
    }

// "Krogh heuristics".
// A column is assigned to a match state unless fraction of
// positions containing gaps is more more than dGapFraction.
bool MSA::IsMatchColumnKrogh(unsigned uColumnIndex, double dGapFraction) const
    {
    assert(uColumnIndex < GetColCount());
    unsigned uSeqCount = GetSeqCount();
    assert(uSeqCount > 0);
    unsigned uGapCount = 0;
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        if (IsGap(uSeqIndex, uColumnIndex))
            ++uGapCount;
    
    double dFraction = (double) uGapCount / (double) uSeqCount;
    return dFraction <= dGapFraction;
    }

// "Sjolander heuristics".
// A column is assigned to a match state iff all positions are
// upper-case letters or deletes (dashes). Exception: if all
// positions are deletes, is not a match.
bool MSA::IsMatchColumnSjolander(unsigned uColumnIndex) const
    {
    assert(uColumnIndex < GetColCount());
    unsigned uSeqCount = GetSeqCount();
    assert(uSeqCount > 0);
    unsigned uUpperCaseCount = 0;
    bool bAllDeletes = true;
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        char c = GetChar(uSeqIndex, uColumnIndex);
        if (isupper(c))
            {
            bAllDeletes = false;
            continue;
            }
        if ('-' == c)
            continue;
        return false;
        }
    return !bAllDeletes;
    }

// A column is assigned to an insert state if it's not a
// match state. Here "insert state" includes the prefix
// inserter N and suffix inserter C as well as the I state
// in a node.
bool MSA::IsInsertColumn(unsigned uColumnIndex, BUILD_METHOD BuildMethod,
  double dGapFraction) const
    {
    return !IsMatchColumn(uColumnIndex, BuildMethod, dGapFraction) &&
      !IsDeleteColumn(uColumnIndex);
    }

// Delete column iff all positions contain '-'
bool MSA::IsDeleteColumn(unsigned uColIndex) const
    {
    assert(GetSeqCount() > 0);
    for (unsigned n = 0; n < GetSeqCount(); ++n)
        if ('-' != GetChar(n, uColIndex))
            return false;
    return true;
    }

void MSA::Copy(const MSA &msa)
    {
    Free();
    const unsigned uSeqCount = msa.GetSeqCount();
    const unsigned uColCount = msa.GetColCount();
    SetSize(uSeqCount, uColCount);

    m_Alphabet = msa.GetAlphabet();
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        m_ColInfo[uColIndex] = msa.GetColInfo(uColIndex);

    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        m_szNames[uSeqIndex] = strdup(msa.GetSeqName(uSeqIndex));
        for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
            {
            const char c = msa.GetChar(uSeqIndex, uColIndex);
            SetChar(uSeqIndex, uColIndex, c);
            }
        }
    }

bool MSA::IsGapColumn(unsigned uColIndex) const
    {
    assert(GetSeqCount() > 0);
    for (unsigned uSeqIndex = 0; uSeqIndex < GetSeqCount(); ++uSeqIndex)
        if (!IsGap(uSeqIndex, uColIndex))
            return false;
    return true;
    }

//void MSA::SetColSourceEdge(unsigned uColIndex, unsigned uEdgeIndex)
//    {
//    assert(uColIndex < GetColCount());
//    m_ColInfo[uColIndex].m_Type = CSTYPE_Edge;
//    m_ColInfo[uColIndex].m_uEdgeIndex = uEdgeIndex;
//    }
//
//void MSA::SetColSourceTemplate(unsigned uColIndex, unsigned uTemplateColIndex)
//    {
//    assert(uColIndex < GetColCount());
//    m_ColInfo[uColIndex].m_Type = CSTYPE_Template;
//    m_ColInfo[uColIndex].m_uTemplateColIndex = uTemplateColIndex;
//    }

void MSA::SetColInfo(unsigned uColIndex, const COLINFO &CI)
    {
    assert(uColIndex < GetColCount());
    m_ColInfo[uColIndex] = CI;
    }

const COLINFO &MSA::GetColInfo(unsigned uColIndex) const
    {
    assert(uColIndex < GetColCount());
    return m_ColInfo[uColIndex];
    }

unsigned MSA::GetUngappedColIndex(unsigned uSeqIndex, unsigned uColIndex) const
    {
    const unsigned uSeqCount = GetSeqCount();
    const unsigned uColCount = GetColCount();

    assert(uSeqIndex < uSeqCount);
    assert(uColIndex < uColCount);

    if (0 == m_UngapMap)
        {
        m_UngapMap = new unsigned *[uSeqCount];
        memset(m_UngapMap, 0, uSeqCount*sizeof(unsigned *));
        }

    unsigned *ptrMap = m_UngapMap[uSeqIndex];
    if (0 == ptrMap)
        {
        ptrMap = new unsigned[uColCount];
        memset(ptrMap, 0, uColCount*sizeof(unsigned));
        unsigned uUngappedColIndex = 0;
        for (unsigned uGappedColIndex = 0; uGappedColIndex < uColCount;
          ++uGappedColIndex)
            if (IsGap(uSeqIndex, uGappedColIndex))
                ptrMap[uGappedColIndex] = uInsane;
            else
                {
                ptrMap[uGappedColIndex] = uUngappedColIndex;
                ++uUngappedColIndex;
                }
        m_UngapMap[uSeqIndex] = ptrMap;
        }
    unsigned uUngappedColIndex = ptrMap[uColIndex];
    if (uInsane == uUngappedColIndex)
        Quit("GetUngappedColIndex(%u,%u)", uSeqIndex, uUngappedColIndex);
    return uUngappedColIndex;
    }

bool MSA::GetSeqIndex(const char *ptrSeqName, unsigned *ptruSeqIndex) const
    {
    for (unsigned uSeqIndex = 0; uSeqIndex < GetSeqCount(); ++uSeqIndex)
        if (0 == stricmp(ptrSeqName, GetSeqName(uSeqIndex)))
            {
            *ptruSeqIndex = uSeqIndex;
            return true;
            }
    return false;
    }

char MSA::GetUngappedChar(unsigned uSeqIndex, unsigned uUngappedColIndex) const
    {
    return GetChar(uSeqIndex, GetGappedColIndex(uSeqIndex, uUngappedColIndex));
    }

unsigned MSA::GetGappedColIndex(unsigned uSeqIndex, unsigned uUngappedColIndex) const
    {
    unsigned n = 0;
    for (unsigned uColIndex = 0; uColIndex < GetColCount(); ++uColIndex)
        {
        if (!IsGap(uSeqIndex, uColIndex))
            {
            if (n == uUngappedColIndex)
                {
                assert(GetUngappedColIndex(uSeqIndex, uColIndex) == uUngappedColIndex);
                return uColIndex;
                }
            ++n;
            }
        }
    assert(false);
    return 0;
    }

void MSA::ColInfoToFile(TextFile &File)
    {
    for (unsigned uColIndex = 0; uColIndex < GetColCount(); ++uColIndex)
        {
        const COLINFO &CI = GetColInfo(uColIndex);
        File.PutFormat("%u %d %d %d %d %s %s\n",
          uColIndex,
          (int) CI.m_bAligned,
          CI.m_iNodeIndex,
          CI.m_iTemplateColIndex,
          CI.m_iTargetColIndex,
          ScoreToStr(CI.m_scoreEmit),
          ScoreToStr(CI.m_scoreAvgAffinity));
        }
    File.PutString("//\n");
    }

void MSA::ColInfoFromFile(TextFile &File)
    {
    char szToken[16];
    for (unsigned uColIndex = 0; ; ++uColIndex)
        {
    // Col index stored as sanity check
        File.GetTokenX(szToken, sizeof(szToken));
        if (0 == strcmp(szToken, "//"))
            {
            assert(GetColCount() == uColIndex);
            return;
            }

        assert(IsValidInteger(szToken));
        assert(atoi(szToken) == (int) uColIndex);

        COLINFO CI;
        File.GetTokenX(szToken, sizeof(szToken));
        CI.m_bAligned = (0 != atoi(szToken));

        File.GetTokenX(szToken, sizeof(szToken));
        CI.m_iNodeIndex = atoi(szToken);

        File.GetTokenX(szToken, sizeof(szToken));
        CI.m_iTemplateColIndex = atoi(szToken);

        File.GetTokenX(szToken, sizeof(szToken));
        CI.m_iTargetColIndex = atoi(szToken);

        File.GetTokenX(szToken, sizeof(szToken));
        CI.m_scoreEmit = (SCORE) atof(szToken);

        File.GetTokenX(szToken, sizeof(szToken));
        CI.m_scoreAvgAffinity = (SCORE) atof(szToken);

        SetColInfo(uColIndex, CI);
        }
    }

void MSA::DeleteCol(unsigned uColIndex)
    {
    assert(uColIndex < m_uColCount);
    size_t n = m_uColCount - uColIndex;
    if (n > 0)
        {
        for (unsigned uSeqIndex = 0; uSeqIndex < GetSeqCount(); ++uSeqIndex)
            {
            char *ptrSeq = m_szSeqs[uSeqIndex];
            memmove(ptrSeq + uColIndex, ptrSeq + uColIndex + 1, n);
            }
        }
    --m_uColCount;
    }

bool MSA::IsAllDots(unsigned uColIndex)
    {
    assert(uColIndex < m_uColCount);
    for (unsigned uSeqIndex = 0; uSeqIndex < GetSeqCount(); ++uSeqIndex)
        {
        char c = GetChar(uSeqIndex, uColIndex);
        if ('.' != c)
            return false;
        }
    return true;
    }

void MSA::ListColInfo() const
    {
    for (unsigned uSeqIndex = 0; uSeqIndex < GetSeqCount(); ++uSeqIndex)
        List(" ");
    List("  Col   Aln   Tpl   Tgt  Node      Emit    AvgAff\n");
//         1234  1234  1234  1234  1234  12345678  12345678
    for (unsigned n = 0; n < m_uColCount; ++n)
        {
        for (unsigned uSeqIndex = 0; uSeqIndex < GetSeqCount(); ++uSeqIndex)
            List("%c", m_szSeqs[uSeqIndex][n]);

        const COLINFO &CI = GetColInfo(n);
        List(" %4u     %c  %4d  %4d  %4d  %8d  %8d\n",
          n,
          CI.m_bAligned ? 'y' : 'n',
          CI.m_iTemplateColIndex,
          CI.m_iTargetColIndex,
          CI.m_iNodeIndex,
          CI.m_scoreEmit,
          CI.m_scoreAvgAffinity);
        }
    }

void MSA::SetAllAligned()
    {
    unsigned uColCount = GetColCount();
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        COLINFO CI;
        CI.m_bAligned = true;
        CI.m_iNodeIndex = -1;
        CI.m_iTargetColIndex = -1;
        CI.m_scoreAvgAffinity = MINUS_INFINITY;
        CI.m_scoreEmit = MINUS_INFINITY;
        SetColInfo(uColIndex, CI);
        }
    }

void MSA::AlignByCase()
    {
    m_uAlignedColCount = 0;
    unsigned uColCount = GetColCount();
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        const COLINFO &CI = GetColInfo(uColIndex);
        COLINFO CI2 = CI;
        bool bIsAligned = IsAlignedByCase(uColIndex);
        CI2.m_bAligned = bIsAligned;
        if (bIsAligned)
            ++m_uAlignedColCount;
        SetColInfo(uColIndex, CI2);
        }
    }

void MSA::AlignByCaseOrDash()
    {
    m_uAlignedColCount = 0;
    unsigned uColCount = GetColCount();
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        const COLINFO &CI = GetColInfo(uColIndex);
        COLINFO CI2 = CI;
        bool bIsAligned = IsAlignedByCaseOrDash(uColIndex);
        CI2.m_bAligned = bIsAligned;
        if (bIsAligned)
            ++m_uAlignedColCount;
        SetColInfo(uColIndex, CI2);
        }
    }

void MSA::AlignByGapPct(unsigned uGapPct)
    {
    m_uAlignedColCount = 0;
    unsigned uColCount = GetColCount();
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        const COLINFO &CI = GetColInfo(uColIndex);
        COLINFO CI2 = CI;
        bool bIsAligned = IsAlignedByGapPct(uColIndex, uGapPct);
        CI2.m_bAligned = bIsAligned;
        if (bIsAligned)
            ++m_uAlignedColCount;
        SetColInfo(uColIndex, CI2);
        }
    }

void MSA::TrimUnalignedTerminals()
    {
    assert(0 != m_ColInfo);

    unsigned uFirstAlignedColumn = m_uColCount + 1;
    unsigned uLastAlignedColumn = 0;
    for (unsigned uColIndex = 0; uColIndex < m_uColCount; ++uColIndex)
        {
        const COLINFO &CO = GetColInfo(uColIndex);
        if (CO.m_bAligned)
            {
            uFirstAlignedColumn = uColIndex;
            break;
            }
        }
    if (uFirstAlignedColumn = m_uColCount + 1)
        {
        m_uColCount = 0;
        return;
        }

    for (unsigned uColIndex = m_uColCount - 1; uColIndex >= 0; --uColIndex)
        {
        const COLINFO &CO = GetColInfo(uColIndex);
        if (CO.m_bAligned)
            {
            uLastAlignedColumn = uColIndex;
            break;
            }
        assert(uColIndex != 0);
        }

// Warning -- must delete end first, otherwise column indexes change!
    DeleteColumns(uLastAlignedColumn + 1, m_uColCount - uLastAlignedColumn - 1);
    DeleteColumns(0, uFirstAlignedColumn);
    }

void MSA::DeleteColumns(unsigned uColIndex, unsigned uColCount)
    {
    for (unsigned n = 0; n < uColCount; ++n)
        DeleteCol(uColIndex);
    }

bool MSA::IsAlignedByCase(unsigned uColIndex) const
    {
    bool bAnyLetters = false;
    for (unsigned uSeqIndex = 0; uSeqIndex < m_uSeqCount; ++uSeqIndex)
        {
        char c = GetChar(uSeqIndex, uColIndex);
        if (::IsGap(c))
            continue;
        bAnyLetters = true;
        if (!isupper(c))
            return false;
        }
    if (!bAnyLetters)
        return false;
    return true;
    }

bool MSA::IsAlignedByCaseOrDash(unsigned uColIndex) const
    {
    for (unsigned uSeqIndex = 0; uSeqIndex < m_uSeqCount; ++uSeqIndex)
        {
        char c = GetChar(uSeqIndex, uColIndex);
        if (!isupper(c) && '-' != c)
            return false;
        }
    return true;
    }

bool MSA::IsAlignedByGapPct(unsigned uColIndex, unsigned uGapPct) const
    {
    assert(uGapPct >= 0 && uGapPct <= 100);
    bool bAnyLetters = false;
    unsigned uGapCount = 0;
    for (unsigned uSeqIndex = 0; uSeqIndex < m_uSeqCount; ++uSeqIndex)
        {
        char c = GetChar(uSeqIndex, uColIndex);
        if (::IsGap(c))
            ++uGapCount;
        }
    return (uGapCount*100)/m_uSeqCount <= uGapPct;
    }

void MSA::FromFile(TextFile &File, ALPHABET Alpha)
    {
    char c = 0;
    bool bEof = File.GetChar(c);
    assert(!bEof);
    File.Rewind();
    if ('>' == c)
        FromFASTAFile(File, Alpha);
    else
        FromMSFFile(File, Alpha);
    }

// Weights sum to 1, WCounts sum to NIC
WEIGHT MSA::GetSeqWeight(unsigned uSeqIndex) const
    {
    assert(uSeqIndex < m_uSeqCount);
    CalcWeights();
    WEIGHT w = m_Weights[uSeqIndex];
    assert(w != uInsane);
    return w;
    }

// Weights sum to 1, WCounts sum to NIC
WCOUNT MSA::GetSeqWCount(unsigned uSeqIndex) const
    {
    assert(uSeqIndex < m_uSeqCount);
    CalcWeights();
    WEIGHT w = m_Weights[uSeqIndex];
    assert(w != uInsane);
    WCOUNT wcNIC = GetEffectiveNIC();
    WCOUNT wcValue;
    MulWeightWCount(wcValue, w, wcNIC);
    return wcValue;
    }

void MSA::WeightsToFile(TextFile &File) const
    {
    File.PutFormat("%u\n", m_uSeqCount);
    for (unsigned n = 0; n < m_uSeqCount; ++n)
        File.PutFormat("%u %g\n", n, WeightToDouble(GetSeqWeight(n)));
    File.PutString("//\n");
    }

void MSA::WeightsFromFile(TextFile &File)
    {
    char szToken[32];
    File.GetTokenX(szToken, sizeof(szToken));
    assert(IsValidInteger(szToken));
    unsigned uSize = (unsigned) atoi(szToken);
    assert(uSize == m_uSeqCount);

    for (unsigned n = 0; n < m_uSeqCount; ++n)
        {
        File.GetTokenX(szToken, sizeof(szToken));
        assert(IsValidInteger(szToken));
        assert((unsigned) atoi(szToken) == n);

        File.GetTokenX(szToken, sizeof(szToken));
        m_Weights[n] = DoubleToWeight(atof(szToken));
        }

    File.GetTokenX(szToken, sizeof(szToken));
    assert (0 == strcmp(szToken, "//"));
    }

void MSA::CalcWeights() const
    {
    if (m_bWeightsSet)
        return;
    //printf("Weighting...");
    if (GetFlag("GSC"))
        CalcGSCWeights();
    else
        CalcHenikoffWeights();
    m_bWeightsSet = true;
    //printf("done\n");
    }

void MSA::FillResCounts(WCOUNT wcResCounts[], unsigned uFromColIndex,
  unsigned uToColIndex)
    {
    for (unsigned uColIndex = uFromColIndex; uColIndex <= uToColIndex; ++uColIndex)
      for (unsigned uSeqIndex = 0; uSeqIndex < m_uSeqCount; ++uSeqIndex)
        {
        WCOUNT wcSeq = GetSeqWCount(uSeqIndex);

        char c = m_szSeqs[uSeqIndex][uColIndex];
        unsigned uLetter = CharToLetterAminoEx[c];
        switch (uLetter)
            {
#define c(x)    case AX_##x: wcResCounts[AX_##x] += wcSeq; break;
        c(A) c(C) c(D) c(E) c(F) c(G) c(H) c(I) c(K) c(L)
        c(M) c(N) c(P) c(Q) c(R) c(S) c(T) c(V) c(W) c(Y)
#undef    c

    // No need to count Xs, they contribute zero to emission score.
    // (This is safer and more accurate than using the background
    // distribution here in case the model parameters were estimated
    // with a different distribution).
        case AX_X:
            break;

    // B means D or N. D/N = 1.171
    // D=0.4606 N=0.5394 gives D+N=1, D/N=1.171
        case AX_B:
            wcResCounts[AX_D] += (wcSeq*4606)/10000;
            wcResCounts[AX_N] += (wcSeq*5394)/10000;
            break;

    // Z means E or Q. E/Q = 1.571
    // E=0.6110 Q=0.3890 gives E+Q=1, E/Q=1.571
        case AX_Z:
            wcResCounts[AX_E] += (wcSeq*6110)/10000;
            wcResCounts[AX_Q] += (wcSeq*3890)/10000;
            break;

#ifdef    _DEBUG
        case AX_GAP:
            continue;

        default:
            if (isprint(c))
                Quit("Invalid character '%c' in sequence", c);
            else
                Quit("Invalid character 0x%02x in sequence", c);
            assert(false);
#endif
            }
        }
    }

void MSA::BuildPillars()
    {
// Determine pillar count
    const unsigned uColCount = GetColCount();
    if (0 == uColCount)
        return;
    const unsigned uSeqCount = GetSeqCount();
    bool bLastColAligned = true;
    unsigned uPillarCount = 0;
    m_uAlignedColCount = 0;
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        const COLINFO &CI = GetColInfo(uColIndex);
        if (CI.m_bAligned)
            {
            ++m_uAlignedColCount;
            ++uPillarCount;
            bLastColAligned = true;
            }
        else
            {
            if (bLastColAligned)
                ++uPillarCount;
            bLastColAligned = false;
            }
        }

    m_Pillars = new PILLAR[uPillarCount];
    for (unsigned uPillarIndex2 = 0; uPillarIndex2 < uPillarCount; ++uPillarIndex2)
        m_Pillars[uPillarIndex2].Init(uPillarCount, uSeqCount);
    m_uPillarCount = uPillarCount;

    if (m_uAlignedColCount > 0)
        m_AlignedColToPillar = new unsigned[m_uAlignedColCount];
    else
        m_AlignedColToPillar = 0;

    unsigned uPillarIndex = 0;
    unsigned uAlignedColIndex = 0;
    unsigned uFromCol = uInsane;
    unsigned uToCol = uInsane;
    m_Pillars[0].m_uFromColIndex = 0;
    bLastColAligned = true;
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        const COLINFO &CI = GetColInfo(uColIndex);
        if (CI.m_bAligned)
            {
            m_AlignedColToPillar[uAlignedColIndex++] = uPillarIndex;
            m_Pillars[uPillarIndex].m_uFromColIndex = uColIndex;
            m_Pillars[uPillarIndex].m_bAligned = true;
            if (uPillarIndex > 0)
                m_Pillars[uPillarIndex-1].m_uToColIndex = uColIndex - 1;
            ++uPillarIndex;
            bLastColAligned = true;
            }
        else
            {
            if (bLastColAligned)
                {
                m_Pillars[uPillarIndex].m_bAligned = false;
                m_Pillars[uPillarIndex].m_uFromColIndex = uColIndex;
                if (uPillarIndex > 0)
                    m_Pillars[uPillarIndex-1].m_uToColIndex = uColIndex - 1;
                ++uPillarIndex;
                }
            bLastColAligned = false;
            }
        }
    assert(uPillarIndex == uPillarCount);
    assert(uAlignedColIndex == m_uAlignedColCount);
    m_Pillars[uPillarCount-1].m_uToColIndex = uColCount - 1;

// Order is important here!
    for (unsigned uPillarIndex2 = 0; uPillarIndex2 < uPillarCount; ++uPillarIndex2)
        BuildPillar(uPillarIndex2);

    if (g_bUseBreakMatrices)
        {
        BuildBE();
        BuildBL();
        BuildBG();
        BuildBT();
        }

    for (uPillarIndex= 0; uPillarIndex < uPillarCount; ++uPillarIndex)
        CalcFractionalPillarCounts(uPillarIndex);

// m_Pause needed temporarily to computer FF, FE, EF, EE and T,
// discard now if saving memory.
    if (!g_bUseBreakMatrices)
        {
        for (uPillarIndex= 0; uPillarIndex < uPillarCount; ++uPillarIndex)
            {
            PILLAR &Pillar = m_Pillars[uPillarIndex];
            delete[] Pillar.m_Pause;
            Pillar.m_Pause = 0;
            }
        }
    }

void MSA::BuildPillar(unsigned uPillarIndex)
    {
    assert(uPillarIndex < m_uPillarCount);
    const unsigned uColCount = GetColCount();
    const unsigned uSeqCount = GetSeqCount();
    PILLAR &Pillar = m_Pillars[uPillarIndex];

    unsigned uFromColIndex = Pillar.m_uFromColIndex;
    unsigned uToColIndex = Pillar.m_uToColIndex;

#if    _DEBUG
    assert(uFromColIndex >= 0 && uFromColIndex < uColCount);
    assert(uToColIndex >= 0 && uToColIndex < uColCount);
    if (Pillar.m_bAligned)
        assert(uFromColIndex == uToColIndex);
    else
        assert(uFromColIndex <= uToColIndex);

    if (uPillarIndex > 0)
        assert(uFromColIndex == m_Pillars[uPillarIndex-1].m_uToColIndex + 1);
    else
        assert(0 == uFromColIndex);

    if (uPillarIndex < m_uPillarCount - 1)
        assert(uToColIndex == m_Pillars[uPillarIndex+1].m_uFromColIndex - 1);
    else
        assert(uToColIndex == uColCount - 1);
#endif    // _DEBUG

    FillResCounts(Pillar.m_wcResCounts, uFromColIndex, uToColIndex);

    WCOUNT wcResidueCount = 0;
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        const WCOUNT wcSeq = GetSeqWCount(uSeqIndex);
        unsigned uSeqResCount = 0;
        for (unsigned uColIndex = uFromColIndex; uColIndex <= uToColIndex;
          ++uColIndex)
            {
            if (!IsGap(uSeqIndex, uColIndex))
                {
                ++uSeqResCount;
                wcResidueCount += wcSeq;
                }
            }

    // There is a pause in this sequence if no residues
        if (0 == uSeqResCount)
            {
            Pillar.m_Pause[uSeqIndex] = true;
            Pillar.m_wcE += wcSeq;
            if (uPillarIndex > 0)
                {
                if (m_Pillars[uPillarIndex-1].m_Pause[uSeqIndex])
                    Pillar.m_wcEE += wcSeq;
                else
                    Pillar.m_wcFE += wcSeq;
                }
            else
                {
                Pillar.m_wcFE += wcSeq;
                }
            }
        else
            {
            Pillar.m_Pause[uSeqIndex] = false;
            Pillar.m_wcF += wcSeq;
            if (uPillarIndex > 0)
                {
                if (m_Pillars[uPillarIndex-1].m_Pause[uSeqIndex])
                    Pillar.m_wcEF += wcSeq;
                else
                    Pillar.m_wcFF += wcSeq;
                }
            else
                {
                Pillar.m_wcFF += wcSeq;
                }
            }

        if (uSeqResCount > 1)
            Pillar.m_wcT += wcSeq*(uSeqResCount - 1);
        }
    }

void MSA::CalcFractionalPillarCounts(unsigned uPillarIndex)
    {
    WCOUNT wcNIC = GetEffectiveNIC();
    PILLAR &Pillar = m_Pillars[uPillarIndex];
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        Pillar.m_fcResCounts[uLetter] =
          DivWCount(Pillar.m_wcResCounts[uLetter], wcNIC);

    Pillar.m_fcE = DivWCount(Pillar.m_wcE, wcNIC);
    Pillar.m_fcF = DivWCount(Pillar.m_wcF, wcNIC);
    Pillar.m_fcFF = DivWCount(Pillar.m_wcFF, wcNIC);
    Pillar.m_fcEF = DivWCount(Pillar.m_wcEF, wcNIC);
    Pillar.m_fcFE = DivWCount(Pillar.m_wcFE, wcNIC);
    Pillar.m_fcEE = DivWCount(Pillar.m_wcEE, wcNIC);
    Pillar.m_fcT = DivWCount(Pillar.m_wcT, wcNIC);
    if (!g_bUseBreakMatrices)
        return;

    const unsigned uPillarCount = GetPillarCount();
    for (unsigned n = 0; n <= uPillarCount; ++n)
        {
        Pillar.m_fcBE[n] = DivWCount(Pillar.m_wcBE[n], wcNIC);
        Pillar.m_fcBL[n] = DivWCount(Pillar.m_wcBL[n], wcNIC);
        Pillar.m_fcBG[n] = DivWCount(Pillar.m_wcBG[n], wcNIC);
        }
    for (unsigned n = 0; n < uPillarCount; ++n)
        Pillar.m_fcBT[n] = DivWCount(Pillar.m_wcBT[n], wcNIC);
    }

const PILLAR &MSA::GetPillar(unsigned uPillarIndex) const
    {
    assert(uPillarIndex < m_uPillarCount);
    return m_Pillars[uPillarIndex];
    }

unsigned MSA::GetPillarFmtWidth(unsigned uPillarIndex) const
    {
    const PILLAR &Pillar = GetPillar(uPillarIndex);
    unsigned uWidth = Pillar.m_uToColIndex - Pillar.m_uFromColIndex + 1;
    if (uWidth < 3)
        uWidth = 3;
    return uWidth;
    }

static void FmtChar(char c, unsigned uWidth)
    {
    List("%c", c);
    for (unsigned n = 0; n < uWidth - 1; ++n)
        List(" ");
    }

static void FmtInt(unsigned u, unsigned uWidth)
    {
    static char szStr[1024];
    assert(uWidth < sizeof(szStr));
    if (u > 0)
        sprintf(szStr, "%u", u);
    else
        strcpy(szStr, ".");
    List(szStr);
    unsigned n = (unsigned) strlen(szStr);
    if (n < uWidth)
        for (unsigned i = 0; i < uWidth - n; ++i)
            List(" ");
    }

static void FmtWCount(WCOUNT wc, unsigned uWidth)
    {
    double d = WCountToDouble(wc);
    static char szStr[1024];
    assert(uWidth < sizeof(szStr));
    if (d > 0)
        sprintf(szStr, "%3.2g", d);
    else
        strcpy(szStr, "  .");
    List(szStr);
    unsigned n = (unsigned) strlen(szStr);
    if (n < uWidth)
        for (unsigned i = 0; i < uWidth - n; ++i)
            List(" ");
    }

static void FmtInt0(unsigned u, unsigned uWidth)
    {
    static char szStr[1024];
    assert(uWidth < sizeof(szStr));
    sprintf(szStr, "%u", u);
    List(szStr);
    unsigned n = (unsigned) strlen(szStr);
    if (n < uWidth)
        for (unsigned i = 0; i < uWidth - n; ++i)
            List(" ");
    }

static void FmtPad(unsigned n)
    {
    for (unsigned i = 0; i < n; ++i)
        List(" ");
    }

void MSA::ListPillars() const
    {
    const unsigned uSeqCount = GetSeqCount();
    const unsigned uPillarCount = GetPillarCount();

//// Residue counts by type
//    for (unsigned uLetter = 0; uLetter < 20; ++uLetter)
//        {
//        bool bNone = true;
//        for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
//            {
//            const PILLAR &Pillar = GetPillar(uPillarIndex);
//            unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
//            WCOUNT wcCount = Pillar.m_wcResCounts[uLetter];
//            if (wcCount > 0)
//                {
//                bNone = false;
//                break;
//                }
//            }
//        if (bNone)
//            continue;
//        List("%c    ", LetterToCharAmino(uLetter));
//        for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
//            {
//            const PILLAR &Pillar = GetPillar(uPillarIndex);
//            unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
//            WCOUNT wcCount = Pillar.m_wcResCounts[uLetter];
//            FmtWCount(wcCount, uWidth);
//            }
//        List("\n");
//        }
//
//// Pauses
//    List("\n");
//    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
//        {
//        List("%-5d", uSeqIndex);
//        for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
//            {
//            const PILLAR &Pillar = GetPillar(uPillarIndex);
//            unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
//            if (Pillar.m_Pause[uSeqIndex])
//                FmtChar('-', uWidth);
//            else
//                FmtChar(' ', uWidth);
//            }
//        List("\n");
//        }
//
//// Occupancy vectors
//    List("\n");
//    List("f    ");
//    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
//        {
//        const PILLAR &Pillar = GetPillar(uPillarIndex);
//        unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
//        FmtWCount(Pillar.m_wcF, uWidth);
//        }
//    List("\n");
//    List("e    ");
//    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
//        {
//        const PILLAR &Pillar = GetPillar(uPillarIndex);
//        unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
//        FmtWCount(Pillar.m_wcE, uWidth);
//        }
//    List("\n");
//    List("ff   ");
//    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
//        {
//        const PILLAR &Pillar = GetPillar(uPillarIndex);
//        unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
//        FmtWCount(Pillar.m_wcFF, uWidth);
//        }
//    List("\n");
//    List("ee   ");
//    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
//        {
//        const PILLAR &Pillar = GetPillar(uPillarIndex);
//        unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
//        FmtWCount(Pillar.m_wcEE, uWidth);
//        }
//    List("\n");
//    List("fe   ");
//    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
//        {
//        const PILLAR &Pillar = GetPillar(uPillarIndex);
//        unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
//        FmtWCount(Pillar.m_wcFE, uWidth);
//        }
//    List("\n");
//    List("ef   ");
//    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
//        {
//        const PILLAR &Pillar = GetPillar(uPillarIndex);
//        unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
//        FmtWCount(Pillar.m_wcEF, uWidth);
//        }
//    List("\n");
//    List("t    ");
//    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
//        {
//        const PILLAR &Pillar = GetPillar(uPillarIndex);
//        unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
//        FmtWCount(Pillar.m_wcT, uWidth);
//        }
//    List("\n");
//
//    ListBE();
//    ListBL();
//    ListBG();
//    ListBT();

// Pillar index numbers
    List("\n");
    List("     ");
    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
        {
        const PILLAR &Pillar = GetPillar(uPillarIndex);
        unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
        FmtInt0(uPillarIndex, uWidth);
        }
    List("\n");

// Letters
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        List("%-5d", uSeqIndex);
        for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
            {
            const PILLAR &Pillar = GetPillar(uPillarIndex);
            unsigned n = 0;
            for (unsigned uColIndex = Pillar.m_uFromColIndex;
              uColIndex <= Pillar.m_uToColIndex; ++uColIndex)
                {
                List("%c", GetChar(uSeqIndex, uColIndex));
                ++n;
                }
            unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
            while (n < uWidth)
                {
                List(" ");
                ++n;
                }
            }
        List("\n");
        }
    }

// PILLAR.m_wcBE[c] is the (weighted) number of breaks
// of length c that end in the pillar.
void MSA::BuildBE()
    {
    for (unsigned uSeqIndex = 0; uSeqIndex < m_uSeqCount; ++uSeqIndex)
        {
        unsigned uBreakLength = 0;
        WEIGHT SeqWeight = GetSeqWCount(uSeqIndex);
        for (unsigned uPillarIndex = 0; uPillarIndex < m_uPillarCount; ++uPillarIndex)
            {
            if (GetPillar(uPillarIndex).m_Pause[uSeqIndex])
                ++uBreakLength;
            else if (uBreakLength > 0)
                {
                const PILLAR &Pillar = m_Pillars[uPillarIndex-1];
                Pillar.m_wcBE[uBreakLength] += SeqWeight;
                uBreakLength = 0;
                }
            }
        if (uBreakLength > 0)
            {
            const PILLAR &Pillar = m_Pillars[m_uPillarCount-1];
            Pillar.m_wcBE[uBreakLength] += SeqWeight;
            }
        }
    }

void MSA::BuildBL()
    {
    for (unsigned uPillarIndex = 0; uPillarIndex < m_uPillarCount; ++uPillarIndex)
        {
        PILLAR &Pillar = m_Pillars[uPillarIndex];
        Pillar.m_wcBL[0] = 0;
        for (unsigned uBreakLength = 1; uBreakLength <= m_uPillarCount;
          ++uBreakLength)
            Pillar.m_wcBL[uBreakLength] = Pillar.m_wcBL[uBreakLength-1] +
              Pillar.m_wcBE[uBreakLength-1];
        }
    }

//    BGw[c] = EFw+1 � BLi[c] � BEi[c]
void MSA::BuildBG()
    {
    for (unsigned uPillarIndex = 0; uPillarIndex < m_uPillarCount; ++uPillarIndex)
        {
        PILLAR &Pillar = m_Pillars[uPillarIndex];
        WCOUNT ef;
        if (uPillarIndex < m_uPillarCount - 1)
            ef = m_Pillars[uPillarIndex+1].m_wcEF;
        else
            ef = Pillar.m_wcE;
        for (unsigned uBreakLength = 0; uBreakLength < m_uPillarCount; ++uBreakLength)
            {
            WCOUNT ble = Pillar.m_wcBL[uBreakLength] + Pillar.m_wcBE[uBreakLength];
//            assert(ble <= ef);
            Pillar.m_wcBG[uBreakLength] = ef - ble;
            }
        }
    }

void MSA::BuildBT()
    {
    for (unsigned i = 0; i < m_uPillarCount; ++i)
        {
        PILLAR &Pillar = m_Pillars[i];
        Pillar.m_wcBT[i] = Pillar.m_wcE;
        for (unsigned j = i+1; j < m_uPillarCount;  ++j)
            Pillar.m_wcBT[j] = Pillar.m_wcBT[j-1] - m_Pillars[j-1].m_wcBG[j-i-1];
        }
    }

void MSA::ValidateBreakMatrices() const
    {
    WCOUNT wcNIC = GetEffectiveNIC();
// Check r+g=NIC, rg+gg=g, rr+gr=r, rr+gg+rg+gr=NIC
    for (unsigned uPillarIndex = 0; uPillarIndex < m_uPillarCount; ++uPillarIndex)
        {
        const PILLAR &Pillar = m_Pillars[uPillarIndex];
        if (!WCountEqPct(Pillar.m_wcE + Pillar.m_wcF, wcNIC, 1))
            Quit("Col %u g=%u + r=%u != NIC=%u\n",
              uPillarIndex, Pillar.m_wcE, Pillar.m_wcF, wcNIC);
        if (!WCountEqPct(Pillar.m_wcFF + Pillar.m_wcEF, Pillar.m_wcF, 1))
            Quit("Col %u rr=%u + gr=%u != r=%u\n",
              uPillarIndex, Pillar.m_wcFF, Pillar.m_wcEF, Pillar.m_wcF);
        if (!WCountEqPct(Pillar.m_wcEE + Pillar.m_wcFE, Pillar.m_wcE, 1))
            Quit("Col %u gg=%u + rg=%u != g=%u\n",
              uPillarIndex, Pillar.m_wcEE, Pillar.m_wcFE, Pillar.m_wcE);
        if (!WCountEqPct(Pillar.m_wcFF + Pillar.m_wcEE + Pillar.m_wcFE + Pillar.m_wcEF, wcNIC, 1))
            Quit("Col %u rr=%u + gg=%u + rg=%u + gr=%u != NIC=%u\n",
              uPillarIndex, Pillar.m_wcFF, Pillar.m_wcEE, Pillar.m_wcFE, Pillar.m_wcEF, wcNIC);
        }

// Check value of f from its definition
    for (unsigned uPillarIndex = 0; uPillarIndex < m_uPillarCount; ++uPillarIndex)
        {
        const PILLAR &Pillar = m_Pillars[uPillarIndex];
        for (unsigned uBreakLength = 0; uBreakLength < m_uPillarCount; ++uBreakLength)
            {
            WCOUNT wcSum = 0;
            for (unsigned c = 1; c < uBreakLength; ++c)
                wcSum += Pillar.m_wcBE[c];
            if (!WCountEqPct(Pillar.m_wcBL[uBreakLength], wcSum, 1))
                Quit("Col %u f[%u]=%u, should be %u.\n",
                    uPillarIndex, uBreakLength, Pillar.m_wcBL[uBreakLength], wcSum);
            }
        }

// Check value of b from its definition
    for (unsigned uPillarIndex = 0; uPillarIndex < m_uPillarCount; ++uPillarIndex)
        {
        const PILLAR &Pillar = m_Pillars[uPillarIndex];
        for (unsigned uBreakLength = 0; uBreakLength < m_uPillarCount; ++uBreakLength)
            {
            WCOUNT wcSum = 0;
            for (unsigned c = uBreakLength + 1; c <= m_uPillarCount; ++c)
                wcSum += Pillar.m_wcBE[c];
            if (!WCountEqPct(Pillar.m_wcBG[uBreakLength], wcSum, 1))
                Quit("Col %u b[%u]=%u, should be %u.\n",
                    uPillarIndex, uBreakLength, Pillar.m_wcBG[uBreakLength], wcSum);
            }
        }

// gg[i+1] should be W[i,i+1]
    for (unsigned i = 0; i < m_uPillarCount-1; ++i)
        {
        if (!WCountEqPct(m_Pillars[i+1].m_wcEE, m_Pillars[i].m_wcBT[i+1], 1))
            Quit("gg[%u]=%u != w[%u,%u]=%u\n",
              i+1, m_Pillars[i+1].m_wcEE,
              i, i+1, m_Pillars[i].m_wcBT[i+1]);
        }
    }

void MSA::ListBE() const
    {
    List("\n");
    List("be\n");
    for (unsigned c = 0; c <= GetPillarCount(); ++c)
        {
        bool bNone = true;
        for (unsigned uPillarIndex = 0; uPillarIndex < GetPillarCount(); ++uPillarIndex)
            {
            const PILLAR &Pillar = GetPillar(uPillarIndex);
            WCOUNT n = Pillar.m_wcBE[c];
            if (0 != n)
                {
                bNone = false;
                break;
                }
            }
        if (bNone)
            continue;
        List("%-5d", c);
        for (unsigned uPillarIndex = 0; uPillarIndex < GetPillarCount(); ++uPillarIndex)
            {
            const PILLAR &Pillar = GetPillar(uPillarIndex);
            unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
            FmtWCount(Pillar.m_wcBE[c], uWidth);
            }
        List("\n");
        }
    }

void MSA::ListBG() const
    {
    List("bg\n");
    for (unsigned c = 0; c < GetPillarCount(); ++c)
        {
        bool bNone = true;
        for (unsigned uPillarIndex = 0; uPillarIndex < GetPillarCount(); ++uPillarIndex)
            {
            const PILLAR &Pillar = GetPillar(uPillarIndex);
            WCOUNT n = Pillar.m_wcBG[c];
            if (0 != n)
                {
                bNone = false;
                break;
                }
            }
        if (bNone)
            continue;
        List("%-5d", c);
        for (unsigned uPillarIndex = 0; uPillarIndex < GetPillarCount(); ++uPillarIndex)
            {
            const PILLAR &Pillar = GetPillar(uPillarIndex);
            unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
            FmtWCount(Pillar.m_wcBG[c], uWidth);
            }
        List("\n");
        }
    }

void MSA::ListBL() const
    {
    List("bl\n");
    for (unsigned c = 0; c < GetPillarCount(); ++c)
        {
        bool bNone = true;
        for (unsigned uPillarIndex = 0; uPillarIndex < GetPillarCount(); ++uPillarIndex)
            {
            const PILLAR &Pillar = GetPillar(uPillarIndex);
            WCOUNT n = Pillar.m_wcBL[c];
            if (0 != n)
                {
                bNone = false;
                break;
                }
            }
        if (bNone)
            continue;
        List("%-5d", c);
        for (unsigned uPillarIndex = 0; uPillarIndex < GetPillarCount(); ++uPillarIndex)
            {
            const PILLAR &Pillar = GetPillar(uPillarIndex);
            unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
            FmtWCount(Pillar.m_wcBL[c], uWidth);
            }
        List("\n");
        }
    }

void MSA::ListBT() const
    {
    List("bt\n");
    for (unsigned c = 0; c < GetPillarCount(); ++c)
        {
        bool bNone = true;
        for (unsigned uPillarIndex = 0; uPillarIndex < GetPillarCount(); ++uPillarIndex)
            {
            const PILLAR &Pillar = GetPillar(uPillarIndex);
            WCOUNT n = Pillar.m_wcBT[c];
            if (0 != n)
                {
                bNone = false;
                break;
                }
            }
        if (bNone)
            continue;
        List("%-5d", c);
        for (unsigned uPillarIndex = 0; uPillarIndex < GetPillarCount(); ++uPillarIndex)
            {
            const PILLAR &Pillar = GetPillar(uPillarIndex);
            unsigned uWidth = GetPillarFmtWidth(uPillarIndex);
            FmtWCount(Pillar.m_wcBT[c], uWidth);
            }
        List("\n");
        }
    }

unsigned MSA::AlignedColToPillarIndex(unsigned uAlignedColIndex) const
    {
    assert(uAlignedColIndex < m_uAlignedColCount);
    return m_AlignedColToPillar[uAlignedColIndex];
    }

void MSA::GetNodeCounts(unsigned uAlignedColIndex, NodeCounts &Counts) const
    {
    Counts.Clear();
    unsigned uPillarIndex = AlignedColToPillarIndex(uAlignedColIndex);
    const PILLAR &Pillar = GetPillar(uPillarIndex);
    assert(Pillar.m_bAligned);

// Copy residue counts from pillar
    assert(sizeof(Counts.m_wcMatchEmit) == sizeof(Pillar.m_wcResCounts));
    memcpy(Counts.m_wcMatchEmit, Pillar.m_wcResCounts, sizeof(Counts.m_wcMatchEmit));

    Counts.m_wcResidues = Pillar.m_wcF;
    Counts.m_wcGaps = Pillar.m_wcE;

// If this is the last pillar, no transition counts
    if (uPillarIndex + 1 == GetPillarCount())
        return;

// Calculate transition counts.
    const PILLAR &NextPillar = GetPillar(uPillarIndex+1);
    if (NextPillar.m_bAligned)
        {
        Counts.m_wcMM = NextPillar.m_wcFF;
        Counts.m_wcMD = NextPillar.m_wcFE;
        Counts.m_wcDM = NextPillar.m_wcEF;
        Counts.m_wcDD = NextPillar.m_wcEE;
        }
    else
        {
    // If this is last aligned pillar, no useful transition counts
    // (models don't care about terminal insertions).
        if (uPillarIndex + 2 >= GetPillarCount())
            return;

        const PILLAR &NextAlignedPillar = GetPillar(uPillarIndex+2);

        Counts.m_wcMI = NextPillar.m_wcFF;
        Counts.m_wcDI = NextPillar.m_wcEF;
        Counts.m_wcIM = NextAlignedPillar.m_wcFF;
        Counts.m_wcID = NextAlignedPillar.m_wcFE;
        Counts.m_wcII = NextPillar.m_wcT;
        if (g_bUseBreakMatrices)
            {
            Counts.m_wcMM = NextPillar.m_wcBE[1];
            Counts.m_wcMD = NextPillar.m_wcBT[uPillarIndex+2] - Pillar.m_wcBT[uPillarIndex+2];
            Counts.m_wcDM = NextPillar.m_wcBG[1];
            Counts.m_wcDD = Pillar.m_wcBT[uPillarIndex+2];
            }
        else
            {
        // This pillar is aligned, next pillar is unaligned.
        // Approximation because break matrices not available.
        // Assume 100% residues in next aligned pillar.
            Counts.m_wcMM = NextPillar.m_wcFE;
            Counts.m_wcMD = 0;
            Counts.m_wcDM = NextPillar.m_wcEE;
            Counts.m_wcDD = 0;
            }
        }
    }

void MSA::FromSeq(const Seq &s)
    {
    unsigned uSeqLength = s.Length();
    SetSize(1, uSeqLength);
    SetAlphabet(ALPHABET_Amino);
    SetSeqName(0, s.GetName());
    for (unsigned n = 0; n < uSeqLength; ++n)
        SetChar(0, n, s[n]);
    }

unsigned MSA::PillarPLToColPL(unsigned uPillarPL) const
    {
    if (0 == uPillarPL)
        return 0;
    const PILLAR &Pillar = GetPillar(uPillarPL-1);
    return Pillar.m_uToColIndex + 1;
    }

unsigned MSA::PillarPLToSeqPL(unsigned uPillarPL, unsigned uSeqIndex) const
    {
    if (0 == uPillarPL)
        return 0;
    const PILLAR &Pillar = GetPillar(uPillarPL-1);
    unsigned uToColIndex = Pillar.m_uToColIndex;
    return GetCharCount(uSeqIndex, uToColIndex);
    }

unsigned MSA::GetCharCount(unsigned uSeqIndex, unsigned uColIndex) const
    {
    assert(uSeqIndex < GetSeqCount());
    assert(uColIndex < GetColCount());

    unsigned uCol = 0;
    for (unsigned n = 0; n <= uColIndex; ++n)
        if (!IsGap(uSeqIndex, n))
            ++uCol;
    return uCol;
    }

WCOUNT MSA::GetRawNIC() const
    {
    if (!m_bRawNICSet)
        {
        m_wcRawNIC = CalcRawNIC();
        m_bRawNICSet = true;
        }
    assert(dInsane != m_wcRawNIC);
    return m_wcRawNIC;
    }

WCOUNT MSA::GetEffectiveNIC() const
    {
// HACK -- experience shows this is a good starting point
// for the bits saved procedure.
    return 3.0;

    //if (!m_bEffectiveNICSet)
    //    {
    //    WCOUNT wcMaxNIC = GetMaxNIC();
    //    WCOUNT wcRawNIC = GetRawNIC();
    //    if (wcRawNIC > wcMaxNIC)
    //        m_wcEffectiveNIC = wcMaxNIC;
    //    else
    //        m_wcEffectiveNIC = wcRawNIC;
    //    m_bEffectiveNICSet = true;
    //    }
    //assert(dInsane != m_wcRawNIC);
    //return m_wcEffectiveNIC;
    };

// Sjolander heuristic for Number of Independent Counts,
// what HMMer calls the Effective Sequence Count.
WCOUNT MSA::CalcRawNIC() const
    {
    double dAvgCons = GetAvgCons();
    double dRawNIC = pow(GetSeqCount(), 1 - dAvgCons);
    return DoubleToWCount(dRawNIC);
    }

void MSA::CopySeq(unsigned uToSeqIndex, const MSA &msaFrom, unsigned uFromSeqIndex)
    {
    assert(uToSeqIndex < m_uSeqCount);
    const unsigned uColCount = msaFrom.GetColCount();
    assert(m_uColCount == uColCount ||
      (0 == m_uColCount && uColCount <= m_uCacheSeqLength));

    memcpy(m_szSeqs[uToSeqIndex], msaFrom.GetSeqBuffer(uFromSeqIndex), uColCount);
    m_szNames[uToSeqIndex] = strdup(msaFrom.GetSeqName(uFromSeqIndex));
    if (0 == m_uColCount)
        m_uColCount = uColCount;
    }

const char *MSA::GetSeqBuffer(unsigned uSeqIndex) const
    {
    assert(uSeqIndex < m_uSeqCount);
    return m_szSeqs[uSeqIndex];
    }

void MSA::CopyReversed(const MSA &msa)
    {
    Free();
    const unsigned uSeqCount = msa.GetSeqCount();
    const unsigned uColCount = msa.GetColCount();
    SetSize(uSeqCount, uColCount);

    m_Alphabet = msa.GetAlphabet();
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        m_ColInfo[uColIndex] = msa.GetColInfo(uColIndex);

    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        m_szNames[uSeqIndex] = strdup(msa.GetSeqName(uSeqIndex));
        for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
            {
            const unsigned uReversedColIndex = uColCount - uColIndex - 1;
            const char c = msa.GetChar(uSeqIndex, uColIndex);
            SetChar(uSeqIndex, uReversedColIndex, c);
            }
        }

    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        const COLINFO &CI = msa.GetColInfo(uColIndex);
        const unsigned uReversedColIndex = uColCount - uColIndex - 1;
        SetColInfo(uReversedColIndex, CI);
        }

    m_bWeightsSet = msa.m_bWeightsSet;
    memcpy(m_Weights, msa.m_Weights, uSeqCount*sizeof(WEIGHT));

    m_bRawNICSet = msa.m_bRawNICSet;
    m_wcRawNIC = msa.m_wcRawNIC;
    
    m_bEffectiveNICSet = msa.m_bEffectiveNICSet;
    m_wcEffectiveNIC = msa.m_wcEffectiveNIC;

    BuildPillars();
    }

void MSA::SanityCheckPillarCount() const
    {
    unsigned uAlignedPillarCount = 0;
    const unsigned uPillarCount = GetPillarCount();
    bool bPrevPillarAligned = true;
    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
        {
        const PILLAR &Pillar = GetPillar(uPillarIndex);
    // Cannot be two consecutive unaligned pillars
        if (!Pillar.m_bAligned && !bPrevPillarAligned)
            Quit("Consecutive unaligned pillars");
        if (Pillar.m_bAligned)
            ++uAlignedPillarCount;
        bPrevPillarAligned = Pillar.m_bAligned;
        }
    if (uAlignedPillarCount != m_uAlignedColCount)
        Quit("Pillar count mismatch");
    }

void MSA::DeleteSeq(unsigned uSeqIndex)
    {
    assert(uSeqIndex < m_uSeqCount);

    delete m_szSeqs[uSeqIndex];
    delete m_szNames[uSeqIndex];

    const unsigned uBytesToMove = (m_uSeqCount - uSeqIndex)*sizeof(char *);
    if (uBytesToMove > 0)
        {
        memmove(m_szSeqs + uSeqIndex, m_szSeqs + uSeqIndex + 1, uBytesToMove);
        memmove(m_szNames + uSeqIndex, m_szNames + uSeqIndex + 1, uBytesToMove);
        }

    --m_uSeqCount;

    FreePillars();

    delete[] m_ColInfo;
    m_ColInfo = 0;

    delete[] m_Weights;
    m_Weights = 0;

    m_bRawNICSet = false;
    m_bEffectiveNICSet = false;
    m_bWeightsSet = false;
    }

bool MSA::IsEmptyCol(unsigned uColIndex) const
    {
    const unsigned uSeqCount = GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        if (!IsGap(uSeqIndex, uColIndex))
            return false;
    return true;
    }

void MSA::DeleteEmptyCols(bool bProgress)
    {
    unsigned uColCount = GetColCount();
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        if (IsEmptyCol(uColIndex))
            {
            if (bProgress)
                {
                List("Deleting col %u of %u\n", uColIndex, uColCount);
                printf("Deleting col %u of %u\n", uColIndex, uColCount);
                }
            DeleteCol(uColIndex);
            --uColCount;
            }
        }
    }

unsigned MSA::AlignedColIndexToColIndex(unsigned uAlignedColIndex) const
    {
    const unsigned uPillarIndex = AlignedColToPillarIndex(uAlignedColIndex);
    const PILLAR &Pillar = GetPillar(uPillarIndex);
    assert(Pillar.m_bAligned);
    assert(Pillar.m_uFromColIndex == Pillar.m_uToColIndex);
    return Pillar.m_uFromColIndex;
    }

void MSA::FromAlignedColumns(const MSA &a)
    {
    const unsigned uAlignedColCount = a.GetAlignedColCount();
    const unsigned uSeqCount = a.GetSeqCount();
    SetSize(uSeqCount, uAlignedColCount);

    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        SetSeqName(uSeqIndex, a.GetSeqName(uSeqIndex));

    for (unsigned uAlignedColIndex = 0; uAlignedColIndex < uAlignedColCount;
      ++uAlignedColIndex)
        {
        const unsigned uColIndex = a.AlignedColIndexToColIndex(uAlignedColIndex);
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
            {
            char c = a.GetChar(uSeqIndex, uColIndex);
            SetChar(uSeqIndex, uAlignedColIndex, c);
            }
        }
    }

void MSA::FreeUngapMap()
    {
    if (0 == m_UngapMap)
        return;

    const unsigned uSeqCount = GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        delete[] m_UngapMap[uSeqIndex];
    m_UngapMap = 0;
    }

WEIGHT MSA::GetTotalSeqWeight() const
    {
    WEIGHT wTotal = 0;
    const unsigned uSeqCount = GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        wTotal += m_Weights[uSeqIndex];
    return wTotal;
    }

bool MSA::SeqsEq(const MSA &a1, unsigned uSeqIndex1, const MSA &a2,
  unsigned uSeqIndex2)
    {
    Seq s1;
    Seq s2;

    a1.GetSeq(uSeqIndex1, s1);
    a2.GetSeq(uSeqIndex2, s2);

    s1.StripGaps();
    s2.StripGaps();

    return s1.EqIgnoreCase(s2);
    }

unsigned MSA::GetSeqLength(unsigned uSeqIndex) const
    {
    assert(uSeqIndex < GetSeqCount());

    const unsigned uColCount = GetColCount();
    unsigned uLength = 0;
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        if (!IsGap(uSeqIndex, uColIndex))
            ++uLength;
    return uLength;
    }

void MSA::GetPWID(unsigned uSeqIndex1, unsigned uSeqIndex2, double *ptrPWID,
  unsigned *ptruPosCount) const
    {
    assert(uSeqIndex1 < GetSeqCount());
    assert(uSeqIndex2 < GetSeqCount());

    unsigned uSameCount = 0;
    unsigned uPosCount = 0;
    const unsigned uColCount = GetColCount();
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        {
        if (!IsAligned(uColIndex))
            continue;
        char c1 = GetChar(uSeqIndex1, uColIndex);
        if (::IsGap(c1))
            continue;
        char c2 = GetChar(uSeqIndex2, uColIndex);
        if (::IsGap(c2))
            continue;
        ++uPosCount;
        if (c1 == c2)
            ++uSameCount;
        }
    *ptruPosCount = uPosCount;
    if (uPosCount > 0)
        *ptrPWID = 100.0 * (double) uSameCount / (double) uPosCount;
    else
        *ptrPWID = 0;
    }

void MSA::UnWeight()
    {
    for (unsigned uSeqIndex = 0; uSeqIndex < GetSeqCount(); ++uSeqIndex)
        m_Weights[uSeqIndex] = 1.0;
    m_bWeightsSet = true;
    }
