// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef DirMix_h
#define    DirMix_h

class TextFile;
class Dirichlet;
class DirMix;

const unsigned MAX_DIRICHLET_COMPS = 32;

struct DirComp
    {
    double m_dCompProb;
    double m_dLogCompProb;
    double m_dSumAlphas;
    double m_dAlphas[MAX_ALPHA];
    };

extern DirMix *g_ptrdirmixMatchEmitPrior;
extern DirMix *g_ptrdirmixMatchTransPrior;
extern DirMix *g_ptrdirmixDeleteTransPrior;
extern DirMix *g_ptrdirmixInsertTransPrior;

class DirMix
    {
public:
    DirMix()
        {
        m_uCompCount = uInsane;
        m_uAlphaCount = uInsane;
        m_Comps = 0;
        }
    ~DirMix()
        {
        delete[] m_Comps;
        }

    void FromFile(TextFile &File);
    void ListMe() const;
    void Validate() const;
    void CountsToProbs(const WCOUNT wCounts[], PROB Probs[]);

public:
    unsigned m_uCompCount;
    unsigned m_uAlphaCount;
    DirComp *m_Comps;
    };

void AddDirichletPrior(const WCOUNT wCounts[], const Dirichlet &DP, PROB Probs[],
  PROB ProbMix[][MAX_DIRICHLET_COMPS] = 0);
double DirichletLogProb(const double dCounts[], unsigned uVarCount,
  const DirComp *ptrComp);
void GetPriorBackground(PROB Prob[]);

#endif    // DirMix_h
