// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "DataBuffer.h"
#include "Profile.h"

void DoProfStats(const char *in)
    {
    DataBuffer Data;
    Data.FromFile(in);

    Profile prof;

    char szStem[128];
    NameFromPath(in, szStem, sizeof(szStem));
    prof.FromBuffer(Data, szStem);

    printf("File=%s;Stem=%s;Length=%u;Aligned=%u\n",
      in,
      szStem,
      prof.GetPosCount(),
      prof.GetAlignedPosCount());

    List("File=%s;Stem=%s;Length=%u;Aligned=%u\n",
      in,
      szStem,
      prof.GetPosCount(),
      prof.GetAlignedPosCount());
    }
