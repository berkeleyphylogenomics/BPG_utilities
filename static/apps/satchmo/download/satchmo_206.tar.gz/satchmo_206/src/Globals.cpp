// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <time.h>
#include <errno.h>

#if    WIN32
#include <windows.h>
#include <share.h>
#endif

#ifndef    MAX_PATH
#define    MAX_PATH    260
#endif

static char g_strListFileName[MAX_PATH];
static bool g_bListFileAppend = false;

void SetListFileName(const char *ptrListFileName, bool bAppend)
    {
    assert(strlen(ptrListFileName) < MAX_PATH);
    strcpy(g_strListFileName, ptrListFileName);
    g_bListFileAppend = bAppend;
    }

void List(const char szFormat[], ...)
    {
    if (0 == g_strListFileName[0])
        return;

    static FILE *f = NULL;
    char *mode;
    if (g_bListFileAppend)
        mode = "a";
    else
        mode = "w";
    if (NULL == f)
        f = _fsopen(g_strListFileName, mode, _SH_DENYNO);
    if (NULL == f)
        Quit("Cannot open list file '%s' errno=%d", g_strListFileName, errno);

    char szStr[4096];
    va_list ArgList;
    va_start(ArgList, szFormat);
    vsprintf(szStr, szFormat, ArgList);
    fprintf(f, "%s", szStr);
    fflush(f);
    }
static WCOUNT g_wcMaxNIC = DoubleToWCount(DEFAULT_MAX_NIC);

void SetMaxNIC(WCOUNT wcMaxNIC)
    {
    g_wcMaxNIC = wcMaxNIC;
    }

WCOUNT GetMaxNIC()
    {
    return g_wcMaxNIC;
    }

const char *GetTimeAsStr()
    {
    static char szStr[32];
    time_t t;
    time(&t);
    struct tm *ptmCurrentTime = localtime(&t);
    strcpy(szStr, asctime(ptmCurrentTime));
    assert('\n' == szStr[24]);
    szStr[24] = 0;
    return szStr;
    }

// Exit immediately with error message, printf-style.
void Quit(const char szFormat[], ...)
    {
    va_list ArgList;
    char szStr[4096];

    va_start(ArgList, szFormat);
    vsprintf(szStr, szFormat, ArgList);

    fprintf(stderr, "%s\n", szStr);

    List("\n*** FATAL ERROR ***\n");
    List("%s\n", szStr);

#ifdef WIN32
    if (IsDebuggerPresent())
        {
#if    _DEBUG
        int iBtn = MessageBox(NULL, szStr, "Lobster", MB_ICONERROR | MB_OKCANCEL);
        if (IDCANCEL == iBtn)
            Break();
#else
        int iBtn = MessageBox(NULL, szStr, "Lobster", MB_ICONERROR);
#endif
        }
    else
        fprintf(stderr, "%s\n", szStr);
#endif
    exit(1);
    }

void Fatal(const char szFormat[], ...)
    {
    va_list ArgList;
    char szStr[4096];

    va_start(ArgList, szFormat);
    vsprintf(szStr, szFormat, ArgList);

    fprintf(stderr, "%s\n", szStr);

    List("\n*** COMMAND LINE ERROR ***\n");
    List("%s\n", szStr);

    exit(1);
    }

void CmdLineError(const char szFormat[], ...)
    {
    va_list ArgList;
    char szStr[4096];

    va_start(ArgList, szFormat);
    vsprintf(szStr, szFormat, ArgList);

    fprintf(stderr, "%s\n", szStr);

    List("\n*** COMMAND LINE ERROR ***\n");
    List("%s\n", szStr);

#if    _DEBUG
    Break();
#endif

    exit(1);
    }

// Remove leading and trailing blanks from string
void TrimBlanks(char szStr[])
    {
    TrimLeadingBlanks(szStr);
    TrimTrailingBlanks(szStr);
    }

void TrimLeadingBlanks(char szStr[])
    {
    size_t n = strlen(szStr);
    while (szStr[0] == ' ')
        {
        memmove(szStr, szStr+1, n);
        szStr[--n] = 0;
        }
    }

void TrimTrailingBlanks(char szStr[])
    {
    size_t n = strlen(szStr);
    while (n > 0 && szStr[n-1] == ' ')
        szStr[--n] = 0;
    }

bool Verbose()
    {
    return true;
    }

SCORE StrToScore(const char *pszStr)
    {
    return (SCORE) atof(pszStr);
    }

const char *ScoreToStr(SCORE Score)
    {
    if (MINUS_INFINITY >= Score)
        return "       *";
// Hack to use "circular" buffer so when called multiple
// times in a printf-like argument list it works OK.
    const int iBufferCount = 16;
    const int iBufferLength = 16;
    static char szStr[iBufferCount*iBufferLength];
    static int iBufferIndex = 0;
    iBufferIndex = (iBufferIndex + 1)%iBufferCount;
    char *pStr = szStr + iBufferIndex*iBufferLength;
    sprintf(pStr, "%8.3g", Score);
    return pStr;
    }

// Left-justified version of ScoreToStr
const char *ScoreToStrL(SCORE Score)
    {
    if (MINUS_INFINITY >= Score)
        return "*";
// Hack to use "circular" buffer so when called multiple
// times in a printf-like argument list it works OK.
    const int iBufferCount = 16;
    const int iBufferLength = 16;
    static char szStr[iBufferCount*iBufferLength];
    static int iBufferIndex = 0;
    iBufferIndex = (iBufferIndex + 1)%iBufferCount;
    char *pStr = szStr + iBufferIndex*iBufferLength;
    sprintf(pStr, "%.3g", Score);
    return pStr;
    }

const char *WCountToStr(WCOUNT wc)
    {
    return ScoreToStr(wc);
    }

const char *WeightToStr(WEIGHT w)
    {
    return ScoreToStr(w);
    }

void StripGaps(char szStr[])
    {
    unsigned uOutPos = 0;
    unsigned uInPos = 0;
    while (char c = szStr[uInPos++])
        if ('-' != c)
            szStr[uOutPos++] = c;
    szStr[uOutPos] = 0;
    }

bool IsValidSignedInteger(const char *Str)
    {
    if (0 == strlen(Str))
        return false;
    if ('+' == *Str || '-' == *Str)
        ++Str;
    while (char c = *Str++)
        if (!isdigit(c))
            return false;
    return true;
    }

bool IsValidInteger(const char *Str)
    {
    if (0 == strlen(Str))
        return false;
    while (char c = *Str++)
        if (!isdigit(c))
            return false;
    return true;
    }

// Is c valid as first character in an identifier?
int isidentf(char c)
    {
    return isalpha(c) || '_' == c;
    }

// Is c valid character in an identifier?
int isident(char c)
    {
    return isalpha(c) || isdigit(c) || '_' == c;
    }

bool IsValidIdentifier(const char *Str)
    {
    if (!isidentf(Str[0]))
        return false;
    while (char c = *Str++)
        if (!isident(c))
            return false;
    return true;
    }

const char *BoundsToStr(BOUNDS b)
    {
    switch (b)
        {
    case GLOBAL:
        return "GLOBAL";
    case LOCAL:
        return "LOCAL";
        }
    assert(false);
    return "?BOUNDS?";
    }

void SetLogFile()
    {
    const char *strFileName = GetOptionalParam("loga");
    if (0 != strFileName)
        g_bListFileAppend = true;
    else
        strFileName = GetOptionalParam("log");
    if (0 == strFileName)
        return;
    strcpy(g_strListFileName, strFileName);
    }

// Get filename, stripping any extension and directory parts.
void NameFromPath(const char szPath[], char szName[], unsigned uBytes)
    {
    if (0 == uBytes)
        return;
    const char *pstrLastSlash = strrchr(szPath, '/');
    const char *pstrLastBackslash = strrchr(szPath, '\\');
    const char *pstrLastDot = strrchr(szPath, '.');
    const char *pstrLastSep = pstrLastSlash > pstrLastBackslash ?
      pstrLastSlash : pstrLastBackslash;
    const char *pstrBegin = pstrLastSep ? pstrLastSep + 1 : szPath;
    const char *pstrEnd = pstrLastDot ? pstrLastDot - 1 : szPath + strlen(szPath);
    unsigned uNameLength = (unsigned) (pstrEnd - pstrBegin + 1);
    if (uNameLength > uBytes - 1)
        uNameLength = uBytes - 1;
    memcpy(szName, pstrBegin, uNameLength);
    szName[uNameLength] = 0;
    }
