// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef GNode2_h
#define GNode2_h

#include "HMM.h"
#include "HMMPath.h"
#include "MSA.h"

class TextFile;

const unsigned GNode_Magic = 0x123123;

class GNode2
    {
public:
    GNode2()
        {
        m_uMagic = GNode_Magic;
        m_ptrParent = 0;
        m_ptrLeft = 0;
        m_ptrRight = 0;
        m_ptrNext = 0;
        m_ptrPrev = 0;
        m_Dist = 0;
        m_uDistCount = 0;
        m_uNodeIndex = uInsane;
        m_uRightChildIndex = uInsane;
        m_uLeftChildIndex = uInsane;
        m_ptrName = 0;
        m_dRawNIC = dInsane;
        m_ptrName = 0;
        }
    virtual ~GNode2();

public:
    void AllocDistVector(unsigned uNodeCount);
    void DeleteFromList(GNode2 *&ptrList);
    void AddToList(GNode2 *&ptrList);
    void Validate() const;
    unsigned GetDepth() const;
    bool IsLeaf() const;
    bool IsRoot() const;
    void DistToFile(TextFile &File);
    void DistFromFile(TextFile &File);
    GNode2 *GetRoot();
    void Clear();

    void SetName(const char *ptrName) { m_ptrName = strdup(ptrName); }
    const char *GetName() const { return m_ptrName; }

    static void ValidateList(const GNode2 *ptrHead);
    static unsigned GetListLength(const GNode2 *ptrHead);

public:
    unsigned m_uMagic;
    char *m_ptrName;
    HMM m_Model;
    MSA m_MSA;
    double m_dRawNIC;
    HMMPath m_MPP;

    GNode2 *m_ptrParent;
    GNode2 *m_ptrLeft;
    GNode2 *m_ptrRight;
    GNode2 *m_ptrNext;
    GNode2 *m_ptrPrev;

    unsigned m_uNodeIndex;
    unsigned m_uRightChildIndex;
    unsigned m_uLeftChildIndex;

    double *m_Dist;
    unsigned m_uDistCount;
    };

#endif    // GNode_h
