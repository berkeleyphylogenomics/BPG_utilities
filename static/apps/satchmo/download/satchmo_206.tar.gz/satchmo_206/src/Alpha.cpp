// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include <ctype.h>

const char szNucleic[]    = "ACGT";
const char szAmino[]    = "ACDEFGHIKLMNPQRSTVWY";
const char szAminoEx[]    = "ACDEFGHIKLMNPQRSTVWYBZX";

static unsigned uReverseNucleic[256];
static unsigned uReverseAmino[256];
// static unsigned uReverseAminoG[256];

unsigned CharToLetterAminoEx[256];

static void InitCharToLetterAminoEx()
    {
    memset(CharToLetterAminoEx, 0xff, sizeof(CharToLetterAminoEx));

    CharToLetterAminoEx['a'] = AX_A;
    CharToLetterAminoEx['c'] = AX_C;
    CharToLetterAminoEx['d'] = AX_D;
    CharToLetterAminoEx['e'] = AX_E;
    CharToLetterAminoEx['f'] = AX_F;
    CharToLetterAminoEx['g'] = AX_G;
    CharToLetterAminoEx['h'] = AX_H;
    CharToLetterAminoEx['i'] = AX_I;
    CharToLetterAminoEx['k'] = AX_K;
    CharToLetterAminoEx['l'] = AX_L;
    CharToLetterAminoEx['m'] = AX_M;
    CharToLetterAminoEx['n'] = AX_N;
    CharToLetterAminoEx['p'] = AX_P;
    CharToLetterAminoEx['q'] = AX_Q;
    CharToLetterAminoEx['r'] = AX_R;
    CharToLetterAminoEx['s'] = AX_S;
    CharToLetterAminoEx['t'] = AX_T;
    CharToLetterAminoEx['v'] = AX_V;
    CharToLetterAminoEx['w'] = AX_W;
    CharToLetterAminoEx['y'] = AX_Y;

    CharToLetterAminoEx['b'] = AX_B;
    CharToLetterAminoEx['z'] = AX_Z;
    CharToLetterAminoEx['x'] = AX_X;

    CharToLetterAminoEx['A'] = AX_A;
    CharToLetterAminoEx['C'] = AX_C;
    CharToLetterAminoEx['D'] = AX_D;
    CharToLetterAminoEx['E'] = AX_E;
    CharToLetterAminoEx['F'] = AX_F;
    CharToLetterAminoEx['G'] = AX_G;
    CharToLetterAminoEx['H'] = AX_H;
    CharToLetterAminoEx['I'] = AX_I;
    CharToLetterAminoEx['K'] = AX_K;
    CharToLetterAminoEx['L'] = AX_L;
    CharToLetterAminoEx['M'] = AX_M;
    CharToLetterAminoEx['N'] = AX_N;
    CharToLetterAminoEx['P'] = AX_P;
    CharToLetterAminoEx['Q'] = AX_Q;
    CharToLetterAminoEx['R'] = AX_R;
    CharToLetterAminoEx['S'] = AX_S;
    CharToLetterAminoEx['T'] = AX_T;
    CharToLetterAminoEx['V'] = AX_V;
    CharToLetterAminoEx['W'] = AX_W;
    CharToLetterAminoEx['Y'] = AX_Y;

    CharToLetterAminoEx['B'] = AX_B;
    CharToLetterAminoEx['Z'] = AX_Z;
    CharToLetterAminoEx['X'] = AX_X;

    CharToLetterAminoEx['.'] = AX_GAP;
    CharToLetterAminoEx['-'] = AX_GAP;
    }

static bool InitReverseTables()
    {
    InitCharToLetterAminoEx();

    memset(uReverseNucleic, 0xff, sizeof(uReverseNucleic));
    memset(uReverseAmino, 0xff, sizeof(uReverseAmino));
//    memset(uReverseAminoG, 0xff, sizeof(uReverseAminoG));

    unsigned n;
    for (n = 0; n < sizeof(szNucleic); ++n)
        {
        unsigned char c = (unsigned char) szNucleic[n];
        if (isalpha(c))
            {
            uReverseNucleic[toupper(c)] = n;
            uReverseNucleic[tolower(c)] = n;
            }
        else
            uReverseNucleic[tolower(c)] = n;
        }

    for (n = 0; n < sizeof(szAmino); ++n)
        {
        unsigned char c = (unsigned char) szAmino[n];
        if (isalpha(c))
            {
            uReverseAmino[toupper(c)] = n;
            uReverseAmino[tolower(c)] = n;
            }
        else
            uReverseAmino[tolower(c)] = n;
        }

//    for (n = 0; n < sizeof(szAminoG); ++n)
//        {
//        unsigned char c = (unsigned char) szAminoG[n];
//        uReverseAminoG[szAminoG[n]] = n;
//        }
    return true;
    }
static bool bInitDone = InitReverseTables();

unsigned GetAlphabetSize(ALPHABET Alpha)
    {
    assert(4 == countof(szNucleic) - 1);
    assert(20 == countof(szAmino) - 1);
//    assert(21 == countof(szAminoG) - 1);

    switch (Alpha)
        {
    case ALPHABET_Nucleic:
        return 4;
    case ALPHABET_Amino:
        return 20;
//    case ALPHABET_AminoG:
//        return 21;
        }
    Quit("GetAlphabetSize:Invalid alphabet %d", Alpha);

// Not reached, return just to suppress compiler warning.
    return 0;
    }

char LetterToCharAmino(unsigned uLetter)
    {
    assert(uLetter < 20);
    return szAmino[uLetter];
    }

char LetterToCharAminoEx(unsigned uLetter)
    {
    assert(uLetter < 23);
    return szAminoEx[uLetter];
    }

char LetterToCharNucleic(unsigned uLetter)
    {
    assert(uLetter < 4);
    return szNucleic[uLetter];
    }

char LetterToChar(unsigned uLetter, ALPHABET Alpha)
    {
    assert(uLetter < GetAlphabetSize(Alpha));

    switch (Alpha)
        {
    case ALPHABET_Nucleic:
        return szNucleic[uLetter];

    case ALPHABET_Amino:
        return szAmino[uLetter];

//    case ALPHABET_AminoG:
//        return szAminoG[uLetter];
        }

    Quit("LetterToChar:Invalid alphabet, %d", Alpha);

// Not reached, return just to suppress compiler warning.
    return '?';
    }

unsigned CharToLetterNucleic(char c)
    {
    unsigned uLetter = uReverseNucleic[(unsigned char) c];
    assert(uLetter < 4);
    return uLetter;
    }

unsigned CharToLetterAmino(char c)
    {
    unsigned uLetter = uReverseAmino[(unsigned char) c];
    assert(uLetter < 20);
    return uLetter;
    }

//unsigned CharToLetterAminoG(char c)
//    {
//    unsigned uLetter = uReverseAminoG[(unsigned char) c];
//    assert(uLetter < 21);
//    return uLetter;
//    }

unsigned CharToLetter(char c, ALPHABET Alpha)
    {
    switch (Alpha)
        {
    case ALPHABET_Nucleic:
        return CharToLetterNucleic(c);
    case ALPHABET_Amino:
        return CharToLetterAmino(c);
//    case ALPHABET_AminoG:
//        return CharToLetterAminoG(c);
    default:
      return CharToLetterAmino(c);
        }
    Quit("CharToLetter:Invalid alphabet %d", Alpha);

// Not reached, return statement to suppress compiler warning.
    return 0;
    }

const char *AlphabetName(ALPHABET Alpha)
    {
    switch (Alpha)
        {
    case ALPHABET_Nucleic:
        return "Nucleic";
    case ALPHABET_Amino:
        return "Amino";
//    case ALPHABET_AminoG:
//        return "AminoG";
        }
    Quit("AlphabetName(%d)", Alpha);

// Not reached, return statement to suppress compiler warning.
    return "?AlphabetName?";
    }

bool IsValidAmino(char c)
    {
    return 0 != strchr(szAmino, toupper(c));
    }

bool IsGap(char c)
    {
    return '-' == c || '.' == c;
    }

bool IsWildcard(char c)
    {
    c = toupper(c);
    return 'X' == c || 'B' == c || 'Z' == c;
    }

bool StrHasAmino(const char *Str)
    {
    while (char c = *Str++)
        if (IsValidAmino(c))
            return true;
    return false;
    }

bool StrHasGap(const char *Str)
    {
    while (char c = *Str++)
        if (IsGap(c))
            return true;
    return false;
    }

char UnalignChar(char c)
    {
    if (isalpha(c))
        return tolower(c);
    else if ('-' == c || '.' == c)
        return '.';
    assert(false);
    return 0;
    }

bool IsAlignedChar(char c)
    {
    return (isalpha(c) && isupper(c)) || '-' == c;
    }

