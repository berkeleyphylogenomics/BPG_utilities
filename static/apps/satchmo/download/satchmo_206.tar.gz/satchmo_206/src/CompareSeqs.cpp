// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

/***
Pairwise identity, defined over aligned positions as:

    (number of identical positions) / (number of positions)

Value is in range 0.0 to 1.0.
***/

#include "lobster.h"
#include "MSA.h"

double PairwiseIdentityAlignedOnly(const MSA &a, unsigned uSeqIndex1,
  unsigned uSeqIndex2)
    {
    unsigned uLength = a.GetColCount();

    unsigned uAlignedCount = 0;
    unsigned uIdentCount = 0;
    for (unsigned n = 0; n < uLength; ++n)
        {
        char c1 = a.GetChar(uSeqIndex1, n);
        char c2 = a.GetChar(uSeqIndex2, n);
        if (isupper(c1))
            {
            ++uAlignedCount;
            assert(IsGap(c2) || isupper(c2));
            if (c1 == c2)
                ++uIdentCount;
            }
        }
    assert(uIdentCount <= uAlignedCount);
    if (0 == uAlignedCount)
        return 0.0;
    double dDist = (double) uIdentCount / (double) uAlignedCount;
    assert(dDist >= 0.0 && dDist <= 1.0);
    return dDist;
    }

double PairwiseIdentityAll(const MSA &a, unsigned uSeqIndex1,
  unsigned uSeqIndex2)
    {
    unsigned uColCount = a.GetColCount();

    unsigned uIdentCount = 0;
    unsigned uCount = 0;
    for (unsigned n = 0; n < uColCount; ++n)
        {
        char c1 = a.GetChar(uSeqIndex1, n);
        char c2 = a.GetChar(uSeqIndex2, n);
        if (IsGap(c1) || IsGap(c2))
            continue;
        ++uCount;
        if (toupper(c1) == toupper(c2))
            ++uIdentCount;
        }
    assert(uIdentCount <= uCount);
    if (0 == uCount)
        return 0.0;
    double dDist = (double) uIdentCount / (double) uCount;
    assert(dDist >= 0.0 && dDist <= 1.0);
    return dDist;
    }
