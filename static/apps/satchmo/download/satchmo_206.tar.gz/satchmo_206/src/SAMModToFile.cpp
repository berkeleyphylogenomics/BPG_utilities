// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "SAMMod.h"
#include "TextFile.h"

void SAMMod::ToFile(TextFile &File) const
    {
    File.PutString("MODEL\n");
    File.PutString("alphabet protein\n");

    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        if (0 == uNodeIndex)
            File.PutFormat("Begin\n");
        else if (m_uNodeCount - 1 == uNodeIndex)
            File.PutFormat("End\n");
        else
            File.PutFormat(" %u\n", uNodeIndex);
        const SAMNode &Node = GetNode(uNodeIndex);
        NodeToFile(File, Node);
        }
    File.PutString("ENDMODEL\n");
    }

void SAMMod::NodeToFile(TextFile &File, const SAMNode &Node) const
    {
    File.PutFormat("%8.6f %8.6f %8.6f\n", Node.m_probDD, Node.m_probMD, Node.m_probID);
    File.PutFormat("%8.6f %8.6f %8.6f\n", Node.m_probDM, Node.m_probMM, Node.m_probIM);
    File.PutFormat("%8.6f %8.6f %8.6f\n", Node.m_probDI, Node.m_probMI, Node.m_probII);

    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        {
        File.PutFormat("%8.6f", Node.m_probMatchEmit[uLetter]);
        if (0 == (uLetter+1)%5)
            File.PutString("\n");
        else
            File.PutString(" ");
        }
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        {
        File.PutFormat("%8.6f", Node.m_probInsertEmit[uLetter]);
        if (0 == (uLetter+1)%5)
            File.PutString("\n");
        else
            File.PutString(" ");
        }
    }
