// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Ckp.h"
#include "DataBuffer.h"

void Ckp::CkpOrderToAlpha(const double dPBFreq[], double dAlphaFreq[])
    {
    dAlphaFreq[AX_A] = dPBFreq[PBA_A];
    dAlphaFreq[AX_C] = dPBFreq[PBA_C];
    dAlphaFreq[AX_D] = dPBFreq[PBA_D];
    dAlphaFreq[AX_E] = dPBFreq[PBA_E];
    dAlphaFreq[AX_F] = dPBFreq[PBA_F];
    dAlphaFreq[AX_G] = dPBFreq[PBA_G];
    dAlphaFreq[AX_H] = dPBFreq[PBA_H];
    dAlphaFreq[AX_I] = dPBFreq[PBA_I];
    dAlphaFreq[AX_K] = dPBFreq[PBA_K];
    dAlphaFreq[AX_L] = dPBFreq[PBA_L];
    dAlphaFreq[AX_M] = dPBFreq[PBA_M];
    dAlphaFreq[AX_N] = dPBFreq[PBA_N];
    dAlphaFreq[AX_P] = dPBFreq[PBA_P];
    dAlphaFreq[AX_Q] = dPBFreq[PBA_Q];
    dAlphaFreq[AX_R] = dPBFreq[PBA_R];
    dAlphaFreq[AX_S] = dPBFreq[PBA_S];
    dAlphaFreq[AX_T] = dPBFreq[PBA_T];
    dAlphaFreq[AX_V] = dPBFreq[PBA_V];
    dAlphaFreq[AX_W] = dPBFreq[PBA_W];
    dAlphaFreq[AX_Y] = dPBFreq[PBA_Y];
    }

void Ckp::AlphaToCkpOrder(const double dAlphaFreq[], double dPBFreq[])
    {
    dPBFreq[PBA_A] = dAlphaFreq[AX_A];
    dPBFreq[PBA_C] = dAlphaFreq[AX_C];
    dPBFreq[PBA_D] = dAlphaFreq[AX_D];
    dPBFreq[PBA_E] = dAlphaFreq[AX_E];
    dPBFreq[PBA_F] = dAlphaFreq[AX_F];
    dPBFreq[PBA_G] = dAlphaFreq[AX_G];
    dPBFreq[PBA_H] = dAlphaFreq[AX_H];
    dPBFreq[PBA_I] = dAlphaFreq[AX_I];
    dPBFreq[PBA_K] = dAlphaFreq[AX_K];
    dPBFreq[PBA_L] = dAlphaFreq[AX_L];
    dPBFreq[PBA_M] = dAlphaFreq[AX_M];
    dPBFreq[PBA_N] = dAlphaFreq[AX_N];
    dPBFreq[PBA_P] = dAlphaFreq[AX_P];
    dPBFreq[PBA_Q] = dAlphaFreq[AX_Q];
    dPBFreq[PBA_R] = dAlphaFreq[AX_R];
    dPBFreq[PBA_S] = dAlphaFreq[AX_S];
    dPBFreq[PBA_T] = dAlphaFreq[AX_T];
    dPBFreq[PBA_V] = dAlphaFreq[AX_V];
    dPBFreq[PBA_W] = dAlphaFreq[AX_W];
    dPBFreq[PBA_Y] = dAlphaFreq[AX_Y];
    }

Ckp::Ckp()
    {
    m_uPosCount = 0;
    m_pstrQuery = 0;
    m_Pos = 0;
    }

Ckp::~Ckp()
    {
    Clear();
    }

void Ckp::Clear()
    {
    m_uPosCount = 0;
    delete[] m_pstrQuery;
    delete[] m_Pos;
    }

void Ckp::SetSize(unsigned uPosCount)
    {
    Clear();
    m_uPosCount = uPosCount;
    m_pstrQuery = new char [uPosCount+1];
    m_Pos = new CkpPos[uPosCount];
    }

CkpPos &Ckp::GetPos(unsigned uPosIndex) const
    {
    if (uPosIndex >= m_uPosCount)
        Quit("Ckp::GetPos(%u), invalid index", uPosIndex);
    return m_Pos[uPosIndex];
    }

void Ckp::FromBuffer(DataBuffer &Data)
    {
    Clear();
    unsigned uPosCount;
    Data.Get(0, &uPosCount, 4);
    SetSize(uPosCount);
    Data.Get(4, m_pstrQuery, uPosCount);
    m_pstrQuery[uPosCount] = 0;
    unsigned uOffset = 4 + uPosCount;
    const unsigned uEntryBytes = MAX_ALPHA*sizeof(double);
    for (unsigned uPosIndex = 0; uPosIndex < uPosCount; ++uPosIndex)
        {
        double dFreq[MAX_ALPHA];
        Data.Get(uOffset, dFreq, uEntryBytes);
        CkpPos &CP = m_Pos[uPosIndex];
        CkpOrderToAlpha(dFreq, CP.dFreq);
        uOffset += uEntryBytes;
        }
    }

void Ckp::ToBuffer(DataBuffer &Data) const
    {
    const unsigned uPosCount = GetPosCount();
    Data.Clear();
    Data.SetSize(GetBufferSize());
    Data.Put(0, &m_uPosCount, 4);
    Data.Put(4, m_pstrQuery, uPosCount);
    unsigned uOffset = 4 + uPosCount;
    const unsigned uEntryBytes = MAX_ALPHA*sizeof(double);
    for (unsigned uPosIndex = 0; uPosIndex < uPosCount; ++uPosIndex)
        {
        double dFreq[MAX_ALPHA];
        const CkpPos &CP = GetPos(uPosIndex);
        AlphaToCkpOrder(CP.dFreq, dFreq);
        Data.Put(uOffset, dFreq, uEntryBytes);
        uOffset += uEntryBytes;
        }
    }

static const char *LocalFormat(double d)
    {
    if (d < 0.00001 && d > -0.00001)
        return "     0";
    static char szStr[16];
    sprintf(szStr, "%6.4f", d);
    return szStr;
    }

void Ckp::ListMe() const
    {
    List("Length %u\n", m_uPosCount);
    List(">Query\n");
    const unsigned uBlockCount = (m_uPosCount + 79)/80;
    for (unsigned uBlock = 0; uBlock < uBlockCount; ++uBlock)
        {
        unsigned uLetters = m_uPosCount - uBlock*80;
        if (uLetters > 80)
            uLetters = 80;
        for (unsigned uLetter = 0; uLetter < uLetters; ++uLetter)
            List("%c", m_pstrQuery[uBlock*80 + uLetter]);
        List("\n");
        }
    List("\n");
    List("Pos ");
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        List("      %c", LetterToCharAmino(uLetter));
    List("   Sum\n");
    for (unsigned uPosIndex = 0; uPosIndex < m_uPosCount; ++uPosIndex)
        {
        List("%3u ", uPosIndex);
        unsigned uBiggestLetter = MAX_ALPHA;
        double dSum = 0;
        double dBiggestFreq = 0.0;
        const CkpPos &PP = GetPos(uPosIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            {
            const double dFreq = PP.dFreq[uLetter];
            dSum += dFreq;
            if (dFreq > dBiggestFreq)
                {
                uBiggestLetter = uLetter;
                dBiggestFreq = dFreq;
                }
            }
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            {
            char s[16];
            strcpy(s, LocalFormat(PP.dFreq[uLetter]));
            if (uLetter == uBiggestLetter)
                s[0] = '*';
            List(" %s", s);
            }
        List("  %s\n", LocalFormat(dSum));
        }
    }

unsigned Ckp::GetBufferSize() const
    {
    return 4 + m_uPosCount*sizeof(char) + m_uPosCount*sizeof(CkpPos);
    }
