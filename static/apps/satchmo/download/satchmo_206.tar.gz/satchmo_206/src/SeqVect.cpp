// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "SeqVect.h"
#include "TextFile.h"
#include "MSA.h"

SeqVect::~SeqVect()
    {
    Clear();
    }

void SeqVect::Clear()
    {
    for (size_t n = 0; n < size(); ++n)
        delete (*this)[n];
    }

void SeqVect::ToFASTAFile(TextFile &File) const
    {
    for (;;)
        {
        Seq *ptrSeq = new Seq;
        ptrSeq->ToFASTAFile(File);
        }
    }

void SeqVect::FromFASTAFile(TextFile &File)
    {
    Clear();

    for (;;)
        {
        Seq *ptrSeq = new Seq;
        bool bEof = ptrSeq->FromFASTAFile(File);
        if (bEof)
            {
            if (0 == size())
                Quit("Empty FASTA file %s", File.GetFileName());
            delete ptrSeq;
            return;
            }
        push_back(ptrSeq);
        }
    }

void SeqVect::PadToMSA(MSA &msa)
    {
    msa.SetAlphabet(ALPHABET_Amino);
    unsigned uSeqCount = Length();
    if (0 == uSeqCount)
        {
        msa.Clear();
        return;
        }

    unsigned uLongestSeqLength = 0;
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        Seq *ptrSeq = at(uSeqIndex);
        unsigned uColCount = ptrSeq->Length();
        if (uColCount > uLongestSeqLength)
            uLongestSeqLength = uColCount;
        }
    msa.SetSize(uSeqCount, uLongestSeqLength);
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        Seq *ptrSeq = at(uSeqIndex);
        msa.SetSeqName(uSeqIndex, ptrSeq->GetName());
        unsigned uColCount = ptrSeq->Length();
        unsigned uColIndex;
        for (uColIndex = 0; uColIndex < uColCount; ++uColIndex)
            {
            char c = ptrSeq->at(uColIndex);
            msa.SetChar(uSeqIndex, uColIndex, c);
            }
        while (uColIndex < uLongestSeqLength)
            msa.SetChar(uSeqIndex, uColIndex++, '.');
        }
    }

void SeqVect::Copy(const SeqVect &rhs)
    {
    clear();
    unsigned uSeqCount = rhs.Length();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        Seq *ptrSeq = rhs.at(uSeqIndex);
        Seq *ptrSeqCopy = new Seq;
        ptrSeqCopy->Copy(*ptrSeq);
        push_back(ptrSeqCopy);
        }
    }

void SeqVect::StripGaps()
    {
    unsigned uSeqCount = Length();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        Seq *ptrSeq = at(uSeqIndex);
        ptrSeq->StripGaps();
        }
    }

void SeqVect::ToUpper()
    {
    unsigned uSeqCount = Length();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        Seq *ptrSeq = at(uSeqIndex);
        ptrSeq->ToUpper();
        }
    }
