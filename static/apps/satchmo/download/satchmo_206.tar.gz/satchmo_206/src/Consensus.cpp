// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "Seq.h"

void Consensus(const MSA &msaTest, const MSA &msaRef, MSA &msaConsensus)
    {
    int *iRefMapA;
    int *iRefMapB;
    int *iTestMapA;
    int *iTestMapB;

    const unsigned uRefSeqIndexA = 0;
    const unsigned uRefSeqIndexB = 1;

    const char *strNameA = msaRef.GetSeqName(uRefSeqIndexA);
    const char *strNameB = msaRef.GetSeqName(uRefSeqIndexB);

    unsigned uTestSeqIndexA;
    unsigned uTestSeqIndexB;

    bool bFound = msaTest.GetSeqIndex(strNameA, &uTestSeqIndexA);
    if (!bFound)
        Quit("Sequence %s not found", strNameA);

    bFound = msaTest.GetSeqIndex(strNameB, &uTestSeqIndexB);
    if (!bFound)
        Quit("Sequence %s not found", strNameB);

    MakePairMaps(msaTest, uTestSeqIndexA, uTestSeqIndexB, msaRef, uRefSeqIndexA,
      uRefSeqIndexB, &iTestMapA, &iTestMapB, &iRefMapA, &iRefMapB);

    const int iLengthA = (int) msaRef.GetSeqLength(uRefSeqIndexA);
    const int iLengthB = (int) msaRef.GetSeqLength(uRefSeqIndexB);

    const unsigned uColCount = msaRef.GetColCount();
    msaConsensus.Clear();
    msaConsensus.SetSize(2, uColCount);
    msaConsensus.SetSeqName(0, strNameA);
    msaConsensus.SetSeqName(1, strNameB);

    Seq seqRefA;
    Seq seqRefB;

    msaRef.GetSeq(uRefSeqIndexA, seqRefA);
    msaRef.GetSeq(uRefSeqIndexB, seqRefB);

    unsigned uColIndex = 0;
    int iPosA = 0;
    int iPosB = 0;
    while (iPosA < iLengthA)
        {
        int iRefPosB = iRefMapA[iPosA];
        if (iRefPosB != -1)
            {
            while (iPosB < iRefPosB)
                {
                char cB = seqRefB[iPosB];
                msaConsensus.SetChar(0, uColIndex, '.');
                msaConsensus.SetChar(1, uColIndex, tolower(cB));
                ++iPosB;
                ++uColIndex;
                }
            char cA = seqRefA[iPosA];
            char cB = seqRefB[iPosB];
            int iTestPosB = iTestMapA[iPosA];
            if (iRefPosB == iTestPosB)
                {
                msaConsensus.SetChar(0, uColIndex, toupper(cA));
                msaConsensus.SetChar(1, uColIndex, toupper(cB));
                }
            else
                {
                msaConsensus.SetChar(0, uColIndex, tolower(cA));
                msaConsensus.SetChar(1, uColIndex, tolower(cB));
                }
            ++uColIndex;
            ++iPosA;
            ++iPosB;
            }
        else
            {
            char cA = seqRefA[iPosA];
            msaConsensus.SetChar(0, uColIndex, tolower(cA));
            msaConsensus.SetChar(1, uColIndex, '.');
            ++iPosA;
            ++uColIndex;
            }
        }
    while (iPosB < iLengthB)
        {
        char cB = seqRefB[iPosB];
        msaConsensus.SetChar(0, uColIndex, '.');
        msaConsensus.SetChar(1, uColIndex, tolower(cB));
        ++iPosB;
        ++uColIndex;
        }

    delete[] iRefMapA;
    delete[] iRefMapB;
    delete[] iTestMapA;
    delete[] iTestMapB;
    }
