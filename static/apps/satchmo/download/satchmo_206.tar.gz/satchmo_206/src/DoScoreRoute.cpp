// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "MSA.h"
#include "HMM.h"
#include "HMMPath.h"

void DoScoreRoute(const char *strPathFileName, const char *strModelFileName,
  const char *strTargetFileName)
    {
    TextFile PathFile(strPathFileName);
    HMMPath Route;
    Route.FromFile(PathFile);

    TextFile ModelFile(strModelFileName);
    HMM Model;
    Model.FromFile(ModelFile);

    TextFile TargetFile(strTargetFileName);
    MSA a;
    a.FromFile(TargetFile);
    a.AlignByCase();
    a.BuildPillars();

    SCORE scorePath = Model.ScoreRouteAln(Route, a);
    List("Score %s\n", ScoreToStr(scorePath));
    }
