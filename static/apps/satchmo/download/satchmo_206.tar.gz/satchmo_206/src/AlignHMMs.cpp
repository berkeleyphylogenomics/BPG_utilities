// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "MSA.h"
#include "Seq.h"
#include "PWPath.h"

#define    VERBOSE    0

static void AppendDelete(const MSA &msaA, unsigned &uColIndexA, unsigned uSeqCountB,
  MSA &msaCombined, unsigned &uColIndexCombined)
    {
#if    VERBOSE
    List("AppendDelete ColIxA=%u ColIxCmb=%u\n",
      uColIndexA, uColIndexCombined);
#endif
    const unsigned uSeqCountA = msaA.GetSeqCount();
    const unsigned uLengthA = msaA.GetColCount();
    assert(uColIndexA < uLengthA);
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCountA; ++uSeqIndex)
        {
        char c = msaA.GetChar(uSeqIndex, uColIndexA);
        assert(IsAlignedChar(c));
        msaCombined.SetChar(uSeqIndex, uColIndexCombined, c);
        }
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCountB; ++uSeqIndex)
        msaCombined.SetChar(uSeqCountA + uSeqIndex, uColIndexCombined, '-');

    ++uColIndexCombined;
    ++uColIndexA;
    }

static void AppendInsert(const MSA &msaB, unsigned &uColIndexB, unsigned uSeqCountA, 
  MSA &msaCombined, unsigned &uColIndexCombined)
    {
#if    VERBOSE
    List("AppendInsert ColIxB=%u ColIxCmb=%u\n",
      uColIndexB, uColIndexCombined);
#endif
    const unsigned uSeqCountB = msaB.GetSeqCount();
    const unsigned uLengthB = msaB.GetColCount();
    assert(uColIndexB < uLengthB);
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCountA; ++uSeqIndex)
        msaCombined.SetChar(uSeqIndex, uColIndexCombined, '-');
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCountB; ++uSeqIndex)
        {
        char c = msaB.GetChar(uSeqIndex, uColIndexB);
        assert(IsAlignedChar(c));
        msaCombined.SetChar(uSeqCountA + uSeqIndex, uColIndexCombined, c);
        }

    ++uColIndexCombined;
    ++uColIndexB;
    }

static void AppendTplInserts(const MSA &msaA, unsigned &uColIndexA, unsigned uColCountA,
  const MSA &msaB, unsigned &uColIndexB, unsigned uColCountB, MSA &msaCombined,
  unsigned &uColIndexCombined)
    {
#if    VERBOSE
    List("AppendTplInserts ColIxA=%u CntA=%u ColIxB=%u CntB=%u ColIxCmb=%u\n",
      uColIndexA, uColCountA, uColIndexB, uColCountB, uColIndexCombined);
#endif
    const unsigned uSeqCountA = msaA.GetSeqCount();
    const unsigned uSeqCountB = msaB.GetSeqCount();
    const unsigned uLengthA = msaA.GetColCount();
    const unsigned uLengthB = msaB.GetColCount();
    assert(uColCountA < uLengthA);
    if (uColCountA > 0)
        {
        assert(uColIndexA < uLengthA);
        assert(uColIndexA + uColCountA <= uLengthA);
        }
    assert(uColCountB < uLengthB);
    if (uColCountB > 0)
        {
        assert(uColIndexB < uLengthB);
        assert(uColIndexB + uColCountB <= uLengthB);
        }

    unsigned uNewColCount = uColCountA;
    if (uColCountB > uNewColCount)
        uNewColCount = uColCountB;

    for (unsigned n = 0; n < uColCountA; ++n)
        {
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCountA; ++uSeqIndex)
            {
            char c = msaA.GetChar(uSeqIndex, uColIndexA + n);
            c = UnalignChar(c);
            msaCombined.SetChar(uSeqIndex, uColIndexCombined + n, c);
            }
        }
    for (unsigned n = uColCountA; n < uNewColCount; ++n)
        {
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCountA; ++uSeqIndex)
            msaCombined.SetChar(uSeqIndex, uColIndexCombined + n, '.');
        }

    for (unsigned n = 0; n < uColCountB; ++n)
        {
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCountB; ++uSeqIndex)
            {
            char c = msaB.GetChar(uSeqIndex, uColIndexB + n);
            c = UnalignChar(c);
            msaCombined.SetChar(uSeqCountA + uSeqIndex, uColIndexCombined + n, c);
            }
        }
    for (unsigned n = uColCountB; n < uNewColCount; ++n)
        {
        for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCountB; ++uSeqIndex)
            msaCombined.SetChar(uSeqCountA + uSeqIndex, uColIndexCombined + n, '.');
        }

    uColIndexCombined += uNewColCount;
    uColIndexA += uColCountA;
    uColIndexB += uColCountB;
    }

static void AppendMatch(const MSA &msaA, unsigned &uColIndexA, const MSA &msaB,
  unsigned &uColIndexB, MSA &msaCombined, unsigned &uColIndexCombined)
    {
#if    VERBOSE
    List("AppendMatch ColIxA=%u ColIxB=%u ColIxCmb=%u\n",
      uColIndexA, uColIndexB, uColIndexCombined);
#endif
    const unsigned uSeqCountA = msaA.GetSeqCount();
    const unsigned uSeqCountB = msaB.GetSeqCount();

    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCountA; ++uSeqIndex)
        {
        char c = msaA.GetChar(uSeqIndex, uColIndexA);
        assert(IsAlignedChar(c));
        msaCombined.SetChar(uSeqIndex, uColIndexCombined, c);
        }
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCountB; ++uSeqIndex)
        {
        char c = msaB.GetChar(uSeqIndex, uColIndexB);
        assert(IsAlignedChar(c));
        msaCombined.SetChar(uSeqCountA + uSeqIndex, uColIndexCombined, c);
        }
    ++uColIndexA;
    ++uColIndexB;
    ++uColIndexCombined;
    }

void AlignHMMs(const HMM &hmmA, const HMM &hmmB, const PWPath &Path, MSA &msaCombined)
    {
    msaCombined.Clear();

    const MSA &msaA = hmmA.GetTemplate();
    const MSA &msaB = hmmB.GetTemplate();
#if    VERBOSE
    List("AlignHMMs\n");
    List("Template A:\n");
    msaA.ListMe();
    List("Template B:\n");
    msaB.ListMe();
#endif

    const unsigned uSeqCountA = msaA.GetSeqCount();
    const unsigned uSeqCountB = msaB.GetSeqCount();
    const unsigned uSeqCountCombined = uSeqCountA + uSeqCountB;
    const unsigned uNodeCountA = hmmA.GetNodeCount();
    const unsigned uNodeCountB = hmmB.GetNodeCount();
    const unsigned uColCountA = msaA.GetColCount();
    const unsigned uColCountB = msaB.GetColCount();

    msaCombined.SetAlphabet(ALPHABET_Amino);
    msaCombined.SetSeqCount(uSeqCountCombined);

// Copy sequence names into combined MSA
    for (unsigned n = 0; n < uSeqCountA; ++n)
        msaCombined.SetSeqName(n, msaA.GetSeqName(n));
    for (unsigned n = 0; n < uSeqCountB; ++n)
        msaCombined.SetSeqName(uSeqCountA + n,
          msaB.GetSeqName(n));

    unsigned uColIndexA = 0;
    unsigned uColIndexB = 0;
    unsigned uColIndexCombined = 0;
    const unsigned uEdgeCount = Path.GetEdgeCount();
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const PWEdge &Edge = Path.GetEdge(uEdgeIndex);
#if    VERBOSE
        List("\nEdge %u %c%u.%u\n",
          uEdgeIndex,
          Edge.cType,
          Edge.uPrefixLengthA,
          Edge.uPrefixLengthB);
#endif
        const char cType = Edge.cType;

/***
To create a combined alignment that includes complete sequences, we have
to include columns in the template alignments that were considered to be
inserts when the HMMs were built ("template inserts").

The following diagram illustrates the situation for one of the templates (A).

    uColIndexA is the index of the next column to be output to the
    combined alignment.

    uNodeIndexA = uPrefixLengthA - 1 is the node index of the HMM node to
    be output in the next column to be added to the combined alignment.

    uTplColIndexA is the column index in template A that was used
    to construct the match state in node uNodeIndexA.

            last column output to combined alignment (uColIndexA - 1)
            |    uColIndexA
            |    |        uTplColIndexA
            |    |        |
            v    v        v
Col            5    6    7    8
Template    M    i    i    M

Here, there are two columns of inserts. The number of template insert
columns is:
    uColCountA = uTplColIndexA - uColIndexA
***/
        const unsigned uPrefixLengthA = Edge.uPrefixLengthA;
        unsigned uColCountA = 0;
        if (uPrefixLengthA > 0)
            {
            const unsigned uNodeIndexA = uPrefixLengthA - 1;
            const unsigned uTplColIndexA =
              hmmA.NodeIndexToTemplateColIndex(uNodeIndexA);
#if VERBOSE
            List("NodeIxToTplIxA(%u) = %u\n", uPrefixLengthA-1, uTplColIndexA);
#endif
            if (uTplColIndexA > uColIndexA)
                uColCountA = uTplColIndexA - uColIndexA;
            }

        const unsigned uPrefixLengthB = Edge.uPrefixLengthB;
        unsigned uColCountB = 0;
        if (uPrefixLengthB > 0)
            {
            const unsigned uNodeIndexB = uPrefixLengthB - 1;
            const unsigned uTplColIndexB =
              hmmB.NodeIndexToTemplateColIndex(uNodeIndexB);
#if VERBOSE
            List("NodeIxToTplIxB(%u) = %u\n", uPrefixLengthB-1, uTplColIndexB);
#endif
            if (uTplColIndexB > uColIndexB)
                uColCountB = uTplColIndexB - uColIndexB;
            }

        AppendTplInserts(msaA, uColIndexA, uColCountA, msaB, uColIndexB, uColCountB,
          msaCombined, uColIndexCombined);

        switch (cType)
            {
        case 'M':
            {
            assert(uPrefixLengthA > 0);
            assert(uPrefixLengthB > 0);
            const unsigned uColA = hmmA.NodeIndexToTemplateColIndex(uPrefixLengthA - 1);
            const unsigned uColB = hmmB.NodeIndexToTemplateColIndex(uPrefixLengthB - 1);
            assert(uColIndexA == uColA);
            assert(uColIndexB == uColB);
            AppendMatch(msaA, uColIndexA, msaB, uColIndexB, msaCombined,
              uColIndexCombined);
            break;
            }
        case 'D':
            {
            assert(uPrefixLengthA > 0);
            const unsigned uColA = hmmA.NodeIndexToTemplateColIndex(uPrefixLengthA - 1);
            assert(uColIndexA == uColA);
            AppendDelete(msaA, uColIndexA, uSeqCountB, msaCombined, uColIndexCombined);
            break;
            }
        case 'I':
            {
            assert(uPrefixLengthB > 0);
            const unsigned uColB = hmmB.NodeIndexToTemplateColIndex(uPrefixLengthB - 1);
            assert(uColIndexB == uColB);
            AppendInsert(msaB, uColIndexB, uSeqCountA, msaCombined, uColIndexCombined);
            break;
            }
        default:
            assert(false);
            }
        }
    unsigned uInsertColCountA = msaA.GetColCount() - uColIndexA;
    unsigned uInsertColCountB = msaB.GetColCount() - uColIndexB;
    AppendTplInserts(msaA, uColIndexA, uInsertColCountA, msaB, uColIndexB,
      uInsertColCountB, msaCombined, uColIndexCombined);

// Sanity check
    for (unsigned n = 0; n < uSeqCountA; ++n)
        {
        Seq seqA;
        Seq seqCombined;

        msaA.GetSeq(n, seqA);
        msaCombined.GetSeq(n, seqCombined);
        if (!seqA.EqIgnoreCase(seqCombined))
            {
            msaCombined.ListMe();
            List("SeqA:        ");
            seqA.ListMe();
            List("SeqCombined: "); 
            seqCombined.ListMe();
            Quit("AlignHMMs sanity check");
            }
        }
    for (unsigned n = 0; n < uSeqCountB; ++n)
        {
        Seq seqB;
        Seq seqCombined;

        msaB.GetSeq(n, seqB);
        msaCombined.GetSeq(uSeqCountA + n, seqCombined);
        if (!seqB.EqIgnoreCase(seqCombined))
            {
            msaCombined.ListMe();
            List("SeqB:        ");
            seqB.ListMe();
            List("SeqCombined: "); 
            seqCombined.ListMe();
            Quit("AlignHMMs sanity check");
            }
        }
    }
