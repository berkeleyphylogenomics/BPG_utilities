// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include <time.h>

/***
On 2.5 GHz processor, estimated times for Satchmo algorithm,
using Viterbi algorithm, expressed as multiplier of N^2 L^2.
v1 is version 1 (not implemented in this code).
v2 is full version 2 implementation with break matrices.
nobm is space-saving approximation with no break matrices.
nobmv1 is space- and time-saving approximation similar to
version 1.

    v1        1.4e-6
    v2        3e-6
    nobm    2.3e-6
    nobmv1    1e-6

Estimated memory is:
    v2        10*sizeof(SCORE)*L^2

With nobm, memory is harder to estimate, but small enough
that it is unlikely to be a problem.
***/

char *SecsToHHMMSS(long lSecs, char szStr[])
    {
    long HH = lSecs/(60*60);
    lSecs -= HH*60*60;
    long MM = lSecs/60;
    long SS = lSecs - MM*60;
    sprintf(szStr, "%02ld:%02ld:%02ld", HH, MM, SS);
    return szStr;
    }

const char *ElapsedTimeAsString()
    {
    long tNow = (long) time(0);
    long tElapsed = tNow - g_tStart;
    static char szStr[64];
    return SecsToHHMMSS(tElapsed, szStr);
    }

double EstMB_v2(unsigned N, unsigned L)
    {
    const unsigned MSAv2 = 10*L*L*sizeof(SCORE);
    return (N*MSAv2)/1000000.0;
    }

double EstSecs_v2(unsigned N, unsigned L, double dGHz)
    {
    double dL = (double) L;
    double dN = (double) N;
    double dN2L2 = dL*dL*dN*dN;
    double x = 3e-6;
#ifndef    WIN32
    x /= 1.5;
#endif
    return (x*dN2L2)*(2.5/dGHz);
    }

double EstSecs_nobm(unsigned N, unsigned L, double dGHz)
    {
    double dL = (double) L;
    double dN = (double) N;
    double dN2L2 = dL*dL*dN*dN;
    double x = 2.3e-6;
#ifndef    WIN32
    x /= 1.5;
#endif
    return (x*dN2L2)*(2.5/dGHz);
    }

double EstSecs_nobmv1(unsigned N, unsigned L, double dGHz)
    {
    double dL = (double) L;
    double dN = (double) N;
    double dN2L2 = dL*dL*dN*dN;
    double x = 1e-6;
#ifndef    WIN32
    x /= 1.5;
#endif
    return (x*dN2L2)*(2.5/dGHz);
    }
