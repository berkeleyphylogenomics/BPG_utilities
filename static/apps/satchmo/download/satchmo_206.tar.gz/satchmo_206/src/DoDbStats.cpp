// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "MSA.h"
#include "SeqVect.h"

void DoDbStats(const char *strFileName)
    {
    TextFile File(strFileName);
    SeqVect v;
    v.FromFASTAFile(File);
    unsigned uTotalLength = 0;
    const unsigned uSeqCount = v.Length();
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        Seq *s = v[uSeqIndex];
        s->StripGaps();
        uTotalLength += s->Length();
        }
    unsigned uSeqLength = uSeqCount > 0 ? uTotalLength/uSeqCount : 0;
    printf("%s: %u seqs, average length %u\n",
      strFileName, uSeqCount, uSeqLength);

    double dGHz = GetCPUGHz();
    const unsigned N = uSeqCount;
    const unsigned L = uSeqLength;
    double dMB_v2 = EstMB_v2(N, L);
    long lSecs_v2 = (long) EstSecs_v2(N, L, dGHz);
    long lSecs_nobm = (long) EstSecs_nobm(N, L, dGHz);
    long lSecs_nobmv1 = (long) EstSecs_nobmv1(N, L, dGHz);

    char szStr[64];
    printf("Memory  -bm -v2    %u MB\n", (long) dMB_v2);
    printf("Time    -bm -v2    %s\n", SecsToHHMMSS(lSecs_v2, szStr));
    printf("Time    -nobm      %s\n", SecsToHHMMSS(lSecs_nobm, szStr));
    printf("Time    -nobm -v1  %s\n", SecsToHHMMSS(lSecs_nobmv1, szStr));
    }
