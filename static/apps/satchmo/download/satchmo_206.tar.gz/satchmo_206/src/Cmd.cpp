// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

// *** GENERATED CODE, DO NOT EDIT ***
// Created by cmds.py Thu May 08 11:42:29 2003

#include "lobster.h"

// External functions
void Usage();
void InitCmd();
void DefCommand(const char *name, bool bHasInArg);
void DefParam(const char *opt);
void DefOption(const char *opt);
void DefFlag(const char *opt);
void DefDefaultedOption(const char *opt, const char *def);
bool CmdNameIs(const char *name);
const char *GetParam(const char *name);
const char *GetInArg();

// Commands
void DoAddOutlier(const char *in, const char *out);
void DoAlignAln(const char *in, const char *hmm, const char *tpl, const char *out);
void DoAlignSeq(const char *in, const char *hmm, const char *tpl, const char *out);
void DoAlnStats(const char *in);
void DoBete(const char *in, const char *out);
void DoBete2(const char *in1, const char *in2);
void DoBuildHMM(const char *in, const char *hmm);
void DoBuildProf(const char *in, const char *prof);
void DoCkp2Ckt(const char *in, const char *ckt);
void DoCkp2Prof(const char *in, const char *prof);
void DoCkt2Ckp(const char *in, const char *ckp);
void DoClustalFilter(const char *in, const char *out);
void DoCoach1(const char *in, const char *hmm, const char *tpl, const char *out);
void DoCompareAlns(const char *test, const char *ref);
void DoCompareMSA(const char *in, const char *ref);
void DoComparePair(const char *test, const char *ref, const char *id1, const char *id2);
void DoCompareSeqs(const char *file1, const char *id1, const char *file2, const char *id2);
void DoConsensus(const char *in1, const char *in2, const char *out);
void DoDbStats(const char *in);
void DoDelEmptyCols(const char *in, const char *out);
void DoDeleteSeq(const char *in, const char *id, const char *out);
void DoHMM2SAM(const char *in, const char *sam);
void DoKSNIC(const char *in);
void DoListCkp(const char *in);
void DoListHMM(const char *in);
void DoListProf(const char *in);
void DoListProfCounts(const char *in);
void DoListTree(const char *in);
void DoMMPRC(const char *hmm1, const char *hmm2, const char *tpl1, const char *tpl2, const char *out, const char *bounds);
void DoMakeGapInfo(const char *in, const char *out);
void DoMakeMasterProf(const char *in, const char *n, const char *profpath, const char *master);
void DoNJ(const char *in, const char *out);
void DoPRC(const char *hmm1, const char *hmm2, const char *tpl1, const char *tpl2, const char *out, const char *bounds);
void DoPRC1(const char *hmm1, const char *hmm2, const char *tpl1, const char *tpl2, const char *out, const char *bounds);
void DoPWID(const char *in);
void DoPathFromAln(const char *in, const char *path);
void DoPctIds(const char *in);
void DoProf2Ckp(const char *in, const char *ckp);
void DoProfProf(const char *prof1, const char *prof2, const char *colpair, const char *gapstyle, const char *bounds, const char *out);
void DoProfStats(const char *in);
void DoProtDist(const char *in, const char *out);
void DoQuickAlign(const char *seq1, const char *seq2, const char *out);
void DoQuickAlign(const char *seq1, const char *seq2, const char *out);
void DoRandTreeScores(const char *FamilySizes);
void DoRootByOutlier(const char *in, const char *out);
void DoSAM2HMM(const char *in, const char *hmm);
void DoSatchmo(const char *in);
void DoScoreMasterProf(const char *in, const char *colpair);
void DoScorePPPath(const char *in, const char *prof1, const char *prof2, const char *colpair, const char *gapstyle, const char *bounds);
void DoScorePath(const char *in, const char *seq, const char *hmm);
void DoScoreRoute(const char *in, const char *aln, const char *hmm);
void DoScoreSeqs(const char *in, const char *hmm);
void DoScoreTree(const char *in);
void DoShowBitsSaved(const char *in);
void DoShowTotalWeight(const char *in);
void DoShowWeights(const char *in);
void DoSv2Afa(const char *in, const char *out);
void DoSv2Phy(const char *in, const char *out);
void DoUPGMA(const char *in, const char *out);
void DoVCompareMSA(const char *in, const char *ref);
void DoWeight(const char *in, const char *out);
void DoXAln(const char *in, const char *out);
void DoXPair(const char *in, const char *seq1, const char *seq2, const char *tpl1, const char *tpl2);

void DetailedUsage()
    {
    printf(
"Commands:\n"
"\n"
"AddOutlier <file> : Add \"BLOSUM-worst\" outlier sequence to an alignment\n"
"  <file>   Input alignment file (.afa)\n"
"  out      Output alignment file (.afa)\n"
"\n"
"AlignAln <file> : Align alignment to HMM (Coach)\n"
"  <file>   Input alignment (.afa)\n"
"  hmm      Model file (.hmm)\n"
"  tpl      Template used to create model (.afa)\n"
"  out      Output alignment (.afa)\n"
"\n"
"AlignSeq <file> : Align sequence to HMM\n"
"  <file>   Input sequence (.fa)\n"
"  hmm      Model file (.hmm)\n"
"  tpl      Template used to create model (.afa)\n"
"  out      Output alignment (.afa)\n"
"\n"
"AlnStats <file> : Show info for alignment\n"
"  <file>   Input alignment (.afa)\n"
"\n"
"Bete <file> : Ad-hoc phylogenetic clustering using profiles\n"
"  <file>   Alignment (.afa)\n"
"  out      Output filename for tree (.phy)\n"
"\n"
"Bete2: Show per-column profile-profile score give two MSAs\n"
"  in1      Alignment (.afa)\n"
"  in2      Alignment (.afa)\n"
"\n"
"BuildHMM <file> : Create HMM from alignment\n"
"  <file>   Input alignment (.afa)\n"
"  hmm      Model file (.hmm)\n"
"\n"
"BuildProf <file> : Create profile from alignment\n"
"  <file>   Input alignment (.afa)\n"
"  prof     Profile (.prof)\n"
"\n"
"Ckp2Ckt <file> : Convert PSI-BLAST checkpoint profile to text format\n"
"  <file>   Input profile (.ckp)\n"
"  ckt      Output profile in text format (.ckt)\n"
"\n"
"Ckp2Prof <file> : Convert PSI-BLAST profile to Lobster profile\n"
"  <file>   PSI-BLAST profile (.ckp)\n"
"  prof     Lobster profile (.prof)\n"
"\n"
"Ckt2Ckp <file> : Convert PSI-BLAST checkpoint profile from text format to binary\n"
"  <file>   Input profile (.ckt)\n"
"  ckp      Output profile in binary format (.ckp)\n"
"\n"
"ClustalFilter <file> : Remove sequence pairs with no aligned residue pairs\n"
"  <file>   Input alignment (.afa)\n"
"  out      Output alignment (.afa)\n"
"\n"
"Coach1 <file> : Align alignment to HMM (Coach), output pairwise alignment only\n"
"  <file>   Input alignment (.afa), 1st seq must be seed\n"
"  hmm      Model file (.hmm)\n"
"  tpl      Template used to create model (.afa), 1st seq must be seed\n"
"  out      Output pairwise alignment (.afa)\n"
"\n"
"CompareAlns: Compare two alignments\n"
"  test     Test alignment (.afa)\n"
"  ref      Reference alignment (.afa)\n"
"\n"
"CompareMSA <file> : Compare two MASs\n"
"  <file>   Test alignment (.afa)\n"
"  ref      Reference alignmend (.afa)\n"
"\n"
"ComparePair: Compare pair-wise alignment from two alignments\n"
"  test     Test alignment (.afa)\n"
"  ref      Reference alignment (.afa)\n"
"  id1      First sequence id\n"
"  id2      Second sequence id\n"
"\n"
"CompareSeqs: Compare two sequences in two .afa files\n"
"  file1    First sequence or alignment file (.afa)\n"
"  id1      Id of sequence in first file\n"
"  file2    Second sequence or alignment file (.afa)\n"
"  id2      Id of sequence in second file\n"
"\n"
"Consensus: Find consensus of two pair-wise alignments\n"
"  in1      Pair-wise aligment (.afa)\n"
"  in2      Pair-wise aligment (.afa)\n"
"  out      Consensus alignment (.afa)\n"
"\n"
"DbStats <file> : Show info for sequence database file\n"
"  <file>   Sequence database file (.fa)\n"
"\n"
"DelEmptyCols <file> : Delete columns containing only gap characters\n"
"  <file>   Input alignment file (.afa)\n"
"  out      Output alignment file (.afa)\n"
"\n"
"DeleteSeq <file> : Delete a sequence\n"
"  <file>   Input alignment (.afa)\n"
"  id       Sequence to delete\n"
"  out      Output alignment (.afa)\n"
"\n"
"HMM2SAM <file> : Convert Lobster HMM file to SAM format\n"
"  <file>   Lobster HMM file (.hmm)\n"
"  sam      SAM HMM file (.mod)\n"
"\n"
"KSNIC <file> : List Kimmen's heuristic NIC\n"
"  <file>   Alignment (.afa)\n"
"\n"
"ListCkp <file> : Dump contents of PSI-BLAST checkpoint profile\n"
"  <file>   PSI-BLAST profile (.ckp)\n"
"\n"
"ListHMM <file> : Dump HMM parameters\n"
"  <file>   Model file (.hmm)\n"
"\n"
"ListProf <file> : Dump contents of profile\n"
"  <file>   Profile (.prof)\n"
"\n"
"ListProfCounts <file> : Dump contents of profile for estimate-dist\n"
"  <file>   Profile (.prof)\n"
"\n"
"ListTree <file> : List tree\n"
"  <file>   Tree file (.phy)\n"
"\n"
"MMPRC: Martin Madera's PRC (PRofile Compare) algorithm\n"
"  hmm1     Model file name (.hmm)\n"
"  hmm2     Model file name (.hmm)\n"
"  tpl1     Template alignment for hmm1 (.afa)\n"
"  tpl2     Template alignment for hmm2 (.afa)\n"
"  out      String, Output file for combined alignment (.afa)\n"
"  bounds   Bounds, G=global L=local (GG|GL|LG|LL)\n"
"\n"
"MakeGapInfo <file> : Make gap info file (.gap)\n"
"  <file>   Alignment (.afa)\n"
"  out      Output file (.gap)\n"
"\n"
"MakeMasterProf <file> : Build column pair master profile\n"
"  <file>   Colpair file (.txt)\n"
"  n        Number of pairs in colpair file\n"
"  profpath Directory containing profiles\n"
"  master   File name for master (.prof)\n"
"\n"
"NJ <file> : Build neighbor joining tree from alignment\n"
"  <file>   Alignment (.afa)\n"
"  out      Output filename for tree (.phy)\n"
"\n"
"PRC: Bob's version of Martin Madera's PRC (PRofile Compare) algorithm\n"
"  hmm1     Model file name (.hmm)\n"
"  hmm2     Model file name (.hmm)\n"
"  tpl1     Template alignment for hmm1 (.afa)\n"
"  tpl2     Template alignment for hmm2 (.afa)\n"
"  out      String, Output file for combined alignment (.afa)\n"
"  bounds   Bounds, G=global L=local (GG|GL|LG|LL)\n"
"\n"
"PRC1: Bob's version of Martin Madera's PRC (PRofile Compare) algorithm\n"
"  hmm1     Model file name (.hmm)\n"
"  hmm2     Model file name (.hmm)\n"
"  tpl1     Template alignment for hmm1 (.afa), 1st seq must be seed\n"
"  tpl2     Template alignment for hmm2 (.afa), 1st seq must be seed\n"
"  out      String, Output file for combined alignment (.afa), seeds only\n"
"  bounds   Bounds, G=global L=local (GG|GL|LG|LL)\n"
"\n"
"PWID <file> : List pair-wise identities for seqs in an MSA\n"
"  <file>   Alignment (.afa)\n"
"\n"
"PathFromAln <file> : Create path file from pair-wise alignment\n"
"  <file>   Alignment of two sequences (.afa)\n"
"  path     Path file (.path)\n"
"\n"
"PctIds <file> : Show pct ids of all pairs of sequences in an alignment\n"
"  <file>   Input alignment (.afa)\n"
"\n"
"Prof2Ckp <file> : Convert Lobster profile to PSI-BLAST profile\n"
"  <file>   Lobster profile (.prof)\n"
"  ckp      PSI-BLAST profile (.ckp)\n"
"\n"
"ProfProf: Profile-profile alignment\n"
"  prof1    First profile (.prof)\n"
"  prof2    Second profile (.prof)\n"
"  colpair  Column pair scoring (YL|MdotF...)\n"
"  gapstyle Gap scoring (simple|Coach|none)\n"
"  bounds   Bounds, G=global L=local (GG|GL|LG|LL)\n"
"  out      Output file for combined alignment (.afa\n"
"\n"
"ProfStats <file> : Show info for profile\n"
"  <file>   Input profile (.prof)\n"
"\n"
"ProtDist <file> : Create protein distance file (like Phylip PROTDIST module)\n"
"  <file>   Alignment (.afa)\n"
"  out      Distance matrix file (.pdist, Phylip-compatible)\n"
"\n"
"QuickAlign: Simple and fast alignment of two very similar sequences\n"
"  seq1     Sequence (.fa)\n"
"  seq2     Sequence (.af)\n"
"  out      Alignment (.afa)\n"
"\n"
"QuickAlign: Simple and fast alignment of two very similar sequences\n"
"  seq1     Sequence (.fa)\n"
"  seq2     Sequence (.af)\n"
"  out      Alignment (.afa)\n"
"\n"
"RandTreeScores: Compute average scores of random trees\n"
"  FamilySizes Family sizes separated by /, e.g. 23/7/12/2\n"
"\n"
"RootByOutlier <file> : Create rooted tree using outlier\n"
"  <file>   Input tree (.phy, unrooted)\n"
"  out      Output rooted tree (.phy, rooted)\n"
"\n"
"SAM2HMM <file> : Convert SAM HMM file to Lobster format\n"
"  <file>   SAM HMM file (.mod)\n"
"  hmm      Lobster HMM file (.hmm)\n"
"\n"
"Satchmo <file> : SATCHMO algorithm\n"
"  <file>      Input file containing sequences (.fa, indels and case ignored)\n"
"  minaff      Minimum average affinity (for Satchmo)\n"
"  bs          SATCHMO jumpstart: cluster results directory path\n"
"  alignstyle  Alignment method for Viterbi (local|global) or Forward-Backward(fb) \n"
"              Used for both scoring and alignment.\n"
" joinmethod   specify how nodes are joined (longer)\n"
"\n"
"ScoreMasterProf <file> : Log column pair scores from master profile\n"
"  <file>   Master profile (.prof)\n"
"  colpair  Column pair scoring (YL|MdotF...)\n"
"\n"
"ScorePPPath <file> : Score path for profile-profile alignment\n"
"  <file>   Path file (.path)\n"
"  prof1    First profile (.prof)\n"
"  prof2    Second profile (.prof)\n"
"  colpair  Column pair scoring (YL|Coach)\n"
"  gapstyle Gap scoring (simple|Coach)\n"
"  bounds   Bounds, G=global L=local (GG|GL|LG|LL)\n"
"\n"
"ScorePath <file> : Score sequence path against HMM\n"
"  <file>   Path file (.path)\n"
"  seq      Sequence file (.fa)\n"
"  hmm      Model file (.hmm)\n"
"\n"
"ScoreRoute <file> : Score alignment route against HMM\n"
"  <file>   Route file (.path)\n"
"  aln      Alignment file (.afa)\n"
"  hmm      Model file (.hmm)\n"
"\n"
"ScoreSeqs <file> : Score sequence database file against HMM\n"
"  <file>   Sequence database file (.fa)\n"
"  hmm      Model file (.hmm)\n"
"\n"
"ScoreTree <file> : Compute scores for tree\n"
"  <file>   Input tree (.phy)\n"
"\n"
"ShowBitsSaved <file> : Show bits saved in model\n"
"  <file>   Model file(.hmm)\n"
"\n"
"ShowTotalWeight <file> : Show total weight of alignment\n"
"  <file>   Input alignment (.afa)\n"
"\n"
"ShowWeights <file> : Display calculated weights for alignment file\n"
"  <file>   Input alignment (.afa)\n"
"\n"
"Sv2Afa <file> : Convert root alignment in SatchmoView file to aligned FASTA\n"
"  <file>   Input SatchmoView file (.sv)\n"
"  out      Output alignment (.afa)\n"
"\n"
"Sv2Phy <file> : Convert tree in SatchmoView file to PHYLIP\n"
"  <file>   Input SatchmoView file (.sv)\n"
"  out      Output tree file (.phy)\n"
"\n"
"UPGMA <file> : Build UPGMA tree from alignment\n"
"  <file>   Alignment (.afa)\n"
"  out      Ouptut filename for tree (.phy)\n"
"\n"
"VCompareMSA <file> : Verbose comparison of two MASs\n"
"  <file>   Test alignment (.afa)\n"
"  ref      Reference alignmend (.afa)\n"
"\n"
"Weight <file> : Add weight annotation to alignment file\n"
"  <file>   Input alignment (.afa)\n"
"  out      Output alignment (.afa)\n"
"\n"
"XAln <file> : Extract aligned columns\n"
"  <file>   Input alignment (.afa)\n"
"  out      Output alignment (.afa)\n"
"\n"
"XPair <file> : List position pairs\n"
"  <file>   Reference alignment\n"
"  seq1     Name of first sequence\n"
"  seq2     Name of second sequence\n"
"  tpl1     Template alignment for seq1\n"
"  tpl2     Template alignment for seq2\n"
"\n\nOptions:\n"
"  gapextend Gap extend penalty\n"
"  gapopen  Gap open penalty\n"
"  log      Log file (delete any existing file)\n"
"  loga     Log file (append to any existing file)\n"
"  matchprior Dirichlet mixture for match states (.mpr)\n"
"  out      Output file for Satchmo root alignment (.afa)\n"
"  phy      Output file for Satchmo tree (.phy)\n"
"  seed     Name of seed sequence (defaults to first)\n"
"  shift    Shift parameter\n"
"  sv       SatchmoView file name (.sv)\n"
"  transprior Transition priors (.tpr)\n"
"\n\nFlags:\n"
"  GSC      GSC weighting\n"
"  henikoff Henikoff weighting (default)\n"
"  nobm     Use approximation that saves space, doesn't use break matrices\n"
"  reverse  Compute reverse score\n"
"  samepath Force all sequences to take same path (Satchmo v1 approximation)\n"
"  savehmms Save HMM parameters in SatchmoView file\n"
"  savemss  Save match state scores in SatchmoView file\n"
"  unweight Disable sequence weighting for (Bete2 only)\n"
    );
    }

void InitCmd()
    {
    DefCommand("Commands", false);
    DefCommand("AddOutlier", true);
    DefCommand("AlignAln", true);
    DefCommand("AlignSeq", true);
    DefCommand("AlnStats", true);
    DefCommand("Bete", true); 
    DefCommand("Bete2", false);
    DefCommand("BuildHMM", true);
    DefCommand("BuildProf", true);
    DefCommand("Ckp2Ckt", true);
    DefCommand("Ckp2Prof", true);
    DefCommand("Ckt2Ckp", true);
    DefCommand("ClustalFilter", true);
    DefCommand("Coach1", true);
    DefCommand("CompareAlns", false);
    DefCommand("CompareMSA", true);
    DefCommand("ComparePair", false);
    DefCommand("CompareSeqs", false);
    DefCommand("Consensus", false);
    DefCommand("DbStats", true);
    DefCommand("DelEmptyCols", true);
    DefCommand("DeleteSeq", true);
    DefCommand("HMM2SAM", true);
    DefCommand("KSNIC", true);
    DefCommand("ListCkp", true);
    DefCommand("ListHMM", true);
    DefCommand("ListProf", true);
    DefCommand("ListProfCounts", true);
    DefCommand("ListTree", true);
    DefCommand("MMPRC", false);
    DefCommand("MakeGapInfo", true);
    DefCommand("MakeMasterProf", true);
    DefCommand("NJ", true);
    DefCommand("PRC", false);
    DefCommand("PRC1", false);
    DefCommand("PWID", true);
    DefCommand("PathFromAln", true);
    DefCommand("PctIds", true);
    DefCommand("Prof2Ckp", true);
    DefCommand("ProfProf", false);
    DefCommand("ProfStats", true);
    DefCommand("ProtDist", true);
    DefCommand("QuickAlign", false);
    DefCommand("QuickAlign", false);
    DefCommand("RandTreeScores", false);
    DefCommand("RootByOutlier", true);
    DefCommand("SAM2HMM", true);
    DefCommand("Satchmo", true);
    DefCommand("ScoreMasterProf", true);
    DefCommand("ScorePPPath", true);
    DefCommand("ScorePath", true);
    DefCommand("ScoreRoute", true);
    DefCommand("ScoreSeqs", true);
    DefCommand("ScoreTree", true);
    DefCommand("ShowBitsSaved", true);
    DefCommand("ShowTotalWeight", true);
    DefCommand("ShowWeights", true);
    DefCommand("Sv2Afa", true);
    DefCommand("Sv2Phy", true);
    DefCommand("UPGMA", true);
    DefCommand("VCompareMSA", true);
    DefCommand("Weight", true);
    DefCommand("XAln", true);
    DefCommand("XPair", true);
    DefCommand("extractpw", true); // new
    DefParam("FamilySizes");
    DefParam("aln");
    DefParam("bounds");
    DefParam("ckp");
    DefParam("ckt");
    DefParam("colpair");
    DefParam("file1");
    DefParam("file2");
    DefParam("gapstyle");
    DefParam("hmm");
    DefParam("hmm1");
    DefParam("hmm2");
    DefParam("id");
    DefParam("id1");
    DefParam("id2");
    DefParam("in1");
    DefParam("in2");
    DefParam("master");
    DefParam("n");
    DefParam("out");
    DefParam("path");
    DefParam("prof");
    DefParam("prof1");
    DefParam("prof2");
    DefParam("profpath");
    DefParam("ref");
    DefParam("sam");
    DefParam("seq");
    DefParam("seq1");
    DefParam("seq2");
    DefParam("test");
    DefParam("tpl");
    DefParam("tpl1");
    DefParam("tpl2");
    DefFlag("GSC");
    DefFlag("henikoff");
    DefFlag("nobm");
    DefFlag("reverse");
    DefFlag("samepath");
    DefFlag("savehmms");
    DefFlag("savemss");
    DefFlag("unweight");
    DefOption("gapextend");
    DefOption("gapopen");
    DefOption("log");
    DefOption("loga");
    DefOption("matchprior");
    DefOption("out");
    DefOption("phy");
    DefOption("seed");
    DefOption("shift");
    DefOption("sv");
    DefOption("transprior");
    DefOption("bs");   // new
    DefOption("threshold"); //new
    DefOption("alignstyle"); //new
    DefOption("paironly1");//new cluster of seq 1
    DefOption("paironly2");//new cluster of seq 2
    DefOption("joinmethod");
    DefOption("minaff");
    }

void DoCmd()
    {
    if (CmdNameIs("Commands"))
        DetailedUsage();
    else if (CmdNameIs("AddOutlier"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoAddOutlier(in, out);
        }
    else if (CmdNameIs("AlignAln"))
        {
        const char *in = GetInArg();
        const char *hmm = GetParam("hmm");
        const char *tpl = GetParam("tpl");
        const char *out = GetParam("out");
        DoAlignAln(in, hmm, tpl, out);
        }
    else if (CmdNameIs("AlignSeq"))
        {
        const char *in = GetInArg();
        const char *hmm = GetParam("hmm");
        const char *tpl = GetParam("tpl");
        const char *out = GetParam("out");
        DoAlignSeq(in, hmm, tpl, out);
        }
    else if (CmdNameIs("AlnStats"))
        {
        const char *in = GetInArg();
        DoAlnStats(in);
        }
    else if (CmdNameIs("Bete"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoBete(in, out);
        }
    else if (CmdNameIs("Bete2"))
        {
        const char *in1 = GetParam("in1");
        const char *in2 = GetParam("in2");
        DoBete2(in1, in2);
        }
    else if (CmdNameIs("BuildHMM"))
        {
        const char *in = GetInArg();
        const char *hmm = GetParam("hmm");
        DoBuildHMM(in, hmm);
        }
    else if (CmdNameIs("BuildProf"))
        {
        const char *in = GetInArg();
        const char *prof = GetParam("prof");
        DoBuildProf(in, prof);
        }
    else if (CmdNameIs("Ckp2Ckt"))
        {
        const char *in = GetInArg();
        const char *ckt = GetParam("ckt");
        DoCkp2Ckt(in, ckt);
        }
    else if (CmdNameIs("Ckp2Prof"))
        {
        const char *in = GetInArg();
        const char *prof = GetParam("prof");
        DoCkp2Prof(in, prof);
        }
    else if (CmdNameIs("Ckt2Ckp"))
        {
        const char *in = GetInArg();
        const char *ckp = GetParam("ckp");
        DoCkt2Ckp(in, ckp);
        }
    else if (CmdNameIs("ClustalFilter"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoClustalFilter(in, out);
        }
    else if (CmdNameIs("Coach1"))
        {
        const char *in = GetInArg();
        const char *hmm = GetParam("hmm");
        const char *tpl = GetParam("tpl");
        const char *out = GetParam("out");
        DoCoach1(in, hmm, tpl, out);
        }
    else if (CmdNameIs("CompareAlns"))
        {
        const char *test = GetParam("test");
        const char *ref = GetParam("ref");
        DoCompareAlns(test, ref);
        }
    else if (CmdNameIs("CompareMSA"))
        {
        const char *in = GetInArg();
        const char *ref = GetParam("ref");
        DoCompareMSA(in, ref);
        }
    else if (CmdNameIs("ComparePair"))
        {
        const char *test = GetParam("test");
        const char *ref = GetParam("ref");
        const char *id1 = GetParam("id1");
        const char *id2 = GetParam("id2");
        DoComparePair(test, ref, id1, id2);
        }
    else if (CmdNameIs("CompareSeqs"))
        {
        const char *file1 = GetParam("file1");
        const char *id1 = GetParam("id1");
        const char *file2 = GetParam("file2");
        const char *id2 = GetParam("id2");
        DoCompareSeqs(file1, id1, file2, id2);
        }
    else if (CmdNameIs("Consensus"))
        {
        const char *in1 = GetParam("in1");
        const char *in2 = GetParam("in2");
        const char *out = GetParam("out");
        DoConsensus(in1, in2, out);
        }
    else if (CmdNameIs("DbStats"))
        {
        const char *in = GetInArg();
        DoDbStats(in);
        }
    else if (CmdNameIs("DelEmptyCols"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoDelEmptyCols(in, out);
        }
    else if (CmdNameIs("DeleteSeq"))
        {
        const char *in = GetInArg();
        const char *id = GetParam("id");
        const char *out = GetParam("out");
        DoDeleteSeq(in, id, out);
        }
    else if (CmdNameIs("HMM2SAM"))
        {
        const char *in = GetInArg();
        const char *sam = GetParam("sam");
        DoHMM2SAM(in, sam);
        }
    else if (CmdNameIs("KSNIC"))
        {
        const char *in = GetInArg();
        DoKSNIC(in);
        }
    else if (CmdNameIs("ListCkp"))
        {
        const char *in = GetInArg();
        DoListCkp(in);
        }
    else if (CmdNameIs("ListHMM"))
        {
        const char *in = GetInArg();
        DoListHMM(in);
        }
    else if (CmdNameIs("ListProf"))
        {
        const char *in = GetInArg();
        DoListProf(in);
        }
    else if (CmdNameIs("ListProfCounts"))
        {
        const char *in = GetInArg();
        DoListProfCounts(in);
        }
    else if (CmdNameIs("ListTree"))
        {
        const char *in = GetInArg();
        DoListTree(in);
        }
    else if (CmdNameIs("MMPRC"))
        {
        const char *hmm1 = GetParam("hmm1");
        const char *hmm2 = GetParam("hmm2");
        const char *tpl1 = GetParam("tpl1");
        const char *tpl2 = GetParam("tpl2");
        const char *out = GetParam("out");
        const char *bounds = GetParam("bounds");
        DoMMPRC(hmm1, hmm2, tpl1, tpl2, out, bounds);
        }
    else if (CmdNameIs("MakeGapInfo"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoMakeGapInfo(in, out);
        }
    else if (CmdNameIs("MakeMasterProf"))
        {
        const char *in = GetInArg();
        const char *n = GetParam("n");
        const char *profpath = GetParam("profpath");
        const char *master = GetParam("master");
        DoMakeMasterProf(in, n, profpath, master);
        }
    else if (CmdNameIs("NJ"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoNJ(in, out);
        }
    else if (CmdNameIs("PRC"))
        {
        const char *hmm1 = GetParam("hmm1");
        const char *hmm2 = GetParam("hmm2");
        const char *tpl1 = GetParam("tpl1");
        const char *tpl2 = GetParam("tpl2");
        const char *out = GetParam("out");
        const char *bounds = GetParam("bounds");
        DoPRC(hmm1, hmm2, tpl1, tpl2, out, bounds);
        }
    else if (CmdNameIs("PRC1"))
        {
        const char *hmm1 = GetParam("hmm1");
        const char *hmm2 = GetParam("hmm2");
        const char *tpl1 = GetParam("tpl1");
        const char *tpl2 = GetParam("tpl2");
        const char *out = GetParam("out");
        const char *bounds = GetParam("bounds");
        DoPRC1(hmm1, hmm2, tpl1, tpl2, out, bounds);
        }
    else if (CmdNameIs("PWID"))
        {
        const char *in = GetInArg();
        DoPWID(in);
        }
    else if (CmdNameIs("PathFromAln"))
        {
        const char *in = GetInArg();
        const char *path = GetParam("path");
        DoPathFromAln(in, path);
        }
    else if (CmdNameIs("PctIds"))
        {
        const char *in = GetInArg();
        DoPctIds(in);
        }
    else if (CmdNameIs("Prof2Ckp"))
        {
        const char *in = GetInArg();
        const char *ckp = GetParam("ckp");
        DoProf2Ckp(in, ckp);
        }
    else if (CmdNameIs("ProfProf"))
        {
        const char *prof1 = GetParam("prof1");
        const char *prof2 = GetParam("prof2");
        const char *colpair = GetParam("colpair");
        const char *gapstyle = GetParam("gapstyle");
        const char *bounds = GetParam("bounds");
        const char *out = GetParam("out");
        DoProfProf(prof1, prof2, colpair, gapstyle, bounds, out);
        }
    else if (CmdNameIs("ProfStats"))
        {
        const char *in = GetInArg();
        DoProfStats(in);
        }
    else if (CmdNameIs("ProtDist"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoProtDist(in, out);
        }
    else if (CmdNameIs("QuickAlign"))
        {
        const char *seq1 = GetParam("seq1");
        const char *seq2 = GetParam("seq2");
        const char *out = GetParam("out");
        DoQuickAlign(seq1, seq2, out);
        }
    else if (CmdNameIs("QuickAlign"))
        {
        const char *seq1 = GetParam("seq1");
        const char *seq2 = GetParam("seq2");
        const char *out = GetParam("out");
        DoQuickAlign(seq1, seq2, out);
        }
    else if (CmdNameIs("RandTreeScores"))
        {
        const char *FamilySizes = GetParam("FamilySizes");
        DoRandTreeScores(FamilySizes);
        }
    else if (CmdNameIs("RootByOutlier"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoRootByOutlier(in, out);
        }
    else if (CmdNameIs("SAM2HMM"))
        {
        const char *in = GetInArg();
        const char *hmm = GetParam("hmm");
        DoSAM2HMM(in, hmm);
        }
    else if (CmdNameIs("Satchmo"))
        {
        const char *in = GetInArg();
        DoSatchmo(in);
        }
    else if (CmdNameIs("ScoreMasterProf"))
        {
        const char *in = GetInArg();
        const char *colpair = GetParam("colpair");
        DoScoreMasterProf(in, colpair);
        }
    else if (CmdNameIs("ScorePPPath"))
        {
        const char *in = GetInArg();
        const char *prof1 = GetParam("prof1");
        const char *prof2 = GetParam("prof2");
        const char *colpair = GetParam("colpair");
        const char *gapstyle = GetParam("gapstyle");
        const char *bounds = GetParam("bounds");
        DoScorePPPath(in, prof1, prof2, colpair, gapstyle, bounds);
        }
    else if (CmdNameIs("ScorePath"))
        {
        const char *in = GetInArg();
        const char *seq = GetParam("seq");
        const char *hmm = GetParam("hmm");
        DoScorePath(in, seq, hmm);
        }
    else if (CmdNameIs("ScoreRoute"))
        {
        const char *in = GetInArg();
        const char *aln = GetParam("aln");
        const char *hmm = GetParam("hmm");
        DoScoreRoute(in, aln, hmm);
        }
    else if (CmdNameIs("ScoreSeqs"))
        {
        const char *in = GetInArg();
        const char *hmm = GetParam("hmm");
        DoScoreSeqs(in, hmm);
        }
    else if (CmdNameIs("ScoreTree"))
        {
        const char *in = GetInArg();
        DoScoreTree(in);
        }
    else if (CmdNameIs("ShowBitsSaved"))
        {
        const char *in = GetInArg();
        DoShowBitsSaved(in);
        }
    else if (CmdNameIs("ShowTotalWeight"))
        {
        const char *in = GetInArg();
        DoShowTotalWeight(in);
        }
    else if (CmdNameIs("ShowWeights"))
        {
        const char *in = GetInArg();
        DoShowWeights(in);
        }
    else if (CmdNameIs("Sv2Afa"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoSv2Afa(in, out);
        }
    else if (CmdNameIs("Sv2Phy"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoSv2Phy(in, out);
        }
    else if (CmdNameIs("UPGMA"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoUPGMA(in, out);
        }
    else if (CmdNameIs("VCompareMSA"))
        {
        const char *in = GetInArg();
        const char *ref = GetParam("ref");
        DoVCompareMSA(in, ref);
        }
    else if (CmdNameIs("Weight"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoWeight(in, out);
        }
    else if (CmdNameIs("XAln"))
        {
        const char *in = GetInArg();
        const char *out = GetParam("out");
        DoXAln(in, out);
        }
    else if (CmdNameIs("XPair"))
        {
        const char *in = GetInArg();
        const char *seq1 = GetParam("seq1");
        const char *seq2 = GetParam("seq2");
        const char *tpl1 = GetParam("tpl1");
        const char *tpl2 = GetParam("tpl2");
        DoXPair(in, seq1, seq2, tpl1, tpl2);
        }
    else if (CmdNameIs("extractpw"))
        {
        const char *in = GetInArg();
        const char *seq1 = GetParam("seq1");
        const char *seq2 = GetParam("seq2");
        const char *out = GetParam("out");
        DoExtractPW(in, seq1, seq2, out);
        }
    else
        Usage();
    }
