// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "EnumPaths.h"
#include "HMMPath.h"

#define    VERBOSE    0

/***
Enumerate all paths through an HMM.

As a preamble, we need a bit of number theory. I vaguely
remember that this is some elementary stuff from the theory
of parititions of integers. I don't know the terminology
and was too lazy / too busy to look it up; so here are
my definitions. Given an integer N, we define a partition
of size j to be a set of j different integers in the
range 0 .. N-1. An integer in a partition is called a part.
The order is not important, so {1,3,7} and {3,7,1} are
considered identical partitions. We define a chain of N of 
size j to be an ordered series of j integers that sum to N.
In a chain, order is significant, so {1,1,2} and {1,2,1}
are two different chains with N=4, j=3. An integer in a chain
is called a link. Partitions and chains are closely related.

Let the number of HMM nodes be M and the number of emitter
states to be visited be e. We can enumerate all paths by
performing the following process (E, for emitter) in all
possible ways.

E1. Choose a number m of match states to visit in range
0 .. min(M,e).

E2. Choose a subset of match states size m to visit. In each
node whose match state is not chosen, visit the delete state.

E3. Choose a number i of insert states to visit in range
0 .. min(M,e-m).

E4. Choose a subset of insert states size i to visit.

E5. Choose how many times to visit each insert state in the
chosen subset. The total number of visits is v = e-m, so
distribute this number over the chosen insert states such
that each is visited at least once.

Note that in steps E2 and E4, "choose a subset" can be done by
choosing partitions of m and i respectively. In step 3, "choose
how many times" can be done by choosing a chain of v.

Let the sequence length be L, and first consider the case of 
alignment global to the model. FIMs are assumed at the beginning
and end of the model; i.e., local to the sequence. The process (G,
for global) for enumerating paths for alignments global to the
model is:

G1. Choose the number of letters n to be emitted by the start FIM.
The range is n = 0 .. L.

G2. Choose the number of letters e to be emitted by the main model.
The range is e = 0 .. L-n. (This determines the number of letters
that must be emitted by the end FIM to be L-n-e.)

G3. Perform process E given the chosen e.

For alignment local to the model (process C):

C1. Choose the first node f = 0 .. M-1.

C2. Choose the number of nodes to visit v = 1 .. M - f + 1.

C3. Choose the number of letters e to be emitted by the
main model, the range is 0 .. L.
***/

#define min(a, b)    ((a) < (b) ? (a) : (b))

// Enumerate partitions. Set bFirst to true before the first call.
// Returns true if a partition is generated, false when no more.
bool NextPartition(unsigned j, unsigned N, unsigned Parts[], bool &bFirst)
    {
    assert(j <= N);

    if (bFirst)
        {
        bFirst = false;
    // Special case: the set of integers
    // in the range [0,0-1] is empty.
        if (0 == j)
            return 0 == N;
        for (unsigned i = 0; i < j; ++i)
            Parts[i] = i;
        return true;
        }

    for (int k = j - 1; k >= 0; --k)
        {
        if ((k == j - 1 && Parts[k] == N-1) || (Parts[k] == Parts[k+1] - 1))
            continue;
        ++Parts[k];
        for (unsigned i = k + 1; i < j; ++i)
            Parts[i] = Parts[i-1] + 1;
        return true;
        }
    return false;
    }

// Enumerate chains. Set bFirst to true before the first call.
// Returns true if a chain is generated, false when no more.
bool NextChain(unsigned j, unsigned N, unsigned Links[], bool &bFirst)
    {
    assert(j <= N);

    if (0 == j)
        {
        if (bFirst)
            {
        // Special case: the set of integers
        // in the range [0,0-1] is empty.
            bFirst = false;
            return 0 == N;
            }
        return false;
        }
    if (bFirst)
        {
        bFirst = false;
        for (unsigned i = 0; i < j - 1; ++i)
            Links[i] = 1;
        Links[j-1] = N - j + 1;
        return true;
        }

    for (unsigned k = j - 1; k > 0; --k)
        {
        if (Links[k] > 1)
            {
            ++Links[k-1];
            unsigned uDiff = 0;
            for (unsigned i = k; i < j - 1; ++i)
                {
                uDiff += Links[i] - 1;
                Links[i] = 1;
                }
            Links[j-1] += uDiff - 1;
            return true;
            }
        }
    return false;
    }

static void BuildPath(unsigned uNodeCount, unsigned uEmitterStateCount,
  unsigned uNLength, unsigned uFirstNodeIndex, unsigned uMatchStateCount,
  unsigned MatchStates[], unsigned uInsertStateCount, unsigned InsertStates[],
  unsigned InsertStateVisits[], EnumPathsSink &Sink)
    {
    HMMPath Path;

    char MorD[MAX_HMM_PATH];

    memset(MorD, 'D', uNodeCount);
    for (unsigned n = 0; n < uMatchStateCount; ++n)
        MorD[MatchStates[n]] = 'M';

    unsigned InsertStateCounts[MAX_HMM_PATH];
    memset(InsertStateCounts, 0, uNodeCount*sizeof(unsigned));
    for (unsigned n = 0; n < uInsertStateCount; ++n)
        InsertStateCounts[InsertStates[n]] = InsertStateVisits[n];

    HMMEdge Edge;
    unsigned uPrefixLength = uNLength;
    for (unsigned n = 0; n < uNodeCount; ++n)
        {
        if (MorD[n] != 'D')
            ++uPrefixLength;
        Edge.uNodeIndex = uFirstNodeIndex + n;
        Edge.cState = MorD[n];
        Edge.uPrefixLength = uPrefixLength;
        Path.AppendEdge(Edge);
        
        unsigned c = InsertStateCounts[n];
        Edge.cState = 'I';
        for (unsigned i = 0; i < c; ++i)
            {
            ++uPrefixLength;
            Edge.uPrefixLength = uPrefixLength;
            Path.AppendEdge(Edge);
            }
        }
    Sink.OnPath(Path);
    }

static void EnumPaths_E5(unsigned L, unsigned e, unsigned n,
  unsigned f, unsigned m, unsigned MatchStates[], unsigned i,
  unsigned InsertStates[], EnumPathsSink &Sink)
    {
#if    VERBOSE
    List("EnumPaths_E5(L=%u e=%u n=%u f=%u m=%u i=%u InsertStates=",
      L, e, n, f, m, i);
    for (unsigned x = 0; x < i; ++x)
        List(" %u", InsertStates[x]);
    List("\n");
#endif

// E5. Choose how many times to visit each insert state.
    assert(L >= m);
    assert(L - m <= MAX_HMM_PATH);

    unsigned InsertVisits[MAX_HMM_PATH];
    const unsigned v = e - m;
    bool bFirst = true;
    while (NextChain(i, v, InsertVisits, bFirst))
        {
#if    _DEBUG
        unsigned uEmitterStateCount = m;
        for (unsigned j = 0; j < i; ++j)
            {
            assert(InsertVisits[j] <= e);
            uEmitterStateCount += InsertVisits[j];
            }
        assert(uEmitterStateCount == e);
#endif
        BuildPath(L, e, n, f, m, MatchStates, i, InsertStates, InsertVisits, Sink);
        }
    }

static void EnumPaths_E3(unsigned M, unsigned L, unsigned e, unsigned n, unsigned f,
  unsigned m, unsigned MatchStates[], EnumPathsSink &Sink)
    {
#if    VERBOSE
    List("EnumPaths_E3(M=%u L=%u e=%u n=%u f=%u m=%u MatchStates=",
      M, L, e, n, f, m);
    for (unsigned i = 0; i < m; ++i)
        List(" %u", MatchStates[i]);
    List("\n");
#endif

    assert(M > 0);
    assert(min(M-1, e) <= MAX_HMM_PATH);

// E3. Choose a number i of insert states to visit.
// Special case if zero states to visit.
// No insert state in last node, hence none if M=1 and
// choose from M-1 nodes (range 0 .. M-2).
    if (0 == e - m || 1 == M)
        EnumPaths_E5(L, e, n, f, m, MatchStates, 0, 0, Sink);
    for (unsigned i = 1; i <= min(M-1, e-m); ++i)
        {
    // E4. Choose a subset of insert states size i to visit.
        unsigned InsertStates[MAX_HMM_PATH];
        bool bFirst = true;
        while (NextPartition(i, M-1, InsertStates, bFirst))
            EnumPaths_E5(L, e, n, f, m, MatchStates, i, InsertStates, Sink);
        }
    }

// "Process E"
// e = number of emitter states
// n = index of first letter emitted
// f = index of first node visited
// L - n - e = number of letters emitted by end FIM
static void EnumPaths_E(unsigned M, unsigned L, unsigned e, unsigned n, unsigned f,
  EnumPathsSink &Sink)
    {
#if    VERBOSE
    List("EnumPaths_E(M=%u L=%u e=%u n=%u\n", M, L, e, n);
#endif

    assert(min(M, e) <= MAX_HMM_PATH);

// E1. Choose a number m of match states to visit
// m = 0 is special case.
    EnumPaths_E3(M, L, e, n, f, 0, NULL, Sink);
    for (unsigned m = 1; m <= min(M, e); ++m)
        {
    // E2. Choose a subset of match states size m to visit.
        unsigned MatchStates[MAX_HMM_PATH];
        bool bFirst = true;
        while (NextPartition(m, M, MatchStates, bFirst))
            EnumPaths_E3(M, L, e, n, f, m, MatchStates, Sink);
        }
    }

// M = number of main model nodes
// L = sequence length
void EnumPaths(unsigned M, unsigned L, MODEL_BOUNDS ModelBounds,
  SEQ_BOUNDS SeqBounds, EnumPathsSink &Sink)
    {
    if (GLOBAL_MODEL == ModelBounds)
        {
        if (GLOBAL_SEQ == SeqBounds)
            EnumPaths_E(M, L, L, 0, 0, Sink);
        else
            {
            assert(LOCAL_SEQ == SeqBounds);
        // Choose number of letters n to be emitted by the start FIM.
            for (unsigned n = 0; n <= L; ++n)
            // Choose number of letters e to be emitted by main model
                for (unsigned e = 0; e <= L - n; ++e)
                    EnumPaths_E(M, L, e, n, 0, Sink);
            }
        }
    else
        {
        assert(LOCAL_MODEL == ModelBounds);
        if (GLOBAL_SEQ == SeqBounds)
            {
        // Choose first node f
            for (unsigned f = 0; f <= M; ++f)
            // Choose number of nodes m to visit
                for (unsigned m = 1; m <= M - f; ++m)
                    EnumPaths_E(m, L, L, 0, f, Sink);
            }
        else
            {
            assert(LOCAL_SEQ == SeqBounds);
        // Choose first node f
            for (unsigned f = 0; f <= M; ++f)
            // Choose number of nodes m to visit
                for (unsigned m = 1; m <= M - f; ++m)
                // Choose number of letters n to be emitted by the start FIM.
                    for (unsigned n = 0; n <= L; ++n)
                    // Choose number of letters e to be emitted by main model
                        for (unsigned e = 0; e <= L - n; ++e)
                            EnumPaths_E(m, L, e, n, f, Sink);
            }
        }
    }
