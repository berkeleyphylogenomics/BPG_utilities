// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWDir.h"
#include "DirMix.h"
#include <math.h>

extern DirMix *g_ptrdirmixNullEmitPrior;

SCORE PWDir::PWDirScore(const FCOUNT fcCountsA[], const FCOUNT fcCountsB[])
    {
    const DirMix *ptrMix = g_ptrdirmixMatchEmitPrior;
    const unsigned uVarCount = ptrMix->m_uAlphaCount;
    const unsigned uCompCount = ptrMix->m_uCompCount;

    assert(uVarCount == 20);

    double *dCounts = new double[uVarCount];
    for (unsigned n = 0; n < uVarCount; ++n)
        {
        //double dCountA = 3.0*fcCountsA[n];
        //double dCountB = 3.0*fcCountsB[n];
        double dCountA = 3*fcCountsA[n];
        double dCountB = 3*fcCountsB[n];
        dCounts[n] = dCountA + dCountB;
        }

    return PWDirScoreN(dCounts);
    }

SCORE LogProbCountsGivenMix(const DirMix *ptrMix, const double dCounts[])
    {
    const unsigned uVarCount = ptrMix->m_uAlphaCount;
    const unsigned uCompCount = ptrMix->m_uCompCount;

    assert(uVarCount == 20);

    double dSumCounts = 0.0;
    for (unsigned uVarIndex = 0; uVarIndex < uVarCount; ++uVarIndex)
        dSumCounts += dCounts[uVarIndex];

    const double lnGammaSumCountsPlusOne = LnGamma(dSumCounts + 1.0);

    double probTotal = 0.0;
    double probMax = 0.0;
    for (unsigned uCompIndex = 0; uCompIndex < uCompCount; ++uCompIndex)
        {
        const DirComp &Comp = ptrMix->m_Comps[uCompIndex];

        const double lnGammaSumAlphas = LnGamma(Comp.m_dSumAlphas);
        const double lnGammaSumAlphasPlusSumCounts = LnGamma(Comp.m_dSumAlphas + dSumCounts);

        double scoreComp = lnGammaSumCountsPlusOne + lnGammaSumAlphas -
          lnGammaSumAlphasPlusSumCounts;

        for (unsigned uVarIndex = 0; uVarIndex < uVarCount; ++uVarIndex)
            {
            const double dAlpha = Comp.m_dAlphas[uVarIndex];
            const double dCount = dCounts[uVarIndex];
            const double dCountPlusAlpha = dCount + dAlpha;
            const double dCountPlusOne = dCount + 1;
            scoreComp += LnGamma(dCountPlusAlpha) - LnGamma(dCountPlusOne) - LnGamma(dAlpha);
            }
        const double probComp = exp(scoreComp);

        const double probThisComp = ptrMix->m_Comps[uCompIndex].m_dCompProb*probComp;

        if (probComp > probMax)
            probMax = probThisComp;

//        List("P(%u) = %g\n", uCompIndex, probThisComp);
        probTotal += probThisComp;
        }

    assert(probTotal > 0 && probTotal < 1.01);
//    return ProbToScore(probMax / probTotal);
    return ProbToScore((PROB) probTotal);
    }

SCORE PWDir::PWDirScoreN(const double dCounts[])
    {
    SCORE scoreMix = LogProbCountsGivenMix(g_ptrdirmixMatchEmitPrior, dCounts);
    SCORE scoreNull = (SCORE) (LogProbCountsGivenMix(g_ptrdirmixNullEmitPrior, dCounts) - log2(9.0));
    return scoreMix - scoreNull;
    }

void TestDir()
    {
    SCORE s;
    SetListFileName("c:\\tmp\\lobster.log", false);

    double Counts[MAX_ALPHA];
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        Counts[n] = GetNullEmitProb(n)*10;
    s = PWDir::PWDirScoreN(Counts);
    List("Background   %g\n", s);

    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        Counts[n] = 0;
    Counts[AX_W] = 8;
    s = PWDir::PWDirScoreN(Counts);
    List("WWWWWWWW   %g\n", s);

    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        Counts[n] = 0;
    Counts[AX_L] = 2;
    Counts[AX_I] = 2;
    Counts[AX_V] = 2;
    s = PWDir::PWDirScoreN(Counts);
    List("LLIIVV   %g\n", s);

    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        Counts[n] = 0;
    Counts[AX_L] = 2;
    Counts[AX_I] = 2;
    Counts[AX_V] = 1;
    Counts[AX_W] = 1;
    s = PWDir::PWDirScoreN(Counts);
    List("LLIIVW   %g\n", s);
    }
