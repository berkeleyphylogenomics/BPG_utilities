// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "Seq.h"
#include "MSA.h"

#define    VERBOSE 0

// Macros to simulate 2D matrices
#define DPM(NodeIndex, PrefixLength)    DPM_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPD(NodeIndex, PrefixLength)    DPD_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPI(NodeIndex, PrefixLength)    DPI_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPN(NodeIndex, PrefixLength)    DPN_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPS(NodeIndex, PrefixLength)    DPS_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTM(NodeIndex, PrefixLength)    DPTM_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTD(NodeIndex, PrefixLength)    DPTD_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTI(NodeIndex, PrefixLength)    DPTI_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]

SCORE HMM::BackwardSeq(const Seq &s, SCORE **ptrptrDPM)
    {
    const unsigned uSeqLength = s.Length();
    const unsigned uPrefixCount = uSeqLength + 1;
    const unsigned uNodeCount = GetNodeCount();
    assert(uSeqLength > 0 && uNodeCount > 0);
    *ptrptrDPM = 0;

// Allocate DP matrices
    size_t LM = uPrefixCount*uNodeCount;
    SCORE *DPM_ = new SCORE[LM];
    SCORE *DPD_ = new SCORE[LM];
    SCORE *DPI_ = new SCORE[LM];

#if    _DEBUG
    memset(DPM_, cInsane, LM*sizeof(SCORE));
    memset(DPD_, cInsane, LM*sizeof(SCORE));
    memset(DPI_, cInsane, LM*sizeof(SCORE));
#endif

// Last node is special case.
    const unsigned uLastNodeIndex = uNodeCount - 1;
    DPM(uLastNodeIndex, uSeqLength) = 0;
    DPD(uLastNodeIndex, uSeqLength) = 0;
    DPI(uLastNodeIndex, uSeqLength) = MINUS_INFINITY;

// Full sequence is special case, can only go through delete states.
    for (int iNodeIndex = (int) uLastNodeIndex - 1; iNodeIndex >= 0; --iNodeIndex)
        {
        unsigned uNodeIndex = (unsigned) iNodeIndex;
        const HMMNode &Node = GetNode(uNodeIndex);

        SCORE scoreMD = Add2(DPD(uNodeIndex+1, uSeqLength), Node.m_scoreMD);
        DPM(uNodeIndex, uSeqLength) = scoreMD;

        SCORE scoreDD = Add2(DPD(uNodeIndex+1, uSeqLength), Node.m_scoreDD);
        DPD(uNodeIndex, uSeqLength) = scoreDD;

        SCORE scoreID = Add2(DPD(uNodeIndex+1, uSeqLength), Node.m_scoreID);
        DPI(uNodeIndex, uSeqLength) = scoreID;
        }

    for (int iPrefixLength = (int) uSeqLength - 1; iPrefixLength >= 0; --iPrefixLength)
        {
        const unsigned uPrefixLength = (unsigned) iPrefixLength;
        const unsigned uLetter = s.GetLetter(uPrefixLength);

    // Last node is special case
    // Global/global
        DPM(uLastNodeIndex, uPrefixLength) = MINUS_INFINITY;
        DPD(uLastNodeIndex, uPrefixLength) = MINUS_INFINITY;
        DPI(uLastNodeIndex, uPrefixLength) = MINUS_INFINITY;

        for (int iNodeIndex = (int) uLastNodeIndex - 1; iNodeIndex >= 0; --iNodeIndex)
            {
            unsigned uNodeIndex = (unsigned) iNodeIndex;
            const HMMNode &Node = GetNode(uNodeIndex);
            const HMMNode &NextNode = GetNode(uNodeIndex+1);
            SCORE scoreMatchEmitNext = NextNode.m_scoreMatchEmit[uLetter];
            SCORE scoreInsertEmitNext = NextNode.m_scoreInsertEmit[uLetter];

        // Transitions from M
            {
            SCORE scoreMM = Add3(DPM(uNodeIndex+1, uPrefixLength+1), Node.m_scoreMM,
              scoreMatchEmitNext);
            SCORE scoreMD = Add2(DPD(uNodeIndex+1, uPrefixLength), Node.m_scoreMD);
            SCORE scoreMI = Add3(DPI(uNodeIndex, uPrefixLength+1), Node.m_scoreMI,
              scoreInsertEmitNext);
            DPM(uNodeIndex, uPrefixLength) = SumLog(scoreMM, scoreMI, scoreMD);
            }

        // Transitions from D
            {
            SCORE scoreDM = Add3(DPM(uNodeIndex+1, uPrefixLength+1), Node.m_scoreDM,
              scoreMatchEmitNext);
            SCORE scoreDD = Add2(DPD(uNodeIndex+1, uPrefixLength), Node.m_scoreDD);
            SCORE scoreDI = Add3(DPI(uNodeIndex, uPrefixLength+1), Node.m_scoreDI,
              scoreInsertEmitNext);
            DPD(uNodeIndex, uPrefixLength) = SumLog(scoreDM, scoreDI, scoreDD);
            }

        // Transitions from I
            {
            SCORE scoreIM = Add3(DPM(uNodeIndex+1, uPrefixLength+1), Node.m_scoreIM,
              scoreMatchEmitNext);
            SCORE scoreID = Add2(DPD(uNodeIndex+1, uPrefixLength), Node.m_scoreID);
            SCORE scoreII = Add3(DPI(uNodeIndex, uPrefixLength+1), Node.m_scoreII,
              scoreInsertEmitNext);
            DPI(uNodeIndex, uPrefixLength) = SumLog(scoreIM, scoreII, scoreID);
            }
            }
        }

    const HMMNode &FirstNode = GetNode(0);
    const unsigned uFirstLetter = s.GetLetter(0);
    SCORE scoreM = Add3(DPM(0, 1), m_scoreFirstM,
      FirstNode.m_scoreMatchEmit[uFirstLetter]);
    SCORE scoreD = DPD(0, 0) + m_scoreFirstD;
    SCORE scoreBwd = SumLog(scoreM, scoreD);

#if VERBOSE
    ListDPProb(uNodeCount, uSeqLength, DPM_, DPD_, DPI_);
#endif    // VERBOSE

//    delete[] DPM_;
    *ptrptrDPM = DPM_;
    delete[] DPD_;
    delete[] DPI_;

    return scoreBwd;
    }
    
SCORE HMM::BackwardAln(const MSA &a,  SCORE **ptrptrDPM)
    {
//    fprintf(stderr, "Backward..\n");
    const unsigned uPillarCount = a.GetPillarCount();
    const unsigned uPrefixCount = uPillarCount + 1;
    const unsigned uNodeCount = GetNodeCount();
    assert(uPillarCount > 0 && uNodeCount > 0);

// Allocate DP matrices
    size_t LM = uPrefixCount*uNodeCount;
    SCORE *DPM_ = new SCORE[LM];
    SCORE *DPD_ = new SCORE[LM];
    SCORE *DPI_ = new SCORE[LM];
    unsigned *DPN_ = new unsigned[LM];
    char *DPS_ = new char[LM];
    char *DPTM_ = new char[LM];
    char *DPTD_ = new char[LM];
    char *DPTI_ = new char[LM];

    CheckMemUse();
    
#if    _DEBUG
    memset(DPM_, cInsane, LM*sizeof(SCORE));
    memset(DPD_, cInsane, LM*sizeof(SCORE));
    memset(DPI_, cInsane, LM*sizeof(SCORE));
#endif

// Last node is special case.
    const unsigned uLastNodeIndex = uNodeCount - 1;
    DPM(uLastNodeIndex, uPillarCount) = 0;
    DPD(uLastNodeIndex, uPillarCount) = 0;
    DPI(uLastNodeIndex, uPillarCount) = MINUS_INFINITY;
    DPN(0, 0) = uInsane;
    DPS(0, 0) = INVALID_STATE;
    DPTM(0, 0) = INVALID_STATE;
    DPTD(0, 0) = INVALID_STATE;
    DPTI(0, 0) = INVALID_STATE;

// Full sequence is special case, can only go through delete states.
    for (int iNodeIndex = (int) uLastNodeIndex - 1; iNodeIndex >= 0; --iNodeIndex)
        {
        unsigned uNodeIndex = (unsigned) iNodeIndex;
        const HMMNode &Node = GetNode(uNodeIndex);

        SCORE scoreMD = Add2(DPD(uNodeIndex+1, uPillarCount), Node.m_scoreMD);
        DPM(uNodeIndex, uPillarCount) = scoreMD;
        DPTM(uNodeIndex, 0) = INVALID_STATE;//

        SCORE scoreDD = Add2(DPD(uNodeIndex+1, uPillarCount), Node.m_scoreDD);
        DPD(uNodeIndex, uPillarCount) = scoreDD;
        DPTD(uNodeIndex, 0) = 'D';//
        

        SCORE scoreID = Add2(DPD(uNodeIndex+1, uPillarCount), Node.m_scoreID);
        DPI(uNodeIndex, uPillarCount) = scoreID;
        DPTI(uNodeIndex, 0) = INVALID_STATE;//

        DPN(uNodeIndex, 0) = uInsane;//
        DPS(uNodeIndex, 0) = INVALID_STATE;//
        } 

    for (int iPrefixLength = (int) uPillarCount - 1; iPrefixLength >= 0; --iPrefixLength)
        {
        const unsigned uPrefixLength = (unsigned) iPrefixLength;
//        const unsigned uLetter = s.GetLetter(uPrefixLength);
        const PILLAR &Pillar = a.GetPillar(uPrefixLength-1);
        const bool bIsAligned = Pillar.m_bAligned;
        
    // Last node is special case
    // Global/global
        DPM(uLastNodeIndex, uPrefixLength) = MINUS_INFINITY;
        DPD(uLastNodeIndex, uPrefixLength) = MINUS_INFINITY;
        DPI(uLastNodeIndex, uPrefixLength) = MINUS_INFINITY;

        for (int iNodeIndex = (int) uLastNodeIndex - 1; iNodeIndex >= 0; --iNodeIndex)
            {
            unsigned uNodeIndex = (unsigned) iNodeIndex;
//            const HMMNode &Node = GetNode(uNodeIndex);
//            const HMMNode &NextNode = GetNode(uNodeIndex+1);
            SCORE scoreMatchEmitNext = EmitM(a, uNodeIndex+1, uPrefixLength); //NextNode.m_scoreMatchEmit[uLetter];
            SCORE scoreInsertEmitNext =EmitI(a, uNodeIndex+1, uPrefixLength); // NextNode.m_scoreInsertEmit[uLetter];

        // Transitions from M
            if (bIsAligned)
                {
            SCORE scoreMM = Add3(DPM(uNodeIndex+1, uPrefixLength+1), LegMM(a,uNodeIndex,uPrefixLength),
              scoreMatchEmitNext);
            SCORE scoreMD = Add2(DPD(uNodeIndex+1, uPrefixLength), LegMD(a,uNodeIndex,uPrefixLength));
            SCORE scoreMI = Add3(DPI(uNodeIndex, uPrefixLength+1), LegMI(a,uNodeIndex,uPrefixLength),
              scoreInsertEmitNext);
                if (scoreMM >= scoreMD && scoreMM >= scoreMI)
                    {
                    DPM(uNodeIndex, uPrefixLength) = Add2(scoreMM, scoreMatchEmitNext);
                    DPTM(uNodeIndex, uPrefixLength) = 'M';
                    }
                else if (scoreMD >= scoreMM && scoreMD >= scoreMI)
                    {
                    DPM(uNodeIndex, uPrefixLength) = Add2(scoreMD, scoreMatchEmitNext);
                    DPTM(uNodeIndex, uPrefixLength) = 'D';
                    }
                else
                    {
                    assert(scoreMI >= scoreMM && scoreMI >= scoreMD);
                    DPM(uNodeIndex, uPrefixLength) = Add2(scoreMI, scoreMatchEmitNext);
                    DPTM(uNodeIndex, uPrefixLength) = 'I';
                    }
                    DPM(uNodeIndex, uPrefixLength) = scoreMatchEmitNext + scoreMI + scoreMM + scoreMD;
                }
                        else
            // Not aligned
                {
                DPM(uNodeIndex, uPrefixLength) = MINUS_INFINITY;
                DPTM(uNodeIndex, uPrefixLength) = '!';
                }    

        // Transitions from D
            {
            SCORE scoreDM = Add3(DPM(uNodeIndex+1, uPrefixLength+1), LegDM(a,uNodeIndex,uPrefixLength),
              scoreMatchEmitNext);
            SCORE scoreDD = Add2(DPD(uNodeIndex+1, uPrefixLength), LegDD(a,uNodeIndex,uPrefixLength));
            SCORE scoreDI = Add3(DPI(uNodeIndex, uPrefixLength+1), LegDI(a,uNodeIndex,uPrefixLength),
              scoreInsertEmitNext);
            if (scoreDM >= scoreDD && scoreDM >= scoreDI)
                {
                DPD(uNodeIndex, uPrefixLength) = scoreDM;
                DPTD(uNodeIndex, uPrefixLength) = 'M';
                }
            else if (scoreDD >= scoreDM && scoreDD >= scoreDI)
                {
                DPD(uNodeIndex, uPrefixLength) = scoreDD;
                DPTD(uNodeIndex, uPrefixLength) = 'D';
                }
            else
                {
                assert(scoreDI >= scoreDM && scoreDI >= scoreDD);
                DPD(uNodeIndex, uPrefixLength) = scoreDI;
                DPTD(uNodeIndex, uPrefixLength) = 'I';
                }
                DPD(uNodeIndex, uPrefixLength) = scoreDM+scoreDD+scoreDI;
            }

        // Transitions from I
            {
            SCORE scoreIM = Add3(DPM(uNodeIndex+1, uPrefixLength+1), LegIMApprox(a,uNodeIndex,uPrefixLength),
              scoreMatchEmitNext);
            SCORE scoreID = Add2(DPD(uNodeIndex+1, uPrefixLength),LegIDApprox(a,uNodeIndex,uPrefixLength));
            SCORE scoreII = Add3(DPI(uNodeIndex, uPrefixLength+1), LegIIApprox(a,uNodeIndex,uPrefixLength),
              scoreInsertEmitNext);
            if (scoreIM >= scoreID && scoreIM >= scoreII)
                    {
                    DPI(uNodeIndex, uPrefixLength) = scoreIM;
                    DPN(uNodeIndex, uPrefixLength) = uPrefixLength-1;
                    DPS(uNodeIndex, uPrefixLength) = 'M';
                    DPTI(uNodeIndex, uPrefixLength) = 'M';
                    }
                else if (scoreID >= scoreIM && scoreID >= scoreII)
                    {
                    DPI(uNodeIndex, uPrefixLength) = scoreID;
                    DPN(uNodeIndex, uPrefixLength) = uPrefixLength-1;
                    DPS(uNodeIndex, uPrefixLength) = 'D';
                    DPTI(uNodeIndex, uPrefixLength) = 'D';
                    }
                else
                    {
                    assert(scoreII >= scoreIM && scoreII >= scoreID);
                    DPI(uNodeIndex, uPrefixLength) = scoreII;
                    DPN(uNodeIndex, uPrefixLength) = DPN(uNodeIndex, uPrefixLength-1);
                    DPS(uNodeIndex, uPrefixLength) = DPS(uNodeIndex, uPrefixLength-1);
                    DPTI(uNodeIndex, uPrefixLength) = 'I';
                    }
                    DPI(uNodeIndex, uPrefixLength) =scoreIM + scoreID + scoreII;
                }
            }
        }

    const HMMNode &FirstNode = GetNode(0);
    //const unsigned uFirstLetter = s.GetLetter(0);
    SCORE scoreM = Add3(DPM(0, 1), m_scoreFirstM,
     EmitM(a, 0, 0)); //  FirstNode.m_scoreMatchEmit[uFirstLetter]
    SCORE scoreD = DPD(0, 0) + m_scoreFirstD;
    SCORE scoreBwd = SumLog(scoreM, scoreD);

#if VERBOSE
    ListDPProb(uNodeCount, uSeqLength, DPM_, DPD_, DPI_);
#endif    // VERBOSE

//    delete[] DPM_;
    *ptrptrDPM = DPM_;
    delete[] DPD_;
    delete[] DPI_;
    delete[] DPN_;
    delete[] DPS_;
    delete[] DPTM_;
    delete[] DPTD_;
    delete[] DPTI_;

    return scoreBwd;
}
