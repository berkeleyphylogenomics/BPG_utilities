// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWYL.h"
#include "PWYLD.h"
#include "PWYLDF.h"
#include <math.h>

#define VERBOSE    0

// const double dShift = 0.45;

// Background emission probabilities
static PROB probBackground[] =
    {
    (PROB) 0.075520,        // A
    (PROB) 0.016973,        // C
    (PROB) 0.053029,        // D
    (PROB) 0.063204,        // E
    (PROB) 0.040762,        // F
    (PROB) 0.068448,        // G
    (PROB) 0.022406,        // H
    (PROB) 0.057284,        // I
    (PROB) 0.059398,        // K
    (PROB) 0.093399,        // L
    (PROB) 0.023569,        // M
    (PROB) 0.045293,        // N
    (PROB) 0.049262,        // P
    (PROB) 0.040231,        // Q
    (PROB) 0.051573,        // R
    (PROB) 0.072214,        // S
    (PROB) 0.057454,        // T
    (PROB) 0.065252,        // V
    (PROB) 0.012513,        // W
    (PROB) 0.031985            // Y
    };

// Estimate the common source distribution, assume lambda=0.5
// (2nd equation p.1260).
static void CommonSource(const PROB p[], const PROB q[], PROB r[])
    {
    for (int n = 0; n < 20; ++n)
        r[n] = (PROB) ((p[n] + q[n])/2.0);
    }

// The Kullback-Leibler divergence, also
// known as the relative entropy
static double DKL(const PROB p[], const PROB q[])
    {
    double dSum = 0.0;
    for (int n = 0; n < MAX_ALPHA; ++n)
        if (q[n] != 0.0)
            dSum += p[n]*log2(p[n]/q[n]);
    return dSum;
    }

// The symmetric Jenson-Shannon divergence, i.e. the lambda-
// Jenson-Shannon divergence with lambda = 1/2.
static double DJS(const PROB p[], const PROB q[])
    {
    PROB r[20];
    CommonSource(p, q, r);

    double dDJS = (DKL(p, r) + DKL(q, r))/2;

// Should range from zero to 1
    assert(dDJS >= 0.0 && dDJS <= 1.0);
    return dDJS;
    }

// Score(p, q) the last definition on left-
// hand column of p. 1261.
double PWYL::YLScore(const PROB p[], const PROB q[])
    {
    double DJS_pq = DJS(p, q);
// Should be symmetrical
    assert(DJS_pq == DJS(q, p));

    PROB r[20];
    CommonSource(p, q, r);

    double DJS_rP0 = DJS(r, probBackground);
// Should be symmetrical
    assert(DJS_rP0 == DJS(probBackground, r));

    double dScore = (1 - DJS_pq)*(1 + DJS_rP0)/2;
#if    VERBOSE
    List("D=%g S=%g Score(p,q)=%g\n",
      DJS_pq, DJS_rP0, dScore);
#endif
    return dScore;
    }

double PWYLDF::YLDFScore(const FCOUNT p[], const FCOUNT q[])
    {
    PROB P[MAX_ALPHA];
    PROB Q[MAX_ALPHA];

    for (int n = 0; n < MAX_ALPHA; ++n)
        {
        P[n] = (PROB) p[n];
        Q[n] = (PROB) q[n];
        }
    return PWYLD::YLDScore(P, Q);
    }

double PWYLD::YLDScore(const PROB p[], const PROB q[])
    {
    double DJS_pq = DJS(p, q);
// Should be symmetrical
    assert(DJS_pq == DJS(q, p));

    return 1 - DJS_pq;
    }

void TestYL()
    {
    List("Background vs. Background\n");
    PWYL::YLScore(probBackground, probBackground);

    PROB prob0[MAX_ALPHA];
    PROB prob1[MAX_ALPHA];
    PROB prob2[MAX_ALPHA];

    for (int n = 0; n < MAX_ALPHA; ++n)
        {
        prob0[n] = 0.0;
        prob1[n] = 0.0;
        prob2[n] = 0.0;
        }
    prob0[0] = 1.0;
    prob1[1] = 1.0;

    List("0 vs 0\n");
    PWYL::YLScore(prob0, prob0);

    List("1 vs 1\n");
    PWYL::YLScore(prob1, prob1);

    List("0 vs 1\n");
    PWYL::YLScore(prob0, prob1);

    List("1 vs 0\n");
    PWYL::YLScore(prob1, prob0);

    prob2[0] = 0.5;
    prob2[1] = 0.5;
    List("2 vs 2\n");
    PWYL::YLScore(prob2, prob2);
    }
