// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    PWAff_h
#define    PWAff_h

#include "PWScore.h"

class Seq;

class PWAff : public PWScore
    {
public:
    PWAff();
    virtual ~PWAff();

public:
    void Init(const Seq &SeqA, BOUNDS BoundsA, const Seq &SeqB, BOUNDS BoundsB);
    BOUNDS GetBoundsA() { return m_boundsA; }
    BOUNDS GetBoundsB() { return m_boundsB; }

public:
    virtual BOUNDS GetBoundsA() const { return m_boundsA; }
    virtual BOUNDS GetBoundsB() const { return m_boundsB; }
    virtual unsigned GetLengthA() const;
    virtual unsigned GetLengthB() const;
    virtual SCORE ScoreMM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreMD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreMI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreDM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreDD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreDI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreIM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreID(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreII(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreSM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreSD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreSI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreME(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreDE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreIE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreLL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreLG(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;
    virtual SCORE ScoreGL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const;

private:
    const Seq *m_ptrSeqA;
    const Seq *m_ptrSeqB;

    BOUNDS m_boundsA;
    BOUNDS m_boundsB;

    SCORE m_scoreGapOpen;
    SCORE m_scoreGapExtend;
    SCORE m_scoreLL[23][23];
    };

#endif    // PWAff_h
