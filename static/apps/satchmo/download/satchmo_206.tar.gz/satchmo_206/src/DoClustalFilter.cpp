// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "TextFile.h"

static bool HasCommonAlignedPosition(const MSA &a, unsigned uSeqIndex1,
  unsigned uSeqIndex2)
    {
    const unsigned uColCount = a.GetColCount();
    for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
        if (!a.IsGap(uSeqIndex1, uColIndex) && !a.IsGap(uSeqIndex2, uColIndex))
            return true;
    return false;
    }

// Remove all pairs of sequences that have no aligned positions in common.
static void ClustalFilter(const MSA &msaIn, MSA &msaOut)
    {
    const unsigned uSeqCount = msaIn.GetSeqCount();
    if (uSeqCount < 2)
        return;

    bool *bFlaggedForDeletion = new bool[uSeqCount];
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        bFlaggedForDeletion[uSeqIndex] = false;

    unsigned uDeleteCount = 0;
    for (unsigned uSeqIndex1 = 0; uSeqIndex1 < uSeqCount; ++uSeqIndex1)
        {
        if (bFlaggedForDeletion[uSeqIndex1])
            continue;

        for (unsigned uSeqIndex2 = uSeqIndex1 + 1; uSeqIndex2 < uSeqCount; ++uSeqIndex2)
            {
            if (bFlaggedForDeletion[uSeqIndex1] || bFlaggedForDeletion[uSeqIndex2])
                continue;

            if (!HasCommonAlignedPosition(msaIn, uSeqIndex1, uSeqIndex2))
                {
                printf("---Deleting:\n");
                printf("    %s\n", msaIn.GetSeqName(uSeqIndex1));
                printf("    %s\n", msaIn.GetSeqName(uSeqIndex2));

                List("---Deleting:\n");
                List("    %s\n", msaIn.GetSeqName(uSeqIndex1));
                List("    %s\n", msaIn.GetSeqName(uSeqIndex2));

                bFlaggedForDeletion[uSeqIndex1] = true;
                bFlaggedForDeletion[uSeqIndex2] = true;

            // Can skip all other comparisons against Seq1 because we just
            // flagged it for deletion.
                break;
                }
            }
        }

    unsigned uOutSeqCount = 0;
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        if (!bFlaggedForDeletion[uSeqIndex])
            ++uOutSeqCount;

    const unsigned uColCount = msaIn.GetColCount();
    msaOut.SetSize(uOutSeqCount, uColCount);

    unsigned uOutSeqIndex = 0;
    for (unsigned uInSeqIndex = 0; uInSeqIndex < uSeqCount; ++uInSeqIndex)
        {
        if (bFlaggedForDeletion[uInSeqIndex])
            continue;
        msaOut.CopySeq(uOutSeqIndex, msaIn, uInSeqIndex);
        ++uOutSeqIndex;
        }
    assert(uOutSeqCount == uOutSeqIndex);
    }

void DoClustalFilter(const char *strInFileName, const char *strOutFileName)
    {
    TextFile InFile(strInFileName);
    MSA msaIn;
    msaIn.FromFile(InFile);

    MSA msaOut;
    ClustalFilter(msaIn, msaOut);

    TextFile OutFile(strOutFileName, true);
    msaOut.ToFASTAFile(OutFile);
    }
