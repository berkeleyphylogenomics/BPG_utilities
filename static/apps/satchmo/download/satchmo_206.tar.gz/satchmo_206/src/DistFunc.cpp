// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "DistFunc.h"
#include <assert.h>

DistFunc::DistFunc()
    {
    m_Dists = 0;
    m_uCount = 0;
    m_uCacheCount = 0;
    }

DistFunc::~DistFunc()
    {
    delete[] m_Dists;
    }

double DistFunc::GetDist(unsigned uIndex1, unsigned uIndex2) const
    {
    return m_Dists[VectorIndex(uIndex1, uIndex2)];
    }

unsigned DistFunc::GetCount() const
    {
    return m_uCount;
    }

void DistFunc::SetCount(unsigned uCount)
    {
    m_uCount = uCount;
    if (uCount <= m_uCacheCount)
        return;
    delete[] m_Dists;
    m_Dists = new double[VectorLength()];
    m_uCacheCount = uCount;
    }

void DistFunc::SetDist(unsigned uIndex1, unsigned uIndex2, double dDist)
    {
    m_Dists[VectorIndex(uIndex1, uIndex2)] = dDist;
    m_Dists[VectorIndex(uIndex2, uIndex1)] = dDist;
    }

unsigned DistFunc::VectorIndex(unsigned uIndex1, unsigned uIndex2) const
    {
    assert(uIndex1 < m_uCount && uIndex2 < m_uCount);
    return uIndex1*m_uCount + uIndex2;
    }

unsigned DistFunc::VectorLength() const
    {
    return m_uCount*m_uCount;
    }
