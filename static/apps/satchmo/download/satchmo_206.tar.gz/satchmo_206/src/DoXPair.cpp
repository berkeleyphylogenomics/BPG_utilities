// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "TextFile.h"
#include "Seq.h"

void DoXPair(const char *in, const char *seq1, const char *seq2, const char *tpl1,
  const char *tpl2)
    {
    TextFile fileIn(in);
    TextFile fileAtpl(tpl1);
    TextFile fileBtpl(tpl2);

    MSA msaIn;
    MSA msaAtpl;
    MSA msaBtpl;

    msaIn.FromFASTAFile(fileIn);
    msaAtpl.FromFASTAFile(fileAtpl);
    msaBtpl.FromFASTAFile(fileBtpl);

    msaIn.AlignByCase();
    msaAtpl.AlignByCase();
    msaBtpl.AlignByCase();

    unsigned uSeqIndexAin;
    unsigned uSeqIndexBin;
    unsigned uSeqIndexAtpl;
    unsigned uSeqIndexBtpl;

    bool bFound = msaIn.GetSeqIndex(seq1, &uSeqIndexAin);
    if (!bFound)
        Quit("Seq %s not found in %s", seq1, in);

    bFound = msaIn.GetSeqIndex(seq2, &uSeqIndexBin);
    if (!bFound)
        Quit("Seq %s not found in %s", seq2, in);

    bFound = msaAtpl.GetSeqIndex(seq1, &uSeqIndexAtpl);
    if (!bFound)
        Quit("Seq %s not found in %s", seq1, tpl1);
    
    bFound = msaBtpl.GetSeqIndex(seq2, &uSeqIndexBtpl);
    if (!bFound)
        Quit("Seq %s not found in %s", seq2, tpl2);

    Seq seqAin;
    Seq seqBin;
    Seq seqAtpl;
    Seq seqBtpl;

    msaIn.GetSeq(uSeqIndexAin, seqAin);
    msaIn.GetSeq(uSeqIndexBin, seqBin);
    msaAtpl.GetSeq(uSeqIndexAtpl, seqAtpl);
    msaBtpl.GetSeq(uSeqIndexBtpl, seqBtpl);

    if (stricmp(seq1, seqAin.GetName()) != 0 ||
      stricmp(seq2, seqBin.GetName()) != 0 ||
      stricmp(seq1, seqAtpl.GetName()) != 0 ||
      stricmp(seq2, seqBtpl.GetName()) != 0)
        Quit("Assert failed");

    unsigned uLengthAin = seqAin.Length();
    unsigned uLengthBin = seqBin.Length();
    unsigned uLengthAtpl = seqAtpl.Length();
    unsigned uLengthBtpl = seqBtpl.Length();

    int *iMapAinBin = new int[uLengthAin];
    int *iMapBinAin = new int[uLengthBin];
    int *iMapAinAtpl = new int[uLengthAin];
    int *iMapAtplAin = new int[uLengthAtpl];
    int *iMapBinBtpl = new int[uLengthBin];
    int *iMapBtplBin = new int[uLengthBtpl];

    msaIn.GetPairMap(uSeqIndexAin, uSeqIndexBin, iMapAinBin, iMapBinAin);

    QuickAlign(seqAin, seqAtpl, iMapAinAtpl, iMapAtplAin);
    QuickAlign(seqBin, seqBtpl, iMapBinBtpl, iMapBtplBin);

    char szStem[256];
    NameFromPath(in, szStem, sizeof(szStem));

    for (int iPosAin = 0; iPosAin < (int) uLengthAin; ++iPosAin)
        {
        int iPosBin = iMapAinBin[iPosAin];
        if (-1 == iPosBin)
            continue;

        int iPosAtpl = iMapAinAtpl[iPosAin];
        if (-1 == iPosAtpl)
            continue;

        int iPosBtpl = iMapBinBtpl[iPosBin];
        if (-1 == iPosBtpl)
            continue;

        char cAin = seqAin[iPosAin];
        if (!isupper(cAin))
            continue;

        char cAtpl = seqAtpl[iPosAtpl];
        if (cAin != cAtpl)
            List("Warning: Ain[%d]=%c Atpl[%d]=%c\n", iPosAin, cAin, iPosAtpl, cAtpl);

        char cBtpl = seqBtpl[iPosBtpl];

        List("A=%s;APos=%d;Ac=%c;B=%s;BPos=%d;Bc=%c\n",
          seq1, iPosAtpl, cAtpl, seq2, iPosBtpl, cBtpl);
        }

    delete[] iMapAinBin;
    delete[] iMapBinAin;
    delete[] iMapAinAtpl;
    delete[] iMapAtplAin;
    delete[] iMapBinBtpl;
    delete[] iMapBtplBin;
    }
