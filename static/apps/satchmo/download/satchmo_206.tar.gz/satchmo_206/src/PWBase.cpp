// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWBase.h"

PWBase::PWBase()
    {
    m_profA = 0;
    m_profB = 0;

    m_BoundsA = BOUNDS_Undefined;
    m_BoundsB = BOUNDS_Undefined;
    m_GapStyle = GAPSTYLE_Undefined;

    m_scoreGapOpen = BTInsane;
    m_scoreGapExtend = BTInsane;
    m_scoreShift = BTInsane;

    m_uLengthA = uInsane;
    m_uLengthB = uInsane;
    }

PWBase::~PWBase()
    {
    }

BOUNDS PWBase::GetBoundsA() const
    {
    return m_BoundsA;
    }

BOUNDS PWBase::GetBoundsB() const
    {
    return m_BoundsB;
    }

SCORE PWBase::ScoreMM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GAPSTYLE_Simple == m_GapStyle)
        return 0;

    assert(uPrefixLengthA > 0 && uPrefixLengthB > 0);
    const ProfPos &PPA = m_profA->GetAlignedPos(uPrefixLengthA - 1);
    const ProfPos &PPB = m_profB->GetAlignedPos(uPrefixLengthB - 1);
    const FCOUNT fcGapOpens = PPA.m_fcFE + PPB.m_fcFE;
    const FCOUNT fcGapExtends = PPA.m_fcEE + PPB.m_fcEE;
    SCORE scoreTrans = fcGapOpens*m_scoreGapOpen + fcGapExtends*m_scoreGapExtend;
    return scoreTrans;
    }

SCORE PWBase::ScoreMD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
// Terminal gaps are free
    if (GetLengthB() == uPrefixLengthB)
        return 0;

    if (GAPSTYLE_Simple == m_GapStyle)
        return m_scoreGapOpen;

    assert(uPrefixLengthA > 0 && uPrefixLengthB > 0);
    const ProfPos &PPA = m_profA->GetAlignedPos(uPrefixLengthA - 1);
    const ProfPos &PPB = m_profB->GetAlignedPos(uPrefixLengthB - 1);
    const FCOUNT fcGapOpens = PPA.m_fcFE + PPB.m_fcF;
    const FCOUNT fcGapExtends = PPA.m_fcEE + PPB.m_fcE;
    SCORE scoreTrans = fcGapOpens*m_scoreGapOpen + fcGapExtends*m_scoreGapExtend;
    return scoreTrans;
    }

SCORE PWBase::ScoreMI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
// Terminal gaps are free
    if (GetLengthA() == uPrefixLengthA)
        return 0;

    if (GAPSTYLE_Simple == m_GapStyle)
        return m_scoreGapOpen;

    assert(uPrefixLengthA > 0 && uPrefixLengthB > 0);
    const ProfPos &PPA = m_profA->GetAlignedPos(uPrefixLengthA - 1);
    const ProfPos &PPB = m_profB->GetAlignedPos(uPrefixLengthB - 1);
    const FCOUNT fcGapOpens = PPA.m_fcF + PPB.m_fcFE;
    const FCOUNT fcGapExtends = PPA.m_fcE + PPB.m_fcEE;
    SCORE scoreTrans = fcGapOpens*m_scoreGapOpen + fcGapExtends*m_scoreGapExtend;
    return scoreTrans;
    }

SCORE PWBase::ScoreDM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GAPSTYLE_Simple == m_GapStyle)
        return 0;

    assert(uPrefixLengthA > 0 && uPrefixLengthB > 0);
    const ProfPos &PPA = m_profA->GetAlignedPos(uPrefixLengthA - 1);
    const ProfPos &PPB = m_profB->GetAlignedPos(uPrefixLengthB - 1);
    const FCOUNT fcGapOpens = PPA.m_fcFE;
    const FCOUNT fcGapExtends = PPA.m_fcEE + PPB.m_fcE;
    SCORE scoreTrans = fcGapOpens*m_scoreGapOpen + fcGapExtends*m_scoreGapExtend;
    return scoreTrans;
    }

SCORE PWBase::ScoreDD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GAPSTYLE_Simple == m_GapStyle)
        return m_scoreGapExtend;

    assert(uPrefixLengthA > 0);
    const ProfPos &PPA = m_profA->GetAlignedPos(uPrefixLengthA - 1);
    const FCOUNT fcGapOpens = PPA.m_fcFE;
    const FCOUNT fcGapExtends = PPA.m_fcEE + (FCOUNT) 1.0;
    SCORE scoreTrans = fcGapOpens*m_scoreGapOpen + fcGapExtends*m_scoreGapExtend;
    return scoreTrans;
    }

SCORE PWBase::ScoreDI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
// Terminal gaps are free
    if (GetLengthA() == uPrefixLengthA)
        return 0;

    if (GAPSTYLE_Simple == m_GapStyle)
        return m_scoreGapOpen;

    assert(uPrefixLengthA > 0 && uPrefixLengthB > 0);
    const ProfPos &PPA = m_profA->GetAlignedPos(uPrefixLengthA - 1);
    const ProfPos &PPB = m_profB->GetAlignedPos(uPrefixLengthB - 1);
    const FCOUNT fcGapOpens = PPA.m_fcF;
    const FCOUNT fcGapExtends = PPA.m_fcE + PPB.m_fcE;
    SCORE scoreTrans = fcGapOpens*m_scoreGapOpen + fcGapExtends*m_scoreGapExtend;
    return scoreTrans;
    }

SCORE PWBase::ScoreIM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GAPSTYLE_Simple == m_GapStyle)
        return 0;

    assert(uPrefixLengthA > 0 && uPrefixLengthB > 0);
    const ProfPos &PPA = m_profA->GetAlignedPos(uPrefixLengthA - 1);
    const ProfPos &PPB = m_profB->GetAlignedPos(uPrefixLengthB - 1);
    const FCOUNT fcGapOpens = PPB.m_fcFE;
    const FCOUNT fcGapExtends = PPA.m_fcE + PPB.m_fcEE;
    SCORE scoreTrans = fcGapOpens*m_scoreGapOpen + fcGapExtends*m_scoreGapExtend;
    return scoreTrans;
    }

SCORE PWBase::ScoreID(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
// Terminal gaps are free
    if (GetLengthB() == uPrefixLengthB)
        return 0;

    if (GAPSTYLE_Simple == m_GapStyle)
        return m_scoreGapOpen;

    assert(uPrefixLengthA > 0 && uPrefixLengthB > 0);
    const ProfPos &PPA = m_profA->GetAlignedPos(uPrefixLengthA - 1);
    const ProfPos &PPB = m_profB->GetAlignedPos(uPrefixLengthB - 1);
    const FCOUNT fcGapOpens = PPB.m_fcF;
    const FCOUNT fcGapExtends = PPA.m_fcE + PPB.m_fcE;
    SCORE scoreTrans = fcGapOpens*m_scoreGapOpen + fcGapExtends*m_scoreGapExtend;
    return scoreTrans;
    }

SCORE PWBase::ScoreII(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (GAPSTYLE_Simple == m_GapStyle)
        return m_scoreGapExtend;

    assert(uPrefixLengthB > 0);
    const ProfPos &PPB = m_profB->GetAlignedPos(uPrefixLengthB - 1);
    const FCOUNT fcGapOpens = PPB.m_fcFE;
    const FCOUNT fcGapExtends = PPB.m_fcEE + (FCOUNT) 1.0;
    SCORE scoreTrans = fcGapOpens*m_scoreGapOpen + fcGapExtends*m_scoreGapExtend;
    return scoreTrans;
    }

SCORE PWBase::ScoreSM(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (m_BoundsA == GLOBAL && uPrefixLengthA != 1)
        return MINUS_INFINITY;
    if (m_BoundsB == GLOBAL && uPrefixLengthB != 1)
        return MINUS_INFINITY;

    if (0 == uPrefixLengthA || 0 == uPrefixLengthB)
        return MINUS_INFINITY;

// Terminal gaps are free
    return 0;
    }

SCORE PWBase::ScoreSD(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (m_BoundsA == LOCAL)
        return MINUS_INFINITY;

    if (m_BoundsA == GLOBAL && uPrefixLengthA != 1)
        return MINUS_INFINITY;

    if (m_BoundsB == GLOBAL && uPrefixLengthB != 0)
        return MINUS_INFINITY;
    
    if (0 == uPrefixLengthA)
        return MINUS_INFINITY;

// Terminal gaps are free
    return 0;
    }

SCORE PWBase::ScoreSI(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (m_BoundsB == LOCAL)
        return MINUS_INFINITY;

    if (m_BoundsA == GLOBAL && uPrefixLengthA != 0)
        return MINUS_INFINITY;
    if (m_BoundsB == GLOBAL && uPrefixLengthB != 1)
        return MINUS_INFINITY;

    if (0 == uPrefixLengthB)
        return MINUS_INFINITY;

// Terminal gaps are free
    return 0;
    }

SCORE PWBase::ScoreME(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (m_BoundsA == GLOBAL && uPrefixLengthA != m_uLengthA)
        return MINUS_INFINITY;
    if (m_BoundsB == GLOBAL && uPrefixLengthB != m_uLengthB)
        return MINUS_INFINITY;

    if (0 == uPrefixLengthA || 0 == uPrefixLengthB)
        return MINUS_INFINITY;

// Terminal gaps are free
    return 0;
    }

SCORE PWBase::ScoreDE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (m_BoundsA == GLOBAL && uPrefixLengthA != m_uLengthA)
        return MINUS_INFINITY;
    if (m_BoundsB == GLOBAL && uPrefixLengthB != m_uLengthB)
        return MINUS_INFINITY;

    if (LOCAL == m_BoundsA)
        return MINUS_INFINITY;

    if (0 == uPrefixLengthA || 0 == uPrefixLengthB)
        return MINUS_INFINITY;

// Terminal gaps are free
    return 0;
    }

SCORE PWBase::ScoreIE(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    if (m_BoundsA == GLOBAL && uPrefixLengthA != m_uLengthA)
        return MINUS_INFINITY;
    if (m_BoundsB == GLOBAL && uPrefixLengthB != m_uLengthB)
        return MINUS_INFINITY;

    if (LOCAL == m_BoundsB)
        return MINUS_INFINITY;

    if (0 == uPrefixLengthA || 0 == uPrefixLengthB)
        return MINUS_INFINITY;

// Terminal gaps are free
    return 0;
    }

SCORE PWBase::ScoreLL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    assert(uPrefixLengthA > 0 && uPrefixLengthB > 0);
    const ProfPos &PPA = m_profA->GetAlignedPos(uPrefixLengthA - 1);
    const ProfPos &PPB = m_profB->GetAlignedPos(uPrefixLengthB - 1);
    const SCORE scoreProfPos = ScoreProfPos(PPA, PPB);
    return scoreProfPos - m_scoreShift;
    }

SCORE PWBase::ScoreLG(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return 0;
    }

SCORE PWBase::ScoreGL(unsigned uPrefixLengthA, unsigned uPrefixLengthB) const
    {
    return 0;
    }
