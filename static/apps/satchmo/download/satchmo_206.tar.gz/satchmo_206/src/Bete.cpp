// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "Seq.h"
#include "TextFile.h"
#include "Bete.h"
#include "PPDist.h"
#include "Profile.h"
#include "Clust.h"

#define VERBOSE 1

extern DirMix *g_ptrdirmixMatchEmitPrior;

extern SCORE LogProbCountsGivenMix(const DirMix *ptrMix, const double dCounts[]);

static void GetColCounts(const MSA &msa, unsigned uColIndex, double dCounts[])
    {
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        dCounts[uLetter] = 0;

    const unsigned uSeqCount = msa.GetSeqCount();

    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        unsigned uLetter = msa.GetLetter(uSeqIndex, uColIndex);
        ++(dCounts[uLetter]);
        }
    }

static SCORE ColLogProbNull(double dCounts[])
    {
    SCORE Score = 0;
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        Score += (SCORE) dCounts[uLetter]*GetNullEmitScore(uLetter);
    return Score;
    }

static SCORE ColLogProbMix(double dCounts[])
    {
    return LogProbCountsGivenMix(g_ptrdirmixMatchEmitPrior, dCounts);
    }

Bete::Bete()
    {
    m_ptrMSA = 0;
    m_ptrPPDist = 0;
    m_MSAs = 0;
    m_Profiles = 0;
    m_JoinStyle = JOINSTYLE_NearestNeighbor;
    m_CentroidStyle = CENTROIDSTYLE_ComputedBySet;
    }

Bete::~Bete()
    {
    delete[] m_MSAs;
    delete[] m_Profiles;
    }

JOINSTYLE Bete::GetJoinStyle()
    {
    return m_JoinStyle;
    }

CENTROIDSTYLE Bete::GetCentroidStyle()
    {
    return m_CentroidStyle;
    }

void Bete::SetJoinStyle(JOINSTYLE JoinStyle)
    {
    m_JoinStyle = JoinStyle;
    }

void Bete::SetCentroidStyle(CENTROIDSTYLE CentroidStyle)
    {
    m_CentroidStyle = CentroidStyle;
    }

unsigned Bete::GetLeafCount()
    {
    return m_ptrMSA->GetSeqCount();
    }

const char *Bete::GetLeafName(unsigned uNodeIndex)
    {
    return m_ptrMSA->GetSeqName(uNodeIndex);
    }

bool Bete::IsRooted()
    {
    if (CENTROIDSTYLE_NeighborJoining == m_CentroidStyle)
        return false;
    return true;
    }

double Bete::ComputeDist(const Clust &C, unsigned uNodeIndex1, unsigned uNodeIndex2)
    {
    const Profile &Prof1 = m_Profiles[uNodeIndex1];
    const Profile &Prof2 = m_Profiles[uNodeIndex2];
    return m_ptrPPDist->ComputePPDist(Prof1, Prof2);
    }

void Bete::JoinNodes(const Clust &C, unsigned uLeftNodeIndex,
  unsigned uRightNodeIndex, unsigned uJoinedNodeIndex,
  double *ptrdLeftLength, double *ptrdRightLength)
    {
#if    VERBOSE
    List("Bete::JoinNodes(L=%u, R=%u, J=%u)\n",
      uLeftNodeIndex, uRightNodeIndex, uJoinedNodeIndex);
#endif

    const double dLogProb = LogProb(C);

#if VERBOSE
    List("LogProb=%g\n", dLogProb);
#endif

    const MSA &msaLeft = m_MSAs[uLeftNodeIndex];
    const MSA &msaRight = m_MSAs[uRightNodeIndex];
    MSA &msaJoined = m_MSAs[uJoinedNodeIndex];

    const unsigned uLeftSeqCount = msaLeft.GetSeqCount();
    const unsigned uRightSeqCount = msaRight.GetSeqCount();
    const unsigned uColCount = msaLeft.GetColCount();
    assert(msaRight.GetColCount() == uColCount);

    msaJoined.SetSize(uLeftSeqCount + uRightSeqCount, uColCount);
    
    for (unsigned uSeqIndex = 0; uSeqIndex < uLeftSeqCount; ++uSeqIndex)
        {
        const char *ptrSeqName = msaLeft.GetSeqName(uSeqIndex);
        msaJoined.SetSeqName(uSeqIndex, ptrSeqName);
        for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
            {
            const char c = msaLeft.GetChar(uSeqIndex, uColIndex);
            msaJoined.SetChar(uSeqIndex, uColIndex, c);
            }
        }

    for (unsigned uSeqIndex = 0; uSeqIndex < uRightSeqCount; ++uSeqIndex)
        {
        const char *ptrSeqName = msaRight.GetSeqName(uSeqIndex);
        msaJoined.SetSeqName(uLeftSeqCount + uSeqIndex, ptrSeqName);
        for (unsigned uColIndex = 0; uColIndex < uColCount; ++uColIndex)
            {
            const char c = msaRight.GetChar(uSeqIndex, uColIndex);
            msaJoined.SetChar(uLeftSeqCount + uSeqIndex, uColIndex, c);
            }
        }

    msaJoined.SetAlphabet(ALPHABET_Amino);
    msaJoined.AlignByCaseOrDash();

//#if    VERBOSE
//    List("msaLeft=\n");
//    msaLeft.ListMe();
//    List("msaRight=\n");
//    msaRight.ListMe();
//    List("msaJoined=\n");
//    msaJoined.ListMe();
//#endif

    Profile &profJoined = m_Profiles[uJoinedNodeIndex];

    const char *ptrSeedId = msaJoined.GetSeqName(0);

    msaJoined.BuildPillars();
    profJoined.FromMSA(msaJoined, ptrSeedId);
    msaJoined.FreePillars();

//#if    VERBOSE
//    List("profJoined=\n");
//    profJoined.ListMe();
//#endif

    const double dDistLR = C.GetDist(uLeftNodeIndex, uRightNodeIndex);
    *ptrdLeftLength = dDistLR/2;
    *ptrdRightLength = dDistLR/2;

//#if    VERBOSE
//    List("DistLR=%g edge=%g\n", dDistLR, dDistLR/2);
//    profJoined.ListMe();
//#endif
    }

void Bete::Init(MSA &msa, PPDist &Dist)
    {
      fprintf(stderr, "Bete Init\n");
    m_ptrMSA = &msa;
    m_wcNIC = msa.GetRawNIC();
    m_ptrPPDist = &Dist;

    const unsigned uSeqCount = msa.GetSeqCount();
    const unsigned uNodeCount = 2*uSeqCount - 1;

    m_MSAs = new MSA[uNodeCount];
    m_Profiles = new Profile[uNodeCount];
    
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        Seq s;
        msa.GetAlignedSeq(uSeqIndex, s);
        
        MSA &Leaf = m_MSAs[uSeqIndex];
        Leaf.FromSeq(s);
        Leaf.AlignByCaseOrDash();

//#if VERBOSE
//        List("Leaf %u=\n", uSeqIndex);
//        Leaf.ListMe();
//#endif

        const char *ptrSeedId = Leaf.GetSeqName(0);

        Profile &LeafProf = m_Profiles[uSeqIndex];

        Leaf.BuildPillars();
        LeafProf.FromMSA(Leaf, ptrSeedId);
        Leaf.FreePillars();
        }
    }
