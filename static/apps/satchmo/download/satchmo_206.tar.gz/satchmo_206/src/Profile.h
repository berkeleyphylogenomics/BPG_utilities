// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef Profile_h
#define    Profile_h

class MSA;
class DataBuffer;
class Ckp;
struct CkpPos;

struct ProfPos
    {
    bool m_bAligned;
    FCOUNT m_fcCounts[MAX_ALPHA];        // Fractional counts (sum <= 1)
    PROB m_Probs[MAX_ALPHA];            // Probabilities (sum = 1)
    FCOUNT m_fcE;
    FCOUNT m_fcF;
    FCOUNT m_fcFF;
    FCOUNT m_fcEF;
    FCOUNT m_fcFE;
    FCOUNT m_fcEE;
    FCOUNT m_fcT;
    };

class Profile
    {
public:
    Profile();
    virtual ~Profile();

    void FromMSA(const MSA &a, const char *pstrSeedId);
    void FromBuffer(const DataBuffer &Data, const char *pstrSeedId = "");
    void FromCkp(const Ckp &Prof, const char *pstrSeedId = "");
    void SetPosCount(unsigned uPosCount);
    unsigned GetPosCount() const { return m_uPosCount; }
    unsigned GetAlignedPosCount() const;
    void ToBuffer(DataBuffer &Data) const;
    const ProfPos &GetPos(unsigned uPosIndex) const;
    const ProfPos &GetAlignedPos(unsigned uAlignedPosIndex) const;
    void SetPos(const ProfPos &PP, unsigned uPosIndex);
    unsigned GetBufferSize() const;
    void Clear();
    void SetSize(unsigned uPosCount, unsigned uSeedLength);
    void ListMe() const;
    void ListCounts() const;
    double BitsSaved() const;
    void GetSeed(Seq &seqSeed) const;
    unsigned PosIndexToSeedColIndex(unsigned uPosIndex) const;
    unsigned AlignedPosIndexToSeedColIndex(unsigned uAlignedPosIndex) const;
    unsigned SeedColIndexToPosIndex(unsigned uPosIndex) const;
    void SetName(const char *pstrName);
    const char *GetName() const { return m_pstrName; }
    unsigned GetSeedLength() const;
    unsigned GetUnalignedPosIndex(unsigned uAlignedPosIndex) const;

    WEIGHT GetTotalSeqWeight() const { return m_weightTotalSeq; }

    static void CkpPosToProfPos(const CkpPos &CP, ProfPos &PP);

private:
    void AddPseudoCounts();
    void CountsToProbs(const FCOUNT fcCounts[], double dNIC, PROB Probs[]);
    void AddPseudoCountsBitsSaved(double dBitsToSave, unsigned uMaxIter,
      double dMaxErrorPct);
    void AddPseudoCountsBitsSavedIter(double dNIC);
    void BuildSeedMaps() const;
    const unsigned *GetAlignedSeedColIndexToPosIndex() const;

private:
    unsigned m_uPosCount;
    ProfPos *m_Pos;
    char *m_pstrSeed;
    char *m_pstrName;
    WEIGHT m_weightTotalSeq;
    mutable unsigned m_uSeedLength;
    mutable unsigned *m_uSeedColIndexToPosIndex;
    mutable unsigned *m_uPosIndexToSeedColIndex;
    mutable unsigned m_uAlignedPosCount;
    mutable unsigned *m_uAlignedIndexToUnalignedIndex;
    };

#endif    // Profile_h
