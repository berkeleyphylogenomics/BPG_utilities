// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "GNode2.h"
#include "GTree2.h"
#include "SeqVect.h"

GTree2::~GTree2()
    {
    Free();
    }

void GTree2::FreeSubtree(GNode2 *ptrRoot)
    {
    if (0 == ptrRoot)
        return;
    FreeSubtree(ptrRoot->m_ptrLeft);
    FreeSubtree(ptrRoot->m_ptrRight);
    delete ptrRoot;
    }

void GTree2::Free()
    {
    FreeSubtree(m_ptrRoot);
    delete[] m_Nodes;
    m_ptrRoot = 0;
    m_ptrDisjoints = 0;
    m_ptrJoins = 0;
    m_uNodeCount = 0;
    }

GNode2 *GTree2::GetRoot()
    {
    return m_ptrRoot;
    }

unsigned GTree2::TreeSize(const GNode2 *ptrRoot) const
    {
    if (0 == ptrRoot)
        return 0;
    return 1 + TreeSize(ptrRoot->m_ptrLeft) + TreeSize(ptrRoot->m_ptrRight);
    }

unsigned GTree2::ForestSize(const GNode2 *ptrForest) const
    {
    unsigned uSize = 0;
    for (const GNode2 *ptrNode = ptrForest; ptrNode; ptrNode = ptrNode->m_ptrNext)
        {
        unsigned uTreeSize = TreeSize(ptrNode);
        uSize += uTreeSize;
        }
    return uSize;
    }

void GTree2::Validate() const
    {
    GNode2::ValidateList(m_ptrDisjoints);
    GNode2::ValidateList(m_ptrJoins);

    unsigned uDisjointLength = GNode2::GetListLength(m_ptrDisjoints);
    unsigned uJoinCount = GNode2::GetListLength(m_ptrJoins);
    unsigned uDisjointCount = ForestSize(m_ptrDisjoints);
    //  assert(m_uNodeCount == uDisjointCount + uJoinCount );
    }

GNode2 *GTree2::GetNode(unsigned uNodeIndex)
    {
    assert(uNodeIndex <= m_uNodeCount);
    return m_Nodes[uNodeIndex];
    }

unsigned GTree2::GetNodeCount() const
    {
    return m_uNodeCount;
    }

unsigned GTree2::GetLeafCount() const
    {
    if (0 == m_uNodeCount)
        return 0;
    return (m_uNodeCount + 1)/2;
    }

unsigned GTree2::GetJoinCount() const
    {
    return GetNodeCount() - GetLeafCount();
    }

double GTree2::GetDist(unsigned uNodeIndexA, unsigned uNodeIndexB)
    {
    assert(uNodeIndexA < m_uNodeCount);
    assert(uNodeIndexB < m_uNodeCount);
    assert(uNodeIndexA != uNodeIndexB);
    double *ptrDist = GetNode(uNodeIndexA)->m_Dist;
    if (0 == ptrDist)
        return 0;
    return ptrDist[uNodeIndexB];
    }

void GTree2::Clear()
    {
    Free();
    }

void GTree2::SetInputSeqs(const SeqVect &Seqs)
    {
    Clear();
    m_InputSeqs.Copy(Seqs);
    }
