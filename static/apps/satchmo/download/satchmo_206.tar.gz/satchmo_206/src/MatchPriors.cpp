// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "DirMix.h"
#include <math.h>

static DirMix *DefaultMatchEmitPrior();
static DirMix *DefaultNullEmitPrior();

DirMix *g_ptrdirmixMatchEmitPrior = DefaultMatchEmitPrior();
DirMix *g_ptrdirmixNullEmitPrior = DefaultNullEmitPrior();

#define    EMIT_PRIOR(n, p, A, C, D, E, F, G, H, I, K,    \
  L, M, N, P, Q, R, S, T, V, W, Y)                        \
    {                                                    \
    DirComp *ptrComp = &ptrDM->m_Comps[n];                \
    ptrComp->m_dAlphas[0] = (A);                        \
    ptrComp->m_dAlphas[1] = (C);                        \
    ptrComp->m_dAlphas[2] = (D);                        \
    ptrComp->m_dAlphas[3] = (E);                        \
    ptrComp->m_dAlphas[4] = (F);                        \
    ptrComp->m_dAlphas[5] = (G);                        \
    ptrComp->m_dAlphas[6] = (H);                        \
    ptrComp->m_dAlphas[7] = (I);                        \
    ptrComp->m_dAlphas[8] = (K);                        \
    ptrComp->m_dAlphas[9] = (L);                        \
    ptrComp->m_dAlphas[10] = (M);                        \
    ptrComp->m_dAlphas[11] = (N);                        \
    ptrComp->m_dAlphas[12] = (P);                        \
    ptrComp->m_dAlphas[13] = (Q);                        \
    ptrComp->m_dAlphas[14] = (R);                        \
    ptrComp->m_dAlphas[15] = (S);                        \
    ptrComp->m_dAlphas[16] = (T);                        \
    ptrComp->m_dAlphas[17] = (V);                        \
    ptrComp->m_dAlphas[18] = (W);                        \
    ptrComp->m_dAlphas[19] = (Y);                        \
    double dSum = 0;                                    \
    for (unsigned i = 0; i < 20; ++i)                    \
        dSum += ptrComp->m_dAlphas[i];                    \
    ptrComp->m_dSumAlphas = dSum;                        \
    ptrComp->m_dCompProb = (p);                            \
    ptrComp->m_dLogCompProb = log(ptrComp->m_dCompProb);\
    }

static DirMix *DefaultMatchEmitPrior()
    {
    DirMix *ptrDM = new DirMix;
    ptrDM->m_uAlphaCount = 20;
    ptrDM->m_uCompCount = 9;
    ptrDM->m_Comps = new DirComp[20];

    EMIT_PRIOR(0, 0.178091,
        0.270671, 0.039848, 0.017576, 0.016415, 0.014268, 
        0.131916, 0.012391, 0.022599, 0.020358, 0.030727, 
        0.015315, 0.048298, 0.053803, 0.020662, 0.023612,
        0.216147, 0.147226, 0.065438, 0.003758, 0.009621)

    EMIT_PRIOR(1, 0.056591,
        0.021465, 0.010300, 0.011741, 0.010883, 0.385651, 
        0.016416, 0.076196, 0.035329, 0.013921, 0.093517, 
        0.022034, 0.028593, 0.013086, 0.023011, 0.018866, 
        0.029156, 0.018153, 0.036100, 0.071770, 0.419641)

    EMIT_PRIOR(2, 0.0960191,
        0.561459, 0.045448, 0.438366, 0.764167, 0.087364,
        0.259114, 0.214940, 0.145928, 0.762204, 0.247320,
        0.118662, 0.441564, 0.174822, 0.530840, 0.465529, 
        0.583402, 0.445586, 0.227050, 0.029510, 0.121090)

    EMIT_PRIOR(3, 0.0781233,
        0.070143, 0.011140, 0.019479, 0.094657, 0.013162, 
        0.048038, 0.077000, 0.032939, 0.576639, 0.072293, 
        0.028240, 0.080372, 0.037661, 0.185037, 0.506783, 
        0.073732, 0.071587, 0.042532, 0.011254, 0.028723)

    EMIT_PRIOR(4, 0.0834977,
        0.041103, 0.014794, 0.005610, 0.010216, 0.153602, 
        0.007797, 0.007175, 0.299635, 0.010849, 0.999446, 
        0.210189, 0.006127, 0.013021, 0.019798, 0.014509, 
        0.012049, 0.035799, 0.180085, 0.012744, 0.026466)

    EMIT_PRIOR(5, 0.0904123,
        0.115607, 0.037381, 0.012414, 0.018179, 0.051778, 
        0.017255, 0.004911, 0.796882, 0.017074, 0.285858, 
        0.075811, 0.014548, 0.015092, 0.011382, 0.012696, 
        0.027535, 0.088333, 0.944340, 0.004373, 0.016741)
    
    EMIT_PRIOR(6, 0.114468,
        0.093461, 0.004737, 0.387252, 0.347841, 0.010822, 
        0.105877, 0.049776, 0.014963, 0.094276, 0.027761, 
        0.010040, 0.187869, 0.050018, 0.110039, 0.038668, 
        0.119471, 0.065802, 0.025430, 0.003215, 0.018742)

    EMIT_PRIOR(7, 0.0682132,
        0.452171, 0.114613, 0.062460, 0.115702, 0.284246,
        0.140204, 0.100358, 0.550230, 0.143995, 0.700649, 
        0.276580, 0.118569, 0.097470, 0.126673, 0.143634, 
        0.278983, 0.358482, 0.661750, 0.061533, 0.199373)

    EMIT_PRIOR(8, 0.234585,
        0.005193, 0.004039, 0.006722, 0.006121, 0.003468, 
        0.016931, 0.003647, 0.002184, 0.005019, 0.005990, 
        0.001473, 0.004158, 0.009055, 0.003630, 0.006583, 
        0.003172, 0.003690, 0.002967, 0.002772, 0.002686)

    ptrDM->Validate();
    return ptrDM;
    }

void SetMatchPriors(const char *strMatchPriorFileName)
    {
    delete g_ptrdirmixMatchEmitPrior;
    g_ptrdirmixMatchEmitPrior = new DirMix;
    TextFile File(strMatchPriorFileName);
    g_ptrdirmixMatchEmitPrior->FromFile(File);
    g_ptrdirmixMatchEmitPrior->Validate();
    }

void Set_matchprior(const char *in)
    {
    SetMatchPriors(in);
    }
static DirMix *DefaultNullEmitPrior()
    {
    DirMix *ptrDM = new DirMix;
    ptrDM->m_uAlphaCount = 20;
    ptrDM->m_uCompCount = 1;
    ptrDM->m_Comps = new DirComp[1];

    EMIT_PRIOR(0, 1,
        1.27766*10, 0.315614*10, 1.67433*10, 1.24089*10, 0.557719*10,
        0.621908*10,0.500621*10, 1.66738*10, 0.873265*10, 2.3084*10,
        0.768123*10, 0.855952*10,0.692243*10, 0.721669*10, 1.08449*10,
        1.03986*10, 0.912243*10, 1.96176*10, 0.175105*10, 0.352687*10)

    ptrDM->Validate();
    return ptrDM;
    }
