// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

typedef unsigned __int64 TICKS;

#pragma warning(disable:4035)
inline TICKS GetClockTicks()
    {
    _asm
        {
        _emit    0x0f
        _emit    0x31
        }
    }

#define    StartTimer()    __int64 t1__ = GetClockTicks()

#define    GetElapsedTicks()    (GetClockTicks() - t1__)

static double TicksToSecs(TICKS t)
    {
    return (__int64) t/500000000.0;
    }
