// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "MSA.h"
#include "Seq.h"

#ifndef    VERBOSE
#define    VERBOSE 0
#endif

//SCORE HMM::ScorePathSeq(const HMMPath &Path, const Seq &s) const
//    {
//#if    VERBOSE
//    List("HMM::ScorePathSeq\n");
//#endif
//    unsigned uEdgeCount = Path.GetEdgeCount();
//
//    SCORE Score = 0;
//
//// First edge is special case
//    const HMMEdge &FirstEdge = Path.GetEdge(0);
//    assert(0 == FirstEdge.uNodeIndex);
//    char cToState = FirstEdge.cState;
//    assert('M' == cToState || 'D' == cToState);
//    Score += GetTransScore(0, 'S', cToState);
//
////    if ('M' == FirstEdge.cState)
////        {
////        Score = TransScoreFirstM();
////#if    VERBOSE
////        List("%7d  trans S->M%u = %s\n", Score, FirstEdge.uNodeIndex, ScoreToStr(Score));
////#endif
////        cFromState = 'M';
////        }
////    else
////        {
////        assert('D' == FirstEdge.cState);
////        Score = TransScoreFirstD();
////#if    VERBOSE
////        List("%7d  trans S->D%u = %s\n", Score, FirstEdge.uNodeIndex, ScoreToStr(Score));
////#endif
////        cFromState = 'D';
////        }
//
//    for (unsigned uEdgeIndex = 1; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
//        {
//        char cFromState = cToState;
//        const HMMEdge &Edge = Path.GetEdge(uEdgeIndex);
//        cToState = Edge.cState;
//        unsigned uFromNodeIndex;
//        if ('M' == cToState || 'D' == cToState)
//            uFromNodeIndex = Edge.uNodeIndex - 1;
//        else
//            {
//            assert('I' == cToState);
//            uFromNodeIndex = Edge.uNodeIndex;
//            }
//
////        const HMMNode &Node = GetNode(uFromNodeIndex);
////        SCORE scoreTrans;
////#define    c2(a, b)    ((a) | ((b) << 8))
////        int iStates = c2(cFromState, cToState);
////        switch (iStates)
////            {
////        case c2('M', 'M'): scoreTrans = Node.m_scoreMM; break;
////        case c2('M', 'D'): scoreTrans = Node.m_scoreMD; break;
////        case c2('M', 'I'): scoreTrans = Node.m_scoreMI; break;
////        case c2('D', 'M'): scoreTrans = Node.m_scoreDM; break;
////        case c2('D', 'D'): scoreTrans = Node.m_scoreDD; break;
////        case c2('D', 'I'): scoreTrans = Node.m_scoreDI; break;
////        case c2('I', 'M'): scoreTrans = Node.m_scoreIM; break;
////        case c2('I', 'D'): scoreTrans = Node.m_scoreID; break;
////        case c2('I', 'I'): scoreTrans = Node.m_scoreII; break;
////        default: assert(false);
////            }
////        Score += scoreTrans;
//
//        Score += GetTransScore(uFromNodeIndex, cFromState, cToState);
//        cFromState = cToState;
//#if    VERBOSE
//        List("%7s  trans %c->%c%u = %s\n",
//          ScoreToStr(Score),
//          cFromState,
//          Edge.cState,
//          Edge.uNodeIndex,
//          ScoreToStr(scoreTrans));
//#endif
//        }
//#undef c2
//    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
//        {
//        const HMMEdge &Edge = Path.GetEdge(uEdgeIndex);
//        if ('M' == Edge.cState)
//            {
//            assert(Edge.uPrefixLength > 0);
//            const unsigned uColIndex = Edge.uPrefixLength - 1;
//            const char c = s[uColIndex];
//
//            //const HMMNode &Node = GetNode(Edge.uNodeIndex);
//            //SCORE scoreEmit;
//            //if ('x' == c || 'X' == c)
//            //    scoreEmit = 0;
//            //else if ('b' == c || 'B' == c)
//            //    scoreEmit = (SCORE) (Node.m_scoreMatchEmit[AX_D]*0.4606 +
//            //      Node.m_scoreMatchEmit[AX_N]*0.5394);
//            //else if ('z' == c || 'Z' == c)
//            //    scoreEmit = (SCORE) (Node.m_scoreMatchEmit[AX_E]*0.6110 +
//            //      Node.m_scoreMatchEmit[AX_Q]*0.3890);
//            //else
//            //    {
//            //    unsigned uLetter = s.GetLetter(uColIndex);
//            //    scoreEmit = Node.m_scoreMatchEmit[uLetter];
//            //    }
//
//            SCORE scoreEmit = GetMatchEmitScore(Edge.uNodeIndex, c);
//            Score += scoreEmit;
//#if    VERBOSE
//            List("%7s  emit M%u(%c) = %s\n",
//              ScoreToStr(Score),
//              Edge.uNodeIndex,
//              s[Edge.uPrefixLength-1],
//              ScoreToStr(scoreEmit));
//#endif
//            }
//        }
//    return Score;
//    }

SCORE HMM::TransScorePath(const HMMPath &Path) const
    {
    SCORE scorePath = 0;
    for (unsigned uEdgeIndex = 0; uEdgeIndex < Path.GetEdgeCount(); ++uEdgeIndex)
        {
        SCORE scoreEdge = Path.GetTransScore(uEdgeIndex, *this);
        scorePath = Add2(scorePath, scoreEdge);
        }
    return scorePath;
    }

SCORE HMM::ScorePathSeq(const HMMPath &Path, const Seq &s) const
    {
    SCORE scorePath = 0;
    for (unsigned uEdgeIndex = 0; uEdgeIndex < Path.GetEdgeCount(); ++uEdgeIndex)
        {
        SCORE scoreEdge = Path.GetEdgeScore(uEdgeIndex, *this, s);
        scorePath = Add2(scorePath, scoreEdge);
        }
    return scorePath;
    }

SCORE HMM::ScorePathAlnSeq(const HMMPath &Path, const MSA &a, unsigned uSeqIndex) const
    {
    Seq s;
    a.GetSeq(uSeqIndex, s);

    unsigned uEdgeCount = Path.GetEdgeCount();
    const HMMEdge &FirstEdge = Path.GetEdge(0);
    SCORE Score;
    char cFromState;
    if ('M' == FirstEdge.cState)
        {
        Score = m_scoreFirstM;
#if    VERBOSE
        List("%7s  trans S->M%u = %d\n",
          ScoreToStr(Score),
          FirstEdge.uNodeIndex,
          ScoreToStr(Score));
#endif
        cFromState = 'M';
        }
    else
        {
        assert('D' == FirstEdge.cState);
        Score = m_scoreFirstD;
#if    VERBOSE
        List("%7s  trans S->D%u = %s\n",
          ScoreToStr(Score),
          FirstEdge.uNodeIndex,
          ScoreToStr(Score));
#endif
        cFromState = 'D';
        }
    for (unsigned uEdgeIndex = 1; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const HMMEdge &Edge = Path.GetEdge(uEdgeIndex);
        char cToState = Edge.cState;
        unsigned uFromNodeIndex;
        if ('M' == cToState || 'D' == cToState)
            uFromNodeIndex = Edge.uNodeIndex - 1;
        else
            {
            assert('I' == cToState);
            uFromNodeIndex = Edge.uNodeIndex;
            }
        const HMMNode &Node = GetNode(uFromNodeIndex);
        SCORE scoreTrans;
#define    c2(a, b)    ((a) | ((b) << 8))
        int iStates = c2(cFromState, cToState);
        switch (iStates)
            {
        case c2('M', 'M'): scoreTrans = Node.m_scoreMM; break;
        case c2('M', 'D'): scoreTrans = Node.m_scoreMD; break;
        case c2('M', 'I'): scoreTrans = Node.m_scoreMI; break;
        case c2('D', 'M'): scoreTrans = Node.m_scoreDM; break;
        case c2('D', 'D'): scoreTrans = Node.m_scoreDD; break;
        case c2('D', 'I'): scoreTrans = Node.m_scoreDI; break;
        case c2('I', 'M'): scoreTrans = Node.m_scoreIM; break;
        case c2('I', 'D'): scoreTrans = Node.m_scoreID; break;
        case c2('I', 'I'): scoreTrans = Node.m_scoreII; break;
        default: assert(false);
            }
        Score += scoreTrans;
#if    VERBOSE
        List("%7s  trans %c->%c%u = %s\n",
          ScoreToStr(Score),
          cFromState,
          Edge.cState,
          Edge.uNodeIndex,
          ScoreToStr(scoreTrans));
#endif
        cFromState = cToState;
        }
#undef c2
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const HMMEdge &Edge = Path.GetEdge(uEdgeIndex);
        if ('M' == Edge.cState)
            {
            const HMMNode &Node = GetNode(Edge.uNodeIndex);
            assert(Edge.uPrefixLength > 0);
            unsigned uColIndex = Edge.uPrefixLength - 1;
            char c = s[uColIndex];
            c = toupper(c);
            if ('B' == c)
                Score += (Node.m_scoreMatchEmit[AX_D]*4606)/10000 + 
                  (Node.m_scoreMatchEmit[AX_N]*5394)/10000;
            else if ('Z' == c)
                Score += (Node.m_scoreMatchEmit[AX_E]*6110)/10000 + 
                  (Node.m_scoreMatchEmit[AX_Q]*3890)/10000;
            else if ('X' == c)
                Score += 0;
            else if ('X' != c)
                {
                unsigned uLetter = s.GetLetter(uColIndex);
                SCORE scoreEmit = Node.m_scoreMatchEmit[uLetter];
                Score += scoreEmit;
                }
#if    VERBOSE
            List("%7s  emit M%u(%c) = %s\n",
              ScoreToStr(Score),
              Edge.uNodeIndex,
              s[uColIndex],
              ScoreToStr(scoreEmit));
#endif
            }
        else if ('I' == Edge.cState)
            {
            const HMMNode &Node = GetNode(Edge.uNodeIndex);
            assert(Edge.uPrefixLength > 0);
            unsigned uColIndex = Edge.uPrefixLength - 1;
            char c = s[uColIndex];
            c = toupper(c);
            if ('B' == c)
                Score += (Node.m_scoreInsertEmit[AX_D]*4606)/10000 + 
                  (Node.m_scoreInsertEmit[AX_N]*5394)/10000;
            else if ('Z' == c)
                Score += (Node.m_scoreInsertEmit[AX_E]*6110)/10000 + 
                  (Node.m_scoreInsertEmit[AX_Q]*3890)/10000;
            else if ('X' == c)
                Score += 0;
            else if ('X' != c)
                {
                unsigned uLetter = s.GetLetter(uColIndex);
                SCORE scoreEmit = Node.m_scoreInsertEmit[uLetter];
                Score += scoreEmit;
                }
#if    VERBOSE
            List("%7s  emit I%u(%c) = %s\n",
              ScoreToStr(Score),
              Edge.uNodeIndex,
              s[uColIndex],
              ScoreToStr(scoreEmit));
#endif
            }
        }
    return Score;
    }

SCORE HMM::ScoreNTermSeq(const HMMPath &Path, const Seq &s) const
    {
    const unsigned uSeqLength = s.Length();
    if (0 == uSeqLength)
        return 0;
    const HMMEdge &FirstEdge = Path.GetEdge(0);
    unsigned NTermLength = FirstEdge.uPrefixLength;
    if (IsEmitterState(FirstEdge.cState))
        --NTermLength;

    SCORE scoreTotal = 0;
    for (unsigned n = 0; n < NTermLength; ++n)
        {
        const unsigned uLetter = CharToLetterAmino(s[n]);
        SCORE scoreLetter = GetNullEmitScore(uLetter);
        scoreTotal += scoreLetter;
        }
    scoreTotal = 0;//TODO!!!!!!!!!!!!!!!!!

    const SCORE scoreTrans = GetNullEmitTransScore();
    const SCORE scoreT = ProbToScore(DoubleToScore(1.0) - ScoreToProb(scoreTrans));
    return scoreTotal + NTermLength*scoreTrans + scoreT;
    }

SCORE HMM::ScoreCTermSeq(const HMMPath &Path, const Seq &s) const
    {
    const unsigned uSeqLength = s.Length();
    if (0 == uSeqLength)
        return 0;
    const HMMEdge &LastEdge = Path.GetEdge(Path.GetEdgeCount() - 1);
    const unsigned uStartIndex = LastEdge.uPrefixLength;
    assert(uStartIndex <= uSeqLength);
    unsigned CTermLength = uSeqLength - uStartIndex;

    SCORE scoreTotal = 0;
    for (unsigned n = uStartIndex; n < uSeqLength; ++n)
        {
        const unsigned uLetter = CharToLetterAmino(s[n]);
        SCORE scoreLetter = GetNullEmitScore(uLetter);
        scoreTotal += scoreLetter;
        }
    scoreTotal = 0;//TODO!!!!!!!!!!!!!!!!!

    const SCORE scoreTrans = GetNullEmitTransScore();
    const PROB probTrans = ScoreToProb(scoreTrans);
    const PROB probB = (PROB) 1.0 - probTrans;
    const SCORE scoreB = ProbToScore(probB);
    return scoreTotal + CTermLength*scoreTrans + scoreB;
    }
