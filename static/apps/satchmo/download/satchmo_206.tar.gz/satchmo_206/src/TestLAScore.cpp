// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWLA.h"

// Tests suggested by von Ohsen by e-mail:
// Put in a background frequency vector on one side - it has to yield zero, no matter
// what the other side is. Do the same for the other side. Put in all 400 combinations
// of unit vectors - you should get the blosum62 matrix back, divided by 2.88.

const double dBackground[MAX_ALPHA] =
    {
//           A          C           D           E           F
//           G          H           I           K           L
//           M          N           P           Q           R
//           S          T           V           W           Y
     0.0742162,    0.0246875,    0.0536260,    0.0543119,    0.0474185, 
     0.0741469,    0.0262130,    0.0679174,    0.0581557,    0.0989079, 
     0.0249902,    0.0446458,    0.0385380,    0.0342596,    0.0516145, 
     0.0572290,    0.0508914,    0.0729191,    0.0130300,    0.0322815
    };

static FCOUNT fcJunk[MAX_ALPHA] =
    {
    13, 2, 11, 6,
    4, 8, 10, 3,
    1, 2, 3, 4,
    4, 3, 2, 1
    };

static void MakeUnitVector(FCOUNT fcUnit[MAX_ALPHA], unsigned n)
    {
    for (unsigned i = 0; i < MAX_ALPHA; ++i)
        {
        if (i == n)
            fcUnit[i] = 1;
        else
            fcUnit[i] = 0;
        }
    }

void TestLAScore()
    {
    SCORE Score;

    Normalize(fcJunk, MAX_ALPHA);

    FCOUNT fcBackground[MAX_ALPHA];
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        fcBackground[n] = (SCORE) dBackground[n];

    Score = PWLA::LAScore(fcBackground, fcJunk);
    printf("Background / Junk = %g, should be zero\n", Score);

    Score = PWLA::LAScore(fcJunk, fcBackground);
    printf("Junk / Background = %g, should be zero\n", Score);

    for (unsigned uLetter1 = 0; uLetter1 < MAX_ALPHA; ++uLetter1)
        {
        FCOUNT fcUnit1[MAX_ALPHA];
        MakeUnitVector(fcUnit1, uLetter1);
        for (unsigned uLetter2 = 0; uLetter2 < MAX_ALPHA; ++uLetter2)
            {
            FCOUNT fcUnit2[MAX_ALPHA];
            MakeUnitVector(fcUnit2, uLetter2);
            Score = PWLA::LAScore(fcUnit1, fcUnit2);
            printf(" %5.2f", Score*2.88);
            }
        printf("\n");
        }
    }
