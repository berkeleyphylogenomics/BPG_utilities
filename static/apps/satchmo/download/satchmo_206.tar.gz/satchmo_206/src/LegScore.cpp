// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "MSA.h"

// Leg score is transition score for adding given leg that ends
// in node uNodeIndex and emits prefix of given length.

SCORE HMM::LegMM(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    if (!Pillar.m_bAligned)
        return MINUS_INFINITY;

    const HMMNode &Node = GetNode(uNodeIndex-1);

    SCORE s1;
    SCORE s2;
    SCORE s3;
    SCORE s4;
    MulFCountScore(s1, Pillar.m_fcFF, Node.m_scoreMM);
    MulFCountScore(s2, Pillar.m_fcEF, Node.m_scoreDM);
    MulFCountScore(s3, Pillar.m_fcFE, Node.m_scoreMD);
    MulFCountScore(s4, Pillar.m_fcEE, Node.m_scoreDD);
    return Add4(s1, s2, s3, s4);
    }

SCORE HMM::LegMD(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const HMMNode &Node = GetNode(uNodeIndex-1);

    SCORE s1;
    SCORE s2;
    MulFCountScore(s1, Pillar.m_fcF, Node.m_scoreMD);
    MulFCountScore(s2, Pillar.m_fcE, Node.m_scoreDD);
    return Add2(s1, s2);
    }

SCORE HMM::LegMI(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const HMMNode &Node = GetNode(uNodeIndex);

    SCORE s1;
    SCORE s2;
    SCORE s3;
    MulFCountScore(s1, Pillar.m_fcFF, Node.m_scoreMI);
    MulFCountScore(s2, Pillar.m_fcEF, Node.m_scoreDI);
    MulFCountScore(s3, Pillar.m_fcT, Node.m_scoreII);
    return Add3(s1, s2, s3);
    }

SCORE HMM::LegDM(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const HMMNode &Node = GetNode(uNodeIndex-1);

    SCORE s1;
    SCORE s2;
    MulFCountScore(s1, Pillar.m_fcF, Node.m_scoreDM);
    MulFCountScore(s2, Pillar.m_fcE, Node.m_scoreDD);
    return Add2(s1, s2);
    }

SCORE HMM::LegDD(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    const HMMNode &Node = GetNode(uNodeIndex-1);
    return Node.m_scoreDD;
    }

SCORE HMM::LegDI(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const HMMNode &Node = GetNode(uNodeIndex);
    SCORE s1;
    SCORE s2;
    MulFCountScore(s1, Pillar.m_fcF, Node.m_scoreDI);
    MulFCountScore(s2, Pillar.m_fcT, Node.m_scoreII);
    return Add2(s1, s2);
    }

SCORE HMM::LegSM(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
//    assert(0 == uNodeIndex);
    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    SCORE s1;
    SCORE s2;
    MulFCountScore(s1, Pillar.m_fcF, m_scoreFirstM);
    MulFCountScore(s2, Pillar.m_fcE, m_scoreFirstD);
    SCORE scoreTerminalGap = ScoreTerminalGap(uPrefixLength);
    return Add3(scoreTerminalGap, s1, s2);
    }

SCORE HMM::LegSD(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(0 == uNodeIndex);
    SCORE scoreTerminalGap = ScoreTerminalGap(uPrefixLength);
    return Add2(scoreTerminalGap, m_scoreFirstD);
    }

SCORE HMM::LegIM(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength,
  unsigned uFirstIPillar, char cPrevState) const
    {
    if (!g_bUseBreakMatrices)
        return LegIMApprox(Aln, uNodeIndex, uPrefixLength);

    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    assert('M' == cPrevState || 'D' == cPrevState);
    assert(uFirstIPillar < Aln.GetPillarCount());
    assert(uPillarIndex >= uFirstIPillar);

    const HMMNode &Node = GetNode(uNodeIndex-1);
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const PILLAR &PrevPillar = Aln.GetPillar(uPillarIndex-1);
    const PILLAR &PillarC = Aln.GetPillar(uFirstIPillar);
    const unsigned c = uPillarIndex - uFirstIPillar;
    SCORE BTCw = PillarC.m_fcBT[uPillarIndex];
    SCORE Score;
    if ('M' == cPrevState)
        {
        SCORE s1, s2, s3, s4, s5, s6, s7;
        assert(uFirstIPillar > 0);
        const PILLAR &PillarC_1 = Aln.GetPillar(uFirstIPillar-1);
        SCORE BTC_1w = PillarC_1.m_fcBT[uPillarIndex];
        MulFCountScore(s1, Pillar.m_fcFF, Node.m_scoreIM);
        MulFCountScore(s2, PrevPillar.m_fcBL[c], Node.m_scoreIM);
        MulFCountScore(s3, PrevPillar.m_fcBE[c], Node.m_scoreMM);
        MulFCountScore(s4, PrevPillar.m_fcBG[c], Node.m_scoreDM);
        MulFCountScore(s5, BTCw - BTC_1w, Node.m_scoreMD);
        MulFCountScore(s6, Pillar.m_fcE - BTCw, Node.m_scoreID);
        MulFCountScore(s7, BTC_1w, Node.m_scoreDD);
        Score = Add7(s1, s2, s3, s4, s5, s6, s7);
        return Score;
        }
    else
        {
        SCORE s1, s2, s3, s4, s5;
        assert(c > 0);
        MulFCountScore(s1, Pillar.m_fcFF, Node.m_scoreIM);
        MulFCountScore(s2, PrevPillar.m_fcBL[c], Node.m_scoreIM);
        MulFCountScore(s3, PrevPillar.m_fcBG[c-1], Node.m_scoreDM);
        MulFCountScore(s4, Pillar.m_fcE - BTCw, Node.m_scoreID);
        MulFCountScore(s5, BTCw, Node.m_scoreDD);
        Score = Add5(s1, s2, s3, s4, s5);
        }
    return Score;
    }

SCORE HMM::LegID(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength,
  unsigned uFirstIPillar, char cPrevState) const
    {
    if (!g_bUseBreakMatrices)
        return LegIDApprox(Aln, uNodeIndex, uPrefixLength);

    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    assert('M' == cPrevState || 'D' == cPrevState);
    assert(uFirstIPillar < Aln.GetPillarCount());
    assert(uPillarIndex >= uFirstIPillar);

    const HMMNode &Node = GetNode(uNodeIndex-1);
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const PILLAR &PillarC = Aln.GetPillar(uFirstIPillar);

    SCORE BTCw = PillarC.m_fcBT[uPillarIndex];
    SCORE Score;
    if ('M' == cPrevState)
        {
        SCORE s1, s2, s3, s4;
        assert(uFirstIPillar > 0);
        const PILLAR &PillarC_1 = Aln.GetPillar(uFirstIPillar-1);
        SCORE BTC_1w = PillarC_1.m_fcBT[uPillarIndex];
        MulFCountScore(s1, Pillar.m_fcF, Node.m_scoreID);
        MulFCountScore(s2, Pillar.m_fcE - BTCw, Node.m_scoreID);
        MulFCountScore(s3, BTCw - BTC_1w, Node.m_scoreMD);
        MulFCountScore(s4, BTC_1w, Node.m_scoreDD);
        Score = Add4(s1, s2, s3, s4);
        }
    else
        {
        SCORE s1, s2, s3;
        MulFCountScore(s1, Pillar.m_fcF, Node.m_scoreID);
        MulFCountScore(s2, Pillar.m_fcE - BTCw, Node.m_scoreID);
        MulFCountScore(s3, BTCw, Node.m_scoreDD);
        Score = Add3(s1, s2, s3);
        }
    return Score;
    }

SCORE HMM::LegII(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength,
  unsigned uFirstIPillar, char cPrevState) const
    {
    if (!g_bUseBreakMatrices)
        return LegIIApprox(Aln, uNodeIndex, uPrefixLength);

    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    assert('M' == cPrevState || 'D' == cPrevState);
    assert(uFirstIPillar < Aln.GetPillarCount());
    assert(uPillarIndex > 0);

    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const PILLAR &PrevPillar = Aln.GetPillar(uPillarIndex-1);
    const HMMNode &Node = GetNode(uNodeIndex);
    const unsigned c = uPillarIndex - uFirstIPillar;
    SCORE Score;
    if ('M' == cPrevState)
        {
        SCORE s1, s2, s3, s4, s5;
        MulFCountScore(s1, Pillar.m_fcFF, Node.m_scoreII);
        MulFCountScore(s2, PrevPillar.m_fcBL[c], Node.m_scoreII);
        MulFCountScore(s3, PrevPillar.m_fcBE[c], Node.m_scoreMI);
        MulFCountScore(s4, PrevPillar.m_fcBG[c], Node.m_scoreDI);
        MulFCountScore(s5, Pillar.m_fcT, Node.m_scoreII);
        Score = Add5(s1, s2, s3, s4, s5);
        }
    else
        {
        SCORE s1, s2, s3, s4;
        assert(c > 0);
        MulFCountScore(s1, Pillar.m_fcFF, Node.m_scoreII);
        MulFCountScore(s2, PrevPillar.m_fcBL[c], Node.m_scoreII);
        MulFCountScore(s3, PrevPillar.m_fcBG[c-1], Node.m_scoreDI);
        MulFCountScore(s4, Pillar.m_fcT, Node.m_scoreII);
        Score = Add4(s1, s2, s3, s4);
        }
    return Score;
    }

SCORE HMM::EmitM(const MSA &Aln, unsigned uNodeIndex, unsigned uPillarIndex) const
    {
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    if (!Pillar.m_bAligned)
        return MINUS_INFINITY;

    const HMMNode &Node = GetNode(uNodeIndex);
    SCORE Score = 0;
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        {
        FCOUNT fcLetter = Pillar.m_fcResCounts[uLetter];
        if (fcLetter > 0)
            {
            SCORE scoreLetter;
            MulFCountScore(scoreLetter, fcLetter, Node.m_scoreMatchEmit[uLetter]);
            Score = Add2(Score, scoreLetter);
            }
        }
    return Score;
    }
//new
SCORE HMM::EmitI(const MSA &Aln, unsigned uNodeIndex, unsigned uPillarIndex) const
    {
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    if (!Pillar.m_bAligned)
        return MINUS_INFINITY;

    const HMMNode &Node = GetNode(uNodeIndex);
    SCORE Score = 0;
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        {
	  //emission prob. of should be set to be naive log0.05
	   FCOUNT fcLetter = Pillar.m_fcResCounts[uLetter];
	   if (fcLetter > 0)
            {
            SCORE scoreLetter;
	    MulFCountScore(scoreLetter, fcLetter, Node.m_scoreInsertEmit[uLetter]);
                       Score = Add2(Score, scoreLetter);
	     }
        }
    return Score;
    }
    
SCORE HMM::LegIMApprox(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const HMMNode &Node = GetNode(uNodeIndex-1);

    SCORE s1, s2;
    FCOUNT fc = Pillar.m_fcFF + Pillar.m_fcEF + Pillar.m_fcEE;
    MulFCountScore(s1, fc, Node.m_scoreIM);
    MulFCountScore(s2, Pillar.m_fcFE, Node.m_scoreID);
    SCORE Score = Add2(s2, s2);
    return Score;
    }

SCORE HMM::LegIDApprox(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const HMMNode &Node = GetNode(uNodeIndex-1);

    FCOUNT fc = Pillar.m_fcFF + Pillar.m_fcE;
    SCORE Score;
    MulFCountScore(Score, fc, Node.m_scoreID);
    return Score;
    }

SCORE HMM::LegIIApprox(const MSA &Aln, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    const unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const HMMNode &Node = GetNode(uNodeIndex);

    FCOUNT fc = Pillar.m_fcFF + Pillar.m_fcEF + Pillar.m_fcT;
    SCORE Score;
    MulFCountScore(Score, fc, Node.m_scoreII);
    return Score;
    }
