// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "TextFile.h"

const unsigned INSANE_NODE_COUNT = 99999;

void HMM::FromFile(TextFile &File)
    {
    Clear();

    char szToken[1024];

    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "SatchmoHMM"));

// Opening "{" 
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "{"));

// "length"
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "length"));
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(IsValidInteger(szToken));
    m_uNodeCount = (unsigned) atoi(szToken);
    assert(m_uNodeCount > 0 && m_uNodeCount < INSANE_NODE_COUNT);

    m_Nodes = new HMMNode[m_uNodeCount];

// "entry"
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "entry"));
    File.GetTokenXC(szToken, sizeof(szToken));
    m_scoreFirstM = StrToScore(szToken);
    File.GetTokenXC(szToken, sizeof(szToken));
    m_scoreFirstD = StrToScore(szToken);

// "trans"
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "trans"));
    for (unsigned uNodeIndex = 0; uNodeIndex + 1 < m_uNodeCount; ++uNodeIndex)
        {
        HMMNode &Node = m_Nodes[uNodeIndex];
        for (unsigned i = 0; i < 10; ++i)
            {
            File.GetTokenXC(szToken, sizeof(szToken));
            SCORE n = StrToScore(szToken);
            switch (i)
                {
            case 0:    assert((unsigned) n == uNodeIndex); break;
            case 1:    Node.m_scoreMM = n; break;
            case 2:    Node.m_scoreMD = n; break;
            case 3:    Node.m_scoreMI = n; break;
            case 4:    Node.m_scoreDM = n; break;
            case 5:    Node.m_scoreDD = n; break;
            case 6:    Node.m_scoreDI = n; break;
            case 7:    Node.m_scoreIM = n; break;
            case 8:    Node.m_scoreID = n; break;
            case 9:    Node.m_scoreII = n; break;
            default: assert(false);
                }
            }
        }
    HMMNode &LastNode = m_Nodes[m_uNodeCount-1];
    LastNode.m_scoreMM = MINUS_INFINITY;
    LastNode.m_scoreMD = MINUS_INFINITY;
    LastNode.m_scoreMI = MINUS_INFINITY;
    LastNode.m_scoreDM = MINUS_INFINITY;
    LastNode.m_scoreDD = MINUS_INFINITY;
    LastNode.m_scoreDI = MINUS_INFINITY;
    LastNode.m_scoreIM = MINUS_INFINITY;
    LastNode.m_scoreID = MINUS_INFINITY;
    LastNode.m_scoreII = MINUS_INFINITY;

// "match"
    File.GetTokenXC(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "match"));
    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        HMMNode &Node = m_Nodes[uNodeIndex];
        File.GetTokenXC(szToken, sizeof(szToken));
        assert(IsValidSignedInteger(szToken));
        unsigned n = (unsigned) atoi(szToken);
        assert(n == uNodeIndex);
        for (unsigned uLetter = 0; uLetter< MAX_ALPHA; ++uLetter)
            {
            File.GetTokenXC(szToken, sizeof(szToken));
            SCORE s = StrToScore(szToken);
            Node.m_scoreMatchEmit[uLetter] = s;
            }
        }

#if    INSERT_EMITS
// "insert"
    File.GetTokenXC(szToken, sizeof(szToken));
    if (0 == strcmp(szToken, "insert"))
        {
        for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
            {
            HMMNode &Node = m_Nodes[uNodeIndex];
            File.GetTokenXC(szToken, sizeof(szToken));
            assert(IsValidSignedInteger(szToken));
            unsigned n = (unsigned) atoi(szToken);
            assert(n == uNodeIndex);
            for (unsigned uLetter = 0; uLetter< MAX_ALPHA; ++uLetter)
                {
                File.GetTokenXC(szToken, sizeof(szToken));
                SCORE s = StrToScore(szToken);
                Node.m_scoreInsertEmit[uLetter] = s;
                }
            }
        File.GetTokenXC(szToken, sizeof(szToken));
        }
    else
        {
        for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
            {
            HMMNode &Node = m_Nodes[uNodeIndex];
            for (unsigned uLetter = 0; uLetter< MAX_ALPHA; ++uLetter)
                Node.m_scoreInsertEmit[uLetter] = 0;
            }
        }
#endif    // INSERT_EMITS

// closing "}"
    assert(0 == strcmp(szToken, "}"));

    CalcStateEntries();
    AssertNormalized();
    }
