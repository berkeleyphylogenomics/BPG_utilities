// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"

#define VERBOSE 0

/***
Posterior decoding (PD) alignment uses a matrix P, where Pij is the
posterior probability that position i in one sequence aligns to
position j in the other sequence. The alignment that maximizes
the sum over Pij for aligned positions is the PD alignment.

Ref. Holmes and Durbin, Dyanmic programming alignment accuracy,
JCB 5(3) 493-504, 1998, also the Durbin et al. textbook.

The highest sum is found using a Viterbi algorithm in which the gap
costs are zero. As we are adding rather than multiplying, we work with
the probability values directly, not logs.

The DP matrix for the Viterbi algorithm is:

    DP(NodeIndex, Pos)
    
    = Sum over Pij for highest scoring path that aligns position Pos to
    node NodeIndex.
***/

// Macros to simulate 2D matrices
#define P(NodeIndex, Pos)        P_[(NodeIndex)*(uSeqLength) + (Pos)]
#define DP(NodeIndex, Pos)        DP_[(NodeIndex)*(uSeqLength) + (Pos)]
#define    TB(NodeIndex, Pos)        TB_[(NodeIndex)*(uSeqLength) + (Pos)]

void HMM::PDAlign(const PROB *P_, unsigned uSeqLength, HMMPath &Path) const
    {
    const unsigned uNodeCount = GetNodeCount();
    assert(uSeqLength > 0 && uNodeCount > 0);

    size_t LM = uSeqLength*uNodeCount;
    PROB *DP_ = new SCORE[LM];
#if    _DEBUG
    memset(DP_, cInsane, LM*sizeof(PROB));
#endif

    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        for (unsigned uPos = 0; uPos < uSeqLength; ++uPos)
            {
            PROB probM;
            PROB probD;
            PROB probI;

            if (uNodeIndex > 0 && uPos > 0)
                probM = DP(uNodeIndex - 1, uPos - 1) + P(uNodeIndex, uPos);
            else
                probM = P(uNodeIndex, uPos);

            if (uNodeIndex > 0)
                probD = DP(uNodeIndex - 1, uPos);
            else
                probD = -1.0;

            if (uPos > 0)
                probI = DP(uNodeIndex, uPos - 1);
            else
                probI = -1.0;
            DP(uNodeIndex, uPos) = Max3(probM, probD, probI);
            }

#if    VERBOSE
    List("PDAlign\n");
    List("Pos      ");
    for (unsigned uPos = 0; uPos < uSeqLength; ++uPos)
        List(" %8u", uPos);
    List("\n");
    List("DP[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPos = 0; uPos < uSeqLength; ++uPos)
            List(" %s", ScoreToStr(DP(uNodeIndex, uPos)));
        List("\n");
        }
#endif    // VERBOSE

    PDTraceBack(P_, DP_, uSeqLength, Path);
    }

void HMM::PDTraceBack(const PROB *P_, const PROB *DP_, unsigned uSeqLength,
  HMMPath &Path) const
    {
    const unsigned uNodeCount = GetNodeCount();
    assert(uSeqLength > 0 && uNodeCount > 0);

    Path.Clear();

// Require alignment global to model.
// Find highest-scoring path
    PROB probHighest = -1.0;
    unsigned uPosHighest = uInsane;
    unsigned uNodeHighest = uInsane;
    const unsigned uLastNodeIndex = uNodeCount - 1;
    for (unsigned uPL = 0; uPL < uSeqLength; ++uPL)
        {
        PROB probPath = DP(uLastNodeIndex, uPL);
        if (probPath > probHighest)
            {
            probHighest = probPath;
            uPosHighest = uPL;
            uNodeHighest = uLastNodeIndex;
            }
        }
    const unsigned uLastPos = uSeqLength - 1;
    for (unsigned uNI = 0; uNI < uNodeCount; ++uNI)
        {
        PROB probPath = DP(uNI, uLastPos);
        if (probPath > probHighest)
            {
            probHighest = probPath;
            uPosHighest = uLastPos;
            uNodeHighest = uNI;
            }
        }

    assert(probHighest != -1.0);
    assert(uPosHighest != uInsane);
    assert(uNodeHighest != uInsane);
    assert(uNodeHighest == uLastNodeIndex || uPosHighest == uLastPos);

    unsigned uNodeIndex = uNodeHighest;
    unsigned uPos = uPosHighest;

    HMMEdge Edge;
    
    for (;;)
        {
        PROB p = DP(uNodeIndex, uPos);

        PROB probM;
        PROB probD;
        PROB probI;

        if (uNodeIndex > 0 && uPos > 0)
            probM = DP(uNodeIndex - 1, uPos - 1) + P(uNodeIndex, uPos);
        else
            probM = P(uNodeIndex, uPos);

        if (uNodeIndex > 0)
            probD = DP(uNodeIndex - 1, uPos);
        else
            probD = -1.0;

        if (uPos > 0)
            probI = DP(uNodeIndex, uPos - 1);
        else
            probI = -1.0;

        char cState;
        if (p == probM)
            cState = 'M';
        else if (p == probD)
            cState = 'D';
        else if (p == probI)
            cState = 'I';
        else
            assert(false);

        Edge.uNodeIndex = uNodeIndex;
        Edge.uPrefixLength = uPos + 1;
        Edge.cState = cState;
        Path.PrependEdge(Edge);

        if ('M' == cState || 'D' == cState)
            {
            if (0 == uNodeIndex)
                break;
            --uNodeIndex;
            }

        if ('M' == cState || 'I' == cState)
            {
            if (0 == uPos)
                {
                for (int iNodeIndex = (int) uNodeIndex; iNodeIndex >= 0; --iNodeIndex)
                    {
                    Edge.uNodeIndex = (unsigned) iNodeIndex;
                    Edge.uPrefixLength = 0;
                    Edge.cState = 'D';
                    Path.PrependEdge(Edge);
                    }
                break;
                }
            --uPos;
            }
        }
    }
