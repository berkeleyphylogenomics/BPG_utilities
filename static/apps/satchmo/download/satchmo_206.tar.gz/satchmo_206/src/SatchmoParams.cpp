// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "SatchmoParams.h"
#include "TextFile.h"

void SatchmoParams::ToFile(TextFile &File) const
    {
    File.PutFormat("maxnic %g\n", m_dMaxNIC);
    File.PutFormat("minavgaff %g\n", m_dMinAvgAff);
    File.PutFormat("window %u\n", m_uWindowLength);
    File.PutFormat("gapopen %u\n", m_uGapOpenPct);
    File.PutFormat("gapextend %u\n", m_uGapExtendPct);
    File.PutString("//\n");
    }

void SatchmoParams::FromFile(TextFile &File)
    {
    SetDefaults();
    for (;;)
        {
        char szToken[1024];
        File.GetTokenX(szToken, sizeof(szToken));
        if (0 == strcmp(szToken, "//"))
            break;
        else if (0 == strcmp(szToken, "maxnic"))
            {
            File.GetTokenX(szToken, sizeof(szToken));
            m_dMaxNIC = atof(szToken);
            }
        else if (0 == strcmp(szToken, "minavgaff"))
            {
            File.GetTokenX(szToken, sizeof(szToken));
            m_dMinAvgAff = atof(szToken);
            }
        else if (0 == strcmp(szToken, "window"))
            {
            File.GetTokenX(szToken, sizeof(szToken));
            assert(IsValidInteger(szToken));
            m_uWindowLength = (unsigned) atoi(szToken);
            }
        else if (0 == strcmp(szToken, "gapopen"))
            {
            File.GetTokenX(szToken, sizeof(szToken));
            assert(IsValidInteger(szToken));
            m_uGapOpenPct = (unsigned) atoi(szToken);
            }
        else if (0 == strcmp(szToken, "gapextend"))
            {
            File.GetTokenX(szToken, sizeof(szToken));
            assert(IsValidInteger(szToken));
            m_uGapExtendPct = (unsigned) atoi(szToken);
            }
        else
            assert(false);
        }
    return;
    }

void SatchmoParams::ToString(char szStr[], unsigned uBytes) const
    {
    int n = _snprintf(szStr, uBytes,
      "maxnic=%g minavgaff=%g window=%u gapopen=%u gapextend=%u",
      m_dMaxNIC,
      m_dMinAvgAff,
      m_uWindowLength,
      m_uGapOpenPct,
      m_uGapExtendPct);
    assert(n > 0);
    }
