// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Seq.h"
#include "MSA.h"

#define VERBOSE    0

double ClineScorePair(const MSA &msaRef, const MSA &msaTest,  unsigned uRefSeqIndex1,
  unsigned uRefSeqIndex2, double dEpsilon)
    {
    const char *ptrSeqName1 = msaRef.GetSeqName(uRefSeqIndex1);
    const char *ptrSeqName2 = msaRef.GetSeqName(uRefSeqIndex2);
    unsigned uTestSeqIndex1;
    unsigned uTestSeqIndex2;
    bool bFound = msaTest.GetSeqIndex(ptrSeqName1, &uTestSeqIndex1);
    if (!bFound)
        Quit("ClineScorePair: Seq %s not found in test alignment");
    bFound = msaTest.GetSeqIndex(ptrSeqName2, &uTestSeqIndex2);
    if (!bFound)
        Quit("ClineScorePair: Seq %s not found in test alignment");
    unsigned uTestSeqLength = msaTest.GetColCount();
    unsigned uTestAlignedResiduePairCount = 0;
    double dCSSum = 0.0;
    for (unsigned uTestColIndex = 0; uTestColIndex < uTestSeqLength; ++uTestColIndex)
        {
        if (!msaTest.IsAligned(uTestColIndex))
            continue;
        char cTest1 = msaTest.GetChar(uTestSeqIndex1, uTestColIndex);
        if (IsGap(cTest1))
            continue;
        assert(isupper(cTest1));
        char cTest2 = msaTest.GetChar(uTestSeqIndex2, uTestColIndex);
        if (IsGap(cTest2))
            continue;
        assert(isupper(cTest2));
        ++uTestAlignedResiduePairCount;

        unsigned uTestUngappedColIndex1 =
          msaTest.GetUngappedColIndex(uTestSeqIndex1, uTestColIndex);
        unsigned uTestUngappedColIndex2 =
          msaTest.GetUngappedColIndex(uTestSeqIndex2, uTestColIndex);
        unsigned uRefColIndex1 =
          msaRef.GetGappedColIndex(uRefSeqIndex1, uTestUngappedColIndex1);
        unsigned uRefColIndex2 =
          msaRef.GetGappedColIndex(uRefSeqIndex2, uTestUngappedColIndex2);
#ifdef    _DEBUG
        char cRef1 = msaRef.GetChar(uRefSeqIndex1, uRefColIndex1);
        assert(toupper(cRef1) == toupper(cTest1));
        char cRef2 = msaRef.GetChar(uRefSeqIndex2, uRefColIndex2);
        assert(toupper(cRef2) == toupper(cTest2));
#endif

        double dScore1 = 0;
        if (msaRef.IsAligned(uRefColIndex1))
            {
            char cRefPair1 = msaRef.GetChar(uRefSeqIndex2, uRefColIndex1);
            if (!IsGap(cRefPair1))
                {
                unsigned uRefUngappedColIndex =
                msaRef.GetUngappedColIndex(uRefSeqIndex2, uRefColIndex1);
                int iShift = uRefUngappedColIndex - uTestUngappedColIndex2;
                if (iShift < 0)
                    iShift = -iShift;
                dScore1 = (1 + dEpsilon)/(1 + iShift) - dEpsilon;
                assert(dScore1 >= -dEpsilon);
                assert(dScore1 <= 1);
                }
            }

        double dScore2 = 0;
        if (msaRef.IsAligned(uRefColIndex2))
            {
            char cRefPair2 = msaRef.GetChar(uRefSeqIndex1, uRefColIndex2);
            if (!IsGap(cRefPair2))
                {
                unsigned uRefUngappedColIndex =
                msaRef.GetUngappedColIndex(uRefSeqIndex1, uRefColIndex2);
                int iShift = uRefUngappedColIndex - uTestUngappedColIndex1;
                if (iShift < 0)
                    iShift = -iShift;
                dScore2 = (1 + dEpsilon)/(1 + iShift) - dEpsilon;
                assert(dScore2 >= -dEpsilon);
                assert(dScore2 <= 1);
                }
            }
        dCSSum += dScore1 + dScore2;
        }

    unsigned uRefAlignedResiduePairCount = 0;
    unsigned uRefSeqLength = msaRef.GetColCount();
    for (unsigned uRefColIndex = 0; uRefColIndex < uRefSeqLength; ++uRefColIndex)
        {
        if (!msaRef.IsAligned(uRefColIndex))
            continue;
        char c1 = msaRef.GetChar(uRefSeqIndex1, uRefColIndex);
        if (IsGap(c1))
            continue;
        assert(isupper(c1));
        char c2 = msaRef.GetChar(uRefSeqIndex2, uRefColIndex);
        if (IsGap(c2))
            continue;
        assert(isupper(c2));
        ++uRefAlignedResiduePairCount;
        }
    if (0 == uRefAlignedResiduePairCount)
        {
        List("**Warning*** ClineScorePair: reference alignment has no aligned pairs %u=%s %u=%s\n",
          uRefSeqIndex1,
          msaRef.GetSeqName(uRefSeqIndex1),
          uRefSeqIndex2,
          msaRef.GetSeqName(uRefSeqIndex2));
        fprintf(stderr,
          "**Warning*** ClineScorePair: reference alignment has no aligned pairs %u=%s %u=%s\n",
          uRefSeqIndex1,
          msaRef.GetSeqName(uRefSeqIndex1),
          uRefSeqIndex2,
          msaRef.GetSeqName(uRefSeqIndex2));
        return 1;
        }
    return dCSSum / (uTestAlignedResiduePairCount + uRefAlignedResiduePairCount);
    }

void ClineScore(const MSA &RefAln, const MSA &TestAln, double dEpsilon,
  double *ptrdCS)
    {
    unsigned N = RefAln.GetSeqCount();
    assert(N > 0);

#if    VERBOSE
    RefAln.ListMe();
    TestAln.ListMe();
#endif

    double dTotal = 0.0;
    unsigned nPairs = 0;
    for (unsigned n1 = 0; n1 < N; ++n1)
        {
        printf("Cline score %d of %d\r", n1, N);
        for (unsigned n2 = n1 + 1; n2 < N; ++n2)
            {
            dTotal += ClineScorePair(RefAln, TestAln, n1, n2, dEpsilon);
            ++nPairs;
            }
        }
    printf("\n");
    double d = dTotal / nPairs;
    assert((N*(N - 1))/2 == nPairs);
    assert(d >= -dEpsilon && d <= 1);
    *ptrdCS = d;
    }
