// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    PWYLE_h
#define    PWYLE_h

#include <math.h>
#include "PWYLF.h"
#include "PWBase.h"

class PWYLE : public PWBase
    {
public:
    PWYLE()
        {
        }

    virtual ~PWYLE()
        {
        }

    virtual SCORE DefaultGapOpen() const
        {
        return (SCORE) -0.15;
        }

    virtual SCORE DefaultGapExtend() const
        {
        return (SCORE) -0.01;
        }

    virtual SCORE ScoreProfPos(const ProfPos &PPA, const ProfPos &PPB) const
        {
        double dScore = PWYLF::YLFScore(PPA.m_fcCounts, PPB.m_fcCounts);
        return (SCORE) (3*dScore);
        }
    };

#endif    // PWYLE_h
