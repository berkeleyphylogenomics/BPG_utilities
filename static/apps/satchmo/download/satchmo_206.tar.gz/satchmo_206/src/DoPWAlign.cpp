// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "Seq.h"
#include "PWPath.h"
#include "PWAff.h"
#include "TextFile.h"

void DoPWAlign(const char *strFile1, const char *strFile2)
    {
    TextFile File1(strFile1);
    Seq seq1;
    seq1.FromFASTAFile(File1);

    TextFile File2(strFile2);
    Seq seq2;
    seq2.FromFASTAFile(File2);

    PWAff PWA;
    PWA.Init(seq1, GLOBAL, seq2, GLOBAL);

    PWPath Path;
    PWAlign(PWA, Path);
    Path.ListMe();

    //MSA msa1;
    //msa1.FromSeq(seq1);

    //MSA msa2;
    //msa2.FromSeq(seq2);

//    MSA msaAln;
//    PWAlign(msa1, msa2, Path, msaAln);
//    msaAln.ListMe();
    }
