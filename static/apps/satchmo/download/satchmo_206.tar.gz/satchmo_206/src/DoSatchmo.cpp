// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifdef PARALLEL
#include "mpi.h"
#endif 

#include "lobster.h"
#include "SatchmoParams.h"
#include "TextFile.h"
#include "SeqVect.h"
#include "GTree2.h"
#include "GNode2.h"
#include "SJPM.h"


TextFile *g_ptrSmoFile;
const char *g_strPairOnlyOne; // sequence one cluster
const char *g_strPairOnlyTwo; // sequence two cluster
const char *g_strBSPath;
const char *g_strAlignStyle;
const char *g_strJoinMethod;

void DoSatchmo(const char *in)
    {
    const char *strSatchmoInputFileName = in;

// Three kinds of output -- must specify at least one of them
    const char *strOutputFastaFileName = GetOptionalParam("out");
    const char *strOutputSVFileName = GetOptionalParam("sv");
    const char *strPhylipFileName = GetOptionalParam("phy");
    g_strBSPath = GetOptionalParam("bs");
    g_strPairOnlyOne = GetOptionalParam("paironly1"); //sequence one cluster
    g_strPairOnlyTwo = GetOptionalParam("paironly2"); //sequence two cluster
    g_strAlignStyle = GetOptionalParam("alignstyle");
    g_strJoinMethod = GetOptionalParam("joinmethod");
    

    if (0 == strOutputFastaFileName && 0 == strPhylipFileName &&
      0 == strOutputSVFileName)
        CmdLineError("No output file specified for Satchmo");

    const char *window = GetOptionalParam("window", "7"); // was 7
    const char *minaff = GetOptionalParam("minaff", "-9"); // was -9
    unsigned uWindowLength = (unsigned) atoi(window);
    double dMinAvgAff = atof(minaff);
    
    double dMaxNIC = 3;                        // TODO

    if (0 == uWindowLength%2)
        CmdLineError("Window length %u, must be an odd integer.");

    SatchmoParams Params;
    Params.SetMinAvgAff(dMinAvgAff);
    Params.SetWindowLength(uWindowLength);
    Params.SetMaxNIC(dMaxNIC);


    GTree2 Tree;
    SeqVect Seqs;
    
#ifdef PARALLEL
    if (g_my_rank == 0){
#endif
      TextFile InputFile(strSatchmoInputFileName);

      Seqs.FromFASTAFile(InputFile);
    
      Tree.SetInputSeqs(Seqs);
        
    if (0 != strOutputSVFileName)
        g_ptrSmoFile = new TextFile(strOutputSVFileName, true);
#ifdef PARALLEL
    }
#endif
    BuildMonitor BM;
    
    if ((g_strPairOnlyOne) && (g_strPairOnlyTwo))
       	    fprintf(stderr, "get pairs only.. \n");

    // are we  bootstrapping?, set path
    if (g_strBSPath)
        Tree.Bootstrap(Params, &BM);
    else 
        Tree.Build(Params, &BM);
    printf("done, now output...\n");
    //done, time to output
     if (0 != g_ptrSmoFile)
      {
      delete g_ptrSmoFile;
      g_ptrSmoFile = 0;
      }
#ifdef PARALLEL
    if(g_my_rank == 0){
#endif        
    GNode2 *ptrRoot = Tree.GetRoot();
    if (0 != ptrRoot)
        {
        const MSA &a = ptrRoot->m_MSA;
        if (0 != strOutputFastaFileName)
            {
	    fprintf(stderr, "Outputting a2m file.. \n");
            TextFile File(strOutputFastaFileName, true);
            a.ToFASTAFile(File);
            }
        if (0 != strPhylipFileName)
            {
            fprintf(stderr, "Outputting Phylip Tree.. \n");
	    TextFile File(strPhylipFileName, true);
	    //  printf("root node is %u\n",Tree.GetRoot()->m_uNodeIndex);
	    // printf("left node is %s\n",Tree.GetRoot()->m_ptrLeft->GetName());
	    // printf("right node is %s\n",Tree.GetRoot()->m_ptrRight->GetName());  
            Tree.ToPhylipFile(File);
            }
        }
    else
        {
        fprintf(stderr, "No root, tree not completed.\n");
        List("No root, tree not completed.\n");
        }
        fprintf(stderr, "Finished SATCHMO.\n");
#ifdef PARALLEL        
    }
#endif

}
