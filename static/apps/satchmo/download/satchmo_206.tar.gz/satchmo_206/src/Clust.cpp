// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Clust.h"
#include "ClustSet.h"
#include "Phylip.h"

/***
***/

#define VERBOSE 1

Clust::Clust()
    {
    m_Nodes = 0;
    m_uNodeCount = 0;
    m_uLeafCount = 0;
    m_uClusterCount = 0;
    m_JoinStyle = JOINSTYLE_Undefined;
    m_dDist = 0;
    m_bDistSet = 0;
    m_uLeafCount = 0;
    m_ptrSet = 0;
    }

Clust::~Clust()
    {
    delete[] m_Nodes;
    delete[] m_dDist;
    delete[] m_bDistSet;
    }

void Clust::Create(ClustSet &Set)
    {
    m_ptrSet = &Set;
    m_bIsRooted = Set.IsRooted();

    SetLeafCount(Set.GetLeafCount());
    SetJoinStyle(Set.GetJoinStyle());
    SetCentroidStyle(Set.GetCentroidStyle());
    // fprintf (stderr, "leave number : %u\n", m_uLeafCount );
    if (m_uLeafCount <= 1)
        Quit("Clust::Create: no leaves");

    m_uNodeCount = 2*m_uLeafCount - 1;
    m_Nodes = new ClustNode[m_uNodeCount];

    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        ClustNode &Node = m_Nodes[uNodeIndex];
        Node.m_uIndex = uNodeIndex;
        if (uNodeIndex < m_uLeafCount)
            {
            Node.m_uSize = 1;
            Node.m_uLeafIndexes = new unsigned[1];
            Node.m_uLeafIndexes[0] = uNodeIndex;
            }
        else
            Node.m_uSize = 0;
        }

// Compute initial distance matrix between leaves
    for (unsigned i = 0; i < m_uLeafCount; ++i)
        for (unsigned j = 0; j < i; ++j)
            {
            const double dDist = m_ptrSet->ComputeDist(*this, i, j);
            SetDist(i, j, dDist);
            }

// Call CreateCluster once for each internal node in the tree
    m_uClusterCount = m_uLeafCount;
    for (unsigned uNodeIndex = m_uLeafCount; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        CreateCluster();
    }

void Clust::CreateCluster()
    {

    unsigned uLeftNodeIndex;
    unsigned uRightNodeIndex;
    double dLeftLength;
    double dRightLength;
    ChooseJoin(&uLeftNodeIndex, &uRightNodeIndex, &dLeftLength, &dRightLength);

    const unsigned uNewNodeIndex = m_uNodeCount - m_uClusterCount + 1;

    if (CENTROIDSTYLE_ComputedBySet == m_CentroidStyle)
        m_ptrSet->JoinNodes(*this, uLeftNodeIndex, uRightNodeIndex,
          uNewNodeIndex, &dLeftLength, &dRightLength);

    JoinNodes(uLeftNodeIndex, uRightNodeIndex, dLeftLength, dRightLength,
      uNewNodeIndex);

#if    VERBOSE
    List("Merge New=%u L=%u R=%u Ld=%7.2g Rd=%7.2g\n",
      uNewNodeIndex, uLeftNodeIndex, uRightNodeIndex, dLeftLength, dRightLength);
#endif

// Compute distances to other clusters
    --m_uClusterCount;
    for (unsigned uClusterIndex = 0; uClusterIndex < m_uClusterCount; ++uClusterIndex)
        {
        const unsigned uNodeIndex = GetNodeIndex(uClusterIndex);
        if (uNodeIndex == uLeftNodeIndex || uNodeIndex == uRightNodeIndex)
            continue;

        const double dDist = ComputeDist(uNewNodeIndex, uNodeIndex);
        SetDist(uNewNodeIndex, uNodeIndex, dDist);
        }
    }

void Clust::ChooseJoin(unsigned *ptruLeftIndex, unsigned *ptruRightIndex,
  double *ptrdLeftLength, double *ptrdRightLength)
    {
      //      fprintf(stderr, "join style %u\n",m_JoinStyle);
    switch (m_JoinStyle)
        {
    case JOINSTYLE_NearestNeighbor:
             ChooseJoinNearestNeighbor(ptruLeftIndex, ptruRightIndex, ptrdLeftLength, ptrdRightLength);
        return;
    case JOINSTYLE_NeighborJoining:
        ChooseJoinNeighborJoining(ptruLeftIndex, ptruRightIndex, ptrdLeftLength,
          ptrdRightLength);
        return;
        }
    Quit("Clust::ChooseJoin, Invalid join style %u", m_JoinStyle);
    }

void Clust::ChooseJoinNearestNeighbor(unsigned *ptruLeftIndex,
  unsigned *ptruRightIndex, double *ptrdLeftLength, double *ptrdRightLength)
    {
    const unsigned uClusterCount = GetClusterCount();

    unsigned uMinLeftNodeIndex = uInsane;
    unsigned uMinRightNodeIndex = uInsane;
    dMinDist = PLUS_INFINITY;
    for (unsigned uLeftCluster = 0; uLeftCluster < uClusterCount; ++uLeftCluster)
        {
        const unsigned uLeftNodeIndex = GetNodeIndex(uLeftCluster);
	
       for (unsigned uRightCluster = 0; uRightCluster < uLeftCluster; ++uRightCluster)
            {
            const unsigned uRightNodeIndex = GetNodeIndex(uRightCluster);
            double dDist = GetDist(uLeftNodeIndex, uRightNodeIndex);
            if (dDist < dMinDist)
                {
                dMinDist = dDist;
                uMinLeftNodeIndex = uLeftNodeIndex;
                uMinRightNodeIndex = uRightNodeIndex;
                }
            }
        }

    if (uInsane == uMinLeftNodeIndex || uInsane == uMinRightNodeIndex ||
      MINUS_INFINITY == dMinDist)
      Quit("Clust::ChooseJoinNearestNeighbor failed");

    const double dLeftHeight = GetHeight(uMinLeftNodeIndex);
    const double dRightHeight = GetHeight(uMinRightNodeIndex);

    *ptruLeftIndex = uMinLeftNodeIndex;
    *ptruRightIndex = uMinRightNodeIndex;
    *ptrdLeftLength = (dMinDist - dLeftHeight)/2;
    *ptrdRightLength = (dMinDist - dRightHeight)/2;
    }

void Clust::ChooseJoinNeighborJoining(unsigned *ptruLeftIndex,
  unsigned *ptruRightIndex, double *ptrdLeftLength, double *ptrdRightLength)
    {
    const unsigned uClusterCount = GetClusterCount();

    unsigned uMinLeftNodeIndex = uInsane;
    unsigned uMinRightNodeIndex = uInsane;
    dMinDist = PLUS_INFINITY;
    for (unsigned ic = 0; ic < uClusterCount; ++ic)
        {
        const unsigned i = GetNodeIndex(ic);
        const double ri = Calc_r(i);
        for (unsigned jc = 0; jc < uClusterCount; ++jc)
            {
            const unsigned j = GetNodeIndex(jc);
            const double rj = Calc_r(j);
            const double dij = GetDist(i, j);
            const double Dij = dij - (ri + rj);
            if (Dij < dMinDist)
                {
                dMinDist = Dij;
                uMinLeftNodeIndex = i;
                uMinRightNodeIndex = j;
                }
            }
        }

    const double dDistLR = GetDist(uMinLeftNodeIndex,
      uMinRightNodeIndex);
    const double rL = Calc_r(uMinLeftNodeIndex);
    const double rR = Calc_r(uMinRightNodeIndex);

    const double dLeftLength = (dDistLR + rL - rR)/2;
    const double dRightLength = (dDistLR - rL + rR)/2;

    *ptruLeftIndex = uMinLeftNodeIndex;
    *ptruRightIndex = uMinRightNodeIndex;
    *ptrdLeftLength = dLeftLength;
    *ptrdRightLength = dRightLength;
    }

void Clust::JoinNodes(unsigned uLeftIndex, unsigned uRightIndex, double dLeftLength,
  double dRightLength, unsigned uNodeIndex)
    {
    ClustNode &Parent = m_Nodes[uNodeIndex];
    ClustNode &Left = m_Nodes[uLeftIndex];
    ClustNode &Right = m_Nodes[uRightIndex];

    Left.m_dLength = dLeftLength;
    Right.m_dLength = dRightLength;

    Parent.m_ptrLeft = &Left;
    Parent.m_ptrRight = &Right;

    Left.m_ptrParent = &Parent;
    Right.m_ptrParent = &Parent;

    const unsigned uLeftSize = Left.m_uSize;
    const unsigned uRightSize = Right.m_uSize;
    const unsigned uParentSize = uLeftSize + uRightSize;
    Parent.m_uSize = uParentSize;

    assert(0 == Parent.m_uLeafIndexes);
    Parent.m_uLeafIndexes = new unsigned[uParentSize];

    const unsigned uLeftBytes = uLeftSize*sizeof(unsigned);
    const unsigned uRightBytes = uRightSize*sizeof(unsigned);
    memcpy(Parent.m_uLeafIndexes, Left.m_uLeafIndexes, uLeftBytes);
    memcpy(Parent.m_uLeafIndexes + uLeftSize, Right.m_uLeafIndexes, uRightBytes);
    }

double Clust::Calc_r(unsigned uNodeIndex)
    {
    const unsigned uClusterCount = GetClusterCount();
    if (2 == uClusterCount)
        return 0;

    double dSum = 0;
    for (unsigned ic = 0; ic < uClusterCount; ++ic)
        {
        const unsigned i = GetNodeIndex(ic);
        if (i == uNodeIndex)
            continue;
        dSum += GetDist(uNodeIndex, i);
        }
    return dSum/(uClusterCount - 2);
    }

double Clust::ComputeDist(unsigned uNewNodeIndex, unsigned uNodeIndex)
    {
      //      fprintf (stderr, "centroidside style:%u\n", m_CentroidStyle);
    switch (m_CentroidStyle)
        {
    case CENTROIDSTYLE_AverageLinkage:
        return ComputeDistAverageLinkage(uNewNodeIndex, uNodeIndex);
    case CENTROIDSTYLE_NeighborJoining:
        return ComputeDistNeighborJoining(uNewNodeIndex, uNodeIndex);
    case CENTROIDSTYLE_ComputedBySet:
        return m_ptrSet->ComputeDist(*this, uNewNodeIndex, uNodeIndex);
        }
    Quit("Clust::ComputeDist, invalid centroid style %u", m_CentroidStyle);
    return g_dNAN;
    }

double Clust::ComputeDistAverageLinkage(unsigned uNewNodeIndex, unsigned uNodeIndex)
    {
    const unsigned uLeftNodeIndex = GetLeftIndex(uNewNodeIndex);
    const unsigned uRightNodeIndex = GetRightIndex(uNewNodeIndex);
    const unsigned uSizeL = GetClusterSize(uLeftNodeIndex);
    const unsigned uSizeR = GetClusterSize(uRightNodeIndex);
    const unsigned uNewClusterSize = uSizeL + uSizeR;

    const unsigned uClusterSize = GetClusterSize(uNodeIndex);
    const double dDistL = GetDist(uLeftNodeIndex, uNodeIndex);
    const double dDistR = GetDist(uRightNodeIndex, uNodeIndex);
    const double dDist = (dDistL*uSizeL + dDistR*uSizeR)/uNewClusterSize;
    return dDist;
    }

double Clust::ComputeDistNeighborJoining(unsigned uNewNodeIndex, unsigned uNodeIndex)
    {
    const unsigned uLeftNodeIndex = GetLeftIndex(uNewNodeIndex);
    const unsigned uRightNodeIndex = GetRightIndex(uNewNodeIndex);
    const double dDistLR = GetDist(uLeftNodeIndex, uRightNodeIndex);
    const double dDistL = GetDist(uLeftNodeIndex, uNodeIndex);
    const double dDistR = GetDist(uRightNodeIndex, uNodeIndex);
    const double dDist = (dDistL + dDistR - dDistLR)/2;
    return dDist;
    }

unsigned Clust::GetClusterCount() const
    {
    return m_uClusterCount;
    }

unsigned Clust::GetNodeIndex(unsigned uClusterIndex) const
    {
    unsigned n = 0;
    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        if (0 == m_Nodes[uNodeIndex].m_ptrParent)
            {
            if (uClusterIndex == n)
                return uNodeIndex;
            else
                ++n;
            }
        }
    Quit("Clust::GetIndex");
    return uInsane;
    }

void Clust::ListMe() const
    {
    List("Clust rooted %d, %u leaves, %u nodes, %u clusters.\n",
      m_bIsRooted, m_uLeafCount, m_uNodeCount, m_uClusterCount);

    List("Distance matrix\n");
    const unsigned uNodeCount = GetNodeCount();
    List("       ");
    for (unsigned i = 0; i < uNodeCount - 1; ++i)
        List(" %7u", i);
    List("\n");

    List("       ");
    for (unsigned i = 0; i < uNodeCount - 1; ++i)
        List("  ------");
    List("\n");

    for (unsigned i = 0; i < uNodeCount - 1; ++i)
        {
        bool bAny = false;
        for (unsigned j = 0; j < i; ++j)
            if (DistIsSet(i, j))
                {
                bAny = true;
                break;
                }
        if (!bAny)
            continue;

        List("%4u:  ", i);
        for (unsigned j = 0; j < i; ++j)
            {
            if (DistIsSet(i, j))
                List(" %7.2g", GetDist(i, j));
            else
                List("        ");
            }
        List("\n");
        }

    List("\n");
    List("Node  Size  Prnt  Left  Rght  Length\n");
    List("----  ----  ----  ----  ----  ------\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        const ClustNode &Node = m_Nodes[uNodeIndex];
        List("%4u  %4u", uNodeIndex, Node.m_uSize);
        if (0 != Node.m_ptrParent)
            List("  %4u", Node.m_ptrParent->m_uIndex);
        else
            List("      ");

        if (0 != Node.m_ptrLeft)
            List("  %4u", Node.m_ptrLeft->m_uIndex);
        else
            List("      ");

        if (0 != Node.m_ptrRight)
            List("  %4u", Node.m_ptrRight->m_uIndex);
        else
            List("      ");

        if (uNodeIndex != m_uNodeCount - 1)
            List("  %g", Node.m_dLength);
        List("\n");
        }
    }

const ClustNode &Clust::GetNode(unsigned uNodeIndex) const
    {
    if (uNodeIndex >= m_uNodeCount)
        Quit("ClustNode::GetNode(%u) %u", uNodeIndex, m_uNodeCount);
    return m_Nodes[uNodeIndex];
    }

bool Clust::IsLeaf(unsigned uNodeIndex) const
    {
    return uNodeIndex < m_uLeafCount;
    }

unsigned Clust::GetClusterSize(unsigned uNodeIndex) const
    {
    const ClustNode &Node = GetNode(uNodeIndex);
    return Node.m_uSize;
    }

unsigned Clust::GetLeftIndex(unsigned uNodeIndex) const
    {
    const ClustNode &Node = GetNode(uNodeIndex);
    if (0 == Node.m_ptrLeft)
        Quit("Clust::GetLeftIndex: leaf");
    return Node.m_ptrLeft->m_uIndex;
    }

unsigned Clust::GetRightIndex(unsigned uNodeIndex) const
    {
    const ClustNode &Node = GetNode(uNodeIndex);
    if (0 == Node.m_ptrRight)
        Quit("Clust::GetRightIndex: leaf");
    return Node.m_ptrRight->m_uIndex;
    }

double Clust::GetLength(unsigned uNodeIndex) const
    {
    const ClustNode &Node = GetNode(uNodeIndex);
    return Node.m_dLength;
    }

void Clust::SetLeafCount(unsigned uLeafCount)
    {
    if (uLeafCount <= 1)
        Quit("Clust::SetLeafCount(%u)", uLeafCount);

    m_uLeafCount = uLeafCount;
    const unsigned uNodeCount = GetNodeCount();
    m_dDist = new double[uNodeCount*uNodeCount];
    m_bDistSet = new bool[uNodeCount*uNodeCount];

    for (unsigned i = 0; i < uNodeCount; ++i)
        for (unsigned j = 0; j < uNodeCount; ++j)
            {
            const unsigned u = DistVectorIndex(i, j);
            m_dDist[u] = g_dNAN;
            m_bDistSet[u] = false;
            }
    }

unsigned Clust::GetLeafCount() const
    {
    return m_uLeafCount;
    }

double Clust::GetDist(unsigned uIndex1, unsigned uIndex2) const
    {
    const unsigned u = DistVectorIndex(uIndex1, uIndex2);
    return m_dDist[u];
    }

bool Clust::DistIsSet(unsigned uIndex1, unsigned uIndex2) const
    {
    const unsigned u = DistVectorIndex(uIndex1, uIndex2);
    return m_bDistSet[u];
    }

unsigned Clust::DistVectorIndex(unsigned uIndex1, unsigned uIndex2) const
    {
    const unsigned uNodeCount = GetNodeCount();
    if (uIndex1 >= uNodeCount || uIndex2 >= uNodeCount)
        Quit("DistVectorIndex(%u,%u) %u", uIndex1, uIndex2, uNodeCount);
    return uIndex1 + uNodeCount*uIndex2;
    }

void Clust::SetDist(unsigned uIndex1, unsigned uIndex2, double dDist)
    {
    {
    const unsigned u = DistVectorIndex(uIndex1, uIndex2);
    m_dDist[u] = dDist;
    m_bDistSet[u] = true;
    }
    {
    const unsigned u = DistVectorIndex(uIndex2, uIndex1);
    m_dDist[u] = dDist;
    m_bDistSet[u] = true;
    }
    }

double Clust::GetHeight(unsigned uNodeIndex) const
    {
    if (IsLeaf(uNodeIndex))
        return 0;

    const unsigned uLeftIndex = GetLeftIndex(uNodeIndex);
    const unsigned uRightIndex = GetRightIndex(uNodeIndex);
    const double dLeftLength = GetLength(uLeftIndex);
    const double dRightLength = GetLength(uRightIndex);
    return dLeftLength + dRightLength + GetHeight(uLeftIndex) + GetHeight(uRightIndex);
    }

const char *Clust::GetNodeName(unsigned uNodeIndex) const
    {
    if (uNodeIndex >= GetLeafCount())
        return 0;
    return m_ptrSet->GetLeafName(uNodeIndex);
    }

void Clust::ToPhylip(Phylip &Tree)
    {
    Tree.FromClust(*this);
    }

unsigned Clust::GetLeaf(unsigned uNodeIndex, unsigned uLeafIndex) const
    {
    const ClustNode &Node = GetNode(uNodeIndex);
    const unsigned uLeafCount = Node.m_uSize;
    if (uLeafIndex >= uLeafCount)
        Quit("Clust::GetLeaf, invalid index");
    const unsigned uIndex = Node.m_uLeafIndexes[uLeafIndex];
    if (uIndex >= m_uNodeCount)
        Quit("Clust::GetLeaf, index out of range");
    return uIndex;
    }
    
void Clust::ClusterToThreshold(ClustSet &Set, double threshold)
    {
    fprintf(stderr, "clustering to threshold %f ...\n", threshold);
    m_ptrSet = &Set; 
    m_bIsRooted = Set.IsRooted();

    SetLeafCount(Set.GetLeafCount());
    SetJoinStyle(Set.GetJoinStyle());
    SetCentroidStyle(Set.GetCentroidStyle());

    if (m_uLeafCount <= 1)
        Quit("Clust::Create: no leaves");

    m_uNodeCount = 2*m_uLeafCount - 1;
    m_Nodes = new ClustNode[m_uNodeCount];

    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        ClustNode &Node = m_Nodes[uNodeIndex];
        Node.m_uIndex = uNodeIndex;
        if (uNodeIndex < m_uLeafCount)
            {
            Node.m_uSize = 1;
            Node.m_uLeafIndexes = new unsigned[1];
            Node.m_uLeafIndexes[0] = uNodeIndex;
            }
        else
            Node.m_uSize = 0;
        }

// Compute initial distance matrix between leaves
fprintf(stderr, "Computing initial BETE distance matrix...");
    for (unsigned i = 0; i < m_uLeafCount; ++i)
        for (unsigned j = 0; j < i; ++j)
            {
            const double dDist = m_ptrSet->ComputeDist(*this, i, j);
            SetDist(i, j, dDist);
            }
fprintf(stderr, "...done.");
// Call CreateCluster once for each internal node in the tree
    m_uClusterCount = m_uLeafCount;
    
    dMinDist = -9e99;
    for (unsigned uNodeIndex = m_uLeafCount; uNodeIndex < m_uNodeCount ; ++uNodeIndex){
        fprintf(stderr, "CreateCluster() ");
        CreateCluster();
        fprintf(stderr, "distance = %f\n", dMinDist);
        if( dMinDist >= threshold)
            break;
        
    }
    }
