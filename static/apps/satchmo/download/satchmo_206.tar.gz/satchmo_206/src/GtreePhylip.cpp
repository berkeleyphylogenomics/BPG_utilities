// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "GTree2.h"
#include "GNode2.h"
#include "TextFile.h"

void GTree2::ToPhylipFile(TextFile &File)
    {
      //      printf ("call tophylip file");
    if (0 == m_ptrRoot->m_ptrRight)
        File.PutString("(");
    ToPhylipNode(File, m_ptrRoot);
    if (0 == m_ptrRoot->m_ptrRight)
        File.PutString(")");
    File.PutString(";\n");
    }

static void PutName(TextFile &File, const char szName[])
    {
    while (char c = *szName++)
        {
        if (isspace(c))
            File.PutChar('_');
        else if (isprint(c))
            File.PutChar(c);
        }
    }

void GTree2::ToPhylipNode(TextFile &File, GNode2 *ptrNode)
    {
      //          printf("put node\n");

    if (0 == ptrNode->m_ptrRight)
      {
        //printf(" node one %s\n",ptrNode->m_uNodeIndex);
        PutName(File, ptrNode->GetName());
      }
    else
        {
        File.PutString("(");
        ToPhylipNode(File, ptrNode->m_ptrLeft);
        File.PutString(",\n");
        ToPhylipNode(File, ptrNode->m_ptrRight);
        File.PutString(")");
        }
    }
