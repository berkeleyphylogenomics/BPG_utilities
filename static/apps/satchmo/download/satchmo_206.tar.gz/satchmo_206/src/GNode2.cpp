// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "GNode2.h"
#include "TextFile.h"

GNode2::~GNode2()
    {
    Clear();
    free(m_ptrName);
    }

void GNode2::AllocDistVector(unsigned uNodeCount)
    {
    delete[] m_Dist;
    m_Dist = new double[uNodeCount];
    for (unsigned n = 0; n < uNodeCount; ++n)
        m_Dist[n] = VERY_NEGATIVE_DOUBLE;
    m_uDistCount = uNodeCount;
    }

void GNode2::DeleteFromList(GNode2 *&ptrHead)
    {
      // assert(0 != ptrHead); 

    if (m_ptrNext)
        m_ptrNext->m_ptrPrev = m_ptrPrev;
    if (m_ptrPrev)
        m_ptrPrev->m_ptrNext = m_ptrNext;
    else
        ptrHead = m_ptrNext;

    m_ptrNext = 0;
    m_ptrPrev = 0;
    }

void GNode2::AddToList(GNode2 *&ptrHead)
    {
    if (ptrHead)
        ptrHead->m_ptrPrev = this;

    m_ptrNext = ptrHead;
    m_ptrPrev = 0;
    ptrHead = this;
    }

void GNode2::Validate() const
    {
    assert(GNode_Magic == m_uMagic);
    if (0 != m_ptrNext)
        {
        assert(this == m_ptrNext->m_ptrPrev);
        assert(GNode_Magic == m_ptrNext->m_uMagic);
        }
    if (0 != m_ptrPrev)
        {
        assert(this == m_ptrPrev->m_ptrNext);
        assert(GNode_Magic == m_ptrPrev->m_uMagic);
        }
    }

void GNode2::ValidateList(const GNode2 *ptrHead)
    {
    if (0 == ptrHead)
        return;

    assert(0 == ptrHead->m_ptrPrev);

    for (const GNode2 *ptrNode = ptrHead; ptrNode; ptrNode = ptrNode->m_ptrNext)
        ptrNode->Validate();
    }

unsigned GNode2::GetListLength(const GNode2 *ptrHead)
    {
    if (0 == ptrHead)
        return 0;

    ValidateList(ptrHead);

    unsigned uLength = 0;
    for (const GNode2 *ptrNode = ptrHead; ptrNode; ptrNode = ptrNode->m_ptrNext)
        ++uLength;
    return uLength;
    }

unsigned GNode2::GetDepth() const
    {
    unsigned uDepth = 0;
    for (GNode2 *p = m_ptrParent; p; p = p->m_ptrParent)
        ++uDepth;
    return uDepth;
    }

bool GNode2::IsLeaf() const
    {
    if (0 == m_ptrLeft)
        {
        assert(0 == m_ptrRight);
        return true;
        }
    return false;
    }

bool GNode2::IsRoot() const
    {
    return 0 == m_ptrParent;
    }

void GNode2::DistToFile(TextFile &File)
    {
    File.PutFormat("count %u\n", m_uDistCount);
    for (unsigned n = 0; n < m_uDistCount; ++n)
        {
        double d = m_Dist[n];
        if (VERY_NEGATIVE_DOUBLE == d)
            continue;
        File.PutFormat("%u %g\n", n, d);
        }
    File.PutString("//\n");
    }

void GNode2::DistFromFile(TextFile &File)
    {
    char szToken[32];
    File.GetTokenX(szToken, sizeof(szToken));
    assert(0 == strcmp(szToken, "count"));
    
    File.GetTokenX(szToken, sizeof(szToken));
    assert(IsValidInteger(szToken));
    unsigned uCount = (unsigned) atoi(szToken);
    assert(uCount > 0);
    AllocDistVector(uCount);

    for (;;)
        {
        File.GetTokenX(szToken, sizeof(szToken));
        if (0 == strcmp(szToken, "//"))
            return;
        assert(IsValidInteger(szToken));
        unsigned uNodeIndex = (unsigned) atoi(szToken);
        assert(uNodeIndex >= 0 && uNodeIndex != m_uNodeIndex && uNodeIndex < uCount);

        File.GetTokenX(szToken, sizeof(szToken));
        double d = atof(szToken);
        m_Dist[uNodeIndex] = d;
        }
    }

GNode2 *GNode2::GetRoot()
    {
    GNode2 *ptrRoot;
    for (ptrRoot = this; 0 != ptrRoot->m_ptrParent;
      ptrRoot = ptrRoot->m_ptrParent)
        ;
    return ptrRoot;
    }

// Clear doesn't touch m_ptrLeft/Right/Next/Prev/Parent/Name
// because they may still be used to save the Phylip tree.
// Goal here is to free as many memory resources as is safe.
// (This really needs to be cleaned up; risky design).
void GNode2::Clear()
    {
    m_Model.Clear();
    m_MSA.Clear();
    m_MPP.Clear();

    delete[] m_Dist;
    m_Dist = 0;
    m_uDistCount = 0;
    }
