// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include <math.h>
#include <float.h>

// LnGamma. A minor re-edit of the Gammaln code in HMMer,
// which contained the following acknowledgement:
//        Adapted from a public domain implementation in the
//        NCBI core math library. Thanks to John Spouge and
//        the NCBI. (According to the NCBI, that's Dr. John
//        "Gammas Galore" Spouge to you, pal.)

// Table look-up optimization code due to Wayne Christopher.
// (According to me, that's Wayne "faster than Spouge" to you, pal).

static double cof[] =
    {
    4.694580336184385e+04,
    -1.560605207784446e+05,
    2.065049568014106e+05,
    -1.388934775095388e+05,
    5.031796415085709e+04,
    -9.601592329182778e+03,
    8.785855930895250e+02,
    -3.155153906098611e+01,
    2.908143421162229e-01,
    -2.319827630494973e-04,
    1.251639670050933e-10
    };

static double RawLnGamma(double x)
    {
    assert(11 == countof(cof));

// TODO: I think calling code checks for x=0, we can probably
// assert here instead.
    if (x <= 0.0)
        return 999999.0; 

    double xx  = x - 1.0;
    double tx = xx + 11.0;
    double tmp = tx;
    double value = 1.0;
    for (int i = 10; i >= 0; --i)
        {
        value += cof[i] / tmp;
        tmp -= 1.0;
        }
    value = log(value);
    tx += 0.5;
    return value + 0.918938533 + (xx + 0.5)*log(tx) - tx;
    }

static int lgamma_nc = 0;
static int lgamma_nt = 0;
static int max_lgamma = -1;

#define LG_RESOLUTION 0.001
#define LG_STEPS ((int) (1/LG_RESOLUTION))

static double *lg_vals = NULL;

// Hack to free memory when process terminates,
// this avoids spurious messages from heap checkers.
struct FreeVals
    {
    ~FreeVals()
        {
        free(lg_vals);
        }
    } JustToFreeVals;


#define my_lgamma(v) ((((v) < max_lgamma) && \
               (lg_vals[(int) ((v) * LG_STEPS)] < FLT_MAX)) ? \
              lg_vals[(int) ((v) * LG_STEPS)] : \
              my_lgamma_compute(v))

static double my_lgamma_compute(double v)
    {
    int i;

// Quick and dirty have to prevent table size from overflowing
    if (v > 20000.0)
        return RawLnGamma(v);

    if (v >= max_lgamma)
        {
        if (!lg_vals)
            {
            max_lgamma = 10;
            int s = max_lgamma * LG_STEPS;
            lg_vals = (double *) malloc(sizeof (double) * s);
            for (i = 0; i < s; i++)
            lg_vals[i] = FLT_MAX;
        }
        int s1 = max_lgamma * LG_STEPS;
        max_lgamma = (int) (v + 1);  // what the heck
        //printf("resized lgamma cache to %d\n", max_lgamma);
        int s2 = max_lgamma * LG_STEPS;
        lg_vals = (double *) realloc((void *) lg_vals, sizeof (double) * s2);
        for (i = s1; i < s2; i++)
            lg_vals[i] = FLT_MAX;
        }
    
    int p = (int) (v * LG_STEPS);
    if (lg_vals[p] == FLT_MAX)
        {
        lg_vals[p] = RawLnGamma(v);
        lgamma_nc++;
        }
    lgamma_nt++;

    return lg_vals[p];
    }

double my_lgamma_function(double v)
    {
    int iIndex = (int) (v*LG_STEPS);
    if (v < max_lgamma && lg_vals[iIndex] < FLT_MAX)
        return lg_vals[iIndex];
    return my_lgamma_compute(v);
    }

double LnGamma(double x)
    {
    double r = my_lgamma(x);
    return r;
    }
