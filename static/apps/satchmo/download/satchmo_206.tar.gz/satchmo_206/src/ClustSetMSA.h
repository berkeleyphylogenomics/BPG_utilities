// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef ClustSetMSA_h
#define ClustSetMSA_h

class MSA;
class Clust;

#include "ClustSet.h"
#include "MSADist.h"

// Distance matrix based set.
// Computes distances between leaves, never between
// joined clusters (leaves this to distance matrix method).
class ClustSetMSA : public ClustSet
    {
public:
    ClustSetMSA(MSA &msa, JOINSTYLE JoinStyle, CENTROIDSTYLE CentroidStyle,
      bool bIsRooted, MSADist &MD) :
        m_ptrMSA(&msa),
        m_JoinStyle(JoinStyle),
        m_CentroidStyle(CentroidStyle),
        m_bIsRooted(bIsRooted),
        m_ptrMSADist(&MD)
        {
        if (CENTROIDSTYLE_ComputedBySet == CentroidStyle)
            Quit("ClustSetMSA: cannot use ComputedBySet;"
              " is for distance methods only.");
        }

public:
    virtual unsigned GetLeafCount()
        {
        return m_ptrMSA->GetSeqCount();
        }
    virtual JOINSTYLE GetJoinStyle()
        {
        return m_JoinStyle;
        }
    virtual CENTROIDSTYLE GetCentroidStyle()
        {
        return m_CentroidStyle;
        }
    virtual bool IsRooted()
        {
        return m_bIsRooted;
        }
    virtual const char *GetLeafName(unsigned uNodeIndex)
        {
        return m_ptrMSA->GetSeqName(uNodeIndex);
        }
    virtual void JoinNodes(const Clust &C, unsigned uLeftNodeIndex,
      unsigned uRightNodeIndex, unsigned uJoinedNodeIndex,
      double *ptrdLeftLength, double *ptrdRightLength)
        {
        Quit("ClustSetMSA::JoinNodes, should never be called");
        }
    virtual double ComputeDist(const Clust &C, unsigned uNodeIndex1,
      unsigned uNodeIndex2)
        {
        return m_ptrMSADist->ComputeDist(*m_ptrMSA, uNodeIndex1, uNodeIndex2);
        }

public:
    const MSA &GetMSA();

private:
    MSA *m_ptrMSA;
    JOINSTYLE m_JoinStyle;
    CENTROIDSTYLE m_CentroidStyle;
    bool m_bIsRooted;
    MSADist *m_ptrMSADist;
    };

#endif    // ClustSetMSA_h
