// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    PWRE_h
#define    PWRE_h

#include "PWBase.h"

class PWRE : public PWBase
    {
public:
    PWRE()
        {
        }

    virtual ~PWRE()
        {
        }

    virtual PWCLASS GetClass() const { return PWCLASS_RE; }

    virtual SCORE ScoreProfPos(const ProfPos &PPA, const ProfPos &PPB) const
        {
        return REScore(PPA.m_Probs, PPB.m_Probs);
        }

    static SCORE REScore(const PROB p[], const PROB q[]);
    };

#endif    // PWRE_h
