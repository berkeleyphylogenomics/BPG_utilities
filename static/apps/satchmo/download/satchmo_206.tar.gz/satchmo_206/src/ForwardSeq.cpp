// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "Seq.h"
#include "MSA.h"

#define    VERBOSE    0

// Macros to simulate 2D matrices
#define DPM(NodeIndex, PrefixLength)    DPM_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPD(NodeIndex, PrefixLength)    DPD_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPI(NodeIndex, PrefixLength)    DPI_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPN(NodeIndex, PrefixLength)    DPN_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPS(NodeIndex, PrefixLength)    DPS_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTM(NodeIndex, PrefixLength)    DPTM_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTD(NodeIndex, PrefixLength)    DPTD_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTI(NodeIndex, PrefixLength)    DPTI_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]

SCORE HMM::ForwardSeq(const Seq &s, SCORE **ptrptrDPM)
    {
    const unsigned uSeqLength = s.Length();
    const unsigned uPrefixCount = uSeqLength + 1;
    const unsigned uNodeCount = GetNodeCount();
    assert(uSeqLength > 0 && uNodeCount > 0);
    *ptrptrDPM = 0;

// Allocate DP matrices
    size_t LM = uPrefixCount*uNodeCount;
    SCORE *DPM_ = new SCORE[LM];
    SCORE *DPD_ = new SCORE[LM];
    SCORE *DPI_ = new SCORE[LM];

#if    _DEBUG
    memset(DPM_, 0xcd, LM*sizeof(SCORE));
    memset(DPD_, 0xcd, LM*sizeof(SCORE));
    memset(DPI_, 0xcd, LM*sizeof(SCORE));
#endif

    DPM(0, 0) = MINUS_INFINITY;
    DPI(0, 0) = MINUS_INFINITY;
    DPD(0, 0) = m_scoreFirstD;

    for (unsigned uNodeIndex = 1; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        DPM(uNodeIndex, 0) = MINUS_INFINITY;
        DPD(uNodeIndex, 0) = Add2(DPD(uNodeIndex-1, 0), GetNode(uNodeIndex-1).m_scoreDD);
        DPI(uNodeIndex, 0) = MINUS_INFINITY;
        }

    const HMMNode &Node0 = GetNode(0);
    for (unsigned uPrefixLength = 1; uPrefixLength < uPrefixCount; ++uPrefixLength)
        {
        assert(uPrefixLength > 0);
        const unsigned uLetter = s.GetLetter(uPrefixLength-1);

    // Node 0 is special case.
    // Global/global
        if (1 == uPrefixLength)
            DPM(0, uPrefixLength) = m_scoreFirstM + Node0.m_scoreMatchEmit[uLetter];
        else
            DPM(0, uPrefixLength) = MINUS_INFINITY;
        DPD(0, uPrefixLength) = MINUS_INFINITY;
        SCORE scoreEmit = Node0.m_scoreInsertEmit[uLetter];
        SCORE scoreMI = Add3(DPM(0, uPrefixLength-1), Node0.m_scoreMI, scoreEmit);
        SCORE scoreDI = Add3(DPD(0, uPrefixLength-1), Node0.m_scoreDI, scoreEmit);
        SCORE scoreII = Add3(DPI(0, uPrefixLength-1), Node0.m_scoreII, scoreEmit);
        DPI(0, uPrefixLength) = SumLog(scoreMI, scoreDI, scoreII);

        for (unsigned uNodeIndex = 1; uNodeIndex < uNodeCount; ++uNodeIndex)
            {
            assert(uNodeIndex > 0);
            assert(uPrefixLength > 0);

            const HMMNode &Node = GetNode(uNodeIndex);
            const HMMNode &PrevNode = GetNode(uNodeIndex-1);

        // Transitions into M
            {
            SCORE scoreEmit = Node.m_scoreMatchEmit[uLetter];
            SCORE scoreMM = Add3(DPM(uNodeIndex-1, uPrefixLength-1), PrevNode.m_scoreMM, scoreEmit);
            SCORE scoreDM = Add3(DPD(uNodeIndex-1, uPrefixLength-1), PrevNode.m_scoreDM, scoreEmit);
            SCORE scoreIM = Add3(DPI(uNodeIndex-1, uPrefixLength-1), PrevNode.m_scoreIM, scoreEmit);
            DPM(uNodeIndex, uPrefixLength) = SumLog(scoreMM, scoreDM, scoreIM);
            }

        // Transitions into D
            {
            SCORE scoreMD = Add2(DPM(uNodeIndex-1, uPrefixLength), PrevNode.m_scoreMD);
            SCORE scoreDD = Add2(DPD(uNodeIndex-1, uPrefixLength), PrevNode.m_scoreDD);
            SCORE scoreID = Add2(DPI(uNodeIndex-1, uPrefixLength), PrevNode.m_scoreID);
            DPD(uNodeIndex, uPrefixLength) = SumLog(scoreMD, scoreDD, scoreID);
            }

        // Transitions into I
            {
            SCORE scoreEmit = Node.m_scoreInsertEmit[uLetter];
            SCORE scoreMI = Add3(DPM(uNodeIndex, uPrefixLength-1), Node.m_scoreMI, scoreEmit);
            SCORE scoreDI = Add3(DPD(uNodeIndex, uPrefixLength-1), Node.m_scoreDI, scoreEmit);
            SCORE scoreII = Add3(DPI(uNodeIndex, uPrefixLength-1), Node.m_scoreII, scoreEmit);
            DPI(uNodeIndex, uPrefixLength) = SumLog(scoreMI, scoreDI, scoreII);
            }
            }
        }

    const unsigned uLastNodeIndex = uNodeCount - 1;
    SCORE scoreM = DPM(uLastNodeIndex, uSeqLength);
    SCORE scoreD = DPD(uLastNodeIndex, uSeqLength);
    SCORE scoreFwd = SumLog(scoreM, scoreD);

#if VERBOSE
    ListDPProb(uNodeCount, uSeqLength, DPM_, DPD_, DPI_);
#endif    // VERBOSE

//    delete[] DPM_;
    *ptrptrDPM = DPM_;
    delete[] DPD_;
    delete[] DPI_;

    return scoreFwd;
    }

void ListDP(unsigned uNodeCount, unsigned uSeqLength, const SCORE *DPM_,
  const SCORE *DPD_, const SCORE *DPI_)
    {
    const unsigned uPrefixCount = uSeqLength + 1;
    List("Prefix   ");
    for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
        List(" %8u", uPrefixLength);
    List("\n");
    List("M[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List(" %s", ScoreToStr(DPM(uNodeIndex, uPrefixLength)));
        List("\n");
        }
    List("D[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List(" %s", ScoreToStr(DPD(uNodeIndex, uPrefixLength)));
        List("\n");
        }
    List("I[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            List(" %s", ScoreToStr(DPI(uNodeIndex, uPrefixLength)));
        List("\n");
        }
    }

static void PutScore(SCORE Score)
    {
    if (MINUS_INFINITY == Score)
        List("        *");
    else
        List("%9.5f", ScoreToProb(Score));
    }

void ListDPProb(unsigned uNodeCount, unsigned uSeqLength, const SCORE *DPM_,
  const SCORE *DPD_, const SCORE *DPI_)
    {
    const unsigned uPrefixCount = uSeqLength + 1;
    List("Prefix   ");
    for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
        List(" %8u", uPrefixLength);
    List("\n");
    List("M[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            PutScore(DPM(uNodeIndex, uPrefixLength));
        List("\n");
        }
    List("D[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            PutScore(DPD(uNodeIndex, uPrefixLength));
        List("\n");
        }
    List("I[]\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        List("Node %u:  ", uNodeIndex);
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            PutScore(DPI(uNodeIndex, uPrefixLength));
        List("\n");
        }
    }
/*
SCORE HMM::ForwardAln(const MSA &a, SCORE **ptrptrDPM)
    {
//    fprintf(stderr, "Forward...\n");
    a.SanityCheckPillarCount();
    const unsigned uPillarCount = a.GetPillarCount();
    const unsigned uPrefixCount = uPillarCount + 1;
    const unsigned uNodeCount = GetNodeCount();
    assert(uPillarCount > 0 && uNodeCount > 0);
    *ptrptrDPM = 0;
 
// Allocate DP matrices
    size_t LM = uPrefixCount*uNodeCount;
    SCORE *DPM_ = new SCORE[LM];
    SCORE *DPD_ = new SCORE[LM];
    SCORE *DPI_ = new SCORE[LM];
    unsigned *DPN_ = new unsigned [LM];
    
    CheckMemUse();
    
#if    _DEBUG
    memset(DPM_, 0xcd, LM*sizeof(SCORE));
    memset(DPD_, 0xcd, LM*sizeof(SCORE));
    memset(DPI_, 0xcd, LM*sizeof(SCORE));
#endif

    DPM(0, 0) = MINUS_INFINITY;
    DPI(0, 0) = MINUS_INFINITY;
    DPD(0, 0) = m_scoreFirstD;
    DPN(0, 0) = uInsane;
    
//For all nodes, set first column
    for (unsigned uNodeIndex = 1; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        DPM(uNodeIndex, 0) = MINUS_INFINITY;
        DPD(uNodeIndex, 0) = Add2(DPD(uNodeIndex-1, 0), GetNode(uNodeIndex-1).m_scoreDD);
        DPI(uNodeIndex, 0) = MINUS_INFINITY;
        DPN(uNodeIndex, 0) = uInsane;
        }

//Loop through Prefixii, set first row
    for (unsigned uPrefixLength = 1; uPrefixLength < uPrefixCount; ++uPrefixLength)
        {    
//        ListDPProb(uNodeCount, uPillarCount, DPM_, DPD_, DPI_);
         
        const PILLAR &Pillar = a.GetPillar(uPrefixLength-1);
        const bool bIsAligned = Pillar.m_bAligned;
            
    // Node 0 is special case.
    // Global/global
        if (1 == uPrefixLength)
            DPM(0, uPrefixLength) = EmitM(a, 0, uPrefixLength-1) + LegSM(a, 0, uPrefixLength);//m_scoreFirstM + Node0.m_scoreMatchEmit[uLetter];
        else
            DPM(0, uPrefixLength) = MINUS_INFINITY;
        DPD(0, uPrefixLength) = MINUS_INFINITY;
        SCORE scoreEmit = EmitI(a, 0, uPrefixLength-1); //Node0.m_scoreInsertEmit[uLetter];
        SCORE scoreMI = Add3(DPM(0, uPrefixLength-1), LegMI(a, 0, uPrefixLength), scoreEmit);
        SCORE scoreDI = Add3(DPD(0, uPrefixLength-1), LegDI(a, 0, uPrefixLength), scoreEmit);
        
        unsigned uFirstIPillar = DPN(0, uPrefixLength-1);
        SCORE ii = 1; //Add3(LegII(a, 0, uPrefixLength, uFirstIPillar, 'M'),LegII(a, 0, uPrefixLength, uFirstIPillar, 'D'),LegII(a, 0, uPrefixLength, uFirstIPillar, 'I'));
        SCORE scoreII = Add3(DPI(0, uPrefixLength-1), ii, scoreEmit);
        DPI(0, uPrefixLength) = SumLog(scoreMI, scoreDI, scoreII);
        DPN(0, uPrefixLength) = DPN(0, uPrefixLength - 1);
        
        for (unsigned uNodeIndex = 1; uNodeIndex < uNodeCount; ++uNodeIndex)
            {
            assert(uNodeIndex > 0);
            assert(uPrefixLength > 0);

            const HMMNode &Node = GetNode(uNodeIndex);
            const HMMNode &PrevNode = GetNode(uNodeIndex-1);

        // Transitions into M
            if (bIsAligned) {
            SCORE scoreEmit = EmitM(a, uNodeIndex, uPrefixLength-1); //Node.m_scoreMatchEmit[uLetter];
            SCORE scoreMM = Add3(DPM(uNodeIndex-1, uPrefixLength-1), LegMM(a, uNodeIndex, uPrefixLength), scoreEmit);
            SCORE scoreDM = Add3(DPD(uNodeIndex-1, uPrefixLength-1), LegDM(a, uNodeIndex, uPrefixLength), scoreEmit);
            unsigned uFirstIPillar = DPN(uNodeIndex-1, uPrefixLength-1);
            SCORE im = 1;
            SCORE scoreIM = Add3(DPI(uNodeIndex-1, uPrefixLength-1), im, scoreEmit);
            DPM(uNodeIndex, uPrefixLength) = SumLog(scoreMM, scoreDM, scoreIM);
            } else {
            DPM(uNodeIndex, uPrefixLength) = MINUS_INFINITY;    
            }
            
        // Transitions into D
            {
            SCORE scoreMD = Add2(DPM(uNodeIndex-1, uPrefixLength), LegMD(a, uNodeIndex, uPrefixLength));
            SCORE scoreDD = Add2(DPD(uNodeIndex-1, uPrefixLength), LegDD(a, uNodeIndex, uPrefixLength));
            unsigned uFirstIPillar = DPN(uNodeIndex -1, uPrefixLength);
            SCORE id = 1;
            SCORE scoreID = Add2(DPI(uNodeIndex-1, uPrefixLength), id);
            DPD(uNodeIndex, uPrefixLength) = SumLog(scoreMD, scoreDD, scoreID);
            }

        // Transitions into I
            {
            SCORE scoreEmit = EmitI(a, uNodeIndex, uPrefixLength-1);//Node.m_scoreInsertEmit[uLetter];
            SCORE scoreMI = Add3(DPM(uNodeIndex, uPrefixLength-1), LegMI(a, uNodeIndex, uPrefixLength), scoreEmit);
            SCORE scoreDI = Add3(DPD(uNodeIndex, uPrefixLength-1), LegDI(a, uNodeIndex, uPrefixLength), scoreEmit);
            unsigned uFirstIPillar = DPN(uNodeIndex -1, uPrefixLength);
            SCORE ii = 1;
            SCORE scoreII = Add3(DPI(uNodeIndex, uPrefixLength-1), ii, scoreEmit);
            DPI(uNodeIndex, uPrefixLength) = SumLog(scoreMI, scoreDI, scoreII);
            }
            }
        }

    const unsigned uLastNodeIndex = uNodeCount - 1;
    SCORE scoreM = DPM(uLastNodeIndex, uPillarCount);
    SCORE scoreD = DPD(uLastNodeIndex, uPillarCount);
    SCORE scoreFwd = SumLog(scoreM, scoreD);

#if VERBOSE
    ListDPProb(uNodeCount, uPillarCount, DPM_, DPD_, DPI_);
#endif    // VERBOSE
//    delete[] DPM_;
    *ptrptrDPM = DPM_;
    delete[] DPD_;
    delete[] DPI_;

    return scoreFwd;
    }

*/
SCORE HMM::ForwardAln(const MSA &a, SCORE **ptrptrDPM)
    {
//viterbi import
    a.SanityCheckPillarCount();

    const unsigned uPillarCount = a.GetPillarCount();
    const unsigned uPrefixCount = uPillarCount + 1;
    const unsigned uNodeCount = GetNodeCount();
    assert(uPillarCount > 0 && uNodeCount > 0);

#if    SAVEFILES
    TextFile ModelFile("c:\\tmp\\model.hmm", true);
    ToFile(ModelFile);
    TextFile AlnFile("c:\\tmp\\tgt.fasta", true);
    a.ToFASTAFile(AlnFile);
#endif



// Allocate DP matrices
    size_t LM = uPrefixCount*uNodeCount;
    SCORE *DPM_ = new SCORE[LM];
    SCORE *DPD_ = new SCORE[LM];
    SCORE *DPI_ = new SCORE[LM];
    unsigned *DPN_ = new unsigned[LM];
    char *DPS_ = new char[LM];
    char *DPTM_ = new char[LM];
    char *DPTD_ = new char[LM];
    char *DPTI_ = new char[LM];

    CheckMemUse();

#if    _DEBUG
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        for (unsigned uPrefixLength = 0; uPrefixLength < uPrefixCount; ++uPrefixLength)
            {
            DPM(uNodeIndex, uPrefixLength) = scoreInsane;
            DPD(uNodeIndex, uPrefixLength) = scoreInsane;
            DPI(uNodeIndex, uPrefixLength) = scoreInsane;
            DPN(uNodeIndex, uPrefixLength) = uInsane;
            DPS(uNodeIndex, uPrefixLength) = '-';
            DPTM(uNodeIndex, uPrefixLength) = '-';
            DPTD(uNodeIndex, uPrefixLength) = '-';
            DPTI(uNodeIndex, uPrefixLength) = '-';
            }
#endif

    DPM(0, 0) = MINUS_INFINITY;
    DPI(0, 0) = MINUS_INFINITY;
    DPD(0, 0) = m_scoreFirstD;
    DPN(0, 0) = uInsane;
    DPS(0, 0) = INVALID_STATE;
    DPTM(0, 0) = INVALID_STATE;
    DPTD(0, 0) = INVALID_STATE;
    DPTI(0, 0) = INVALID_STATE;

    for (unsigned uNodeIndex = 1; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        DPM(uNodeIndex, 0) = MINUS_INFINITY;
        DPTM(uNodeIndex, 0) = INVALID_STATE;

        DPD(uNodeIndex, 0) = Add2(DPD(uNodeIndex-1, 0), GetNode(uNodeIndex-1).m_scoreDD);
        DPTD(uNodeIndex, 0) = 'D';

        DPI(uNodeIndex, 0) = MINUS_INFINITY;
        DPTI(uNodeIndex, 0) = INVALID_STATE;

        DPN(uNodeIndex, 0) = uInsane;
        DPS(uNodeIndex, 0) = INVALID_STATE;
        }

    for (unsigned uPrefixLength = 1; uPrefixLength < uPrefixCount; ++uPrefixLength)
        {
        const PILLAR &Pillar = a.GetPillar(uPrefixLength-1);
        const bool bIsAligned = Pillar.m_bAligned;

    // Node 0 is special case.
        DPM(0, uPrefixLength) = LegSM(a, 0, uPrefixLength) + EmitM(a, 0, uPrefixLength-1);
        DPTM(0, uPrefixLength) = 'S';

        DPD(0, uPrefixLength) = LegSD(a, 0, uPrefixLength);
        DPTD(0, uPrefixLength) = 'S';

        SCORE scoreMI = Add2(DPM(0, uPrefixLength-1), LegMI(a, 0, uPrefixLength));
        SCORE scoreDI = Add2(DPD(0, uPrefixLength-1), LegDI(a, 0, uPrefixLength));

        if (uPrefixLength > 1)
            {
            unsigned uFirstIPillar = DPN(0, uPrefixLength-1);
            char cPrevState = DPS(0, uPrefixLength-1);
            SCORE scoreII = Add2(DPI(0, uPrefixLength-1),
              LegII(a, 0, uPrefixLength, uFirstIPillar, cPrevState));
            
            if (scoreMI >= scoreDI && scoreMI >= scoreII)
                {
                DPI(0, uPrefixLength) = scoreMI;
                DPN(0, uPrefixLength) = uPrefixLength-1;
                DPS(0, uPrefixLength) = 'M';
                DPTI(0, uPrefixLength) = 'M';
                }
            else if (scoreDI >= scoreMI && scoreDI >= scoreII)
                {
                DPI(0, uPrefixLength) = scoreDI;
                DPN(0, uPrefixLength) = uPrefixLength-1;
                DPS(0, uPrefixLength) = 'D';
                DPTI(0, uPrefixLength) = 'D';
                }
            else
                {
                assert(scoreII >= scoreMI && scoreII >= scoreDI);
                DPI(0, uPrefixLength) = scoreII;
                DPN(0, uPrefixLength) = DPN(0, uPrefixLength-1);
                DPS(0, uPrefixLength) = DPS(0, uPrefixLength-1);
                DPTI(0, uPrefixLength) = 'I';
                }
                DPI(0, uPrefixLength) = scoreMI + scoreDI + scoreII;
            }
        else
            {
            DPI(0, uPrefixLength) = scoreDI;
            DPN(0, uPrefixLength) = uPrefixLength-1;
            DPS(0, uPrefixLength) = 'D';
            DPTI(0, uPrefixLength) = 'D';
            }

        for (unsigned uNodeIndex = 1; uNodeIndex < uNodeCount; ++uNodeIndex)
            {
            assert(uNodeIndex > 0);
            assert(uPrefixLength > 0);

        // Transitions into M
            if (bIsAligned)
                {
                SCORE scoreEmit = EmitM(a, uNodeIndex, uPrefixLength-1);

            // M->M
                SCORE scoreMM;
                if (uPrefixLength > 1)
                    scoreMM = Add2(DPM(uNodeIndex-1, uPrefixLength-1), 
                      LegMM(a, uNodeIndex, uPrefixLength));
                else
                    scoreMM = MINUS_INFINITY;

            // D->M
                SCORE scoreDM = Add2(DPD(uNodeIndex-1, uPrefixLength-1), 
                LegDM(a, uNodeIndex, uPrefixLength));
            
            // I->M
                unsigned uFirstIPillar = DPN(uNodeIndex-1, uPrefixLength-1);
                char cPrevState = DPS(uNodeIndex-1, uPrefixLength-1);
                SCORE scoreIM;
                if (uPrefixLength > 1)
                    scoreIM = Add2(DPI(uNodeIndex-1, uPrefixLength-1), 
                      LegIM(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevState));
                else
                    scoreIM = MINUS_INFINITY;

            // Find max
                if (scoreMM >= scoreDM && scoreMM >= scoreIM)
                    {
                    DPM(uNodeIndex, uPrefixLength) = Add2(scoreMM, scoreEmit);
                    DPTM(uNodeIndex, uPrefixLength) = 'M';
                    }
                else if (scoreDM >= scoreMM && scoreDM >= scoreIM)
                    {
                    DPM(uNodeIndex, uPrefixLength) = Add2(scoreDM, scoreEmit);
                    DPTM(uNodeIndex, uPrefixLength) = 'D';
                    }
                else
                    {
                    assert(scoreIM >= scoreMM && scoreIM >= scoreDM);
                    DPM(uNodeIndex, uPrefixLength) = Add2(scoreIM, scoreEmit);
                    DPTM(uNodeIndex, uPrefixLength) = 'I';
                    }
                    DPM(uNodeIndex, uPrefixLength) = scoreEmit + scoreIM + scoreMM + scoreDM;
                }
            else
            // Not aligned
                {
                DPM(uNodeIndex, uPrefixLength) = MINUS_INFINITY;
                DPTM(uNodeIndex, uPrefixLength) = '!';
                }

        // Transitions into I
            if (uNodeIndex < uNodeCount - 1)
                {
            // M->I
                SCORE scoreMI = Add2(DPM(uNodeIndex, uPrefixLength-1),
                  LegMI(a, uNodeIndex, uPrefixLength));

            // D->I
                SCORE scoreDI = Add2(DPD(uNodeIndex, uPrefixLength-1),
                  LegDI(a, uNodeIndex, uPrefixLength));

            // I->I
                SCORE scoreII;
                if (uPrefixLength > 1)
                    {
                    unsigned uFirstIPillar = DPN(uNodeIndex, uPrefixLength-1);
                    char cPrevState = DPS(uNodeIndex, uPrefixLength-1);
                    scoreII = Add2(DPI(uNodeIndex, uPrefixLength-1),
                    LegII(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevState));
                    }
                else
                    scoreII = MINUS_INFINITY;
                if (scoreMI >= scoreDI && scoreMI >= scoreII)
                    {
                    DPI(uNodeIndex, uPrefixLength) = scoreMI;
                    DPN(uNodeIndex, uPrefixLength) = uPrefixLength-1;
                    DPS(uNodeIndex, uPrefixLength) = 'M';
                    DPTI(uNodeIndex, uPrefixLength) = 'M';
                    }
                else if (scoreDI >= scoreMI && scoreDI >= scoreII)
                    {
                    DPI(uNodeIndex, uPrefixLength) = scoreDI;
                    DPN(uNodeIndex, uPrefixLength) = uPrefixLength-1;
                    DPS(uNodeIndex, uPrefixLength) = 'D';
                    DPTI(uNodeIndex, uPrefixLength) = 'D';
                    }
                else
                    {
                    assert(scoreII >= scoreMI && scoreII >= scoreDI);
                    DPI(uNodeIndex, uPrefixLength) = scoreII;
                    DPN(uNodeIndex, uPrefixLength) = DPN(uNodeIndex, uPrefixLength-1);
                    DPS(uNodeIndex, uPrefixLength) = DPS(uNodeIndex, uPrefixLength-1);
                    DPTI(uNodeIndex, uPrefixLength) = 'I';
                    }
                    DPI(uNodeIndex, uPrefixLength) =scoreMI + scoreDI + scoreII;
                }
            else
                {
            // No insert state in last node
                DPI(uNodeIndex, uPrefixLength) = MINUS_INFINITY;
                DPN(uNodeIndex, uPrefixLength) = uInsane;
                DPS(uNodeIndex, uPrefixLength) = INVALID_STATE;
                DPTI(uNodeIndex, uPrefixLength) = INVALID_STATE;
                }

        // Transitions into D
            {
        // M->D
            SCORE scoreMD = Add2(DPM(uNodeIndex-1, uPrefixLength),
              LegMD(a, uNodeIndex, uPrefixLength));

        // D->D
            SCORE scoreDD = Add2(DPD(uNodeIndex-1, uPrefixLength),
              LegDD(a, uNodeIndex, uPrefixLength));

        // I->D
            unsigned uFirstIPillar = DPN(uNodeIndex-1, uPrefixLength);
            char cPrevState = DPS(uNodeIndex-1, uPrefixLength);
            SCORE scoreID;
            if (INVALID_STATE == cPrevState)
                {
                assert(1 == uPrefixLength);
                scoreID = MINUS_INFINITY;
                }
            else
                scoreID = Add2(DPI(uNodeIndex-1, uPrefixLength),
                  LegID(a, uNodeIndex, uPrefixLength, uFirstIPillar, cPrevState));
            if (scoreMD >= scoreDD && scoreMD >= scoreID)
                {
                DPD(uNodeIndex, uPrefixLength) = scoreMD;
                DPTD(uNodeIndex, uPrefixLength) = 'M';
                }
            else if (scoreDD >= scoreMD && scoreDD >= scoreID)
                {
                DPD(uNodeIndex, uPrefixLength) = scoreDD;
                DPTD(uNodeIndex, uPrefixLength) = 'D';
                }
            else
                {
                assert(scoreID >= scoreMD && scoreID >= scoreDD);
                DPD(uNodeIndex, uPrefixLength) = scoreID;
                DPTD(uNodeIndex, uPrefixLength) = 'I';
                }
                DPD(uNodeIndex, uPrefixLength) = scoreMD+scoreDD+scoreID;
            }
            }
        }

const unsigned uLastNodeIndex = uNodeCount - 1;
    SCORE scoreM = DPM(uLastNodeIndex, uPillarCount);
    SCORE scoreD = DPD(uLastNodeIndex, uPillarCount);
    SCORE Score = SumLog(scoreM, scoreD);


    *ptrptrDPM =  DPM_;
    delete[] DPD_;
    delete[] DPI_;
    delete[] DPN_;
    delete[] DPS_;
    delete[] DPTM_;
    delete[] DPTD_;
    delete[] DPTI_;

    return Score;
    }
