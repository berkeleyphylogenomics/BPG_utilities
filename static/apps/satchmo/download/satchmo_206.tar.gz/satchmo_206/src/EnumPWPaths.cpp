// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "EnumPaths.h"
#include "HMMPath.h"
#include "PWPath.h"

#define    VERBOSE    0

/***
A pair-wise path (PWPath) specifies an alignment of two sequences (A and B).
It a string of column types, called "edges" by analogy with HMM paths. 
Column types are M, D and I:

    M (match) has a letter from both sequences.
    D (delete) has a letter from A, gap in B.
    I (insert) has gap in A, letter from B.

Deletions and insertions are thus, by convention, considered with respect
to sequence A.

We wish to enumerate all possible pair-wise paths that have uCountA letters
from A and uCountB letters from B, in other words to enumerate all strings
generated from the alphabet {M,D,I} such that:

    count(M) + count(D) = uCountA
    count(M) + count(I) = uCountB

where count(x) means the number of edges of type x in the string.
It is straightforward to enumerate all different combinations
of count(M), count(D) and count(I) that satisfy these constaints.

This reduces the problem to enumerating all different strings given count(M),
count(D) and count(I), which we abbreviate to cM, cD and cI. First consider
the case cI=0. We can enumerate all strings with cM Ms and cD Ds as follows.
Start with a string of cM Ms. Then there are cM+1 different places where we
could insert Ds. For example, suppose cM=3:

    ^M^M^M^

Here, "^" marks a place where we could insert one or more Ds; note there
are 4 places. Now divide the Ds into gD Substrs of length >= 1. Suppose
gD=2. Choose 2 of the 4 possible insertion points in all possible ways,
and insert Ds into the chosen insertion points. To cause this to cover all
possible strings, we consider a the division of Ds into subset to be a list
of gD integers that sum to cD, the order of the integers being significant.
The range of values of gD to be considered is from 1 to min(cM+1, cD).
To handle cI > 0, enumerate all M/D strings and then consider all possible
combinations of insertion points in the M/D string and divisions of the Is
into gI subsets.

A set of k insertion points in a string of length S corresponds to a chain
of S+2 with k+1 links. For example, consider the case S=3, k=2, insertion
points are marked as "+", unused potential insertion points as "^":

    Insertions    Chain
    +M+M^M^        1,1,3
    +M^M+M^        1,2,2
    +M^M^M+        1,3,1
    ^M+M+M^        2,1,2
    ^M+M^M+        2,2,1
    ^M^M+M+        3,1,1

A division of a string of length S into gD substrings corresponds to a
chain of S with gD links.
***/

const size_t MAX_ALNLENGTH = 1000;

#define min(a, b)    ((a) < (b) ? (a) : (b))

class CTmp
    {
public:
    CTmp(unsigned uStartIndexA, unsigned uCountA, unsigned uStartIndexB,
      unsigned uCountB, EnumPWPathsSink &Sink) :
        m_uCountA(uCountA),
        m_uCountB(uCountB),
        m_uStartIndexA(uStartIndexA),
        m_uStartIndexB(uStartIndexB),
        m_ptrSink(&Sink)
        {
        if (m_uCountA + m_uCountB > MAX_ALNLENGTH)
            Quit("Are you nuts?");
        const unsigned uMaxMCount = min(uCountA, uCountB);
        for (m_uMCount = 0; m_uMCount <= uMaxMCount; ++m_uMCount)
            {
            m_uDCount = uCountA - m_uMCount;
            m_uICount = uCountB - m_uMCount;
            Enum2();
            }
        }

// Enum2: m_uxCount values fixed.
    void Enum2()
        {
        if (0 == m_uDCount)
            {
            m_uDSubstrCount = 0;
            Enum3();
            return;
            }

        const unsigned uMaxDSubstrCount = min(m_uDCount, m_uMCount+1);
        for (m_uDSubstrCount = 1; m_uDSubstrCount <= uMaxDSubstrCount; ++m_uDSubstrCount)
            {
            bool bFirst = true;
            while (NextChain(m_uDSubstrCount, m_uDCount, m_uDSubstrLengths, bFirst))
                Enum3();
            }
        }

// Enum3: m_uxCount, m_uDSubstrCount, m_uDSubstrLengths fixed.
    void Enum3()
        {
        if (0 == m_uICount)
            {
            m_uISubstrCount = 0;
            Enum4();
            return;
            }
        const unsigned uMaxISubstrCount = min(m_uICount, m_uMCount + m_uDCount + 1);
        for (m_uISubstrCount = 1; m_uISubstrCount <= uMaxISubstrCount; ++m_uISubstrCount)
            {
            bool bFirst = true;
            while (NextChain(m_uISubstrCount, m_uICount, m_uISubstrLengths, bFirst))
                Enum4();
            }
        }

// Enum4: m_uxCount, m_uxSubstrCount, m_uxSubstrLengths fixed.
    void Enum4()
        {
        if (0 == m_uDSubstrCount)
            {
            Enum5();
            return;
            }
        bool bFirst = true;
        const unsigned uInsertPointCount = m_uMCount + 2;
        while (NextChain(m_uDSubstrCount+1, uInsertPointCount, m_uInsertPointsDsIntoMs, bFirst))
            Enum5();
        }

// Enum5: m_uxCount, m_uxSubstrCount, m_uxSubstrLengths, m_uInsertPointsDsIntoMs fixed.
    void Enum5()
        {
        if (0 == m_uISubstrCount)
            {
            BuildPath();
            return;
            }
        bool bFirst = true;
        const unsigned uInsertPointCount = m_uMCount + m_uDCount + 2;
        while (NextChain(m_uISubstrCount+1, uInsertPointCount, m_uInsertPointsIsIntoMDs, bFirst))
            BuildPath();
        }

    void BuildPath()
        {
#if    VERBOSE
        List("cM=%u cD=%u cI=%u gD=%u gI=%u\n",
          m_uMCount,
          m_uDCount,
          m_uICount,
          m_uDSubstrCount,
          m_uISubstrCount);
        List("Ds");
        for (unsigned n = 0; n < m_uDSubstrCount; ++n)
            List(" %u", m_uDSubstrLengths[n]);
        List(" IPDs=(");
        for (unsigned n = 0; n < m_uDSubstrCount; ++n)
            List(" %u", m_uInsertPointsDsIntoMs[n]);
        List(" ) Is (");
        for (unsigned n = 0; n < m_uISubstrCount; ++n)
            List(" %u", m_uISubstrLengths[n]);
        List(" ) IPIs=(");
        for (unsigned n = 0; n < m_uISubstrCount; ++n)
            List(" %u", m_uInsertPointsIsIntoMDs[n]);
        List(" )\n");
#endif    // VERBOSE

        unsigned uMDPos = 0;
        unsigned uDSubstrIndex = 0;
        unsigned uDInsertPos = MAX_ALNLENGTH + 1;
        if (m_uDSubstrCount > 0)
            uDInsertPos = m_uInsertPointsDsIntoMs[0] - 1;
        char MD[MAX_ALNLENGTH];
        for (unsigned uMPos = 0; uMPos <= m_uMCount; ++uMPos)
            {
            if (uMPos == uDInsertPos)
                {
                const unsigned uSubstrLength = m_uDSubstrLengths[uDSubstrIndex];
                for (unsigned n = 0; n < uSubstrLength; ++n)
                    MD[uMDPos++] = 'D';
                ++uDSubstrIndex;
                if (uDSubstrIndex < m_uDSubstrCount)
                    uDInsertPos += m_uInsertPointsDsIntoMs[uDSubstrIndex];
                }
            if (uMPos == m_uMCount)
                break;
            MD[uMDPos++] = 'M';
            }
        MD[uMDPos] = 0;
#if    VERBOSE
        List("MD = %s\n", MD);
#endif
        unsigned uMDIPos = 0;
        unsigned uISubstrIndex = 0;
        unsigned uIInsertPos = MAX_ALNLENGTH + 1;
        if (m_uISubstrCount > 0)
            uIInsertPos = m_uInsertPointsIsIntoMDs[0] - 1;
        char MDI[MAX_ALNLENGTH];
        for (unsigned uMDPos = 0; uMDPos <= m_uMCount + m_uDCount; ++uMDPos)
            {
            if (uMDPos == uIInsertPos)
                {
                const unsigned uSubstrLength = m_uISubstrLengths[uISubstrIndex];
                for (unsigned n = 0; n < uSubstrLength; ++n)
                    MDI[uMDIPos++] = 'I';
                ++uISubstrIndex;
                if (uISubstrIndex < m_uISubstrCount)
                    uIInsertPos += m_uInsertPointsIsIntoMDs[uISubstrIndex];
                }
            if (uMDPos == m_uMCount + m_uDCount)
                break;
            MDI[uMDIPos++] = MD[uMDPos];
            }
        MDI[uMDIPos] = 0;
#if    VERBOSE
        List("MDI = %s%u.%u\n", MDI, m_uStartIndexA, m_uStartIndexB);
        List("\n");
#endif
        PWPath Path;
        MDIToPath(MDI, Path);
        if (0 != m_ptrSink)
            m_ptrSink->OnPath(Path);
        }

    void MDIToPath(const char *MDI, PWPath &Path)
        {
        Path.Clear();
        unsigned uPrefixLengthA = m_uStartIndexA;
        unsigned uPrefixLengthB = m_uStartIndexB;
        while (char c = *MDI++)
            {
            PWEdge Edge;
            Edge.cType = c;
            switch (c)
                {
            case 'M':
                ++uPrefixLengthA;
                ++uPrefixLengthB;
                break;
            case 'D':
                ++uPrefixLengthA;
                break;
            case 'I':
                ++uPrefixLengthB;
                break;
                }
            Edge.uPrefixLengthA = uPrefixLengthA;
            Edge.uPrefixLengthB = uPrefixLengthB;
            Path.AppendEdge(Edge);
            }
        }

private:
// Input parameters
// ----------------
    const unsigned m_uCountA;
    const unsigned m_uCountB;
    const unsigned m_uStartIndexA;
    const unsigned m_uStartIndexB;
    EnumPWPathsSink * const m_ptrSink;

// State
// -----
    unsigned m_uMCount;
    unsigned m_uDCount;
    unsigned m_uICount;

    unsigned m_uDSubstrCount;
    unsigned m_uISubstrCount;

    unsigned m_uDSubstrLengths[MAX_ALNLENGTH];
    unsigned m_uISubstrLengths[MAX_ALNLENGTH];

    unsigned m_uInsertPointsDsIntoMs[MAX_ALNLENGTH];
    unsigned m_uInsertPointsIsIntoMDs[MAX_ALNLENGTH];

    PWPath m_Path;
    unsigned m_uMPos;
    unsigned m_uMDPos;
    unsigned m_uDInsertPointIndex;
    unsigned m_uDInsertPointOffset;
    unsigned m_uIInsertPointIndex;
    unsigned m_uIInsertPointOffset;
    };

void EnumPWPaths(unsigned uLengthA, unsigned uLengthB, BOUNDS BoundsA, 
  BOUNDS BoundsB, EnumPWPathsSink &Sink)
    {
    if (GLOBAL == BoundsA && GLOBAL == BoundsB)
        CTmp EnumPWPaths2(0, uLengthA, 0, uLengthB, Sink);
    else if (GLOBAL == BoundsA && LOCAL == BoundsB)
        {
        for (unsigned uStartIndexB = 0; uStartIndexB < uLengthB; ++uStartIndexB)
            for (unsigned uCountB = 1; uCountB <= uLengthB - uStartIndexB; ++uCountB)
                CTmp EnumPWPaths2(0, uLengthA, uStartIndexB, uCountB, Sink);
        }
    else if (LOCAL == BoundsA && GLOBAL == BoundsB)
        {
        for (unsigned uStartIndexA = 0; uStartIndexA < uLengthA; ++uStartIndexA)
            for (unsigned uCountA = 1; uCountA <= uLengthA - uStartIndexA; ++uCountA)
                CTmp EnumPWPaths2(uStartIndexA, uCountA, 0, uLengthB, Sink);
        }
    else if (LOCAL == BoundsA && LOCAL == BoundsB)
        {
        for (unsigned uStartIndexA = 0; uStartIndexA < uLengthA; ++uStartIndexA)
            for (unsigned uCountA = 1; uCountA <= uLengthA - uStartIndexA; ++uCountA)
                for (unsigned uStartIndexB = 0; uStartIndexB < uLengthB; ++uStartIndexB)
                    for (unsigned uCountB = 1; uCountB <= uLengthB - uStartIndexB; ++uCountB)
                        CTmp EnumPWPaths2(uStartIndexA, uCountA, uStartIndexB, uCountB, Sink);
        }
    }

void TestE(int argc, char *argv[])
    {
    EnumPWPaths(1, 2, LOCAL, LOCAL, *(EnumPWPathsSink *) 0);
    }
