// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "MSA.h"

SCORE HMM::LegSeqSM(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    assert(Pillar.m_bAligned);
    assert(Pillar.m_uFromColIndex == Pillar.m_uToColIndex);
    unsigned uColIndex = Pillar.m_uToColIndex;
    if (Aln.IsGap(uSeqIndex, uColIndex))
        return m_scoreFirstD;
    return m_scoreFirstM;
    }

SCORE HMM::LegSeqSD(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    return m_scoreFirstD;
    }

SCORE HMM::LegSeqMM(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 1);
    unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const PILLAR &PrevPillar = Aln.GetPillar(uPillarIndex-1);
    assert(Pillar.m_bAligned);
    assert(Pillar.m_uFromColIndex == Pillar.m_uToColIndex);
    assert(PrevPillar.m_bAligned);
    assert(PrevPillar.m_uFromColIndex == PrevPillar.m_uToColIndex);
    unsigned uColIndex = Pillar.m_uToColIndex;
    unsigned uPrevColIndex = PrevPillar.m_uToColIndex;
    assert(uColIndex == uPrevColIndex + 1);
    assert(uNodeIndex > 0);
    const HMMNode &Node = GetNode(uNodeIndex - 1);
    if (Aln.IsGap(uSeqIndex, uPrevColIndex))
        {
        if (Aln.IsGap(uSeqIndex, uColIndex))
            return Node.m_scoreDD;
        else
            return Node.m_scoreDM;
        }
    else
        {
        if (Aln.IsGap(uSeqIndex, uColIndex))
            return Node.m_scoreMD;
        else
            return Node.m_scoreMM;
        }
    }

SCORE HMM::LegSeqMD(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    assert(Pillar.m_bAligned);
    assert(Pillar.m_uFromColIndex == Pillar.m_uToColIndex);
    unsigned uColIndex = Pillar.m_uToColIndex;
    assert(uNodeIndex > 0);
    const HMMNode &Node = GetNode(uNodeIndex - 1);
    if (Aln.IsGap(uSeqIndex, uColIndex))
        return Node.m_scoreDD;
    return Node.m_scoreMD;
    }

SCORE HMM::LegSeqMI(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 1);
    unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    const PILLAR &PrevPillar = Aln.GetPillar(uPillarIndex-1);
    assert(PrevPillar.m_bAligned);
    assert(PrevPillar.m_uFromColIndex == PrevPillar.m_uToColIndex);
    unsigned uFromColIndex = Pillar.m_uFromColIndex;
    unsigned uToColIndex = Pillar.m_uToColIndex;
    unsigned uPrevColIndex = PrevPillar.m_uToColIndex;
    assert(uNodeIndex > 0);
    const HMMNode &Node = GetNode(uNodeIndex);
    bool bPrevGap = Aln.IsGap(uSeqIndex, uPrevColIndex);
    unsigned uInserts = 0;
    for (unsigned uColIndex = uFromColIndex; uColIndex <= uToColIndex; ++uColIndex)
        if (!Aln.IsGap(uSeqIndex, uColIndex))
            ++uInserts;
    SCORE Score = 0;
    if (uInserts > 0)
        {
        if (bPrevGap)
            Score = Add2(Score, Node.m_scoreDI);
        else
            Score = Add2(Score, Node.m_scoreMI);
        }
    if (uInserts > 1)
        {
        SCORE s = Mul2((SCORE) (uInserts-1), Node.m_scoreII);
        Score = Add2(Score, s);
        }
    return Score;
    }

SCORE HMM::LegSeqDM(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    assert(Pillar.m_bAligned);
    assert(Pillar.m_uFromColIndex == Pillar.m_uToColIndex);
    unsigned uColIndex = Pillar.m_uToColIndex;
    assert(uNodeIndex > 0);
    const HMMNode &Node = GetNode(uNodeIndex - 1);
    if (Aln.IsGap(uSeqIndex, uColIndex))
        return Node.m_scoreDD;
    return Node.m_scoreDM;
    }

SCORE HMM::LegSeqDD(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uNodeIndex > 0);
    const HMMNode &Node = GetNode(uNodeIndex - 1);
    return Node.m_scoreDD;
    }

SCORE HMM::LegSeqDI(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength) const
    {
    assert(uPrefixLength > 0);
    unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    unsigned uFromColIndex = Pillar.m_uFromColIndex;
    unsigned uToColIndex = Pillar.m_uToColIndex;
    assert(uNodeIndex > 0);
    const HMMNode &Node = GetNode(uNodeIndex);
    unsigned uInserts = 0;
    for (unsigned uColIndex = uFromColIndex; uColIndex <= uToColIndex; ++uColIndex)
        if (!Aln.IsGap(uSeqIndex, uColIndex))
            ++uInserts;
    SCORE Score = 0;
    if (uInserts > 0)
        Score = Add2(Score, Node.m_scoreDI);
    if (uInserts > 1)
        {
        SCORE s = Mul2((SCORE) (uInserts-1), Node.m_scoreII);
        Score = Add2(Score, s);
        }
    return Score;
    }

SCORE HMM::LegSeqIM(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength,
  unsigned uFirstIPillar, char cPrevState) const
    {
    assert(uPrefixLength > 1);
    unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    assert(Pillar.m_bAligned);
    assert(Pillar.m_uFromColIndex == Pillar.m_uToColIndex);

    unsigned uColIndex = Pillar.m_uToColIndex;
    bool bGap = Aln.IsGap(uSeqIndex, uColIndex);

    assert(uNodeIndex > 0);
    const HMMNode &Node = GetNode(uNodeIndex-1);

    const PILLAR &FirstIPillar = Aln.GetPillar(uFirstIPillar);
    assert(FirstIPillar.m_uToColIndex > 0);
    const PILLAR &PrevPillar = Aln.GetPillar(uPillarIndex - 1);

    bool bBreak = true;
    for (unsigned uColIndex = FirstIPillar.m_uFromColIndex;
        uColIndex <= PrevPillar.m_uToColIndex; ++uColIndex)
        if (!Aln.IsGap(uSeqIndex, uColIndex))
            {
            bBreak = false;
            break;
            }
    
    assert(FirstIPillar.m_uFromColIndex > 0);
    unsigned uPrevColIndex = FirstIPillar.m_uFromColIndex - 1;
    bool bGapPrev = Aln.IsGap(uSeqIndex, uPrevColIndex);

    SCORE Score = 0;
    if ('M' == cPrevState)
        {
        if (bGap)
            {
            if (bBreak)
                {
                if (bGapPrev)
                    Score = Node.m_scoreDD;
                else
                    Score = Node.m_scoreMD;
                }
            else
                Score = Node.m_scoreID;
            }
        else
            {
            if (bBreak)
                {
                if (bGapPrev)
                    Score = Node.m_scoreDM;
                else
                    Score = Node.m_scoreMM;
                }
            else
                Score = Node.m_scoreIM;
            }
        }
    else
        {
        if (bGap)
            {
            if (bBreak)
                Score = Node.m_scoreDD;
            else
                Score = Node.m_scoreID;
            }
        else
            {
            if (bBreak)
                Score = Node.m_scoreDM;
            else
                Score = Node.m_scoreIM;
            }
        }
    return Score;
    }

SCORE HMM::LegSeqID(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength,
  unsigned uFirstIPillar, char cPrevState) const
    {
    assert(uPrefixLength > 0);
    unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    unsigned uFromColIndex = Pillar.m_uFromColIndex;
    unsigned uToColIndex = Pillar.m_uToColIndex;
    unsigned uColIndex = Pillar.m_uToColIndex;
    assert(uNodeIndex > 0);
    const HMMNode &Node = GetNode(uNodeIndex-1);
    unsigned uInserts = 0;
    for (unsigned uColIndex = uFromColIndex; uColIndex <= uToColIndex; ++uColIndex)
        if (!Aln.IsGap(uSeqIndex, uColIndex))
            ++uInserts;
    SCORE Score = 0;
    if (0 == uInserts)
        {
        bool bBreak = true;
        const PILLAR &FirstIPillar = Aln.GetPillar(uFirstIPillar);
        for (unsigned uColIndex = FirstIPillar.m_uFromColIndex;
          uColIndex < uFromColIndex; ++uColIndex)
            if (!Aln.IsGap(uSeqIndex, uColIndex))
                {
                bBreak = false;
                break;
                }
        if (bBreak)
            {
            if ('M' == cPrevState)
                Score = Node.m_scoreMD;
            else
                Score = Node.m_scoreDD;
            }
        else
            {
            if ('M' == cPrevState)
                Score = Node.m_scoreID;
            else
                Score = Node.m_scoreDD;
            }
        }
    else
        Score = Add2(Score, Node.m_scoreID);
    return Score;
    }

SCORE HMM::LegSeqII(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPrefixLength,
  unsigned uFirstIPillar, char cPrevState) const
    {
    assert(uPrefixLength > 1);
    unsigned uPillarIndex = uPrefixLength - 1;
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    unsigned uFromColIndex = Pillar.m_uFromColIndex;
    unsigned uToColIndex = Pillar.m_uToColIndex;

    assert(uNodeIndex > 0);
    const HMMNode &Node = GetNode(uNodeIndex);

// Count inserts in the column emitted by the I state.
    unsigned uInserts = 0;
    for (unsigned uColIndex = uFromColIndex; uColIndex <= uToColIndex; ++uColIndex)
        if (!Aln.IsGap(uSeqIndex, uColIndex))
            ++uInserts;

// If no residues, no transitions implied by this leg.
    if (0 == uInserts)
        return 0;

// Is there a break in all the previous columns touched
// by this I state?
    bool bBreak = true;
    const PILLAR &FirstIPillar = Aln.GetPillar(uFirstIPillar);
    for (unsigned uColIndex = FirstIPillar.m_uFromColIndex;
        uColIndex < uFromColIndex; ++uColIndex)
        if (!Aln.IsGap(uSeqIndex, uColIndex))
            {
            bBreak = false;
            break;
            }

    SCORE Score = 0;

    if (bBreak)
        {
        if ('M' == cPrevState)
            {
            assert(FirstIPillar.m_uToColIndex > 0);
            unsigned uCol = FirstIPillar.m_uFromColIndex - 1;
            if (Aln.IsGap(uSeqIndex, uCol))
                Score = Node.m_scoreDI;
            else
                Score = Node.m_scoreMI;
            }
        else
            Score = Node.m_scoreDI;
        }
    else
        Score = Node.m_scoreII;

    if (uInserts > 1)
        {
        SCORE s = Mul2((SCORE) (uInserts-1), Node.m_scoreII);
        Score = Add2(Score, s);
        }
    return Score;
    }

SCORE HMM::EmitSeqM(const MSA &Aln, unsigned uSeqIndex, unsigned uNodeIndex, unsigned uPillarIndex) const
    {
    const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
    assert(Pillar.m_bAligned);
    assert(Pillar.m_uFromColIndex == Pillar.m_uToColIndex);
    unsigned uColIndex = Pillar.m_uToColIndex;
    const HMMNode &Node = GetNode(uNodeIndex);

    if (Aln.IsGap(uSeqIndex, uColIndex))
        return 0;
    char c = Aln.GetChar(uSeqIndex, uColIndex);
    c = toupper(c);
    if ('X' == c)
        return 0;
    unsigned uLetter = Aln.GetLetter(uSeqIndex, uColIndex);
    return Node.m_scoreMatchEmit[uLetter];
    }
