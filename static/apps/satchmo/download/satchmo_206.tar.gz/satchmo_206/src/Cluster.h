// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

class DistFunc;

class ClusterNode
    {
    friend class ClusterTree;
public:
    ClusterNode()
        {
        m_dWeight = 0.0;
        m_dWeight2 = 0.0;
        m_ptrLeft = 0;
        m_ptrRight = 0;
        m_ptrParent = 0;
        m_uIndex = 0;
        m_ptrPrevDisjoint = 0;
        m_ptrNextDisjoint = 0;
        }
    ~ClusterNode() {}

public:
    unsigned GetIndex() const { return m_uIndex; }
    ClusterNode *GetLeft() const { return m_ptrLeft; }
    ClusterNode *GetRight() const { return m_ptrRight; }
    ClusterNode *GetParent() const { return m_ptrParent; }
    double GetWeight() const { return m_dWeight; }

    const ClusterNode *GetClusterLeaf(unsigned uLeafIndex) const;
    unsigned GetClusterSize() const;
    double GetClusterWeight() const;
    double GetLeftBranchWeight() const;
    double GetRightBranchWeight() const;
    double GetLeftWeight() const;
    double GetRightWeight() const;

    void ListMe() const;

    double GetWeight2() const { return m_dWeight2; }
    void SetWeight2(double dWeight2) { m_dWeight2 = dWeight2; }

protected:
    void SetIndex(unsigned uIndex) { m_uIndex = uIndex; }
    void SetWeight(double dWeight) { m_dWeight = dWeight; }
    void SetLeft(ClusterNode *ptrLeft) { m_ptrLeft = ptrLeft; }
    void SetRight(ClusterNode *ptrRight) { m_ptrRight = ptrRight; }
    void SetParent(ClusterNode *ptrParent) { m_ptrParent = ptrParent; }
    void SetNextDisjoint(ClusterNode *ptrNode) { m_ptrNextDisjoint = ptrNode; }
    void SetPrevDisjoint(ClusterNode *ptrNode) { m_ptrPrevDisjoint = ptrNode; }

    ClusterNode *GetNextDisjoint() { return m_ptrNextDisjoint; }
    ClusterNode *GetPrevDisjoint() { return m_ptrPrevDisjoint; }

private:
    double m_dWeight;
    double m_dWeight2;
    unsigned m_uIndex;
    ClusterNode *m_ptrLeft;
    ClusterNode *m_ptrRight;
    ClusterNode *m_ptrParent;
    ClusterNode *m_ptrNextDisjoint;
    ClusterNode *m_ptrPrevDisjoint;
    };

class ClusterTree
    {
public:
    ClusterTree();
    virtual ~ClusterTree();

    void Create(const DistFunc &DF, CLUSTER_STRATEGY Strategy);

    ClusterNode *GetRoot() const;
    void ListMe() const;

protected:
    void Join(ClusterNode *ptrNode1, ClusterNode *ptrNode2,
      ClusterNode *ptrJoin);
    void AddToDisjoints(ClusterNode *ptrNode);
    void DeleteFromDisjoints(ClusterNode *ptrNode);
    void Validate(unsigned uNodeCount);

private:
    ClusterNode *m_ptrDisjoints;
    ClusterNode *m_Nodes;
    unsigned m_uNodeCount;
    unsigned m_uLeafCount;
    };
