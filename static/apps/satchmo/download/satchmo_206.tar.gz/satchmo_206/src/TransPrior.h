// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef TransPrior_h
#define    TransPrior_h

enum
    {
    DP_MtoM = 0,
    DP_MtoD = 1,
    DP_MtoI = 2,

    DP_ItoM = 0,
    DP_ItoD = 1,
    DP_ItoI = 2,

    DP_DtoM = 0,
    DP_DtoD = 1,
    DP_DtoI = 2,
    };

enum
    {
    TP_MM = 0,
    TP_MD = 1,
    TP_MI = 2,

    TP_DM = 3,
    TP_DD = 4,
    TP_DI = 5,

    TP_IM = 6,
    TP_ID = 7,
    TP_II = 8
    };

// Layout in SAM .regularizer file:
// 0=dd 1=md 2=id
// 3=dm 4=mm 5=im
// 6=di 7=mi 8=ii
enum
    {
    SAMREG_DD = 0,
    SAMREG_MD = 1,
    SAMREG_ID = 2,

    SAMREG_DM = 3,
    SAMREG_MM = 4,
    SAMREG_IM = 5,

    SAMREG_DI = 6,
    SAMREG_MI = 7,
    SAMREG_II = 8
    };

#endif    // TransPrior_h
