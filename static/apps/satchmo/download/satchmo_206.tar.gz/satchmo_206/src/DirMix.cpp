// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "DirMix.h"
#include "TextFile.h"
#include <math.h>

#define VERBOSE    0

const unsigned MAX_SANE_COMP_COUNT = 100;
const unsigned MAX_SANE_ALPHA_COUNT = 100;

static bool FloatEq(double d1, double d2)
    {
    double dDiff = d1 - d2;
    if (0 == dDiff)
        return true;
    return fabs(dDiff/(d1 + d2)) < 0.001;
    }

static void GetKeywordAndValue(const char szLine[], char szKeyword[],
  unsigned uKeywordBytes, char szValue[], unsigned uValueBytes)
    {
    unsigned uLinePos = 0;
    unsigned uKeywordPos = 0;
    unsigned uValuePos = 0;
    char c;
    for (;;)
        {
        c = szLine[uLinePos++];
        if (0 == c)
            Quit("Missing '=' in Dirichlet file.");
        if ('=' == c)
            break;
        if (uKeywordPos + 1 >= uKeywordBytes)
            Quit("Keyword too long in Dirichlet file.");
        szKeyword[uKeywordPos++] = c;
        }
    szKeyword[uKeywordPos] = 0;
    TrimBlanks(szKeyword);
    for (;;)
        {
        c = szLine[uLinePos++];
        if (0 == c)
            {
            szValue[uValuePos] = 0;
            TrimBlanks(szValue);
            return;
            }
        if (uValuePos + 1 >= uValueBytes)
            Quit("Value too long in Dirichlet file.");
        szValue[uValuePos++] = c;
        }
    }

static unsigned GetNextToken(const char szStr[], unsigned uStrPos, char szToken[],
  unsigned uTokenBytes)
    {
// Skip leading blanks
    for (;;)
        {
        char c = szStr[uStrPos];
        if (0 == c)
            Quit("Unexpected end of line in Dirichlet file.");
        if (!isspace(c))
            break;
        ++uStrPos;
        }
    unsigned uTokenPos = 0;
    for (;;)
        {
        char c = szStr[uStrPos];
        if (uTokenPos == uTokenBytes)
            Quit("Token too long in Dirichlet file");
        szToken[uTokenPos] = c;
        if (isspace(c))
            return uStrPos;
        if (0 == c)
            {
            if (0 == uTokenPos)
                Quit("Missing token in Dirichlet file");
            return uStrPos;
            }
        ++uTokenPos;
        ++uStrPos;
        }
    }

static void GetAlphas(const char szValue[], unsigned uAlphaCount, double *dAlphas,
  double *ptrdSumAlphas)
    {
    char szToken[64];
    unsigned uPos = 0;
    uPos = GetNextToken(szValue, uPos, szToken, sizeof(szToken));
    *ptrdSumAlphas = atof(szToken);
    for (unsigned n = 0; n < uAlphaCount; ++n)
        {
        uPos = GetNextToken(szValue, uPos, szToken, sizeof(szToken));
        dAlphas[n] = atof(szToken);
        }
    }

void DirMix::Validate() const
    {
    double dSum = 0;
    unsigned uCompCount = m_uCompCount;
    for (unsigned n = 0; n < uCompCount; ++n)
        dSum += m_Comps[n].m_dCompProb;
    if (!FloatEq(dSum, 1.0))
        Quit("Dirichlet mixture, comp prob sum=%g", dSum);

    for (unsigned n = 0; n < uCompCount; ++n)
        {
        const DirComp *ptrComp = &m_Comps[n];

        if (!FloatEq(ptrComp->m_dLogCompProb, log(ptrComp->m_dCompProb)))
            Quit("Dirichlet component %u log prob is %g, should be %g.",
              n, ptrComp->m_dLogCompProb, log(ptrComp->m_dCompProb));

        dSum = 0;
        for (unsigned i = 0; i < m_uAlphaCount; ++i)
            dSum += ptrComp->m_dAlphas[i];
        if (!FloatEq(dSum, ptrComp->m_dSumAlphas))
            Quit("Dirichlet component %u sum alphas is %g, should be %g",
              n, dSum, ptrComp->m_dSumAlphas);
        }
    }

enum INPUT_STATE
    {
    IS_Begin,
    IS_Header,
    IS_Comp,
    };

void DirMix::FromFile(TextFile &File)
    {
    INPUT_STATE State = IS_Begin;
    
    char szInputLine[1024];
    char szKeyword[32];
    char szValue[1024];
    DirComp *ptrComp = 0;
    unsigned uCompIndex = 0;
    for (;;)
        {
        File.GetLineX(szInputLine, sizeof(szInputLine));
        TrimBlanks(szInputLine);
        if (0 == strlen(szInputLine))
            continue;
        GetKeywordAndValue(szInputLine, szKeyword, sizeof(szKeyword),
          szValue, sizeof(szValue));
        if (0 == stricmp(szKeyword, "EndClassName"))
            {
            if (uCompIndex != m_uCompCount)
                Quit("Missing component(s) in Dirichlet file %s",
                  File.GetFileName());
            Validate();
            return;
            }
        else if (0 == stricmp(szKeyword, "Number"))
            {
            assert(IsValidInteger(szValue));
            unsigned uIndex = (unsigned) atoi(szValue);
            if (uIndex != uCompIndex)
                Quit("Component %u out of order in Dirichlet file %s",
                  uIndex, File.GetFileName());
            ptrComp = &m_Comps[uIndex];
            ++uCompIndex;
            State = IS_Comp;
            continue;
            }

        switch (State)
            {
        case IS_Begin:
            if (0 != stricmp(szKeyword, "ClassName"))
                Quit("Invalid Dirichlet file %s, expecting ClassName", File.GetFileName());
            State = IS_Header;
            continue;

        case IS_Header:
            if (0 == stricmp(szKeyword, "Name"))
                continue;
            else if (0 == stricmp(szKeyword, "Alphabet"))
                continue;
            else if (0 == stricmp(szKeyword, "Order"))
                continue;
            else if (0 == stricmp(szKeyword, "AlphaChar"))
                {
                assert(IsValidInteger(szValue));
                unsigned uCount = (unsigned) atoi(szValue);
                if (uCount == 0 || uCount > MAX_SANE_ALPHA_COUNT)
                    Quit("Insane alpha count %s in Dirichlet file %s",
                      szValue, File.GetFileName());
                m_uAlphaCount = uCount;
                continue;
                }
            else if (0 == stricmp(szKeyword, "NumDistr"))
                {
                assert(IsValidInteger(szValue));
                unsigned uCompCount = (unsigned) atoi(szValue);
                if (uCompCount == 0 || uCompCount > MAX_SANE_COMP_COUNT)
                    Quit("Insane comp count %s in Dirichlet file %s",
                      szValue, File.GetFileName());
                m_Comps = new DirComp[uCompCount];
                m_uCompCount = uCompCount;
                continue;
                }
            else
                Quit("Unexpected keyword %s in Dirichlet file %s",
                  szKeyword, File.GetFileName());

        case IS_Comp:
            if (0 == stricmp(szKeyword, "Comment"))
                continue;
            else if (0 == stricmp(szKeyword, "Mixture"))
                {
                double dProb = atof(szValue);
                if (dProb <= 0 || dProb > 1)
                    Quit("Invalid probability for Dirichlet component %u in file %s",
                      uCompIndex - 1, File.GetFileName());
                ptrComp->m_dCompProb = dProb;
                ptrComp->m_dLogCompProb = log(dProb);
                continue;
                }
            else if (0 == stricmp(szKeyword, "Alpha"))
                {
                if (0 == m_uAlphaCount)
                    Quit("Alpha but no alpha count in Dirichlet file %s",
                      File.GetFileName());
                GetAlphas(szValue, m_uAlphaCount, ptrComp->m_dAlphas,
                  &ptrComp->m_dSumAlphas);
                continue;
                }
            else
                Quit("Unexpected keyword %s in Dirichlet file %s",
                  szKeyword, File.GetFileName());
            }
        }
    }

void DirMix::ListMe() const
    {
    List("CompCount=%u AlphaCount=%u\n", m_uCompCount, m_uAlphaCount);
    for (unsigned n = 0; n < m_uCompCount; ++n)
        {
        const DirComp *ptrComp = &m_Comps[n];
        List("Comp %u Sum=%g Prob=%g\nAlphas=",
          n, ptrComp->m_dSumAlphas, ptrComp->m_dCompProb);
        for (unsigned i = 0; i < m_uAlphaCount; ++i)
            List(" %g", ptrComp->m_dAlphas[i]);
        List("\n");
        }
    }

// Returns log P(Counts | Dirichlet mixture component)
// Log form of Sjloander thesis Lemma 4, p.33 and p.143.
double DirichletLogProb(const double dCounts[], unsigned uVarCount,
  const DirComp *ptrComp)
    {
    double dSumCountPlusAlpha = 0.0;
    double dSumAlpha = 0.0;
    double dSumCount = 0.0;
    double d = 0.0;

    for (unsigned uVar = 0; uVar < uVarCount; ++uVar)
        {
        double dCount = dCounts[uVar];
        double dAlpha = ptrComp->m_dAlphas[uVar];
        double dCountPlusAlpha = dCount + dAlpha;

        dSumCountPlusAlpha += dCountPlusAlpha;
        dSumAlpha += dAlpha;
        dSumCount += dCount;

        d += LnGamma(dCountPlusAlpha) - LnGamma(dCount+1) - LnGamma(dAlpha);
        }
    return d - LnGamma(dSumCountPlusAlpha) + LnGamma(dSumCount+1) +
      LnGamma(dSumAlpha);
    }

void DirMix::CountsToProbs(const WCOUNT wCounts[], PROB Probs[])
    {
    unsigned uVarCount = m_uAlphaCount;
    unsigned uCompCount = m_uCompCount;

#if    VERBOSE
    List("AddDirichletPrior Counts=");
    for (unsigned n = 0; n < uVarCount; ++n)
        List(" %u=%g", n, wCounts[n]);
    List("\n");
#endif

    double *dCounts = new double[uVarCount];
    for (unsigned n = 0; n < uVarCount; ++n)
        dCounts[n] = WCountToDouble(wCounts[n]);

// Calculate mixture coefficients.
// probMix[n] is set to the posterior probability P(Counts | D) of the
// count vector having been generated by Dirichlet distribution D.
    double probMix[MAX_DIRICHLET_COMPS];
    double lnscoreMix[MAX_DIRICHLET_COMPS];
    for (unsigned uCompIndex = 0; uCompIndex < uCompCount; ++uCompIndex)
        {
        const DirComp *ptrComp = &m_Comps[uCompIndex];
        PROB probComp = (PROB) ptrComp->m_dCompProb;

    // Log score (natural log, not log2=bits as elsewhere).
        if (0.0 == probComp)
            {
            lnscoreMix[uCompIndex] = MINUS_INFINITY;
            continue;
            }

        double lnscoreComp = ptrComp->m_dLogCompProb;
        double lnscoreCounts = DirichletLogProb(dCounts, uVarCount, ptrComp);
        lnscoreMix[uCompIndex] = lnscoreComp + lnscoreCounts;
        }
#if    VERBOSE
    List("lnscoreMix=");
    for (unsigned n = 0; n < uCompCount; ++n)
        List(" %u=%g", n, lnscoreMix[n]);
    List("\n");
#endif

// Convert mixture scores to mixture probabilities
    LogNormalize(lnscoreMix, uCompCount, probMix);

#if    VERBOSE
    List("probMix=");
    for (unsigned n = 0; n < uCompCount; ++n)
        List(" %u=%g", n, probMix[n]);
    List("\n");
#endif

// Add in the mixture
// Sjolander thesis eq. 6.15, p.35.
    double dTotalVarCount = VecSum(dCounts, uVarCount);
    for (unsigned uVar = 0; uVar < uVarCount; ++uVar)
        {
        double dVarCount = dCounts[uVar];
        double dSumOverComponents = 0.0;
        for (unsigned uCompIndex = 0; uCompIndex < uCompCount; ++uCompIndex)
            {
            const DirComp *ptrComp = &m_Comps[uCompIndex];
            double dSumAlphas = ptrComp->m_dSumAlphas;
            double d = (dVarCount + ptrComp->m_dAlphas[uVar]) /
              (dTotalVarCount + dSumAlphas);
            double dProbComponent = d * probMix[uCompIndex];
            dSumOverComponents += dProbComponent;
            }
        Probs[uVar] = (PROB) dSumOverComponents;
        }
    delete[] dCounts;
#if    VERBOSE
    List("Probs=");
    for (unsigned n = 0; n < uVarCount; ++n)
        List(" %u=%g", n, Probs[n]);
    List("\n");
#endif
    }
