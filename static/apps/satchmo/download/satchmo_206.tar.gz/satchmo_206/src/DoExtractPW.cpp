#include "lobster.h"
#include "GTree2.h"
#include "GNode2.h"
#include "MSA.h"
#include "TextFile.h"
#include <string>

using namespace std;
bool contains (GNode2 *node, const char* name);
void PairToFASTA(MSA *msa, TextFile &File,const  char* seq1,const char* seq2);
bool matchSeqID(string name1, string name2);

void DoExtractPW(const char *in,const char *seq1,const char *seq2,const char  *out){

    // Read in smo tree
    TextFile smoFile(in);
    GTree2 Tree;
    fprintf (stderr, "reading file..\n");
    Tree.FromSVFile(smoFile);
    fprintf(stderr, "Loading tree..\n");
    // verify that sequences are in tree
    GNode2 *nodeA = 0, *nodeB = 0;
    unsigned numLeaf = Tree.GetLeafCount();
    unsigned numNodes = Tree.GetNodeCount();
    unsigned seen = 0;
    bool bFound1 = false;
    bool bFound2 = false;
    int i=0;
    int nonleave=0;
     printf("TREE LEAVE number: %i\n", numLeaf );
     printf("TREE node number: %i\n", numNodes );
 
     while(i <= numNodes && seen <= numLeaf && !( bFound1 && bFound2 )){
	    if (Tree.GetNode(i)->IsLeaf()){
            string nodeName = Tree.GetNode(i)->m_ptrName;
	    //  printf("leave %i\n", i); 
       if (!bFound1 && matchSeqID(nodeName, seq1)) {
              bFound1 = true;
            nodeA = Tree.GetNode(i);
        } else if (!bFound2 && matchSeqID(nodeName, seq2)) {
            bFound2 = true;
            nodeB = Tree.GetNode(i);
        }
        seen++;
    }
        i++;
	}
	
    if (nodeA == 0)
        Quit("%s not found in satchmo tree!\n", seq1);
    if (nodeB == 0)
        Quit("%s not found in satchmo tree!\n", seq2);
        
    fprintf(stderr, "Extracting Pairwise alignment %s_%s from %s.\n", seq1, seq2, in);
        
    while(nodeA != 0){
        if(contains(nodeA, seq2)) break;
        nodeA = nodeA->m_ptrParent;
    }

    TextFile outFile(out, true);
    MSA *outMSA  = &(nodeA->m_MSA);
    
    PairToFASTA(outMSA, outFile, seq1, seq2);
    //outMSA->ToFASTAFile(outFile, WWS_Never);
    
    fprintf(stderr, "Output written to %s.\n", out);
}


bool contains (GNode2 *node, const char* seq2){
    MSA *msa  = &(node->m_MSA);
    unsigned numSeq = msa->m_uSeqCount; 
    char** names = msa->m_szNames;
    for(int i=0;i<numSeq;++i){
        string name = names[i];
        //if ( name.find(seq2, 0) == 0 || (name.find(seq2) == 1 && name[0] == '>' ))
        if (matchSeqID(name, seq2))
            return true;
    }
        
    return false;
}

bool matchSeqID( string name1, string name2) {
    const unsigned l1 = name1.length();
    const unsigned l2 = name2.length();
    //fprintf(stderr, "Comparing %s to %s\n", name1.c_str(), name2.c_str());
    if (l1 > l2) 
        // must match exactly or al least to a word boundary.
        if ( (name1 == '>' + name2) || (name1.substr(0,l2+1) == name2 + ' ') || (name1.substr(0,l2+2) == '>' + name2 + ' '))
            return true;
        else 
            return false;
    else if (l2 > l1)
        // must match a word boundary.
        if ( (name2 == '>' + name1) || (name2.substr(0,l1+1) == name1 + ' ') || (name2.substr(0,l1+2) == '>' + name1 + ' '))
            return true;
        else
            return false;
    else if (name1 == name2)
        return true;
        
    return false;
                                                                                         
}

void PairToFASTA(MSA *msa, TextFile &File,const  char* seq1,const char* seq2) 
    {
    const unsigned uColCount = msa->GetColCount();
    assert(uColCount > 0);
    const unsigned uLettersPerLine = 69;
    const unsigned uLinesPerSeq = (uColCount - 1)/uLettersPerLine + 1;
    const unsigned uSeqCount =  msa->GetSeqCount();
    bool bWriteWeights = msa->m_bWeightsFoundInInputFile;
    

    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        string name = msa->GetSeqName(uSeqIndex);
        bool bfound1 = false, bfound2 = false;
        if (matchSeqID(name, seq1) && !bfound1 ){
            bfound1 = true;
            File.PutString(">");
            File.PutString(msa->GetSeqName(uSeqIndex));
            if (bWriteWeights)
                {
                WEIGHT w = msa->GetSeqWCount(uSeqIndex);
                if (w != BTInsane)
                    File.PutFormat("|weight=%g", w);
                }
            File.PutString("\n");

            unsigned n = 0;
            for (unsigned uLine = 0; uLine < uLinesPerSeq; ++uLine)
                {
                unsigned uLetters = uColCount - uLine*uLettersPerLine;
                if (uLetters > uLettersPerLine)
                    uLetters = uLettersPerLine;
                for (unsigned i = 0; i < uLetters; ++i)
                {
                    char c = msa->GetChar(uSeqIndex, n);
                    File.PutChar(c);
                    ++n;
                }
            File.PutChar('\n');
            }
        }
        else if( matchSeqID(name, seq2) && !bfound2 ) {
            bfound2 = true;
            File.PutString(">");
            File.PutString(msa->GetSeqName(uSeqIndex));
            if (bWriteWeights)
                {
                WEIGHT w = msa->GetSeqWCount(uSeqIndex);
                if (w != BTInsane)
                    File.PutFormat("|weight=%g", w);
                }
            File.PutString("\n");

            unsigned n = 0;
            for (unsigned uLine = 0; uLine < uLinesPerSeq; ++uLine)
                {
                unsigned uLetters = uColCount - uLine*uLettersPerLine;
                if (uLetters > uLettersPerLine)
                    uLetters = uLettersPerLine;
                for (unsigned i = 0; i < uLetters; ++i)
                    {
                    char c = msa->GetChar(uSeqIndex, n);
                    File.PutChar(c);
                    ++n;
                    }
                File.PutChar('\n');
                }
                
            }
        }
    }



