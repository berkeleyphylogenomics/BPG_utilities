// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

class SJPM
    {
public:
    virtual void OnBuildLeaf(unsigned uIter, unsigned uIterCount) = 0;
    virtual void OnIteration1(unsigned uIter, unsigned uIterCount) = 0;
    virtual void OnIteration2(unsigned uIter, unsigned uIterCount) = 0;
    };

class BuildMonitor : public SJPM
    {
public:
    virtual void OnBuildLeaf(unsigned uIter, unsigned uIterCount)
        {
        if (1 == uIter)
            {
            printf("\n");
            double dGHz = GetCPUGHz();
            double dEstSecs = 0;
            const unsigned N = uIterCount;
            extern unsigned g_uAvgSeqLength;
            const unsigned L = g_uAvgSeqLength;
            if (g_bSamePath)
                dEstSecs = EstSecs_nobmv1(N, L, dGHz);
            else if (!g_bUseBreakMatrices)
                dEstSecs = EstSecs_nobm(N, L, dGHz);
            else
                dEstSecs = EstSecs_v2(N, L, dGHz);
            m_lEstSecs = (long) dEstSecs;
            m_lTimeStartIter2 = -1;
            }
        m_lSecsRemaining = m_lEstSecs - (time(0) - g_tStart);
        printf("Leaf    %5u/%5u %7.1f MB   %s / %s\r",
          uIter,
          uIterCount,
          GetPeakMemUseMB(),
          ElapsedTimeAsString(),
          DoneTimeAsString());
        }
    virtual void OnIteration1(unsigned uIter, unsigned uIterCount)
        {
        m_lSecsRemaining = m_lEstSecs - (time(0) - g_tStart);
        printf("All-all %5u/%5u %7.1f MB   %s / %s\r",
          uIter,
          uIterCount,
          GetPeakMemUseMB(),
          ElapsedTimeAsString(),
          DoneTimeAsString());
        }
    virtual void OnIteration2(unsigned uIter, unsigned uIterCount)
        {
        if (1 == uIter)
            {
            m_lTimeStartIter2 = (long) time(0);
            m_lSecsRemaining = m_lEstSecs - (time(0) - g_tStart);
            }
        else
            {
            long lNow = (long) time(0);
            long lSecsIter2 = lNow - m_lTimeStartIter2;
            double dAvgSecsPerIter = (double) lSecsIter2 / (double) uIter;
            double dSecsRemaining = (uIterCount - uIter)*dAvgSecsPerIter;
            m_lSecsRemaining = (long) dSecsRemaining;
            }
        printf("Cluster %5u/%5u %7.1f MB   %s / %s\r",
          uIter,
          uIterCount,
          GetPeakMemUseMB(),
          ElapsedTimeAsString(),
          DoneTimeAsString());
        if (uIter == uIterCount)
            printf("\n");
        }
    const char *DoneTimeAsString()
        {
        static char szStr[64];
        return SecsToHHMMSS(m_lSecsRemaining, szStr);
        }

    long m_lEstSecs;
    long m_lSecsRemaining;
    long m_lTimeStartIter2;
    };
