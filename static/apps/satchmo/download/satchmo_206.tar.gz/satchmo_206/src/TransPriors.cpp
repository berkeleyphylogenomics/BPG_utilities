// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "DirMix.h"
#include "TextFile.h"
#include "TransPrior.h"

static DirMix *DefaultMatchTransPrior();
static DirMix *DefaultInsertTransPrior();
static DirMix *DefaultDeleteTransPrior();

DirMix *g_ptrdirmixMatchTransPrior = DefaultMatchTransPrior();
DirMix *g_ptrdirmixDeleteTransPrior = DefaultDeleteTransPrior();
DirMix *g_ptrdirmixInsertTransPrior = DefaultInsertTransPrior();

void ListTransPriors()
    {
    DirComp *ptrComp = &g_ptrdirmixMatchTransPrior->m_Comps[0];
    double dMM = ptrComp->m_dAlphas[DP_MtoM];
    double dMD = ptrComp->m_dAlphas[DP_MtoD];
    double dMI = ptrComp->m_dAlphas[DP_MtoI];

    ptrComp = &g_ptrdirmixDeleteTransPrior->m_Comps[0];
    double dDM = ptrComp->m_dAlphas[DP_DtoM];
    double dDD = ptrComp->m_dAlphas[DP_DtoD];
    double dDI = ptrComp->m_dAlphas[DP_DtoI];

    ptrComp = &g_ptrdirmixInsertTransPrior->m_Comps[0];
    double dIM = ptrComp->m_dAlphas[DP_ItoM];
    double dID = ptrComp->m_dAlphas[DP_ItoD];
    double dII = ptrComp->m_dAlphas[DP_ItoI];

    List("Alphas:\n");
    List("MM=%g  MD=%g  MI=%g\n", dMM, dMD, dMI);
    List("DM=%g  DD=%g  DI=%g\n", dDM, dDD, dDI);
    List("IM=%g  ID=%g  II=%g\n", dIM, dID, dII);

    WCOUNT wCounts[3];
    wCounts[0] = 0.0;
    wCounts[1] = 0.0;
    wCounts[2] = 0.0;

    PROB probMatch[3];
    PROB probDelete[3];
    PROB probInsert[3];

    g_ptrdirmixMatchTransPrior->CountsToProbs(wCounts, probMatch);
    g_ptrdirmixDeleteTransPrior->CountsToProbs(wCounts, probDelete);
    g_ptrdirmixInsertTransPrior->CountsToProbs(wCounts, probInsert);

    List("Background probs:\n");
    List("MM=%g  MD=%g  MI=%g\n",
      probMatch[DP_MtoM], probMatch[DP_MtoD], probMatch[DP_MtoI]);
    List("DM=%g  DD=%g  DI=%g\n",
      probDelete[DP_DtoM], probDelete[DP_DtoD], probDelete[DP_DtoI]);
    List("IM=%g  ID=%g  II=%g\n",
      probInsert[DP_ItoM], probInsert[DP_ItoD], probInsert[DP_ItoI]);
    }

static DirMix *MakeTransPrior(double xM, double xD, double xI)
    {
    DirMix *ptrDM = new DirMix;
    ptrDM->m_uAlphaCount = 3;
    ptrDM->m_uCompCount = 1;
    DirComp *ptrComp = new DirComp;
    ptrDM->m_Comps = ptrComp;
    ptrComp->m_dAlphas[0] = xM;
    ptrComp->m_dAlphas[1] = xD;
    ptrComp->m_dAlphas[2] = xI;
    ptrComp->m_dCompProb = 1;
    ptrComp->m_dSumAlphas = ptrComp->m_dAlphas[0] +
      ptrComp->m_dAlphas[1] + ptrComp->m_dAlphas[2];

 // Always 1 component, log2(1) = 0
    ptrComp->m_dLogCompProb = 0;

    ptrDM->Validate();
    return ptrDM;
    }

// Default values are taken from sam1.3.regularizer.
static DirMix *DefaultMatchTransPrior()
    {
    return MakeTransPrior(
        15.521340,        // MM
        0.254944,        // MD
        0.265967);        // MI
    }

static DirMix *DefaultDeleteTransPrior()
    {
    return MakeTransPrior(
        1.819972,        // DM
        1.886984,        // DD
        0.225758);        // DI
    }

static DirMix *DefaultInsertTransPrior()
    {
    return MakeTransPrior(
        3.764209,        // IM
        0.376488,        // ID
        4.006562);        // II
    }

void SetTransPriors(double dAlphas[9])
    {
    delete g_ptrdirmixMatchTransPrior;
    delete g_ptrdirmixDeleteTransPrior;
    delete g_ptrdirmixInsertTransPrior;

    g_ptrdirmixMatchTransPrior = MakeTransPrior(dAlphas[0], dAlphas[1], dAlphas[2]);
    g_ptrdirmixDeleteTransPrior = MakeTransPrior(dAlphas[3], dAlphas[4], dAlphas[5]);
    g_ptrdirmixInsertTransPrior = MakeTransPrior(dAlphas[6], dAlphas[7], dAlphas[8]);

    g_ptrdirmixMatchTransPrior->Validate();
    g_ptrdirmixDeleteTransPrior->Validate();
    g_ptrdirmixInsertTransPrior->Validate();
    }

void Set_transprior(const char *in)
    {
    TextFile File(in);
    double dAlphas[9];
    SAMRegFromFile(File, dAlphas);
    SetTransPriors(dAlphas);
    ListTransPriors();
    }
