// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Profile.h"
#include "MSA.h"
#include "Seq.h"
#include "PWPath.h"

// NOTE -- this code is very similar to AlignHMMs, should be consolidated.

#define    VERBOSE    0

static void AppendDelete(const Seq &seqA, unsigned &uColIndexA, MSA &msaCombined,
  unsigned &uColIndexCombined)
    {
#if    VERBOSE
    List("AppendDelete ColIxA=%u ColIxCmb=%u\n",
      uColIndexA, uColIndexCombined);
#endif
    char c = seqA.GetChar(uColIndexA);
    assert(IsAlignedChar(c));
    msaCombined.SetChar(0, uColIndexCombined, c);
    msaCombined.SetChar(1, uColIndexCombined, '-');

    ++uColIndexCombined;
    ++uColIndexA;
    }

static void AppendInsert(const Seq &seqB, unsigned &uColIndexB, MSA &msaCombined,
  unsigned &uColIndexCombined)
    {
#if    VERBOSE
    List("AppendInsert ColIxB=%u ColIxCmb=%u\n",
      uColIndexB, uColIndexCombined);
#endif
    msaCombined.SetChar(0, uColIndexCombined, '-');
    char c = seqB.GetChar(uColIndexB);
    assert(IsAlignedChar(c));
    msaCombined.SetChar(1, uColIndexCombined, c);

    ++uColIndexCombined;
    ++uColIndexB;
    }

static void AppendTplInserts(const Seq &seqA, unsigned &uColIndexA, unsigned uColCountA,
  const Seq &seqB, unsigned &uColIndexB, unsigned uColCountB, MSA &msaCombined,
  unsigned &uColIndexCombined)
    {
#if    VERBOSE
    List("AppendTplInserts ColIxA=%u ColIxB=%u ColIxCmb=%u\n",
      uColIndexA, uColIndexB, uColIndexCombined);
#endif
    const unsigned uLengthA = seqA.Length();
    const unsigned uLengthB = seqB.Length();

    unsigned uNewColCount = uColCountA;
    if (uColCountB > uNewColCount)
        uNewColCount = uColCountB;

    for (unsigned n = 0; n < uColCountA; ++n)
        {
        char c = seqA.GetChar(uColIndexA + n);
        c = UnalignChar(c);
        msaCombined.SetChar(0, uColIndexCombined + n, c);
        }
    for (unsigned n = uColCountA; n < uNewColCount; ++n)
        msaCombined.SetChar(0, uColIndexCombined + n, '.');

    for (unsigned n = 0; n < uColCountB; ++n)
        {
        char c = seqB.GetChar(uColIndexB + n);
        c = UnalignChar(c);
        msaCombined.SetChar(1, uColIndexCombined + n, c);
        }
    for (unsigned n = uColCountB; n < uNewColCount; ++n)
        msaCombined.SetChar(1, uColIndexCombined + n, '.');

    uColIndexCombined += uNewColCount;
    uColIndexA += uColCountA;
    uColIndexB += uColCountB;
    }

static void AppendMatch(const Seq &seqA, unsigned &uColIndexA, const Seq &seqB,
  unsigned &uColIndexB, MSA &msaCombined, unsigned &uColIndexCombined)
    {
#if    VERBOSE
    List("AppendMatch ColIxA=%u ColIxB=%u ColIxCmb=%u\n",
      uColIndexA, uColIndexB, uColIndexCombined);
#endif

    char c = seqA.GetChar(uColIndexA);
    assert(IsAlignedChar(c));
    msaCombined.SetChar(0, uColIndexCombined, c);
    c = seqB.GetChar(uColIndexB);
    assert(IsAlignedChar(c));
    msaCombined.SetChar(1, uColIndexCombined, c);

    ++uColIndexA;
    ++uColIndexB;
    ++uColIndexCombined;
    }

void AlignProfiles(const Profile &profA, const Profile &profB, const PWPath &Path,
  MSA &msaCombined)
    {
    msaCombined.Clear();

    Seq seqA;
    Seq seqB;
    profA.GetSeed(seqA);
    profB.GetSeed(seqB);

#if    VERBOSE
    List("AlignHMMs\n");
    List("Template A:\n");
    seqA.ListMe();
    List("Template B:\n");
    seqB.ListMe();
#endif

    const unsigned uColCountA = seqA.Length();
    const unsigned uColCountB = seqB.Length();

    msaCombined.SetAlphabet(ALPHABET_Amino);
    msaCombined.SetSeqCount(2);

// Copy sequence names into combined MSA
    msaCombined.SetSeqName(0, seqA.GetName());
    msaCombined.SetSeqName(1, seqB.GetName());

    unsigned uColIndexA = 0;
    unsigned uColIndexB = 0;
    unsigned uColIndexCombined = 0;
    const unsigned uEdgeCount = Path.GetEdgeCount();
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const PWEdge &Edge = Path.GetEdge(uEdgeIndex);
#if    VERBOSE
        List("\nEdge %u %c%u.%u\n",
          uEdgeIndex,
          Edge.cType,
          Edge.uPrefixLengthA,
          Edge.uPrefixLengthB);
#endif
        const char cType = Edge.cType;

/***
To create a combined alignment that includes complete sequences, we have
to include columns in the template alignments that were considered to be
inserts when the HMMs were built ("template inserts").

The following diagram illustrates the situation for one of the templates (A).

    uColIndexA is the index of the next column to be output to the
    combined alignment.

    uNodeIndexA = uPrefixLengthA - 1 is the node index of the HMM node to
    be output in the next column to be added to the combined alignment.

    uTplColIndexA is the column index in template A that was used
    to construct the match state in node uNodeIndexA.

            last column output to combined alignment (uColIndexA - 1)
            |    uColIndexA
            |    |        uTplColIndexA
            |    |        |
            v    v        v
Col            5    6    7    8
Template    M    i    i    M

Here, there are two columns of inserts. The number of template insert
columns is:
    uColCountA = uTplColIndexA - uColIndexA
***/
        const unsigned uPrefixLengthA = Edge.uPrefixLengthA;
        unsigned uColCountA = 0;
        if (uPrefixLengthA > 0)
            {
            const unsigned uNodeIndexA = uPrefixLengthA - 1;
            const unsigned uTplColIndexA =
              profA.AlignedPosIndexToSeedColIndex(uNodeIndexA);
#if VERBOSE
            List("NodeIxToTplIxA(%u) = %u\n", uPrefixLengthA-1, uTplColIndexA);
#endif
            if (uTplColIndexA > uColIndexA)
                uColCountA = uTplColIndexA - uColIndexA;
            }

        const unsigned uPrefixLengthB = Edge.uPrefixLengthB;
        unsigned uColCountB = 0;
        if (uPrefixLengthB > 0)
            {
            const unsigned uNodeIndexB = uPrefixLengthB - 1;
            const unsigned uTplColIndexB =
              profB.AlignedPosIndexToSeedColIndex(uNodeIndexB);
#if VERBOSE
            List("NodeIxToTplIxB(%u) = %u\n", uPrefixLengthB-1, uTplColIndexB);
#endif
            if (uTplColIndexB > uColIndexB)
                uColCountB = uTplColIndexB - uColIndexB;
            }

        AppendTplInserts(seqA, uColIndexA, uColCountA, seqB, uColIndexB, uColCountB,
          msaCombined, uColIndexCombined);

        switch (cType)
            {
        case 'M':
            {
            assert(uPrefixLengthA > 0);
            assert(uPrefixLengthB > 0);
            const unsigned uColA = profA.AlignedPosIndexToSeedColIndex(uPrefixLengthA - 1);
            const unsigned uColB = profB.AlignedPosIndexToSeedColIndex(uPrefixLengthB - 1);
            assert(uColIndexA == uColA);
            assert(uColIndexB == uColB);
            AppendMatch(seqA, uColIndexA, seqB, uColIndexB, msaCombined,
              uColIndexCombined);
            break;
            }
        case 'D':
            {
            assert(uPrefixLengthA > 0);
            const unsigned uColA = profA.AlignedPosIndexToSeedColIndex(uPrefixLengthA - 1);
            assert(uColIndexA == uColA);
            AppendDelete(seqA, uColIndexA, msaCombined, uColIndexCombined);
            break;
            }
        case 'I':
            {
            assert(uPrefixLengthB > 0);
            const unsigned uColB = profB.AlignedPosIndexToSeedColIndex(uPrefixLengthB - 1);
            assert(uColIndexB == uColB);
            AppendInsert(seqB, uColIndexB, msaCombined, uColIndexCombined);
            break;
            }
        default:
            assert(false);
            }
        }
    unsigned uInsertColCountA = seqA.Length() - uColIndexA;
    unsigned uInsertColCountB = seqB.Length() - uColIndexB;
    AppendTplInserts(seqA, uColIndexA, uInsertColCountA, seqB, uColIndexB,
      uInsertColCountB, msaCombined, uColIndexCombined);

// Sanity check
    {
    Seq seqA2;
    msaCombined.GetSeq(0, seqA2);
    if (!seqA.EqIgnoreCaseAndGaps(seqA2))
        {
        msaCombined.ListMe();
        List("SeqA:        ");
        seqA.ListMe();
        List("SeqA2: "); 
        seqA2.ListMe();
        Quit("AlignProfiles sanity check");
        }
    }

    {
    Seq seqB2;
    msaCombined.GetSeq(1, seqB2);
    if (!seqB.EqIgnoreCaseAndGaps(seqB2))
        {
        msaCombined.ListMe();
        List("SeqB:        ");
        seqB.ListMe();
        List("SeqB2: "); 
        seqB2.ListMe();
        Quit("AlignProfiles sanity check");
        }
    }
    }
