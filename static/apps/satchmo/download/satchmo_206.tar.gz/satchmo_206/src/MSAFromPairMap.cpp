// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "Seq.h"

// Create an MSA from two sequences and a pair map.
// iMapB[] is redundant, used as a consistency check only.
void MSA::FromPairMap(const Seq &seqA, const Seq &seqB, int iMapA[], int iMapB[])
    {
    const int iLengthA = (int) seqA.Length();
    const int iLengthB = (int) seqB.Length();

    Clear();
    SetSize(2, 1);

    const char *strNameA = seqA.GetName();
    const char *strNameB = seqB.GetName();

    SetSeqName(0, strNameA);
    SetSeqName(1, strNameB);

    int iPosA = 0;
    int iPosB = 0;
    unsigned uColIndex = 0;
    while (iPosA < iLengthA)
        {
        int iNewPosB = iMapA[iPosA];
        if (-1 == iNewPosB)
            {
            char c = seqA[iPosA];
            SetChar(0, uColIndex, toupper(c));
            SetChar(1, uColIndex, '-');
            ++iPosA;
            ++uColIndex;
            }
        else
            {
            if (iNewPosB >= iLengthB)
                Quit("Invalid pair map");
            if (iMapB[iNewPosB] != iPosA)
                Quit("Invalid pair map");

            while (iPosB < iNewPosB)
                {
                char c = seqB[iPosB];
                SetChar(0, uColIndex, '-');
                SetChar(1, uColIndex, toupper(c));
                ++iPosB;
                ++uColIndex;
                }
            assert(iPosB == iNewPosB);
            char cA = seqA[iPosA];
            char cB = seqB[iPosB];
            SetChar(0, uColIndex, cA);
            SetChar(1, uColIndex, cB);
            ++iPosA;
            ++iPosB;
            ++uColIndex;
            }
        }
    if (iPosA != iLengthA)
        Quit("Internal error (length A)");

    while (iPosB < iLengthB)
        {
        char c = seqB[iPosB];
        SetChar(0, uColIndex, '-');
        SetChar(1, uColIndex, toupper(c));
        ++iPosB;
        ++uColIndex;
        }
    }
