// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "SeqVect.h"
#include "HMM.h"
#include "HMMPath.h"

static void ScoreSeq(const Seq &s, HMM &Model)
    {
    HMMPath Path;
    SCORE scoreViterbi = Model.ViterbiSeq(s, GLOBAL_MODEL, LOCAL_SEQ, Path);
    Seq ReverseSeq;
    ReverseSeq.CopyReversed(s);
    SCORE scoreViterbiReversed = Model.ViterbiSeq(ReverseSeq, GLOBAL_MODEL,
      LOCAL_SEQ, Path);
    printf("Seq %s;Vit=%s;VitRev=%s;Rev=%s\n",
      s.GetName(),
      ScoreToStrL(scoreViterbi),
      ScoreToStrL(scoreViterbiReversed),
      ScoreToStrL(scoreViterbi - scoreViterbiReversed));
    List("Seq %s;Vit=%s;VitRev=%s;Rev=%s\n",
      s.GetName(),
      ScoreToStrL(scoreViterbi),
      ScoreToStrL(scoreViterbiReversed),
      ScoreToStrL(scoreViterbi - scoreViterbiReversed));
    }

void DoScoreSeqs(const char *strDBFileName, const char *strModelFileName)
    {
    TextFile ModelFile(strModelFileName);
    HMM Model;
    Model.FromFile(ModelFile);

    TextFile DBFile(strDBFileName);
    SeqVect db;
    db.FromFASTAFile(DBFile);

    for (unsigned n = 0; n < db.Length(); ++n)
        {
        Seq &s = *db[n];
        s.StripGaps();
        s.ToUpper();
        ScoreSeq(s, Model);
        }
    }
