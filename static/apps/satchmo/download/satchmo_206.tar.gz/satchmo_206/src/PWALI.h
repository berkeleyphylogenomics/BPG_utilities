// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    PWALI_h
#define    PWALI_h

#include "PWBase.h"

class PWALI : public PWBase
    {
public:
    PWALI()
        {
        }

    virtual ~PWALI()
        {
        }

    virtual PWCLASS GetClass() const { return PWCLASS_AL; }


    virtual SCORE ScoreProfPos(const ProfPos &PPA, const ProfPos &PPB) const
        {
        return ALIScore(PPA.m_fcCounts, PPB.m_fcCounts);
        }

    static SCORE ALIScore(const FCOUNT fcCountsA[MAX_ALPHA], 
      const FCOUNT fcCountsB[MAX_ALPHA]);
    };

#endif    // PWALI_h
