// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Prof.h"
#include "Profile.h"
#include "DataBuffer.h"
#include "DirMix.h"
#include "MSA.h"
#include "Seq.h"
#include "Ckp.h"
#include <math.h>

Profile::Profile()
    {
    m_uPosCount = 0;
    m_Pos = 0;
    m_pstrSeed = 0;
    m_pstrName = 0;
    m_uSeedLength = 0;
    m_uSeedColIndexToPosIndex = 0;
    m_uPosIndexToSeedColIndex = 0;
    m_uAlignedPosCount = 0;
    m_uAlignedIndexToUnalignedIndex = 0;
    m_weightTotalSeq = 0.5; // modified by Xia
    }

Profile::~Profile()
    {
    Clear();
    }

void Profile::Clear()
    {
    delete[] m_Pos;
    delete[] m_pstrSeed;
    delete[] m_pstrName;
    delete[] m_uSeedColIndexToPosIndex;
    delete[] m_uPosIndexToSeedColIndex;
    delete[] m_uAlignedIndexToUnalignedIndex;

    m_uPosCount = 0;
    m_Pos = 0;
    m_pstrSeed = 0;
    m_pstrName = 0;
    m_uSeedColIndexToPosIndex = 0;
    m_uPosIndexToSeedColIndex = 0;
    m_uAlignedPosCount = 0;
    m_uAlignedIndexToUnalignedIndex = 0;
    m_uSeedLength = 0;
    }

static const char *LocalFormat(double d)
    {
    if (d < 0.00001 && d > -0.00001)
        return "     0";
    static char szStr[16];
    sprintf(szStr, "%6.4f", d);
    return szStr;
    }

void Profile::ListCounts() const
    {
    const WCOUNT wcountNIC = m_weightTotalSeq;

    for (unsigned uPosIndex = 0; uPosIndex < m_uPosCount; ++uPosIndex)
        {
        if (!GetPos(uPosIndex).m_bAligned)
            continue;
        List("<AA> ");
        const ProfPos &PP = GetPos(uPosIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            {
            WCOUNT wc = PP.m_fcCounts[uLetter]*wcountNIC;
            List(" %s", LocalFormat(wc));
            }
        List("\n");
        }
    }

void Profile::ListMe() const
    {
    List("Length %u, NIC=%g\n", m_uPosCount, m_weightTotalSeq);
    List(">%s\n", m_pstrName ? m_pstrName : "<null>");
    const unsigned uLength = (unsigned) strlen(m_pstrSeed);
    const unsigned uBlockCount = (uLength + 79)/80;
    for (unsigned uBlockIndex = 0; uBlockIndex < uBlockCount; ++uBlockIndex)
        {
        unsigned uPosCount = uLength - uBlockIndex*80;
        if (uPosCount > 80)
            uPosCount = 80;
        for (unsigned n = 0; n < uPosCount; ++n)
            List("%c", m_pstrSeed[uBlockIndex*80 + n]);
        List("\n");
        }

    List("\nCounts A");
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        List("      %c", LetterToCharAmino(uLetter));
    List("\n");

    for (unsigned uPosIndex = 0; uPosIndex < m_uPosCount; ++uPosIndex)
        {
        List("  %4u %c", uPosIndex, GetPos(uPosIndex).m_bAligned ? 'Y' : 'N');
        const ProfPos &PP = GetPos(uPosIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            List(" %s", LocalFormat(PP.m_fcCounts[uLetter]));
        List("\n");
        }

    List("\n Probs");
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        List("      %c", LetterToCharAmino(uLetter));
    List("\n");
    for (unsigned uPosIndex = 0; uPosIndex < m_uPosCount; ++uPosIndex)
        {
        List("  %4u", uPosIndex);
        const ProfPos &PP = GetPos(uPosIndex);
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            List(" %6.4f", PP.m_Probs[uLetter]);
        List("\n");
        }

    List("\nOccVec        F        E       FF       FE       EF       EE          T\n");
    for (unsigned uPosIndex = 0; uPosIndex < m_uPosCount; ++uPosIndex)
        {
        List("  %4u", uPosIndex);
        const ProfPos &PP = GetPos(uPosIndex);
        List("   %s", LocalFormat(PP.m_fcF));
        List("   %s", LocalFormat(PP.m_fcE));
        List("   %s", LocalFormat(PP.m_fcFF));
        List("   %s", LocalFormat(PP.m_fcFE));
        List("   %s", LocalFormat(PP.m_fcEF));
        List("   %s", LocalFormat(PP.m_fcEE));
        if (0.0 == PP.m_fcT)
            List("          0", PP.m_fcT);
        else
            List(" %10.3f", PP.m_fcT);
        List("\n");
        }
    }

void Profile::SetPosCount(unsigned uPosCount)
    {
    Clear();
    m_uPosCount = uPosCount;
    m_Pos = new ProfPos[uPosCount];
    }

const ProfPos &Profile::GetPos(unsigned uPosIndex) const
    {
    assert(uPosIndex < m_uPosCount);
    return m_Pos[uPosIndex];
    }

void Profile::SetPos(const ProfPos &PP, unsigned uPosIndex)
    {
    assert(uPosIndex < m_uPosCount);
    m_Pos[uPosIndex] = PP;
    }

unsigned Profile::GetBufferSize() const
    {
    return sizeof(ProfHdr) + m_uPosCount*sizeof(ProfPos) +
      (unsigned) strlen(m_pstrSeed) + 1;
    }

void Profile::ToBuffer(DataBuffer &Data) const
    {
    unsigned uBytes = GetBufferSize();
    Data.SetSize(uBytes);
    ProfHdr Hdr;
    Hdr.m_uMagic = PROF_MAGIC;
    Hdr.m_uPosCount = m_uPosCount;
    Hdr.m_uSeedLength = (unsigned) strlen(m_pstrSeed);
    Hdr.m_weightTotalSeq = m_weightTotalSeq;
    Data.Put(0, &Hdr, sizeof(Hdr));
    unsigned uPos = sizeof(Hdr);
    Data.Put(uPos, m_pstrSeed, Hdr.m_uSeedLength);
    uPos += Hdr.m_uSeedLength;
    Data.Put(uPos, m_Pos, m_uPosCount*sizeof(ProfPos));
    }

void Profile::FromBuffer(const DataBuffer &Data, const char *pstrSeedId)
    {
    ProfHdr Hdr;
    Data.Get(0, &Hdr, sizeof(Hdr));
    if (PROF_MAGIC != Hdr.m_uMagic)
        Quit("Invalid profile header (magic)");
    SetSize(Hdr.m_uPosCount, Hdr.m_uSeedLength);
    unsigned uPos = sizeof(Hdr);
    Data.Get(uPos, m_pstrSeed, Hdr.m_uSeedLength);
    m_pstrSeed[Hdr.m_uSeedLength] = 0;
    uPos += Hdr.m_uSeedLength;
    Data.Get(uPos, m_Pos, m_uPosCount*sizeof(ProfPos));
    SetName(pstrSeedId);
    m_weightTotalSeq = Hdr.m_weightTotalSeq;
    }

void Profile::SetName(const char *pstrName)
    {
    delete[] m_pstrName;
    unsigned n = (unsigned) strlen(pstrName) + 1;
    m_pstrName = new char[n];
    strcpy(m_pstrName, pstrName);
    }

void Profile::SetSize(unsigned uPosCount, unsigned uSeedLength)
    {
    Clear();
    m_uPosCount = uPosCount;
    m_Pos = new ProfPos[uPosCount];
    m_pstrSeed = new char[uSeedLength+1];
    m_pstrSeed[0] = 0;
    }

void Profile::FromMSA(const MSA &a, const char *pstrSeedId)
    {
    unsigned uSeedSeqIndex;
    bool bFound = a.GetSeqIndex(pstrSeedId, &uSeedSeqIndex);
    if (!bFound)
        Quit("Seed sequence '%s' not found in MSA", pstrSeedId);
    const char *pstrSeed = a.GetSeqBuffer(uSeedSeqIndex);
    unsigned uSeedLength = (unsigned) strlen(pstrSeed) + 1;
    unsigned uPillarCount = a.GetPillarCount();
    SetSize(uPillarCount, uSeedLength);
    strcpy(m_pstrSeed, pstrSeed);
    for (unsigned uPillarIndex = 0; uPillarIndex < uPillarCount; ++uPillarIndex)
        {
        const PILLAR &Pillar = a.GetPillar(uPillarIndex);
        ProfPos &PP = m_Pos[uPillarIndex];
        PP.m_bAligned = Pillar.m_bAligned;
        PP.m_fcF = Pillar.m_fcF;
        PP.m_fcE = Pillar.m_fcE;
        PP.m_fcFF = Pillar.m_fcFF;
        PP.m_fcFE = Pillar.m_fcFE;
        PP.m_fcEF = Pillar.m_fcEF;
        PP.m_fcEE = Pillar.m_fcEE;
        PP.m_fcT = Pillar.m_fcT;
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            {
            PP.m_fcCounts[uLetter] = Pillar.m_fcResCounts[uLetter];
            PP.m_Probs[uLetter] = Pillar.m_fcResCounts[uLetter];
            }

        NormalizeUnlessZero(PP.m_Probs, MAX_ALPHA);
        AssertNormalizedOrZero(PP.m_Probs);
        }
     AddPseudoCounts();
    SetName(pstrSeedId);
    }

double Profile::BitsSaved() const
    {
    PROB probBack[MAX_ALPHA];
    GetPriorBackground(probBack);

    const unsigned uPosCount = GetPosCount();
    double dTotal = 0.0;
    for (unsigned uPosIndex = 0; uPosIndex < uPosCount; ++uPosIndex)
        {
        const ProfPos &PP = GetPos(uPosIndex);
        double dRE = RelativeEntropy(PP.m_Probs, probBack);
        dTotal += dRE;
        }
    double dEntropyPerPos = dTotal/uPosCount;
    return dEntropyPerPos;
    }

void Profile::AddPseudoCountsBitsSaved(double dBitsToSave, unsigned uMaxIter,
  double dMaxErrorPct)
    {
      m_weightTotalSeq = 30.0;
    double dBitsSaved;
    for (unsigned uIter = 0; uIter < uMaxIter; ++uIter)
        {
        AddPseudoCountsBitsSavedIter(m_weightTotalSeq);
        dBitsSaved = BitsSaved();
        double dRatio = dBitsToSave/dBitsSaved;
        double dFractionalError = fabs(1.0 - dRatio);
        double dErrorPct = dFractionalError*100;
	//fprintf(stderr, "Profile Iter %u Bits saved=%g Error=%g%% NIC=%g\n",
	//uIter,
	// dBitsSaved,
	//dErrorPct,
	//m_weightTotalSeq);
        if (dErrorPct <= dMaxErrorPct)
            return;
        m_weightTotalSeq *= (WEIGHT) (dBitsToSave/dBitsSaved);
        }
    fprintf(stderr, "**Warning** bits saved failed to converge, target=%g actual=%g\n",
      dBitsToSave, dBitsSaved);
    List("**Warning** bits saved failed to converge, target=%g actual=%g\n",
      dBitsToSave, dBitsSaved);
    }

void Profile::AddPseudoCounts()
    {
    AddPseudoCountsBitsSaved(0.5, 10, 1);
    //AddPseudoCountsBitsSaved(0.5, 1, 1);
    
    }

void Profile::AddPseudoCountsBitsSavedIter(double dNIC)
    {
    const unsigned uPosCount = GetPosCount();
    for (unsigned uPosIndex = 0; uPosIndex < uPosCount; ++uPosIndex)
        {
        ProfPos &PP = m_Pos[uPosIndex];
        CountsToProbs(PP.m_fcCounts, dNIC, PP.m_Probs);
        }
    }

static void ScaleCounts(const FCOUNT fcCounts[], WCOUNT wcCounts[], double dNIC)
    {
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        wcCounts[n] = (WCOUNT) (fcCounts[n]*dNIC);
    }

void Profile::CountsToProbs(const FCOUNT fcCounts[], double dNIC, PROB Probs[])
    {
    WCOUNT wcCounts[MAX_ALPHA];

    ScaleCounts(fcCounts, wcCounts, dNIC);
    g_ptrdirmixMatchEmitPrior->CountsToProbs(wcCounts, Probs);
    }

void Profile::GetSeed(Seq &seqSeed) const
    {
    seqSeed.Clear();
    seqSeed.SetName(GetName());
    const unsigned uLength = (unsigned) strlen(m_pstrSeed);
    for (unsigned n = 0; n < uLength; ++n)
        seqSeed.push_back(m_pstrSeed[n]);
    }

unsigned Profile::GetSeedLength() const
    {
    if (0 == m_uSeedLength)
        m_uSeedLength = (unsigned) strlen(m_pstrSeed);
    return m_uSeedLength;
    }

unsigned Profile::PosIndexToSeedColIndex(unsigned uPosIndex) const
    {
    assert(uPosIndex < GetPosCount());

    if (0 == m_uPosIndexToSeedColIndex)
        BuildSeedMaps();
    return m_uPosIndexToSeedColIndex[uPosIndex];
    }

unsigned Profile::AlignedPosIndexToSeedColIndex(unsigned uAlignedPosIndex) const
    {
    const unsigned uPosIndex = GetUnalignedPosIndex(uAlignedPosIndex);
    return PosIndexToSeedColIndex(uPosIndex);
    }

void Profile::BuildSeedMaps() const
    {
    const unsigned uSeedLength = GetSeedLength();

    delete[] m_uSeedColIndexToPosIndex;
    delete[] m_uPosIndexToSeedColIndex;
    m_uSeedColIndexToPosIndex = new unsigned[uSeedLength];
    m_uPosIndexToSeedColIndex = new unsigned[m_uPosCount];

    m_uSeedColIndexToPosIndex[0] = 0;
    m_uPosIndexToSeedColIndex[0] = 0;
    unsigned uPosIndex = 0;
    for (unsigned n = 1; n < uSeedLength; ++n)
        {
        const char cPrev = m_pstrSeed[n-1];
        const char c = m_pstrSeed[n];
        if (IsAlignedChar(c) || IsAlignedChar(cPrev))
            ++uPosIndex;
        m_uSeedColIndexToPosIndex[n] = uPosIndex;
        m_uPosIndexToSeedColIndex[uPosIndex] = n;
        }
    if (uPosIndex != GetPosCount() - 1)
        Quit("BuildSeedMaps");
    }

unsigned Profile::SeedColIndexToPosIndex(unsigned uSeedColIndex) const
    {
    assert(uSeedColIndex < GetSeedLength());

    if (0 == m_uSeedColIndexToPosIndex)
        BuildSeedMaps();
    return m_uSeedColIndexToPosIndex[uSeedColIndex];
    }

void Profile::FromCkp(const Ckp &Prof, const char *pstrSeedId)
    {
    const unsigned uPosCount = Prof.GetPosCount();
    const char *pstrQuery = Prof.GetQuery();
    const unsigned uSeedLength = (unsigned) strlen(pstrQuery);
    SetSize(uPosCount, uSeedLength);
    strcpy(m_pstrSeed, pstrQuery);
    for (unsigned uPosIndex = 0; uPosIndex < uPosCount; ++uPosIndex)
        {
        const CkpPos &CP = Prof.GetPos(uPosIndex);
        CkpPosToProfPos(CP, m_Pos[uPosIndex]);
        }
    SetName(pstrSeedId);
    m_weightTotalSeq = 0;
    }

void Profile::CkpPosToProfPos(const CkpPos &CP, ProfPos &PP)
    {
    PP.m_bAligned = true;
    PP.m_fcE = 0;
    PP.m_fcF = 0;
    PP.m_fcFF = 0;
    PP.m_fcEF = 0;
    PP.m_fcFE = 0;
    PP.m_fcEE = 0;
    PP.m_fcT = 0;

    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        {
        PP.m_Probs[uLetter] = (PROB) CP.dFreq[uLetter];
        PP.m_fcCounts[uLetter] = 0;
        PP.m_fcF = 1.0;
        PP.m_fcE = 0.0;
        PP.m_fcFF = 1.0;
        PP.m_fcFE = 0.0;
        PP.m_fcEF = 0.0;
        PP.m_fcEE = 0.0;
        PP.m_fcT = 0.0;
        }
    NormalizeUnlessZero(PP.m_Probs, MAX_ALPHA);
    }

unsigned Profile::GetAlignedPosCount() const
    {
    const unsigned *ForSideEffectOnly = GetAlignedSeedColIndexToPosIndex();
    return m_uAlignedPosCount;
    }

unsigned Profile::GetUnalignedPosIndex(unsigned uAlignedPosIndex) const
    {
    const unsigned *map = GetAlignedSeedColIndexToPosIndex();
    assert(uAlignedPosIndex < m_uAlignedPosCount);
    return map[uAlignedPosIndex];
    }

const ProfPos &Profile::GetAlignedPos(unsigned uAlignedPosIndex) const
    {
    unsigned uPosIndex = GetUnalignedPosIndex(uAlignedPosIndex);
    return GetPos(uPosIndex);
    }

const unsigned *Profile::GetAlignedSeedColIndexToPosIndex() const
    {
    if (0 != m_uAlignedIndexToUnalignedIndex)
        return m_uAlignedIndexToUnalignedIndex;

    m_uAlignedPosCount = 0;
    for (unsigned uPosIndex = 0; uPosIndex < m_uPosCount; ++uPosIndex)
        if (m_Pos[uPosIndex].m_bAligned)
            ++m_uAlignedPosCount;

    m_uAlignedIndexToUnalignedIndex = new unsigned[m_uAlignedPosCount];
    unsigned uAlignedPosIndex = 0;
    for (unsigned uPosIndex = 0; uPosIndex < m_uPosCount; ++uPosIndex)
        if (m_Pos[uPosIndex].m_bAligned)
            {
            m_uAlignedIndexToUnalignedIndex[uAlignedPosIndex] = uPosIndex;
            ++uAlignedPosIndex;
            }
    return m_uAlignedIndexToUnalignedIndex;
    }
