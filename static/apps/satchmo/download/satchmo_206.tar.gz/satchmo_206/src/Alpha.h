// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef    Alpha_h
#define    Alpha_h

enum ALPHABET
    {
    ALPHABET_Unknown,
    ALPHABET_AutoDetect,
    ALPHABET_Nucleic,
    ALPHABET_Amino,
    };

unsigned GetAlphabetSize(ALPHABET Alpha);
unsigned CharToLetter(char c, ALPHABET Alpha);
unsigned CharToLetterAmino(char c);
char LetterToChar(unsigned uLetter, ALPHABET Alpha);
char LetterToCharAmino(unsigned uLetter);
char LetterToCharAminoEx(unsigned uLetter);
char LetterToCharNucleic(unsigned uLetter);
const char *AlphabetName(ALPHABET Alpha);
bool IsValidAmino(char c);
bool IsGap(char c);
bool IsWildcard(char c);
bool StrHasAmino(const char *Str);
bool StrHasGap(const char *Str);
char UnalignChar(char c);
bool IsAlignedChar(char c);

extern unsigned CharToLetterAminoEx[];

// AX=Amino alphabet with eXtensions (B, Z and X)
enum AX
    {
    AX_A,
    AX_C,
    AX_D,
    AX_E,
    AX_F,
    AX_G,
    AX_H,
    AX_I,
    AX_K,
    AX_L,
    AX_M,
    AX_N,
    AX_P,
    AX_Q,
    AX_R,
    AX_S,
    AX_T,
    AX_V,
    AX_W,
    AX_Y,

    AX_B,    // D or N
    AX_Z,    // E or Q
    AX_X,    // Unknown

    AX_GAP,
    };

const int AX_COUNT = 23;

#endif    // Alpha_h
