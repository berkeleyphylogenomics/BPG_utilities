// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWPath.h"
#include "PWScore.h"

#define    VERBOSE    0

// Macros to simulate 2D matrices
#define DPM(PLA, PLB)    DPM_[(PLA)*uPrefixCountB + (PLB)]
#define DPD(PLA, PLB)    DPD_[(PLA)*uPrefixCountB + (PLB)]
#define DPI(PLA, PLB)    DPI_[(PLA)*uPrefixCountB + (PLB)]
#define TBM(PLA, PLB)    TBM_[(PLA)*uPrefixCountB + (PLB)]
#define TBD(PLA, PLB)    TBD_[(PLA)*uPrefixCountB + (PLB)]
#define TBI(PLA, PLB)    TBI_[(PLA)*uPrefixCountB + (PLB)]

SCORE PWAlign(const PWScore &PWS, PWPath &Path)
    {
    const unsigned uLengthA = PWS.GetLengthA();
    const unsigned uLengthB = PWS.GetLengthB();
    assert(uLengthB > 0 && uLengthA > 0);

    const unsigned uPrefixCountA = uLengthA + 1;
    const unsigned uPrefixCountB = uLengthB + 1;

// Allocate DP matrices
    const size_t LM = uPrefixCountA*uPrefixCountB;
    SCORE *DPM_ = new SCORE[LM];
    SCORE *DPD_ = new SCORE[LM];
    SCORE *DPI_ = new SCORE[LM];
    char *TBM_ = new char[LM];
    char *TBD_ = new char[LM];
    char *TBI_ = new char[LM];

    memset(TBM_, '?', LM);
    memset(TBD_, '?', LM);
    memset(TBI_, '?', LM);

    DPM(0, 0) = MINUS_INFINITY;
    DPD(0, 0) = MINUS_INFINITY;
    DPI(0, 0) = MINUS_INFINITY;

// Empty prefix of B is special case
    for (unsigned uPrefixLengthA = 1; uPrefixLengthA < uPrefixCountA; ++uPrefixLengthA)
        {
    // M=LetterA+LetterB, impossible with empty prefix
        DPM(uPrefixLengthA, 0) = MINUS_INFINITY;
        TBM(uPrefixLengthA, 0) = '?';

    // D=LetterA+GapB
        SCORE scoreLG = PWS.ScoreLG(uPrefixLengthA, 0);
        SCORE scoreSD = PWS.ScoreSD(uPrefixLengthA, 0);
        SCORE scoreDD;
        if (uPrefixLengthA > 1)
            scoreDD = Add2(DPD(uPrefixLengthA - 1, 0), PWS.ScoreDD(uPrefixLengthA, 0));
        else
            scoreDD = MINUS_INFINITY;

        SCORE scoreBest;
        if (scoreSD > scoreDD)
            {
            scoreBest = scoreSD;
            TBD(uPrefixLengthA, 0) = 'S';
            }
        else
            {
            scoreBest = scoreDD;
            TBD(uPrefixLengthA, 0) = 'D';
            }
        DPD(uPrefixLengthA, 0) = Add2(scoreBest, scoreLG);

    // I=GapA+LetterB, impossible with empty prefix
        DPI(uPrefixLengthA, 0) = MINUS_INFINITY;
        }

    for (unsigned uPrefixLengthB = 1; uPrefixLengthB < uPrefixCountB; ++uPrefixLengthB)
        {
    // Empty prefix of A is special case
    // M=LetterA+LetterB, impossible with empty prefix
        DPM(0, uPrefixLengthB) = MINUS_INFINITY;

    // D=LetterA+GapB, impossible with empty prefix
        DPD(0, uPrefixLengthB) = MINUS_INFINITY;

    // I=GapA+LetterB
        SCORE scoreGL = PWS.ScoreGL(0, uPrefixLengthB);
        SCORE scoreSI = PWS.ScoreSI(0, uPrefixLengthB);
        SCORE scoreII;
        if (uPrefixLengthB > 1)
            scoreII = Add2(DPI(0, uPrefixLengthB - 1), PWS.ScoreII(0, uPrefixLengthB));
        else
            scoreII = MINUS_INFINITY;
        SCORE scoreBest;
        if (scoreII > scoreSI)
            {
            scoreBest = scoreII;
            TBI(0, uPrefixLengthB) = 'I';
            }
        else
            {
            assert(scoreSI >= scoreII);
            scoreBest = scoreSI;
            TBI(0, uPrefixLengthB) = 'S';
            }
        DPI(0, uPrefixLengthB) = Add2(scoreBest, scoreGL);

        for (unsigned uPrefixLengthA = 1; uPrefixLengthA < uPrefixCountA; ++uPrefixLengthA)
            {
            {
        // M=LetterA+LetterB
            SCORE scoreLL = PWS.ScoreLL(uPrefixLengthA, uPrefixLengthB);
            SCORE scoreSM = PWS.ScoreSM(uPrefixLengthA, uPrefixLengthB);
            SCORE scoreMM = MINUS_INFINITY;
            SCORE scoreDM = MINUS_INFINITY;
            SCORE scoreIM = MINUS_INFINITY;
            if (uPrefixLengthA > 1 && uPrefixLengthB > 1)
                {
                SCORE scoreTransMM = PWS.ScoreMM(uPrefixLengthA, uPrefixLengthB);
                scoreMM = Add2(DPM(uPrefixLengthA-1, uPrefixLengthB-1), scoreTransMM);
                }
            if (uPrefixLengthA > 1)
                {
                SCORE scoreTransDM = PWS.ScoreDM(uPrefixLengthA, uPrefixLengthB);
                scoreDM = Add2(DPD(uPrefixLengthA-1, uPrefixLengthB-1), scoreTransDM);
                }
            if (uPrefixLengthB > 1)
                {
                SCORE scoreTransIM = PWS.ScoreIM(uPrefixLengthA, uPrefixLengthB);
                scoreIM = Add2(DPI(uPrefixLengthA-1, uPrefixLengthB-1), scoreTransIM);
                }
            SCORE scoreBest;
            if (scoreMM >= scoreDM && scoreMM >= scoreIM && scoreMM >= scoreSM)
                {
                scoreBest = scoreMM;
                TBM(uPrefixLengthA, uPrefixLengthB) = 'M';
                }
            else if (scoreDM >= scoreMM && scoreDM >= scoreIM && scoreDM >= scoreSM)
                {
                scoreBest = scoreDM;
                TBM(uPrefixLengthA, uPrefixLengthB) = 'D';
                }
            else if (scoreIM >= scoreMM && scoreIM >= scoreDM && scoreIM >= scoreSM)
                {
                scoreBest = scoreIM;
                TBM(uPrefixLengthA, uPrefixLengthB) = 'I';
                }
            else 
                {
                assert(scoreSM >= scoreMM && scoreSM >= scoreDM && scoreSM >= scoreIM);
                scoreBest = scoreSM;
                TBM(uPrefixLengthA, uPrefixLengthB) = 'S';
                }
            DPM(uPrefixLengthA, uPrefixLengthB) = Add2(scoreBest, scoreLL);
            }

            {
        // D=LetterA+GapB
            SCORE scoreLG = PWS.ScoreLG(uPrefixLengthA, uPrefixLengthB);
            SCORE scoreSD = PWS.ScoreSD(uPrefixLengthA, uPrefixLengthB);
            SCORE scoreMD = MINUS_INFINITY;
            SCORE scoreDD = MINUS_INFINITY;
            if (uPrefixLengthA > 1)
                {
                SCORE scoreTransMD = PWS.ScoreMD(uPrefixLengthA, uPrefixLengthB);
                SCORE scoreTransDD = PWS.ScoreDD(uPrefixLengthA, uPrefixLengthB);
                scoreMD = Add2(DPM(uPrefixLengthA-1, uPrefixLengthB), scoreTransMD);
                scoreDD = Add2(DPD(uPrefixLengthA-1, uPrefixLengthB), scoreTransDD);
                }
            SCORE scoreTransID = PWS.ScoreID(uPrefixLengthA, uPrefixLengthB);
            SCORE scoreID = Add2(DPI(uPrefixLengthA-1, uPrefixLengthB), scoreTransID);
            SCORE scoreBest;
            if (scoreMD >= scoreDD && scoreMD >= scoreID && scoreMD >= scoreSD)
                {
                scoreBest = scoreMD;
                TBD(uPrefixLengthA, uPrefixLengthB) = 'M';
                }
            else if (scoreDD >= scoreMD && scoreDD >= scoreID && scoreDD >= scoreSD)
                {
                scoreBest = scoreDD;
                TBD(uPrefixLengthA, uPrefixLengthB) = 'D';
                }
            else if (scoreID >= scoreMD && scoreID >= scoreDD && scoreID >= scoreSD)
                {
                scoreBest = scoreID;
                TBD(uPrefixLengthA, uPrefixLengthB) = 'I';
                }
            else 
                {
                assert(scoreSD >= scoreMD && scoreSD >= scoreDD && scoreSD >= scoreID);
                scoreBest = scoreSD;
                TBD(uPrefixLengthA, uPrefixLengthB) = 'S';
                }
            DPD(uPrefixLengthA, uPrefixLengthB) = Add2(scoreBest, scoreLG);
            }

        // I=GapA+LetterB
            {
            SCORE scoreGL = PWS.ScoreGL(uPrefixLengthA, uPrefixLengthB);
            SCORE scoreSI = PWS.ScoreSI(uPrefixLengthA, uPrefixLengthB);
            SCORE scoreMI = MINUS_INFINITY;
            SCORE scoreII = MINUS_INFINITY;
            if (uPrefixLengthB > 1)
                {
                SCORE scoreTransMI = PWS.ScoreMI(uPrefixLengthA, uPrefixLengthB);
                SCORE scoreTransII = PWS.ScoreII(uPrefixLengthA, uPrefixLengthB);
                scoreMI = Add2(DPM(uPrefixLengthA, uPrefixLengthB-1), scoreTransMI);
                scoreII = Add2(DPI(uPrefixLengthA, uPrefixLengthB-1), scoreTransII);
                }
            SCORE scoreTransDI = PWS.ScoreDI(uPrefixLengthA, uPrefixLengthB);
            SCORE scoreDI = Add2(DPD(uPrefixLengthA, uPrefixLengthB-1), scoreTransDI);
            SCORE scoreBest;
            if (scoreMI >= scoreDI && scoreMI >= scoreII && scoreMI >= scoreSI)
                {
                scoreBest = scoreMI;
                TBI(uPrefixLengthA, uPrefixLengthB) = 'M';
                }
            else if (scoreDI >= scoreMI && scoreDI >= scoreII && scoreDI >= scoreSI)
                {
                scoreBest = scoreDI;
                TBI(uPrefixLengthA, uPrefixLengthB) = 'D';
                }
            else if (scoreII >= scoreMI && scoreII >= scoreDI && scoreII >= scoreSI)
                {
                scoreBest = scoreII;
                TBI(uPrefixLengthA, uPrefixLengthB) = 'I';
                }
            else 
                {
                assert(scoreSI >= scoreMI && scoreSI >= scoreDI && scoreSI >= scoreII);
                scoreBest = scoreSI;
                TBI(uPrefixLengthA, uPrefixLengthB) = 'S';
                }
            DPI(uPrefixLengthA, uPrefixLengthB) = Add2(scoreBest, scoreGL);
            }
            }
        }

#if VERBOSE
    ListPWDP(DPM_, DPD_, DPI_, TBM_, TBD_, TBI_, uPrefixCountA, uPrefixCountB);
#endif

    SCORE Score = PWTraceBack(PWS, DPM_, DPD_, DPI_, TBM_, TBD_, TBI_, Path);

#if VERBOSE
    Path.ListMe();
#endif

    Path.Validate(PWS);

    delete[] DPM_;
    delete[] DPD_;
    delete[] DPI_;
    delete[] TBM_;
    delete[] TBD_;
    delete[] TBI_;

    return Score;
    }
