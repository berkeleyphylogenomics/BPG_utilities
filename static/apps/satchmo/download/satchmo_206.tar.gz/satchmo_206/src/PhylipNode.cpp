// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Phylip.h"
#include "PhylipNode.h"

void PhylipNode::CalcCounts()
    {
    if (IsLeaf())
        {
        m_uCounts[m_uClass] = 1;
        return;
        }
    m_ptrLeft->CalcCounts();
    m_ptrRight->CalcCounts();
    const unsigned *ptrLeftCounts = m_ptrLeft->GetCounts();
    const unsigned *ptrRightCounts = m_ptrRight->GetCounts();
    m_uClass = uInsane;
    unsigned uMajorityClassCount = 0;
    for (unsigned uClass = 0; uClass < m_uClassCount; ++uClass)
        {
        const unsigned uCount = ptrLeftCounts[uClass] + ptrRightCounts[uClass];
        m_uCounts[uClass] = uCount;
        if (uCount > uMajorityClassCount)
            {
            m_uClass = uClass;
            uMajorityClassCount = uCount;
            }
        }
    assert(m_uClass != uInsane);
    }

void PhylipNode::Validate() const
    {
    if (0 != m_ptrLeft)
        {
        assert(this == m_ptrLeft->GetParent());
        m_ptrLeft->Validate();
        }
    if (0 != m_ptrRight)
        {
        assert(this == m_ptrRight->GetParent());
        m_ptrRight->Validate();
        }
    if (0 != m_ptrParent)
        assert(this == m_ptrParent->GetLeft() || this == m_ptrParent->GetRight());
    }

bool PhylipNode::IsLeftChild() const
    {
    if (0 == m_ptrParent)
        Quit("IsLeftChild");
    return this == m_ptrParent->GetLeft();
    }

bool PhylipNode::IsRightChild() const
    {
    if (0 == m_ptrParent)
        Quit("IsRightChild");
    return this == m_ptrParent->GetRight();
    }

void PhylipNode::ListMe() const
    {
    List("%3u", m_uIndex);

    if (m_ptrParent)
        List(" P%3u", m_ptrParent->GetIndex());
    else
        List(" P---");

    if (m_ptrLeft)
        List(" L%3u", m_ptrLeft->GetIndex());
    else
        List(" L---");

    if (m_ptrRight)
        List(" R%3u", m_ptrRight->GetIndex());
    else
        List(" R---");

    List("\n");
    }

PhylipNode *PhylipNode::GetUnrootedParent() const
    {
    if (0 == m_ptrParent)
        return 0;
    if (m_ptrParent->IsRoot())
        {
        if (IsLeftChild())
            return m_ptrParent->GetRight();
        else
            return m_ptrParent->GetLeft();
        }
    return m_ptrParent;
    }

unsigned PhylipNode::GetCount(unsigned uClass) const
    {
    assert(uClass < m_uClassCount);
    return m_uCounts[uClass];
    }

unsigned PhylipNode::GetFalseNegCount(unsigned uClass) const
    {
    assert(uClass < m_uClassCount);
    const PhylipNode *ptrRoot = m_ptrTree->GetRoot();
    const unsigned uRootCount = ptrRoot->GetCount(uClass);
    const unsigned uCount = m_uCounts[uClass];
    assert(uRootCount >= uCount);
    return uRootCount - uCount;
    }

unsigned PhylipNode::GetFalsePosCount(unsigned uClass) const
    {
    assert(uClass < m_uClassCount);
    unsigned uFalsePosCount = 0;
    for (unsigned uClass2 = 1; uClass2 < m_uClassCount; ++uClass2)
        if (uClass2 != uClass)
            uFalsePosCount += m_uCounts[uClass2];
    return uFalsePosCount;
    }

bool PhylipNode::IsNFP(unsigned N) const
    {
    return IsNFP(m_uClass, N);
    }

bool PhylipNode::IsNFP(unsigned uClass, unsigned N) const
    {
    if (0 == uClass)
        return false;

    return GetFalsePosCount(uClass) <= N &&
      (IsRoot() || m_ptrParent->GetFalsePosCount(uClass) > N);
    }

bool PhylipNode::IsZFN(unsigned uClass) const
    {
    if (GetFalseNegCount(uClass) > 0)
        return false;
    
    if (IsLeaf())
        return true;

    return m_ptrLeft->GetFalseNegCount(uClass) > 0 &&
      m_ptrRight->GetFalseNegCount(uClass) > 0;
    }
