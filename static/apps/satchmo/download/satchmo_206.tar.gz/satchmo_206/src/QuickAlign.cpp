// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "Seq.h"

const int iMINUS_INFINITY = -999999;

#define    VERBOSE    0

// Macro to simulate 2D matrices
#define    DPM(PL1, PL2)    _DPM[(PL1)*uPrefixCount2 + (PL2)]
#define    DPD(PL1, PL2)    _DPD[(PL1)*uPrefixCount2 + (PL2)]
#define    DPI(PL1, PL2)    _DPI[(PL1)*uPrefixCount2 + (PL2)]

static inline int XMax3(int i, int j, int k)
    {
    if (i >= j && i >= k)
        return i;
    else if (j >= i && j >= k)
        return j;
    assert(k >= i && k >= j);
    return k;
    }

/***
Simple global alignment of two sequences.
Score match=1, mismatch=0, gap-open=-2, gap-extend=-1.
Output is a "pair map" (see comments elsewhere).
***/
void QuickAlign(const Seq &s1, const Seq &s2, int iMap1[], int iMap2[])
    {
    if (s1.HasGap() || s2.HasGap())
        Quit("QuickAlign: requires ungapped sequences");

    const unsigned uLength1 = s1.Length();
    const unsigned uLength2 = s2.Length();

    const unsigned uPrefixCount1 = uLength1 + 1;
    const unsigned uPrefixCount2 = uLength2 + 1;

    const unsigned uMatrixEntryCount = uPrefixCount1*uPrefixCount2;

    int *_DPM = new int[uMatrixEntryCount];
    int *_DPD = new int[uMatrixEntryCount];
    int *_DPI = new int[uMatrixEntryCount];

// Usual dynamic programming loop
    for (unsigned uPrefixLength1 = 0; uPrefixLength1 < uPrefixCount1;
      ++uPrefixLength1)
        {
        for (unsigned uPrefixLength2 = 0; uPrefixLength2 < uPrefixCount2;
          ++uPrefixLength2)
            {
        // Letter1 + Letter2
            {
            int iLL = iMINUS_INFINITY;
            if (uPrefixLength1 > 0 && uPrefixLength2 > 0)
                {
                const char c1 = s1[uPrefixLength1 - 1];
                const char c2 = s2[uPrefixLength2 - 1];
                const int iPair = (c1 == c2 ? 1 : 0);
                const unsigned L1 = uPrefixLength1 - 1;
                const unsigned L2 = uPrefixLength2 - 1;
                iLL = XMax3(DPM(L1, L2), DPD(L1, L2), DPI(L1, L2)) + iPair;
                }
            else if (0 == uPrefixLength1 && 0 == uPrefixLength2)
                iLL = 0;
            DPM(uPrefixLength1, uPrefixLength2) = iLL;
            }

        // Letter1 + Gap2
            {
            int iLG = iMINUS_INFINITY;
            if (uPrefixLength1 > 0)
                {
                const unsigned L1 = uPrefixLength1 - 1;
                const unsigned L2 = uPrefixLength2;
                iLG = XMax3(DPM(L1, L2) - 2, DPD(L1, L2) - 1, DPI(L1, L2) - 2);
                }
            DPD(uPrefixLength1, uPrefixLength2) = iLG;
            }

        // Gap1 + Letter2
            {
            int iGL = iMINUS_INFINITY;
            if (uPrefixLength2 > 0)
                {
                const unsigned L1 = uPrefixLength1;
                const unsigned L2 = uPrefixLength2 - 1;
                iGL = XMax3(DPM(L1, L2) - 2, DPD(L1, L2) - 2, DPI(L1, L2) - 1);
                }
            DPI(uPrefixLength1, uPrefixLength2) = iGL;
            }
            }
        }

#if    VERBOSE
// List DP matrices
    {
    List("DPM[]:\n");
    List("      ");
    for (unsigned uPrefixLength2 = 0; uPrefixLength2 < uPrefixCount2;
      ++uPrefixLength2)
        List("      %c", uPrefixLength2 == 0 ? '-' : s2[uPrefixLength2 - 1]);
    List("\n");
    for (unsigned uPrefixLength1 = 0; uPrefixLength1 < uPrefixCount1;
      ++uPrefixLength1)
        {
        List("     %c", uPrefixLength1 == 0 ? '-' : s1[uPrefixLength1 - 1]);
        for (unsigned uPrefixLength2 = 0; uPrefixLength2 < uPrefixCount2;
          ++uPrefixLength2)
            List("%7d", DPM(uPrefixLength1, uPrefixLength2));
        List("\n");
        }
    List("DPD[]:\n");
    List("      ");
    for (unsigned uPrefixLength2 = 0; uPrefixLength2 < uPrefixCount2;
      ++uPrefixLength2)
        List("      %c", uPrefixLength2 == 0 ? '-' : s2[uPrefixLength2 - 1]);
    List("\n");
    for (unsigned uPrefixLength1 = 0; uPrefixLength1 < uPrefixCount1;
      ++uPrefixLength1)
        {
        List("     %c", uPrefixLength1 == 0 ? '-' : s1[uPrefixLength1 - 1]);
        for (unsigned uPrefixLength2 = 0; uPrefixLength2 < uPrefixCount2;
          ++uPrefixLength2)
            List("%7d", DPD(uPrefixLength1, uPrefixLength2));
        List("\n");
        }
    List("DPI[]:\n");
    List("      ");
    for (unsigned uPrefixLength2 = 0; uPrefixLength2 < uPrefixCount2;
      ++uPrefixLength2)
        List("      %c", uPrefixLength2 == 0 ? '-' : s2[uPrefixLength2 - 1]);
    List("\n");
    for (unsigned uPrefixLength1 = 0; uPrefixLength1 < uPrefixCount1;
      ++uPrefixLength1)
        {
        List("     %c", uPrefixLength1 == 0 ? '-' : s1[uPrefixLength1 - 1]);
        for (unsigned uPrefixLength2 = 0; uPrefixLength2 < uPrefixCount2;
          ++uPrefixLength2)
            List("%7d", DPI(uPrefixLength1, uPrefixLength2));
        List("\n");
        }
    }
#endif

// Traceback
    {
    unsigned uPrefixLength1 = uLength1;
    unsigned uPrefixLength2 = uLength2;

    char cState = '?';
    int iScore = iMINUS_INFINITY;

    if (DPM(uLength1, uLength2) >= DPD(uLength1, uLength2) &&
      DPM(uLength1, uLength2) >= DPI(uLength1, uLength2))
        {
        cState = 'M';
        iScore = DPM(uLength1, uLength2);
        }
    else if (DPD(uLength1, uLength2) >= DPM(uLength1, uLength2) &&
      DPD(uLength1, uLength2) >= DPI(uLength1, uLength2))
        {
        cState = 'D';
        iScore = DPD(uLength1, uLength2);
        }
    else
        {
        assert(DPI(uLength1, uLength2) >= DPM(uLength1, uLength2) &&
          DPI(uLength1, uLength2) >= DPD(uLength1, uLength2));
        cState = 'I';
        iScore = DPI(uLength1, uLength2);
        }

    while (uPrefixLength1 > 0 || uPrefixLength2 > 0)
        {
        if (iMINUS_INFINITY == iScore)
            Quit("Traceback");

        switch (cState)
            {
        case 'M':
            {
            assert(uPrefixLength1 > 0 && uPrefixLength2 > 0);
            const char c1 = s1[uPrefixLength1 - 1];
            const char c2 = s2[uPrefixLength2 - 1];
            const int iPair = (c1 == c2 ? 1 : 0);
            const unsigned L1 = uPrefixLength1 - 1;
            const unsigned L2 = uPrefixLength2 - 1;
            iMap1[L1] = (int) L2;
            iMap2[L2] = (int) L1;
#if    VERBOSE
            List("A%-3u %c   B%-3u %c\n", L1, c1, L2, c2);
#endif
            --uPrefixLength1;
            --uPrefixLength2;

            if (DPM(L1, L2) + iPair == iScore)
                {
                cState = 'M';
                iScore = DPM(L1, L2);
                continue;
                }
            else if (DPD(L1, L2) + iPair == iScore)
                {
                cState = 'D';
                iScore = DPD(L1, L2);
                continue;
                }
            else if (DPI(L1, L2) + iPair == iScore)
                {
                cState = 'I';
                iScore = DPI(L1, L2);
                continue;
                }
            Quit("Traceback");
            }

        case 'D':
            {
            assert(uPrefixLength1 > 0);
            const unsigned L1 = uPrefixLength1 - 1;
            const unsigned L2 = uPrefixLength2;
            iMap1[L1] = -1;
#if    VERBOSE
            char c1 = s1[L1];
            List("A%-3u %c        -\n", L1, c1);
#endif
            --uPrefixLength1;

            if (DPM(L1, L2) - 2 == iScore)
                {
                cState = 'M';
                iScore = DPM(L1, L2);
                continue;
                }
            else if (DPD(L1, L2) - 1 == iScore)
                {
                cState = 'D';
                iScore = DPD(L1, L2);
                continue;
                }
            else if (DPI(L1, L2) - 2 == iScore)
                {
                cState = 'I';
                iScore = DPI(L1, L2);
                continue;
                }
            Quit("Traceback");
            }

        case 'I':
            {
            assert(uPrefixLength2 > 0);
            const unsigned L1 = uPrefixLength1;
            const unsigned L2 = uPrefixLength2 - 1;
            iMap2[L2] = -1;
#if    VERBOSE
            char c2 = s2[L2];
            List("     -   B%-3u %c\n", L2, c2);
#endif
            --uPrefixLength2;

            if (DPM(L1, L2) - 2 == iScore)
                {
                cState = 'M';
                iScore = DPM(L1, L2);
                continue;
                }
            else if (DPD(L1, L2) - 2 == iScore)
                {
                cState = 'D';
                iScore = DPD(L1, L2);
                continue;
                }
            else if (DPI(L1, L2) - 1 == iScore)
                {
                cState = 'I';
                iScore = DPI(L1, L2);
                continue;
                }
            Quit("Traceback");
            }

        default:
            Quit("state");
            }
        }
    }

    delete[] _DPM;
    delete[] _DPD;
    delete[] _DPI;
    }
