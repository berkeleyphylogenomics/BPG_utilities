// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWPath.h"
#include "EnumPaths.h"
#include "Seq.h"
#include "TextFile.h"
#include "PWAff.h"
#include "PWPRC.h"
#include <list>

#define    VERBOSE    0

typedef std::list<PWPath *> PATH_BAG;
typedef PATH_BAG::iterator PATH_BAG_ITER;

class EPS_Test : public EnumPWPathsSink
    {
public:
    EPS_Test()
        {
        m_scoreHighest = MINUS_INFINITY;
        m_scoreAllPaths = MINUS_INFINITY;
        m_uPathCount = 0;
        }

    virtual ~EPS_Test()
        {
        ClearPathBag();
        }

    void SetPWS(const PWScore &PWS)
        {
        m_ptrPWS = &PWS;
        }

    virtual void OnPath(const PWPath &Path)
        {
        Path.Validate(*m_ptrPWS);
        ++m_uPathCount;
        SCORE scorePath = PWScorePath(*m_ptrPWS, Path);
        m_scoreAllPaths = (SCORE) SumLog(m_scoreAllPaths, scorePath);
        if (ScoreEq(scorePath, m_scoreHighest))
            AppendPath(Path);
        else if (scorePath > m_scoreHighest)
            {
            m_scoreHighest = scorePath;
            ClearPathBag();
            AppendPath(Path);
            }
#if    VERBOSE
        List("Score %s \t", ScoreToStr(scorePath));
        Path.ListMe();
#endif
        }

    void ListMe()
        {
        List("%u paths checked\n", m_uPathCount);
        List("%u highest-scoring paths\n", m_bagPaths.size());
        List("Total score for all paths %s\n", ScoreToStr(m_scoreAllPaths));
        List("\n");
        List("   Score  Path\n");
        List("   -----  ----\n");
        for (PATH_BAG_ITER p = m_bagPaths.begin(); p != m_bagPaths.end(); ++p)
            {
            const PWPath &Path = **p;
            SCORE Score = PWScorePath(*m_ptrPWS, Path);
            List("%s  ", ScoreToStr(Score));
            Path.ListMe();
            }
        }
    
    void ClearPathBag()
        {
        for (PATH_BAG_ITER p = m_bagPaths.begin(); p != m_bagPaths.end(); ++p)
            delete *p;
        m_bagPaths.clear();
        }

    void AppendPath(const PWPath &Path)
        {
        PWPath *ptrNewPath = new PWPath();
        ptrNewPath->Copy(Path);
        m_bagPaths.push_back(ptrNewPath);
        }

public:
    unsigned m_uPathCount;
    SCORE m_scoreHighest;
    SCORE m_scoreAllPaths;
    PATH_BAG m_bagPaths;
    BOUNDS m_BoundsA;
    BOUNDS m_BoundsB;
    const PWScore *m_ptrPWS;
    };

void TestPWAlign(const PWScore &PWS, PWPath &Path)
    {
    EPS_Test e;
    e.SetPWS(PWS);
    BOUNDS boundsA = PWS.GetBoundsA();
    BOUNDS boundsB = PWS.GetBoundsB();
    e.m_BoundsA = PWS.GetBoundsA();
    e.m_BoundsB = PWS.GetBoundsB();
    EnumPWPaths(PWS.GetLengthA(), PWS.GetLengthB(), boundsA, boundsB, e);
    e.ListMe();

    SCORE scoreBest = PWAlign(PWS, Path);
    List("\n");
    List("PWAlign:\n");
    List("%s  ", ScoreToStr(scoreBest));
    Path.ListMe();
    List("\n");
    }
