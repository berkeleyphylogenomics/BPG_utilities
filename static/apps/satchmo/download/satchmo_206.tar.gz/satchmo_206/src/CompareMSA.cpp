// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"

void CompareMSA(const MSA &msaTest, const MSA &msaRef, double *ptrdSP,
  double *ptrdPS, double *ptrdCS)
    {
    const unsigned uRefSeqCount = msaRef.GetSeqCount();

    double dTotalSP = 0.0;
    double dTotalPS = 0.0;
    double dTotalCS = 0.0;
    unsigned uPairCount = 0;

    for (unsigned uRefSeqIndexA = 0; uRefSeqIndexA < uRefSeqCount; ++uRefSeqIndexA)
        {
        const char *pstrSeqNameA = msaRef.GetSeqName(uRefSeqIndexA);
        unsigned uTestSeqIndexA;
        bool bFound = msaTest.GetSeqIndex(pstrSeqNameA, &uTestSeqIndexA);
        if (!bFound)
            Quit("Sequence '%s' not found in test alignment", pstrSeqNameA);

        for (unsigned uRefSeqIndexB = uRefSeqIndexA + 1; uRefSeqIndexB < uRefSeqCount;
          ++uRefSeqIndexB)
            {
            const char *pstrSeqNameB = msaRef.GetSeqName(uRefSeqIndexB);
            unsigned uTestSeqIndexB;
            bool bFound = msaTest.GetSeqIndex(pstrSeqNameB, &uTestSeqIndexB);
            if (!bFound)
                Quit("Sequence '%s' not found in test alignment", pstrSeqNameB);

            double dSP = dInsane;
            double dPS = dInsane;
            double dCS = dInsane;
            ComparePair(msaTest, uTestSeqIndexA, uTestSeqIndexB, msaRef, uRefSeqIndexA,
              uRefSeqIndexB, &dSP, &dPS, &dCS);

            dTotalSP += dSP;
            dTotalPS += dPS;
            dTotalCS += dCS;
            ++uPairCount;
            }
        }
    *ptrdSP = dTotalSP / uPairCount;
    *ptrdPS = dTotalPS / uPairCount;
    *ptrdCS = dTotalCS / uPairCount;
    }
