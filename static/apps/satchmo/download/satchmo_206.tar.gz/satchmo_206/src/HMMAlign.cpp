// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "MSA.h"
#include "HMMPath.h"
#include "Seq.h"
#include "SatchmoParams.h"

void HMM::AppendInserts(const MSA &msaTarget, MSA &msaCombined,
  unsigned &uCombinedColIndex, unsigned &uTemplateColIndex, unsigned &uTargetColIndex,
  unsigned uTemplateCount, unsigned uTargetCount) const
    {
    const MSA &msaTemplate = *m_ptrTemplate;

    COLINFO CI;
    unsigned uColCount = uTemplateCount;
    if (uTargetCount > uColCount)
        uColCount = uTargetCount;

    unsigned uTemplateSeqCount = msaTemplate.GetSeqCount();
    unsigned n;
    for (n = 0; n < uTemplateCount; ++n)
        {
        for (unsigned uSeqIndex = 0; uSeqIndex < uTemplateSeqCount; ++uSeqIndex)
            {
            char c = msaTemplate.GetChar(uSeqIndex, uTemplateColIndex + n);
            c = UnalignChar(c);
            msaCombined.SetChar(uSeqIndex, uCombinedColIndex + n, c);
            }
        }
    for (; n < uColCount; ++n)
        for (unsigned uSeqIndex = 0; uSeqIndex < uTemplateSeqCount; ++uSeqIndex)
            msaCombined.SetChar(uSeqIndex, uCombinedColIndex + n, '.');

    unsigned uTargetSeqCount = msaTarget.GetSeqCount();
    for (n = 0; n < uTargetCount; ++n)
        {
        for (unsigned uSeqIndex = 0; uSeqIndex < uTargetSeqCount; ++uSeqIndex)
            {
            char c = msaTarget.GetChar(uSeqIndex, uTargetColIndex + n);
            c = UnalignChar(c);
            msaCombined.SetChar(uTemplateSeqCount + uSeqIndex, uCombinedColIndex + n, c);
            }
        }
    for (; n < uColCount; ++n)
        for (unsigned uSeqIndex = 0; uSeqIndex < uTargetSeqCount; ++uSeqIndex)
            msaCombined.SetChar(uTemplateSeqCount + uSeqIndex, uCombinedColIndex + n, '.');

    CI.m_bAligned = false;
    CI.m_iNodeIndex = -1;
    CI.m_scoreAvgAffinity = MINUS_INFINITY;
    CI.m_scoreEmit = MINUS_INFINITY;
    for (unsigned n = 0; n < uColCount; ++n)
        {
        if (n < uTemplateCount)
            CI.m_iTemplateColIndex = (int) (uTemplateColIndex + n);
        else
            CI.m_iTemplateColIndex = -1;

        if (n < uTargetCount)
            CI.m_iTargetColIndex = (int) (uTargetColIndex + n);
        else
            CI.m_iTargetColIndex = -1;
        msaCombined.SetColInfo(uCombinedColIndex + n, CI);
        }

    uCombinedColIndex += uColCount;
    uTemplateColIndex += uTemplateCount;
    uTargetColIndex += uTargetCount;
    }

void HMM::AppendMatch(const MSA &msaTarget, MSA &msaCombined,
  unsigned uNodeIndex, bool bAligned, unsigned &uCombinedColIndex,
  unsigned &uTemplateColIndex, unsigned &uTargetColIndex, SCORE scoreEmit,
  SCORE scoreAvgAffinity) const
    {
    const MSA &msaTemplate = *m_ptrTemplate;
    unsigned uTemplateSeqCount = msaTemplate.GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uTemplateSeqCount; ++uSeqIndex)
        {
        char c = msaTemplate.GetChar(uSeqIndex, uTemplateColIndex);
        assert(IsAlignedChar(c));
        if (!bAligned)
            c = UnalignChar(c);
        msaCombined.SetChar(uSeqIndex, uCombinedColIndex, c);
        }

    unsigned uTargetSeqCount = msaTarget.GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uTargetSeqCount; ++uSeqIndex)
        {
        char c = msaTarget.GetChar(uSeqIndex, uTargetColIndex);
        if (!IsAlignedChar(c))
            {
            List("AppendMatch\n");
            List("NodeIndex=%u Aligned=%u ComCI=%u TplCI=%u TgtCI=%u\n",
              uNodeIndex, (unsigned) bAligned, uCombinedColIndex, uTemplateColIndex, uTargetColIndex);
            List("msaTarget(%u,%u)=%c, not aligned\n", uSeqIndex, uTargetColIndex, c);
            List("Template:\n");
            msaTemplate.ListMe();
            List("Target:\n");
            msaTarget.ListMe();
            List("Combined:\n");
            msaCombined.ListMe();
            Quit("AppendMatch");
            }
         assert(IsAlignedChar(c));
        if (!bAligned)
            c = UnalignChar(c);
        msaCombined.SetChar(uTemplateSeqCount + uSeqIndex, uCombinedColIndex, c);
        }

    COLINFO CI;
    CI.m_bAligned = bAligned;
    CI.m_iNodeIndex = (int) uNodeIndex;
    CI.m_iTemplateColIndex = (int) uTemplateColIndex;
    CI.m_iTargetColIndex = (int) uTargetColIndex;
    CI.m_scoreEmit = scoreEmit;
    CI.m_scoreAvgAffinity = scoreAvgAffinity;
    msaCombined.SetColInfo(uCombinedColIndex, CI);

    ++uCombinedColIndex;
    ++uTemplateColIndex;
    ++uTargetColIndex;
    }

void HMM::AppendDelete(const MSA &msaTarget, MSA &msaCombined, unsigned uNodeIndex,
  bool bAligned, unsigned &uCombinedColIndex, unsigned &uTemplateColIndex,
  SCORE scoreAvgAffinity) const
    {
    const MSA &msaTemplate = *m_ptrTemplate;
    unsigned uTemplateSeqCount = msaTemplate.GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uTemplateSeqCount; ++uSeqIndex)
        {
        char c = msaTemplate.GetChar(uSeqIndex, uTemplateColIndex);
        assert(IsAlignedChar(c));
        if (!bAligned)
            c = UnalignChar(c);
        msaCombined.SetChar(uSeqIndex, uCombinedColIndex, c);
        }

    unsigned uTargetSeqCount = msaTarget.GetSeqCount();
    for (unsigned uSeqIndex = 0; uSeqIndex < uTargetSeqCount; ++uSeqIndex)
        {
        if (bAligned)
            msaCombined.SetChar(uTemplateSeqCount + uSeqIndex, uCombinedColIndex, '-');
        else
            msaCombined.SetChar(uTemplateSeqCount + uSeqIndex, uCombinedColIndex, '.');
        }

    COLINFO CI;
    CI.m_bAligned = bAligned;
    CI.m_iNodeIndex = (int) uNodeIndex;
    CI.m_iTemplateColIndex = (int) uTemplateColIndex;
    CI.m_iTargetColIndex = -1;
    CI.m_scoreEmit = 0;
    CI.m_scoreAvgAffinity = scoreAvgAffinity;
    msaCombined.SetColInfo(uCombinedColIndex, CI);

    ++uCombinedColIndex;
    ++uTemplateColIndex;
    }

void HMM::Align(const HMMPath &Route, MSA &msaCombined, const MSA &msaTarget) const
    {
    const MSA &msaTemplate = GetTemplate();
//    const MSA &msaTarget = Route.GetTarget();
    unsigned n = uInsane;
    unsigned i = uInsane;

// Sanity check
    const unsigned uLegCount = Route.GetEdgeCount();
    for (unsigned uLegIndex = 0; uLegIndex < uLegCount; ++uLegIndex)
        {
        const HMMEdge &Leg = Route.GetEdge(uLegIndex);
        if ('M' != Leg.cState)
            continue;
        unsigned uPillarIndex = Leg.uPrefixLength - 1;
        const PILLAR &Pillar = msaTarget.GetPillar(uPillarIndex);
        if (!Pillar.m_bAligned)
            {
            msaTarget.ListMe();
            Route.ListMe();
            Quit("Match state node %u to unaligned pillar %u cols %u to %u",
              Leg.uNodeIndex, uPillarIndex, Pillar.m_uFromColIndex, Pillar.m_uToColIndex);
            }
        }

    //List("HMM::Align: Route=");
    //Route.ListMe();
    //List("Template:\n");
    //msaTemplate.ListMe();
    //List("Target:\n");
    //msaTarget.ListMe();

    const unsigned uTargetSeqCount = msaTarget.GetSeqCount();
    const unsigned uTargetSeqLength = msaTarget.GetColCount();

    const unsigned uTemplateSeqCount = msaTemplate.GetSeqCount();
    const unsigned uTemplateSeqLength = msaTemplate.GetColCount();

    const unsigned uCombinedSeqCount = uTemplateSeqCount + uTargetSeqCount;

    msaCombined.SetAlphabet(ALPHABET_Amino);
    msaCombined.SetSeqCount(uCombinedSeqCount);

// Copy names into combined MSA
// Convention: template appears above target.
    for (n = 0; n < uTemplateSeqCount; ++n)
        msaCombined.SetSeqName(n, msaTemplate.GetSeqName(n));
    for (n = 0; n < uTargetSeqCount; ++n)
        msaCombined.SetSeqName(uTemplateSeqCount + n,
          msaTarget.GetSeqName(n));

    unsigned uCombinedColIndex = 0;
    unsigned uTemplateColIndex = 0;
    unsigned uTargetColIndex = 0;
    unsigned uNodeIndex = 0;

    unsigned uEdgeCount = Route.GetEdgeCount();
    bool bFirstNodeSeen = false;
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const HMMEdge &Edge = Route.GetEdge(uEdgeIndex);
        if ('D' != Edge.cState && 'M' != Edge.cState)
            continue;
        if (bFirstNodeSeen)
            assert(Edge.uNodeIndex == uNodeIndex);
        else
            {
            bFirstNodeSeen = true;
            uNodeIndex = Edge.uNodeIndex;
            }
        unsigned uColIndex = NodeIndexToTemplateColIndex(uNodeIndex);
        unsigned uTemplateInsertCount = uColIndex - uTemplateColIndex;

        unsigned uColPL = msaTarget.PillarPLToColPL(Edge.uPrefixLength);
        unsigned uTargetInsertCount;
        if ('M' == Edge.cState)
            {
            assert(Edge.uPrefixLength > 0);
            uTargetInsertCount = uColPL - uTargetColIndex - 1;
            }
        else
            {
            assert('D' == Edge.cState);
            uTargetInsertCount = uColPL - uTargetColIndex;
            }

        AppendInserts(msaTarget, msaCombined, uCombinedColIndex, uTemplateColIndex,
          uTargetColIndex, uTemplateInsertCount, uTargetInsertCount);

        bool bAligned = true;
        SCORE scoreAvgAff = 0;
        if (0 != m_ptrSP)
            {
            scoreAvgAff = Route.GetAvgAff(uEdgeIndex, m_ptrSP->GetWindowLength());
            bAligned = (scoreAvgAff >= m_ptrSP->GetMinAvgAff());
            }

        if ('M' == Edge.cState)
            {
            SCORE scoreEmit = Edge.scoreEmit;
            AppendMatch(msaTarget, msaCombined, uNodeIndex, bAligned, uCombinedColIndex,
              uTemplateColIndex, uTargetColIndex, scoreEmit, scoreAvgAff);
            }
        else
            {
            assert('D' == Edge.cState);
            AppendDelete(msaTarget, msaCombined, uNodeIndex, bAligned, uCombinedColIndex,
              uTemplateColIndex, scoreAvgAff);
            }
        ++uNodeIndex;
        }
    unsigned uTemplateCount = msaTemplate.GetColCount() - uTemplateColIndex;
    unsigned uTargetCount = msaTarget.GetColCount() - uTargetColIndex;
    AppendInserts(msaTarget, msaCombined, uCombinedColIndex, uTemplateColIndex,
      uTargetColIndex, uTemplateCount, uTargetCount);

    //List("Combined:\n");
    //msaCombined.ListMe();

#if    0
    for (unsigned uSeqIndex = 0; uSeqIndex < uTemplateSeqCount; ++uSeqIndex)
        {
        Seq seqTpl;
        msaTemplate.GetSeq(uSeqIndex, seqTpl);
        Seq seqCom;
        msaCombined.GetSeq(uSeqIndex, seqCom);
        if (!seqTpl.EqIgnoreCase(seqCom))
            Quit("HMMAligned CHECK 1\n");
        }
    for (unsigned uSeqIndex = 0; uSeqIndex < uTargetSeqCount; ++uSeqIndex)
        {
        Seq seqTgt;
        msaTarget.GetSeq(uSeqIndex, seqTgt);
        Seq seqCom;
        msaCombined.GetSeq(uTemplateSeqCount+uSeqIndex, seqCom);
        if (!seqTgt.EqIgnoreCase(seqCom))
            Quit("HMMAligned CHECK 2\n");
        }
#endif
    }
