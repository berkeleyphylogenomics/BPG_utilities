// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "MSA.h"
#include "HMM.h"
#include "HMMPath.h"
#include "Seq.h"

void DoCoach1(const char *in, const char *hmm, const char *tpl, const char *out)
    {
    const char *strInputFileName = in;
    const char *strModelFileName = hmm;
    const char *strTemplateFileName = tpl;
    const char *strOutputFastaFileName = out;
    const char *strBounds = GetOptionalParam("bounds");

    BOUNDS boundsModel = GLOBAL;
    BOUNDS boundsAln = LOCAL;

    if (0 != strBounds)
        {
        if (!stricmp(strBounds, "GG"))
            {
            boundsModel = GLOBAL;
            boundsAln = GLOBAL;
            }
        else if (!stricmp(strBounds, "GL"))
            {
            boundsModel = GLOBAL;
            boundsAln = LOCAL;
            }
        else if (!stricmp(strBounds, "LG"))
            {
            boundsModel = LOCAL;
            boundsAln = GLOBAL;
            }
        else if (!stricmp(strBounds, "LL"))
            {
            boundsModel = LOCAL;
            boundsAln = LOCAL;
            }
        else
            Quit("Invalid bounds '%s'", strBounds);
        }

    TextFile ModelFile(hmm);
    HMM Model;
    Model.FromFile(ModelFile);

    TextFile InputFile(in);
    MSA msaInput;
    msaInput.FromFASTAFile(InputFile);
    msaInput.AlignByCase();
    msaInput.BuildPillars();
//    msaInput.ValidateBreakMatrices();
    msaInput.SanityCheckPillarCount();

    TextFile TemplateFile(tpl);
    MSA msaTemplate;
    msaTemplate.FromFASTAFile(TemplateFile, ALPHABET_Amino, true);
    msaTemplate.AlignByCase();
    msaTemplate.BuildPillars();
//    msaTemplate.ValidateBreakMatrices();
    msaTemplate.SanityCheckPillarCount();

    HMMPath Path;
//    Path.SetTarget(msaInput);
    SCORE Score;

#pragma warning("TODO DeltaNull")
    Model.DeltaNullModelSelfLoop((SCORE) 0.3);

    if (GLOBAL == boundsModel && LOCAL == boundsAln)
        Score = Model.ViterbiAln(msaInput, Path);
    else if (LOCAL == boundsModel && LOCAL == boundsAln)
        Score = Model.ViterbiAlnLL(msaInput, Path);
    else
        Quit("Unsupported bounds '%s'", strBounds);

    printf("Model=%s;Target=%s;Viterbi=%s\n", 
      strModelFileName,
      strInputFileName,
      ScoreToStrL(Score));
    List("Model=%s;Target=%s;Viterbi=%s\n", 
      strModelFileName,
      strInputFileName,
      ScoreToStrL(Score));

    MSA msaTemplate1;
    msaTemplate1.SetSize(1, msaTemplate.GetColCount());
    msaTemplate1.SetAlphabet(ALPHABET_Amino);
    msaTemplate1.CopySeq(0, msaTemplate, 0);
    msaTemplate1.AlignByCase();
    msaTemplate1.BuildPillars();

    MSA msaInput1;
    msaInput1.SetSize(1, msaInput.GetColCount());
    msaInput1.SetAlphabet(ALPHABET_Amino);
    msaInput1.CopySeq(0, msaInput, 0);
    msaInput1.AlignByCase();
    msaInput1.BuildPillars();

    MSA msaCombined;
    Model.SetTemplate(msaTemplate1);
    Model.Align(Path, msaCombined, msaInput1);

    msaCombined.DeleteEmptyCols();

    TextFile OutFile(strOutputFastaFileName, true);
    msaCombined.ToFASTAFile(OutFile);
    }
