// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"
#include "TextFile.h"

void DoComparePair(const char *test, const char *ref, const char *id1, const char *id2)
    {
    const char *strTestFileName = test;
    const char *strRefFileName = ref;

    TextFile TestFile(strTestFileName);
    MSA msaTest;
    msaTest.FromFile(TestFile);
    msaTest.AlignByCase();

    TextFile RefFile(strRefFileName);
    MSA msaRef;
    msaRef.FromFile(RefFile);
    msaRef.AlignByCase();

    double dSP = dInsane;
    double dTC = dInsane;

    unsigned uRef1;
    bool bFound = msaRef.GetSeqIndex(id1, &uRef1);
    if (!bFound)
        Quit("Sequence not found '%s'", id1);
    unsigned uRef2;
    bFound = msaRef.GetSeqIndex(id1, &uRef2);
    if (!bFound)
        Quit("Sequence not found '%s'", id2);
    double dCS = ClineScorePair(msaRef, msaTest, uRef1, uRef2, 0.2);
    List("Test=%s;Ref=%s;1=%s;2=%s;CS=%.3g\n",
        strTestFileName,
        strRefFileName,
        id1,
        id2,
        dCS);
    }
