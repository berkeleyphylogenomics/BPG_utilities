// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "MSA.h"
#include "Seq.h"

void DoQuickAlign(const char *seq1, const char *seq2, const char *out)
    {
    Seq s1;
    Seq s2;

    TextFile In1(seq1);
    TextFile In2(seq2);

    s1.FromFASTAFile(In1);
    s2.FromFASTAFile(In2);

    unsigned uLength1 = s1.Length();
    unsigned uLength2 = s2.Length();

    int *iMap1 = new int[uLength1];
    int *iMap2 = new int[uLength2];

    s1.StripGaps();
    s2.StripGaps();
    s1.ToUpper();
    s2.ToUpper();

    QuickAlign(s1, s2, iMap1, iMap2);

    MSA a;
    a.FromPairMap(s1, s2, iMap1, iMap2);

    TextFile OutFile(out, true);
    a.ToFASTAFile(OutFile);
    }
