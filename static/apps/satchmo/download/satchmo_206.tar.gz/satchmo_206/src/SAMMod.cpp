// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "SAMMod.h"
#include <math.h>

SAMMod::SAMMod()
    {
    m_uNodeCount = 0;
    m_Nodes = 0;
    }

SAMMod::~SAMMod()
    {
    Clear();
    }

void SAMMod::Clear()
    {
    delete[] m_Nodes;
    m_uNodeCount = 0;
    }

const SAMNode &SAMMod::GetNode(unsigned uNodeIndex) const
    {
    assert(uNodeIndex < m_uNodeCount);
    return m_Nodes[uNodeIndex];
    }

void SAMMod::Validate() const
    {
    if (0 == m_uNodeCount)
        Quit("Invalid SAM model, no nodes");

// Loop over all nodes except Begin and End
    for (unsigned uNodeIndex = 1; uNodeIndex < m_uNodeCount - 1; ++uNodeIndex)
        {
    // Check that transitions out of a state add up to 1.0
        const SAMNode &Node = GetNode(uNodeIndex);
        const SAMNode &NextNode = GetNode(uNodeIndex + 1);

        {
        double dSumM = NextNode.m_probMM + NextNode.m_probMD + Node.m_probMI;
        if (fabs(1.0 - dSumM) > 0.01)
            Quit("Invalid SAM model (M)");
        }

        {
        double dSumI = NextNode.m_probIM + NextNode.m_probID + Node.m_probII;
        if (fabs(1.0 - dSumI) > 0.01)
            Quit("Invalid SAM model (I)");
        }

        {
        double dSumD = NextNode.m_probDM + NextNode.m_probDD + Node.m_probDI;
        if (fabs(1.0 - dSumD) > 0.01)
            Quit("Invalid SAM model (D)");
        }

        {
        double dSumMemit = 0.0;
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            dSumMemit += Node.m_probMatchEmit[uLetter];
        if (fabs(1.0 - dSumMemit) > 0.001)
            Quit("Invalid SAM model (match emit)");
        }

        {
        double dSumIemit = 0.0;
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            dSumIemit += Node.m_probInsertEmit[uLetter];
        if (fabs(1.0 - dSumIemit) > 0.001)
            Quit("Invalid SAM model (insert emit)");
        }
        }
    }

void SAMMod::ListMe() const
    {
    List("MODEL\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        if (0 == uNodeIndex)
            List("Begin\n");
        else if (m_uNodeCount - 1 == uNodeIndex)
            List("End\n");
        else
            List("%5u\n", uNodeIndex);

        const SAMNode &Node = GetNode(uNodeIndex);
        List("%8.6f %8.6f %8.6f\n", Node.m_probDD, Node.m_probMD, Node.m_probID);
        List("%8.6f %8.6f %8.6f\n", Node.m_probDM, Node.m_probMM, Node.m_probIM);
        List("%8.6f %8.6f %8.6f\n", Node.m_probDI, Node.m_probMI, Node.m_probII);

        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            {
            List("%8.6f", Node.m_probMatchEmit[uLetter]);
            if (0 == (uLetter+1)%5)
                List("\n");
            else
                List(" ");
            }
        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            {
            List("%8.6f", Node.m_probInsertEmit[uLetter]);
            if (0 == (uLetter+1)%5)
                List("\n");
            else
                List(" ");
            }
        List("\n");
        }
    List("ENDMODEL\n");
    }
