// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWScore.h"
#include "PWPath.h"

#define VERBOSE    0

SCORE PWScorePath(const PWScore &PWS, const PWPath &Path, bool bVerbose)
    {
    const unsigned uEdgeCount = Path.GetEdgeCount();
    if (0 == uEdgeCount)
        return MINUS_INFINITY;

#if    VERBOSE
    bVerbose = true;
#endif

    if (bVerbose)
        List("\nScorePath lengthA=%u (%s) lengthB=%u (%s)\n",
          PWS.GetLengthA(),
          BoundsToStr(PWS.GetBoundsA()),
          PWS.GetLengthB(),
          BoundsToStr(PWS.GetBoundsB()));

    SCORE scorePath = 0;

// Special case: transition contribution from start to first column
    {
    const PWEdge &FirstEdge = Path.GetEdge(0);
    const unsigned uPrefixLengthA = FirstEdge.uPrefixLengthA;
    const unsigned uPrefixLengthB = FirstEdge.uPrefixLengthB;
    char cEdgeType = FirstEdge.cType;
    SCORE scoreTrans;
    switch (cEdgeType)
        {
    case 'M':
        scoreTrans = PWS.ScoreSM(uPrefixLengthA, uPrefixLengthB);
        break;
    case 'D':
        scoreTrans = PWS.ScoreSD(uPrefixLengthA, uPrefixLengthB);
        break;
    case 'I':
        scoreTrans = PWS.ScoreSI(uPrefixLengthA, uPrefixLengthB);
        break;
    default:
        assert(false);
        }

    if (bVerbose)
        List("Trans  S%c%u.%u  %s\n",
          cEdgeType,
          uPrefixLengthA,
          uPrefixLengthB,
          ScoreToStr(scoreTrans));

    scorePath = Add2(scorePath, scoreTrans);
    }

// Emission contributions
    for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        const PWEdge &Edge = Path.GetEdge(uEdgeIndex);
        char cEdgeType = Edge.cType;
        const unsigned uPrefixLengthA = Edge.uPrefixLengthA;
        const unsigned uPrefixLengthB = Edge.uPrefixLengthB;
        SCORE scoreEmit;
        switch (cEdgeType)
            {
        case 'M':
            scoreEmit = PWS.ScoreLL(uPrefixLengthA, uPrefixLengthB);
            break;
        case 'D':
            scoreEmit = PWS.ScoreLG(uPrefixLengthA, uPrefixLengthB);
            break;
        case 'I':
            scoreEmit = PWS.ScoreGL(uPrefixLengthA, uPrefixLengthB);
            break;
        default:
            assert(false);
            }

        if (bVerbose)
            List(" Emit   %c%u.%u  %s\n",
              cEdgeType,
              uPrefixLengthA,
              uPrefixLengthB,
              ScoreToStr(scoreEmit));

        scorePath = Add2(scorePath, scoreEmit);
        }

// Transition contributions from inter-columns
    for (unsigned uEdgeIndex = 1; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
        {
        char cLastEdgeType = Path.GetEdge(uEdgeIndex - 1).cType;
        const PWEdge &Edge = Path.GetEdge(uEdgeIndex);
        char cEdgeType = Edge.cType;
        const unsigned uPrefixLengthA = Edge.uPrefixLengthA;
        const unsigned uPrefixLengthB = Edge.uPrefixLengthB;
        SCORE scoreTrans;

#define T2(c1, c2)    (((c1) << 8) | (c2))
        switch (T2(cLastEdgeType, cEdgeType))
            {
        case T2('M', 'M'):
            scoreTrans = PWS.ScoreMM(uPrefixLengthA, uPrefixLengthB);
            break;
        case T2('D', 'M'):
            scoreTrans = PWS.ScoreDM(uPrefixLengthA, uPrefixLengthB);
            break;
        case T2('I', 'M'):
            scoreTrans = PWS.ScoreIM(uPrefixLengthA, uPrefixLengthB);
            break;
        case T2('M', 'D'):
            scoreTrans = PWS.ScoreMD(uPrefixLengthA, uPrefixLengthB);
            break;
        case T2('D', 'D'):
            scoreTrans = PWS.ScoreDD(uPrefixLengthA, uPrefixLengthB);
            break;
        case T2('I', 'D'):
            scoreTrans = PWS.ScoreID(uPrefixLengthA, uPrefixLengthB);
            break;
        case T2('M', 'I'):
            scoreTrans = PWS.ScoreMI(uPrefixLengthA, uPrefixLengthB);
            break;
        case T2('D', 'I'):
            scoreTrans = PWS.ScoreDI(uPrefixLengthA, uPrefixLengthB);
            break;
        case T2('I', 'I'):
            scoreTrans = PWS.ScoreII(uPrefixLengthA, uPrefixLengthB);
            break;
        default:
            assert(false);
            }
#undef    T2

        if (bVerbose)
            List("Trans  %c%c%u.%u  %s\n",
              cLastEdgeType,
              cEdgeType,
              uPrefixLengthA,
              uPrefixLengthB,
              ScoreToStr(scoreTrans));

        scorePath = Add2(scorePath, scoreTrans);
        }

// Special case: transition contribution from last edge to end
    {
    const PWEdge &LastEdge = Path.GetEdge(uEdgeCount - 1);
    const unsigned uPrefixLengthA = LastEdge.uPrefixLengthA;
    const unsigned uPrefixLengthB = LastEdge.uPrefixLengthB;
    char cEdgeType = LastEdge.cType;
    SCORE scoreTrans;
    switch (cEdgeType)
        {
    case 'M':
        scoreTrans = PWS.ScoreME(uPrefixLengthA, uPrefixLengthB);
        break;
    case 'D':
        scoreTrans = PWS.ScoreDE(uPrefixLengthA, uPrefixLengthB);
        break;
    case 'I':
        scoreTrans = PWS.ScoreIE(uPrefixLengthA, uPrefixLengthB);
        break;
    default:
        assert(false);
        }
    scorePath = Add2(scorePath, scoreTrans);

    if (bVerbose)
        List("Trans  %cE%u.%u  %s Total=%s\n",
          cEdgeType,
          uPrefixLengthA,
          uPrefixLengthB,
          ScoreToStr(scoreTrans),
          ScoreToStr(scorePath));
// End of special case from last edge to end
    }

    return scorePath;
    }
