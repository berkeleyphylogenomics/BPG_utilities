#ifdef PARALLEL
#ifndef    Serialization_h
#define Serialization_h  


#include <iostream>
#include <sstream>
#include <string>
#include "MSA.h"

class StringBuffer 
{
    private:
        std::stringstream* strStream;
    
    public:
        StringBuffer::StringBuffer(){
                strStream = new std::stringstream();
        }
        StringBuffer::~StringBuffer(){
                delete strStream;
                strStream = 0;
        }
        void SetData(char *data){strStream->str(data);}
        char* GetData() {
          return strdup(strStream->str().data());
        }
        void Skip(){
            char c = strStream->get();
            while(c != '\n' ){
                c = strStream->get();
            }
        }
        void StringBuffer::Flush(){    strStream->sync();strStream->flush();    }
        unsigned StringBuffer::Tellp() {return strStream->tellp();}
        unsigned StringBuffer::GetPos(){ return strStream->tellg();  }
        bool StringBuffer::GetTrimLine(char *szLine, int size){
            //SkipWhite();
            if (!strStream->eof()){
                strStream->clear();
                *strStream >> szLine; //strStream->getline(szLine, size);
                return false;} 
            else return true;
        }
        void StringBuffer::SetPos(unsigned pos){ strStream->clear(); strStream->seekg(pos); }
        void StringBuffer::SkipWhite(){
            char c;
            for (;;){
                c = strStream->get();
                if (!isspace(c)){
                    strStream->unget();
                    break;
                }
            }    
        }
        void StringBuffer::GetTokenXC(char szToken[], int uBytes){
            
            // Skip leading white space
            char c;
            for (;;){
                c = strStream->get();
                if (!isspace(c))
                    break;
            }

            // "{" and "}" are special cases, tokens on their own.
            // All other tokens are terminated by white space or EOF.
            const char szCharTokens[] = "{}*";
                if (0 != strchr(szCharTokens, c))
                    {
                    assert(uBytes >= 2);
                    szToken[0] = c;
                    szToken[1] = 0;
                    return;
                    }
            
            // Loop until token terminated by white space or EOF
                unsigned uBytesCopied = 0;
                for (;;)
                    {
                    if (uBytesCopied < uBytes - 1)
                        szToken[uBytesCopied++] = c;
                    else
                        Quit("HMMSerialize::GetTokenXC: input buffer too small, line.%s", szToken);
                    c = strStream->get();
                    if (isspace(c))
                        {
                        assert(uBytesCopied > 0 && uBytesCopied < uBytes);
                        szToken[uBytesCopied] = 0;
                        return;
                        }
                    }
        }
        void StringBuffer::PutString(char *szLine){
            *strStream << szLine;
        }    
        
        void StringBuffer::PutChar(char c){
            if (c!=0 && c!= '?' && isprint(c))
                *strStream << c;    
        }
        void StringBuffer::Close(){
            *strStream << '\0';        
            strStream->flush();
        }
        void StringBuffer::PutFormat(const char szFormat[], ...)
        {
            char szStr[4096];
            va_list ArgList;
            va_start(ArgList, szFormat);
            vsprintf(szStr, szFormat, ArgList);
            PutString(szStr); 
        }

        
        
}; 
void MSASerialize( MSA *ptrMSA, StringBuffer *File, WRITE_WEIGHT_STYLE WWS, unsigned uGNodeIndex = uInsane) ;
void MSADeserialize( MSA **ptrMSA, StringBuffer *File,  ALPHABET Alpha = ALPHABET_Amino, bool bFirstOnly=true);
#endif // end StringBuffer
#endif //end parallel
