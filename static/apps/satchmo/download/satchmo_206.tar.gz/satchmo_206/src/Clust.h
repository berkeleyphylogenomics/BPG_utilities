// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef Clust_h
#define Clust_h

class Clust;
class ClustNode;
class ClustDist;
class ClustSet;
class Phylip;

class ClustNode
    {
public:
    ClustNode()
        {
        m_uIndex = uInsane;
        m_uSize = uInsane;
        m_dLength = dInsane;
        m_ptrLeft = 0;
        m_ptrRight = 0;
        m_ptrParent = 0;
        m_uLeafIndexes = 0;
        }
    ~ClustNode()
        {
        delete[] m_uLeafIndexes;
        }
    unsigned m_uIndex;
    unsigned m_uSize;
    double m_dLength;
    ClustNode *m_ptrLeft;
    ClustNode *m_ptrRight;
    ClustNode *m_ptrParent;
    unsigned *m_uLeafIndexes;
    };

class Clust
    {
public:
    Clust();
    virtual ~Clust();

    void Create(ClustSet &Set);
    void ClusterToThreshold(ClustSet &Set, double threshold);    
    unsigned GetLeafCount() const;
    bool IsRooted() const { return m_bIsRooted; }

    unsigned GetClusterCount() const;
    unsigned GetNodeIndex(unsigned uClusterIndex) const;
    unsigned GetClusterSize(unsigned uNodeIndex) const;
    unsigned GetLeaf(unsigned uClusterIndex, unsigned uLeafIndex) const;

    unsigned GetNodeCount() const { return 2*m_uLeafCount - 1; }
    const ClustNode &GetRoot() const { return m_Nodes[GetRootNodeIndex()]; }
    unsigned GetRootNodeIndex() const { return m_uNodeCount - 1; }

    const ClustNode &GetNode(unsigned uNodeIndex) const;
    bool IsLeaf(unsigned uNodeIndex) const;
    unsigned GetLeftIndex(unsigned uNodeIndex) const;
    unsigned GetRightIndex(unsigned uNodeIndex) const;
    double GetLength(unsigned uNodeIndex) const;
    double GetHeight(unsigned uNodeIndex) const;
    const char *GetNodeName(unsigned uNodeIndex) const;

    JOINSTYLE GetJoinStyle() const { return m_JoinStyle; }
    CENTROIDSTYLE GetCentroidStyle() const { return m_CentroidStyle; }

    void SetDist(unsigned uIndex1, unsigned uIndex2, double dDist);
    double GetDist(unsigned uIndex1, unsigned uIndex2) const;
    bool DistIsSet(unsigned uIndex1, unsigned uIndex2) const;

    void ToPhylip(Phylip &Tree);

    void ListMe() const;
    double dMinDist;  //added this will be the threshold;
private:
    void SetLeafCount(unsigned uLeafCount);
    void SetJoinStyle(JOINSTYLE JoinStyle) { m_JoinStyle = JoinStyle; }
    void SetCentroidStyle(CENTROIDSTYLE CentroidStyle)
        { m_CentroidStyle = CentroidStyle; }

    void CreateCluster();
    void JoinNodes(unsigned uLeftNodeIndex, unsigned uRightNodeIndex, 
      double dLeftLength, double dRightLength, unsigned uNewNodeIndex);

    void ChooseJoin(unsigned *ptruLeftIndex, unsigned *ptruRightIndex,
      double *ptrdLeftLength, double *ptrdRightLength);
    void ChooseJoinNeighborJoining(unsigned *ptruLeftIndex, unsigned *ptruRightIndex,
      double *ptrdLeftLength, double *ptrdRightLength);
    void ChooseJoinNearestNeighbor(unsigned *ptruLeftIndex, unsigned *ptruRightIndex,
      double *ptrdLeftLength, double *ptrdRightLength);

    double ComputeDist(unsigned uNewNodeIndex, unsigned uNodeIndex);
    double ComputeDistAverageLinkage(unsigned uNewNodeIndex, unsigned uNodeIndex);
    double ComputeDistNeighborJoining(unsigned uNewNewIndex, unsigned uNodeIndex);

    double Calc_r(unsigned uNodeIndex);

    unsigned DistVectorIndex(unsigned uIndex1, unsigned uIndex2) const;
    
private:
    JOINSTYLE m_JoinStyle;
    CENTROIDSTYLE m_CentroidStyle;
    ClustNode *m_Nodes;
    unsigned m_uLeafCount;
    unsigned m_uNodeCount;
    unsigned m_uClusterCount;
    bool m_bIsRooted;
    double *m_dDist;
    bool *m_bDistSet;
    ClustSet *m_ptrSet;
    };

#endif // Clust_h
