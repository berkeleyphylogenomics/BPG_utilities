// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "MSA.h"

void HMM::RouteToPath(const HMMPath &Route, const MSA &Aln, unsigned uSeqIndex,
  HMMPath &Path) const
    {
    Path.Clear();

    const unsigned uLegCount = Route.GetEdgeCount();
    unsigned uPrefixLength = 0;

    if (uLegCount > 0)
        {
        const HMMEdge &FirstLeg = Route.GetEdge(0);
        const unsigned uPillarPL = FirstLeg.uPrefixLength;
        uPrefixLength = Aln.PillarPLToSeqPL(uPillarPL, uSeqIndex);
        }

    for (unsigned uLegIndex = 0; uLegIndex < uLegCount; ++uLegIndex)
        {
        HMMEdge Edge;
        const HMMEdge &Leg = Route.GetEdge(uLegIndex);
        char cState = Leg.cState;

        if ('D' != cState)
            {
            const unsigned uPillarIndex = Leg.uPrefixLength - 1;
            const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
            const bool bPause = Pillar.m_Pause[uSeqIndex];
            if (bPause)
                {
                if ('M' == cState)
                    cState = 'D';
                else if ('I' == cState)
                    continue;
                }
            }

        switch (cState)
            {
        case 'M':
            if (0 != uLegIndex)
                ++uPrefixLength;
            Edge.cState = 'M';
            Edge.uNodeIndex = Leg.uNodeIndex;
            Edge.uPrefixLength = uPrefixLength;
            Path.AppendEdge(Edge);
            break;

        case 'D':
            Edge.cState = 'D';
            Edge.uNodeIndex = Leg.uNodeIndex;
            Edge.uPrefixLength = uPrefixLength;
            Path.AppendEdge(Edge);
            break;

        case 'I':
            {
            const unsigned uPillarIndex = Leg.uPrefixLength - 1;
            const PILLAR &Pillar = Aln.GetPillar(uPillarIndex);
            const unsigned uFromColIndex = Pillar.m_uFromColIndex;
            const unsigned uToColIndex = Pillar.m_uToColIndex;
            unsigned uInserts = 0;
            for (unsigned uColIndex = uFromColIndex; uColIndex <= uToColIndex; ++uColIndex)
                {
                if (Aln.IsGap(uSeqIndex, uColIndex))
                    continue;
                ++uPrefixLength;
                Edge.cState = 'I';
                Edge.uNodeIndex = Leg.uNodeIndex;
                Edge.uPrefixLength = uPrefixLength;
                Path.AppendEdge(Edge);
                ++uInserts;
                }
        // Can't be no inserts, would have been a pause
            assert(uInserts > 0);
            break;
            }

        default:
            assert(false);
            }
        }
    }
