// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "MSA.h"

// Macros to simulate 2D matrices
#define DPM(NodeIndex, PrefixLength)    DPM_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPD(NodeIndex, PrefixLength)    DPD_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPI(NodeIndex, PrefixLength)    DPI_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPN(NodeIndex, PrefixLength)    DPN_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPS(NodeIndex, PrefixLength)    DPS_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTM(NodeIndex, PrefixLength)    DPTM_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTD(NodeIndex, PrefixLength)    DPTD_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]
#define DPTI(NodeIndex, PrefixLength)    DPTI_[(NodeIndex)*(uPrefixCount) + (PrefixLength)]

static bool ScoreEqLocal(SCORE s1, SCORE s2, int n)
    {
    return BTEq(s1, s2);
    }

#define VERBOSE    0

SCORE HMM::TraceBackAln(const MSA &a, const SCORE *DPM_, const SCORE *DPD_,
  const SCORE *DPI_, const unsigned *DPN_, const char *DPS_, const char *DPTM_,
  const char *DPTD_, const char *DPTI_, HMMPath &Route) const
    {
    const unsigned uPillarCount = a.GetPillarCount();
    const unsigned uPrefixCount = uPillarCount + 1;
    const unsigned uNodeCount = GetNodeCount();
    assert(uPillarCount > 0 && uNodeCount > 0);

    Route.Clear();
//    Route.SetTarget(a);

    unsigned uNodeIndex = uNodeCount - 1;
    char cToState;
    SCORE scoreMax = MINUS_INFINITY;
    unsigned uPrefixLength = 0;
    for (unsigned uPL = 1; uPL < uPrefixCount; ++uPL)
        {
        SCORE scoreTerminalGap = ScoreTerminalGap(uPillarCount - uPL);
        SCORE scoreD = Add2(scoreTerminalGap, DPD(uNodeIndex, uPL));
        SCORE scoreM = Add2(scoreTerminalGap, DPM(uNodeIndex, uPL));
        if (scoreD >= scoreMax)
            {
            cToState = 'D';
            uPrefixLength = uPL;
            scoreMax = scoreD;
            }
        if (scoreM >= scoreMax)
            {
            cToState = 'M';
            uPrefixLength = uPL;
            scoreMax = scoreM;
            }
        }
    assert(MINUS_INFINITY != scoreMax);
    assert(uPrefixLength > 0);

    for (;;)
        {
        char cFromState;
        switch (cToState)
            {
        case 'M':
            cFromState = DPTM(uNodeIndex, uPrefixLength);
            break;
        case 'D':
            cFromState = DPTD(uNodeIndex, uPrefixLength);
            break;
        case 'I':
            cFromState = DPTI(uNodeIndex, uPrefixLength);
            break;
        default:
            List("TraceBackAln, NodeIndex=%u PrefixLength=%u state=%c\n",
              uNodeIndex, uPrefixLength, cToState);
            //List("Path so far=\n");
            //Route.ListMe();
            //List("\n");
            //ListDP(uNodeCount, uPrefixCount, DPM_, DPD_, DPI_, DPN_, DPS_, DPTM_, DPTD_, DPTI_);
            Quit("Trace back failed");
            }

        HMMEdge Edge;
        Edge.cState = cToState;
        Edge.uNodeIndex = uNodeIndex;
        Edge.uPrefixLength = uPrefixLength;
        if ('M' == cToState)
            {
            assert(uPrefixLength > 0);
            Edge.scoreEmit = EmitM(a, uNodeIndex, uPrefixLength - 1);
            }
        else
            Edge.scoreEmit = 0;

        if ('M' == cToState || 'I' == cToState)
            {
            assert(uPrefixLength > 0);
            --uPrefixLength;
            }
        if ('M' == cToState || 'D' == cToState)
            {
            assert(uNodeIndex > 0);
            --uNodeIndex;
            }
	//        printf("Edge: ->%c%d [%d]\n",
	// Edge.cState,
	// Edge.uNodeIndex,
	// Edge.uPrefixLength);
#if    VERBOSE
        List("Edge: ->%c%d [%d]\n",
          Edge.cState,
          Edge.uNodeIndex,
          Edge.uPrefixLength);
#endif
        Route.PrependEdge(Edge);
        cToState = cFromState;
        if ('I' != cToState && 0 == uNodeIndex)
            break;
        }
    HMMEdge Edge;
    Edge.cState = cToState;
    Edge.uNodeIndex = uNodeIndex;
    Edge.uPrefixLength = uPrefixLength;
    if ('M' == cToState)
        {
        assert(uPrefixLength > 0);
        Edge.scoreEmit = EmitM(a, uNodeIndex, uPrefixLength - 1);
        }
    else
        Edge.scoreEmit = 0;
    Route.PrependEdge(Edge);

#if    VERBOSE
    List("Edge: ->%c%d [%d]\n",
        Edge.cState,
        Edge.uNodeIndex,
        Edge.uPrefixLength);
#endif

    //Edge.cState = 'S';
    //Edge.uNodeIndex = 0;
    //Edge.uPrefixLength = uPrefixLength;
    //Route.PrependEdge(Edge);

    SCORE scorePath = ScoreRouteAln(Route, a);

#if    VERBOSE
    List("scoreMax=%s scorePath=%s\n",
      ScoreToStr(scoreMax),
      ScoreToStr(scorePath));
#endif
    if (!ScoreEqLocal(scorePath, scoreMax, GetNodeCount()))
        {
        List("\n***WARNING*** TraceBackAln: scorePath=%s scoreMax=%s\n",
          ScoreToStr(scorePath),
          ScoreToStr(scoreMax));
        ListRoute(Route, a);
        }
    else
        {
        ;
#if    VERBOSE
        ListRoute(Route, a);
#endif
        }
    return scoreMax;
    }
