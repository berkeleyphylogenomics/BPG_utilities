// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"

#if    TRU64

#include <stdio.h>
#include <new>
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

extern double GetMemUseMB();

void OnOutOfMemory()
    {
    fprintf(stderr, "\n*** OUT OF MEMORY %g ***\n", GetMemUseMB());
    throw bad_alloc();
    }

void SetNewHandler()
    {
    int i;

    set_new_handler(OnOutOfMemory);

    char *e = getenv("LOB_UNLIMIT");
    if (e != 0 && !strcmp(e, "YES"))
        return;

    struct rlimit RL;

    i = getrlimit(RLIMIT_CPU, &RL); 
    if (i != 0) printf("Error %ld\n", errno);
    // printf("CPU %ld %ld\n", (unsigned long) RL.rlim_cur, RL.rlim_max);

    i = getrlimit(RLIMIT_FSIZE, &RL); 
    if (i != 0) printf("Error %ld\n", errno);
    // printf("FSIZE %ld %ld\n", (unsigned long) RL.rlim_cur, RL.rlim_max);

    i = getrlimit(RLIMIT_DATA, &RL); 
    if (i != 0) printf("Error %ld\n", errno);
    // printf("DATA %ld %ld\n", (unsigned long) RL.rlim_cur, RL.rlim_max);

    i = getrlimit(RLIMIT_STACK, &RL); 
    if (i != 0) printf("Error %ld\n", errno);
    // printf("STACK %ld %ld\n", (unsigned long) RL.rlim_cur, RL.rlim_max);

    i = getrlimit(RLIMIT_RSS, &RL); 
    if (i != 0) printf("Error %ld\n", errno);
    // printf("RSS %ld %ld\n", (unsigned long) RL.rlim_cur, RL.rlim_max);

    i = getrlimit(RLIMIT_NOFILE, &RL); 
    if (i != 0) printf("Error %ld\n", errno);
    // printf("NOFILE %ld %ld\n", (unsigned long) RL.rlim_cur, RL.rlim_max);

    i = getrlimit(RLIMIT_AS, &RL); 
    if (i != 0) printf("Error %ld\n", errno);
    // printf("AS %ld %ld\n", (unsigned long) RL.rlim_cur, RL.rlim_max);

    RL.rlim_cur = 2000000000;
    RL.rlim_max = 2000000000;;
    i = setrlimit(RLIMIT_DATA, &RL);
    if (i != 0)
        fprintf(stderr, "setrlimit = %d, errno = %d\n", i, errno);

    }

#endif // TRU64
