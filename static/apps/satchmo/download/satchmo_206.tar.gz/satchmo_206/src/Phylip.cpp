// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

/***
PHYLIP format description from its Web site
http://evolution.genetics.washington.edu/phylip.html

The tree is specified by nested pairs of parentheses, enclosing names
and separated by commas. If there are any blanks in the names, these
must be replaced by the underscore character "_". Trailing blanks in
the name may be omitted. The pattern of the parentheses indicates the
pattern of the tree by having each pair of parentheses enclose all the
members of a monophyletic group. The tree file could look like this: 

((Mouse,Bovine),(Gibbon,(Orang,(Gorilla,(Chimp,Human))))); 

In this tree the first fork separates the lineage leading to Mouse and
Bovine from the lineage leading to the rest. Within the latter group
there is a fork separating Gibbon from the rest, and so on. The entire
tree is enclosed in an outermost pair of parentheses. The tree ends with
a semicolon. In some programs such as DNAML, FITCH, and CONTML, the tree
will be unrooted. An unrooted tree should have its bottommost fork have
a three-way split, with three groups separated by two commas: 

(A,(B,(C,D)),(E,F)); 

Here the three groups at the bottom node are A, (B,C,D), and (E,F). The
single three-way split corresponds to one of the interior nodes of the
unrooted tree (it can be any interior node of the tree). The remaining
forks are encountered as you move out from that first node. In newer
programs, some are able to tolerate these other forks being multifur-
cations (multi-way splits). You should check the documentation files for
the particular programs you are using to see in which of these forms you
can expect the user tree to be in. Note that many of the programs that
actually estimate an unrooted tree (such as DNAPARS) produce trees in the
treefile in rooted form! This is done for reasons of arbitrary internal
bookkeeping. The placement of the root is arbitrary. We are working toward
having all programs be able to read all trees, whether rooted or unrooted,
multifurcating or bifurcating, and having them do the right thing with them.
But this is a long-term goal and it is not yet achieved. 

For programs that infer branch lengths, these are given in the trees in the
tree file as real numbers following a colon, and placed immediately after
the group descended from that branch. Here is a typical tree with branch
lengths: 

((cat:47.14069,(weasel:18.87953,((dog:25.46154,(raccoon:19.19959,
bear:6.80041):0.84600):3.87382,(sea_lion:11.99700,
seal:12.00300):7.52973):2.09461):20.59201):25.0,monkey:75.85931); 

Note that the tree may continue to a new line at any time except in the
middle of a name or the middle of a branch length, although in trees
written to the tree file this will only be done after a comma. 

These representations of trees are a subset of the standard adopted on
24 June 1986 at the annual meetings of the Society for the Study of
Evolution by an informal committee (its final session in Newick's lobster
restaurant - hence its name, the Newick standard) consisting of Wayne
Maddison (author of MacClade), David Swofford (PAUP), F. James Rohlf
(NTSYS-PC), Chris Meacham (COMPROB and the original PHYLIP tree drawing
programs), James Archie, William H.E. Day, and me. This standard is a
generalization of PHYLIP's format, itself based on a well-known representation
of trees in terms of parenthesis patterns which is due to the famous
mathematician Arthur Cayley, and which has been around for over a century.
The standard is now employed by most phylogeny computer programs but
unfortunately has yet to be decribed in a formal published description.
Other descriptions by me and by Gary Olsen can be accessed at: 

http://evolution.gs.washington.edu/phylip/newicktree.html 
***/

#include "lobster.h"
#include "Phylip.h"
#include "PhylipNode.h"
#include "TextFile.h"

#define VERBOSE    0

Phylip::~Phylip()
    {
    Clear();
    }

void Phylip::ToFile(TextFile &File) const
    {
    ToFile(File, m_ptrRoot);
    }

void Phylip::ToFile(TextFile &File, PhylipNode *ptrNode) const
    {
// Special case: if root node is leaf, must be in parentheses
    if (ptrNode->IsLeaf())
        File.PutString("(");

    ToFileNode(File, ptrNode);

// Special case: if root node is leaf, must be in parentheses
    if (ptrNode->IsLeaf())
        File.PutString(")");

// File terminates with semi-colon
    File.PutString(";\n");
    }

static void PutName(TextFile &File, const char szName[])
    {
    while (char c = *szName++)
        {
        if (isspace(c))
            File.PutChar('_');
        else if (isprint(c))
            File.PutChar(c);
        }
    }

void Phylip::ToFileNode(TextFile &File, PhylipNode *ptrNode) const
    {
    if (ptrNode->IsLeaf())
        File.PutFormat("%s", ptrNode->GetName());
    else
        {
    // Begin group
        File.PutString("(");

    // Left
        ToFileNode(File, ptrNode->GetLeft());
        File.PutString(",\n");

    // Right
        ToFileNode(File, ptrNode->GetRight());

    // Special case: if unrooted, output third branch from root (the "unroot")
        if (m_ptrRoot == ptrNode)
            {
            PhylipNode *ptrUnRoot = m_ptrRoot->GetParent();
            if (0 != ptrUnRoot)
                {
                File.PutString(",\n");
                ToFileNode(File, ptrUnRoot);
                }
            }

    // End group
        File.PutString(")\n");
        }
    if (ptrNode->HasLength())
        File.PutFormat(":%g", ptrNode->GetLength());
    }

void Phylip::Clear()
    {
    ClearSubtree(m_ptrRoot);
    m_ptrRoot = 0;
    m_ptrOutlier = 0;
    }

void Phylip::ClearSubtree(PhylipNode *ptrNode)
    {
    if (0 == ptrNode)
        return;
    ClearSubtree(ptrNode->GetLeft());
    ClearSubtree(ptrNode->GetRight());
    delete ptrNode;
    }

// Expect name to end with ".<class>", where <class> is integer > 0.
static unsigned GetClassFromName(const char strName[])
    {
    char *szName = strdup(strName);
// Strip edge length; if any
    char *ptrLastColon = strrchr(szName, ':');
//    if (NULL != ptrLastColon && isdigit(ptrLastColon[1]))
    if (NULL != ptrLastColon)
        *ptrLastColon = 0;
    char *ptrLastDot = strrchr(szName, '.');
    if (NULL == ptrLastDot)
        {
//        Quit("Invalid Phylip node name '%s'", szName);
        return 0;
        }
    unsigned uClass = (unsigned) atoi(ptrLastDot+1);
    if (uClass == 0)
        Quit("Invalid Phylip node name '%s'", szName);
    free(szName);
    return uClass;
    }

void Phylip::FromFile(TextFile &File)
    {
    Clear();
    m_ptrRoot = FromFileSubtree(File, true);
    }

PhylipNode *Phylip::FromFileSubtree(TextFile &File, bool bFirstNode)
    {
    char szToken[1024];
    File.GetTokenX(szToken, sizeof(szToken), ":(),");

    PhylipNode *ptrNode = new PhylipNode(m_uNodeCount++, this);

#if    VERBOSE
    List("FromFileSubtree Node=%lx\n", ptrNode);
    List("%u Start '%s'\n", File.GetLineNr(), szToken);
#endif

// First token is left-parenthesis or name
    if (0 == strcmp(szToken, "("))
        {
#if    VERBOSE
        List("Get left\n");
#endif
        PhylipNode *ptrLeft = FromFileSubtree(File);
        ptrNode->SetLeft(ptrLeft);
        ptrLeft->SetParent(ptrNode);

        File.GetTokenX(szToken, sizeof(szToken), ":(),");
#if    VERBOSE
        List("%u Expect comma or edge length '%s'\n", File.GetLineNr(), szToken);
#endif
    // Edge length?
        if (':' == szToken[0])
            {
#if    VERBOSE
            List("%u Expect length '%s'\n", File.GetLineNr(), szToken);
#endif
            File.GetTokenX(szToken, sizeof(szToken), ":(),");
            double dLength = atof(szToken);
            ptrNode->SetLength(dLength);
            }
         if (0 != strcmp(szToken, ","))
            Quit("Invalid Phylip tree, expecting comma (line %u)",
              File.GetLineNr());

#if    VERBOSE
        List("Get right\n");
#endif
        PhylipNode *ptrRight = FromFileSubtree(File);
        ptrNode->SetRight(ptrRight);
        ptrRight->SetParent(ptrNode);

        File.GetTokenX(szToken, sizeof(szToken), ":(),");
#if    VERBOSE
        List("%u Expect right paren or comma'%s'\n", File.GetLineNr(), szToken);
#endif
    // Special case for unrooted trees: first node has three children.
        if (bFirstNode && 0 == strcmp(szToken, ","))
            {
#if    VERBOSE
            List("Get unroot\n");
#endif
        // Phylip class represents unrooted tree by having
        // a parent of the "root" node.
            PhylipNode *ptrSubtree = FromFileSubtree(File);
            ptrNode->SetParent(ptrSubtree);
            ptrSubtree->SetParent(ptrNode);
            }
        else if (0 != strcmp(szToken, ")"))
            Quit("Invalid Phylip tree, expected ')', got '%s'", szToken);
        }
    else
        {
#if    VERBOSE
        List("%u Expect name '%s'\n", File.GetLineNr(), szToken);
#endif
        ptrNode->SetName(szToken);
        unsigned uClass = GetClassFromName(szToken);
        ptrNode->SetClass(uClass);
        if (uClass + 1 > m_uClassCount)
            m_uClassCount = uClass + 1;
        if ('$' == szToken[0])
            {
            if (0 != m_ptrOutlier)
                Quit("Two outliers in %s", File.GetFileName());
            m_ptrOutlier = ptrNode;
            }
        }

// Group may be followed by edge length
    char c;
    File.GetCharX(c);
    if (c == ':')
        {
        File.GetTokenX(szToken, sizeof(szToken), ":(),");
#if    VERBOSE
        List("%u Expect edge length '%s'\n", File.GetLineNr(), szToken);
#endif
        double dLength = atof(szToken);
        ptrNode->SetLength(dLength);
        }
    else
        File.PushBack(c);

#if    VERBOSE
    List("Return node=%lx\n", ptrNode);
#endif
    return ptrNode;
    }

void Phylip::ListMe() const
    {
    if (IsRooted())
        {
        List("[Rooted]\n");
        ListSubtree(m_ptrRoot);
        }
    else
        {
        List("[Unrooted]\n");
        ListSubtree(m_ptrRoot);
        List("third branch:\n");
        ListSubtree(m_ptrRoot->GetParent());
        }
    }

void Phylip::ListNodeCounts(const PhylipNode *ptrNode) const
    {
    const unsigned *ptrCounts = ptrNode->GetCounts();
    if (0 == ptrCounts)
        return;
    for (unsigned n = 0; n < m_uClassCount; ++n)
        if (ptrCounts[n] > 0)
            List(" %u=%u", n, ptrCounts[n]);
    }

void Phylip::ListSubtree(const PhylipNode *ptrNode) const
    {
    if (0 == ptrNode)
        return;
    List("%4u  ", ptrNode->GetIndex());
    if (ptrNode->HasLength())
        List(":%-7.2g  ", ptrNode->GetLength());
    else
        List("          ");
    if (ptrNode->IsLeaf())
        {
        if (0 != ptrNode->GetParent())
            List("P%4u               %s[%u]   ",
             ptrNode->GetParent()->GetIndex(),
             ptrNode->GetName(),
             ptrNode->GetClass());
        else
            List("P????  %s[%u]   ",
             ptrNode->GetName(),
             ptrNode->GetClass());
        ListNodeCounts(ptrNode);
        }
    else if (ptrNode->IsRoot())
        {
        List("<Root  L%4u R%4u   ",
          ptrNode->GetLeft()->GetIndex(),
          ptrNode->GetRight()->GetIndex());
        }
    else
        {
        List("P%4u  L%4u R%4u   ",
          ptrNode->GetParent()->GetIndex(),
          ptrNode->GetLeft()->GetIndex(),
          ptrNode->GetRight()->GetIndex());
        ListNodeCounts(ptrNode);
        }
    List("\n");

    ListSubtree(ptrNode->GetLeft());
    ListSubtree(ptrNode->GetRight());
    }

void Phylip::AllocCountsNode(PhylipNode *ptrNode, unsigned uClassCount)
    {
    if (0 == ptrNode)
        return;
    ptrNode->AllocCounts(uClassCount);
    AllocCountsNode(ptrNode->GetLeft(), uClassCount);
    AllocCountsNode(ptrNode->GetRight(), uClassCount);
    }

static void ListLeafNames(PhylipNode *ptrNode)
    {
    if (ptrNode->IsLeaf())
        List(" %s", ptrNode->GetName());
    else
        {
        ListLeafNames(ptrNode->GetRight());
        ListLeafNames(ptrNode->GetLeft());
        }
    }

void Phylip::ListNFPSubtrees(PhylipNode *ptrNode, unsigned N) const
    {
    if (ptrNode->IsNFP(N))
        {
        List("%uFP[%u] ", N, ptrNode->GetIndex());
        ListLeafNames(ptrNode);
        List("\n");
        }
    if (ptrNode->IsLeaf())
        return;
    else
        {
        ListNFPSubtrees(ptrNode->GetLeft(), N);
        ListNFPSubtrees(ptrNode->GetRight(), N);
        }
    }

void Phylip::ListZFNSubtree(PhylipNode *ptrNode, unsigned uClass) const
    {
    if (ptrNode->IsZFN(uClass))
        {
        List("ZFN class %u node %u ", uClass, ptrNode->GetIndex());
        ListLeafNames(ptrNode);
        List("\n");
        }
    if (ptrNode->IsLeaf())
        return;
    else
        {
        ListZFNSubtree(ptrNode->GetLeft(), uClass);
        ListZFNSubtree(ptrNode->GetRight(), uClass);
        }
    }

unsigned Phylip::GetNFPCount(PhylipNode *ptrNode, unsigned N) const
    {
    if (0 == ptrNode)
        return 0;
    return (int) ptrNode->IsNFP(N) + GetNFPCount(ptrNode->GetRight(), N) +
      GetNFPCount(ptrNode->GetLeft(), N);
    }

// No class zero, so must adjust by one
unsigned Phylip::GetClassCount() const
    {
    return m_uClassCount;
    }

void Phylip::AllocCounts()
    {
    AllocCountsNode(m_ptrRoot, m_uClassCount);
    }

void Phylip::CalcCounts()
    {
    m_ptrRoot->CalcCounts();
    }

// The root is inserted into parent edge of the given node.
Phylip *Phylip::Root(PhylipNode *ptrRootChild) const
    {
    m_ptrRoot->Validate();

    PhylipNode *ptrParent = ptrRootChild->GetUnrootedParent();

    PhylipNode *ptrNewRoot = new PhylipNode(m_ptrRoot->GetIndex(), this);
    PhylipNode *ptrNewLeft = EdgeToNode(ptrRootChild, ptrParent);
    PhylipNode *ptrNewRight = EdgeToNode(ptrParent, ptrRootChild);

    ptrNewRoot->SetLeft(ptrNewLeft);
    ptrNewRoot->SetRight(ptrNewRight);

    ptrNewLeft->SetParent(ptrNewRoot);
    ptrNewRight->SetParent(ptrNewRoot);

    ptrNewRoot->Validate();

    Phylip *ptrNewTree = new Phylip;
    ptrNewTree->SetRoot(ptrNewRoot);
    return ptrNewTree;
    }

PhylipNode *Phylip::EdgeToNode(const PhylipNode *ptrFromNode,
  const PhylipNode *ptrToNode) const
    {
    if (0 == ptrToNode)
        return 0;

    const unsigned uIndex = ptrToNode->GetIndex();
    PhylipNode *ptrNewNode = new PhylipNode(uIndex, this);
    ptrNewNode->SetName(ptrToNode->GetName());

    const PhylipNode *ptrLeft = ptrToNode->GetLeft();
    const PhylipNode *ptrRight = ptrToNode->GetRight();
    const PhylipNode *ptrParent = ptrToNode->GetUnrootedParent();

    PhylipNode *ptrNewLeft;
    PhylipNode *ptrNewRight;
    if (ptrFromNode == ptrLeft)
        {
        ptrNewLeft = EdgeToNode(ptrToNode, ptrParent);
        ptrNewRight = EdgeToNode(ptrToNode, ptrRight);
        }
    else if (ptrFromNode == ptrRight)
        {
        ptrNewLeft = EdgeToNode(ptrToNode, ptrLeft);
        ptrNewRight = EdgeToNode(ptrToNode, ptrParent);
        }
    else if (ptrFromNode == ptrParent)
        {
        ptrNewLeft = EdgeToNode(ptrToNode, ptrLeft);
        ptrNewRight = EdgeToNode(ptrToNode, ptrRight);
        }
    else
        Quit("EdgeToNode");

    ptrNewNode->SetRight(ptrNewRight);
    ptrNewNode->SetLeft(ptrNewLeft);

    if (0 != ptrNewLeft)
        ptrNewLeft->SetParent(ptrNewNode);

    if (0 != ptrNewRight)
        ptrNewRight->SetParent(ptrNewNode);

    return ptrNewNode;
    }

void Phylip::ListFromEdge(PhylipNode *ptrNode, PhylipNode *ptrPrevNode) const
    {
    if (0 == ptrNode)
        return;

    PhylipNode *ptrLeft = ptrNode->GetLeft();
    PhylipNode *ptrRight = ptrNode->GetRight();
    PhylipNode *ptrParent = ptrNode->GetParent();

    if (ptrPrevNode != ptrLeft && ptrPrevNode != ptrRight &&
      ptrPrevNode != ptrParent)
        Quit("ListFromEdge");

    List("Edge %3u-%3u ", ptrNode->GetIndex(), ptrPrevNode->GetIndex());
    ptrNode->ListMe();

    if (ptrPrevNode != ptrLeft)
        ListFromEdge(ptrLeft, ptrNode);
    if (ptrPrevNode != ptrRight)
        ListFromEdge(ptrRight, ptrNode);
    if (ptrPrevNode != ptrParent)
        ListFromEdge(ptrParent, ptrNode);
    }

void Phylip::SetRoot(PhylipNode *ptrRoot)
    {
    m_ptrRoot = ptrRoot;
    }

PhylipNode *Phylip::FindNode(unsigned uIndex, PhylipNode *ptrNode)
    {
    if (0 == ptrNode)
        return 0;
    if (ptrNode->GetIndex() == uIndex)
        return ptrNode;
    PhylipNode *ptrFoundNode = FindNode(uIndex, ptrNode->GetLeft());
    if (0 != ptrFoundNode)
        return ptrFoundNode;
    return FindNode(uIndex, ptrNode->GetRight());
    }

PhylipNode *Phylip::GetNode(unsigned uIndex)
    {
    return FindNode(uIndex, GetRoot());
    }

unsigned Phylip::GetSingletonClassCount() const
    {
    PhylipNode *ptrRoot = GetRoot();
    const unsigned *uCounts = ptrRoot->GetCounts();
    const unsigned uClassCount = GetClassCount();
    unsigned uSingletonCount = 0;
    for (unsigned uClass = 1; uClass < uClassCount; ++uClass)
        {
        if (uCounts[uClass] == 1)
            ++uSingletonCount;
        }
    return uSingletonCount;
    }

unsigned Phylip::GetNonEmptyClassCount() const
    {
    PhylipNode *ptrRoot = GetRoot();
    const unsigned *uCounts = ptrRoot->GetCounts();
    const unsigned uClassCount = GetClassCount();
    unsigned uNonEmptyCount = 0;
    for (unsigned uClass = 1; uClass < uClassCount; ++uClass)
        {
        if (uCounts[uClass] > 0)
            ++uNonEmptyCount;
        }
    return uNonEmptyCount;
    }

void Phylip::ListZFNSubtrees() const
    {
    for (unsigned uClass = 1; uClass < GetClassCount(); ++uClass)
        ListZFNSubtree(GetRoot(), uClass);
    }

unsigned Phylip::GetNFPCount(unsigned N) const
    {
    return GetNFPCount(GetRoot(), N);
    }
