// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#ifndef SatchmoParams_h
#define SatchmoParams_h

class TextFile;

const double dDefaultMaxNIC = 5;
const double dDefaultMinAvgAff = 0.01;
const unsigned uDefaultWindowLength = 7;
const unsigned uDefaultGapOpenPct = 75;
const unsigned uDefaultGapExtendPct = 75;

class SatchmoParams
    {
public:
    SatchmoParams()
        {
        SetDefaults();
        }
    ~SatchmoParams() {}

    void SetDefaults()
        {
        m_dMaxNIC = dDefaultMaxNIC;
        m_dMinAvgAff = dDefaultMinAvgAff;
        m_uWindowLength = uDefaultWindowLength;
        m_uGapOpenPct = uDefaultGapOpenPct;
        m_uGapExtendPct = uDefaultGapExtendPct;
        }
    void FromFile(TextFile &File);
    void ToFile(TextFile &File) const;
    void ToString(char szStr[], unsigned uBytes) const;

    double GetMaxNIC() const { return m_dMaxNIC; }
    double GetMinAvgAff() const { return m_dMinAvgAff; }
    SCORE GetMinAvgAffScore() const { return DoubleToScore(m_dMinAvgAff); };
    unsigned GetWindowLength() const { return m_uWindowLength; }
    unsigned GetGapOpenPct() const { return m_uGapOpenPct; }
    unsigned GetGapExtendPct() const { return m_uGapExtendPct; }

    void SetMaxNIC(double dMaxNIC) { m_dMaxNIC = dMaxNIC; }
    void SetMinAvgAff(double dMinAvgAff) { m_dMinAvgAff = dMinAvgAff; }
    void SetWindowLength(unsigned uWindowLength) { m_uWindowLength = uWindowLength; }
    void SetGapOpenPct(unsigned uGapOpenPct) { m_uGapOpenPct = uGapOpenPct; }
    void SetGapExtendPct(unsigned uGapExtendPct) { m_uGapExtendPct = uGapExtendPct; }

private:
    double m_dMaxNIC;
    double m_dMinAvgAff;
    unsigned m_uWindowLength;
    unsigned m_uGapOpenPct;
    unsigned m_uGapExtendPct;
    };

#endif // SatchmoParams_h
