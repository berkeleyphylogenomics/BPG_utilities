// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "MSA.h"

void ComparePair(const MSA &msaTest, unsigned uTestSeqIndexA,
  unsigned uTestSeqIndexB, const MSA &msaRef, unsigned uRefSeqIndexA,
  unsigned uRefSeqIndexB, double *ptrdSP, double *ptrdPS, double *ptrdCS)
    {
    int *iRefMapAr;
    int *iRefMapBr;
    int *iTestMapAr;
    int *iTestMapBr;

    MakePairMaps(msaTest, uTestSeqIndexA, uTestSeqIndexB, msaRef, uRefSeqIndexA,
      uRefSeqIndexB, &iTestMapAr, &iTestMapBr, &iRefMapAr, &iRefMapBr);

    const int iLengthAr = (int) msaRef.GetSeqLength(uRefSeqIndexA);
    const int iLengthBr = (int) msaRef.GetSeqLength(uRefSeqIndexB);

    ComparePairMap(iTestMapAr, iTestMapBr, iRefMapAr, iRefMapBr, iLengthAr, iLengthBr,
      ptrdSP, ptrdPS, ptrdCS);

    delete[] iRefMapAr;
    delete[] iRefMapBr;
    delete[] iTestMapAr;
    delete[] iTestMapBr;
    }
