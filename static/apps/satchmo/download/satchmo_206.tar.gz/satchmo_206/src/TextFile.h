// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include <stdio.h>

struct TEXTFILEPOS
    {
    unsigned uOffset;
    unsigned uLineNr;
    unsigned uColNr;
    };

const unsigned TextFileBufferSize = 256;

class TextFile
    {
private:
// no default c'tor, not implemented
    TextFile();

public:
    virtual ~TextFile();

// mandatory c'tor with filename
    TextFile(const char szFileName[], bool bWrite = false);

    bool GetLine(char szLine[], unsigned uBytes);
    bool GetTrimLine(char szLine[], unsigned uBytes);
    void GetLineX(char szLine[], unsigned uBytes);
    void GetLineXC(char szLine[], unsigned uBytes);

    bool GetToken(char szToken[], unsigned uBytes, const char szCharTokens[] = "{}");
    void GetTokenX(char szToken[], unsigned uBytes, const char szCharTokens[] = "{}");
    void GetTokenXC(char szToken[], unsigned uBytes, const char szCharTokens[] = "{}");

    void Skip();
    void SkipLine();
    void Rewind();
    TEXTFILEPOS GetPos();
    void SetPos(TEXTFILEPOS Pos);
    bool GetChar(char &c);
    void GetCharX(char &c);
    void GetCharXC(char &c);

    unsigned GetLineNr() { return m_uLineNr; }

    void PutString(const char szLine[]);
    void PutFormat(const char szFormat[], ...);
    void PutChar(char c);

    const char *GetFileName() { return m_ptrName; }

    void PushBack(int c) { m_cPushedBack = c; }

private:
    FILE *m_pFile;
    unsigned m_uLineNr;
    unsigned m_uColNr;
    char *m_ptrName;
    bool m_bLastCharWasEOL;
    int m_cPushedBack;
    };
