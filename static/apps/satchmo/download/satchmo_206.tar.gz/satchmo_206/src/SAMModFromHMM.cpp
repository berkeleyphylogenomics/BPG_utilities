// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "SAMMod.h"
#include <math.h>

// See comments in HMMFromSAMMod.cpp.
void SAMMod::FromHMM(const HMM &Model)
    {
    Clear();

    Model.AssertNormalized();

    const unsigned uhmmNodeCount = Model.GetNodeCount();
    if (0 == uhmmNodeCount)
        return;
    m_uNodeCount = uhmmNodeCount + 2;
    m_Nodes = new SAMNode[m_uNodeCount];

// Node 0 (Begin) and 1 (first main model node, which
// corresponds to node 0 in Lobster model) are special cases.
    SAMNode &BeginNode = m_Nodes[0];
    SAMNode &FirstNode = m_Nodes[1];
    const HMMNode &hmmFirstNode = Model.GetNode(0);

// Match emit probs are zero in Begin node
// (which is not a true match state, it's the start state).
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        BeginNode.m_probMatchEmit[uLetter] = 0;

// Insert emit probs in Begin node are set to the null model.
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        BeginNode.m_probInsertEmit[uLetter] = ScoreToProb(GetNullEmitScore(uLetter));

// Only transitions into Begin node states are x->I.
// There is no delete state in Begin, so S->I and I->I are 
// the only non-zero transitions.
// (Start state S is M0, i.e. match state in Begin node).
    BeginNode.m_probMM = 0;
    BeginNode.m_probMD = 0;
    BeginNode.m_probIM = 0;
    BeginNode.m_probID = 0;
    BeginNode.m_probDM = 0;
    BeginNode.m_probDD = 0;
    BeginNode.m_probDI = 0;

// No delete state in Begin node
    FirstNode.m_probDM = 0;
    FirstNode.m_probDD = 0;

// I don't understand what SAM is really doing at the beginning
// of the model, so this is a hack. Typical model files have
// a constant value 0.633784 for the Begin node I->I transition.
// (I would have expected to see the null model I->I which this
// surely isn't, that would be something like 350/351 = 0.997).
// Denote I0 by N for N-terminal insert state.
    const PROB SAM_NN = (PROB) 0.633785;
    BeginNode.m_probII = SAM_NN;

// Set the other transitions by requiring that the relative
// probability of entering the M and D state from both S and N
// is the same as in Lobster:
//        S->M1 / S->D1 = firstM / firstD
//        N->M1 / N->D1 = firstM / firstD
// Using N->N + N->M1 + N->D1 = 1, this gives:
    const PROB r = Model.GetFirstM() / Model.GetFirstD();
    FirstNode.m_probIM = r*(1 - SAM_NN)/(1 + r);
    FirstNode.m_probID = 1 - SAM_NN - FirstNode.m_probIM;

    PROB r2 = FirstNode.m_probIM / FirstNode.m_probID;
    if (fabs(r - r2) > 0.001)
        Quit("Bad algebra");

// For transitions out of M, we hack even mode. All three S->x
// transitions vary in SAM models built with w0.5, and I don't
// really understand what's going on. However, S->I0 doesn't
// vary very much, it's typically about 0.012. We therefore
// fix this value, the S->M and S->D values then follow
// by requiring the ratio to be firstM / firstD.
    const PROB SAM_SN = (PROB) 0.012;
    BeginNode.m_probMI = SAM_SN;

    FirstNode.m_probMM = r*(1 - SAM_SN)/(1 + r);
    FirstNode.m_probMD = 1 - SAM_SN - FirstNode.m_probMM;

    r2 = FirstNode.m_probIM / FirstNode.m_probID;
    if (fabs(r - r2) > 0.001)
        Quit("Bad algebra");

// Insert transitions in the first node correspond exactly to Lobster.
    FirstNode.m_probMI = ScoreToProb(hmmFirstNode.m_scoreMI + GetNullEmitTransScore());
    FirstNode.m_probDI = ScoreToProb(hmmFirstNode.m_scoreDI + GetNullEmitTransScore());
    FirstNode.m_probII = ScoreToProb(hmmFirstNode.m_scoreII + GetNullEmitTransScore());

// Transitions in typical main model nodes
    for (unsigned uhmmNodeIndex = 1; uhmmNodeIndex < uhmmNodeCount; ++uhmmNodeIndex)
        {
        const HMMNode &hmmNode = Model.GetNode(uhmmNodeIndex);
        const HMMNode &hmmPrevNode = Model.GetNode(uhmmNodeIndex - 1);
        SAMNode &Node = m_Nodes[uhmmNodeIndex + 1];

        Node.m_probMM = ScoreToProb(hmmPrevNode.m_scoreMM + GetNullEmitTransScore());
        Node.m_probMI = ScoreToProb(hmmNode.m_scoreMI + GetNullEmitTransScore());
        Node.m_probMD = ScoreToProb(hmmPrevNode.m_scoreMD);

        Node.m_probIM = ScoreToProb(hmmPrevNode.m_scoreIM + GetNullEmitTransScore());
        Node.m_probII = ScoreToProb(hmmNode.m_scoreII + GetNullEmitTransScore());
        Node.m_probID = ScoreToProb(hmmPrevNode.m_scoreID);

        Node.m_probDM = ScoreToProb(hmmPrevNode.m_scoreDM + GetNullEmitTransScore());
        Node.m_probDI = ScoreToProb(hmmNode.m_scoreDI + GetNullEmitTransScore());
        Node.m_probDD = ScoreToProb(hmmPrevNode.m_scoreDD);
        }

// Main model node match states.
    for (unsigned uhmmNodeIndex = 0; uhmmNodeIndex < uhmmNodeCount; ++uhmmNodeIndex)
        {
        const HMMNode &hmmNode = Model.GetNode(uhmmNodeIndex);
        SAMNode &Node = m_Nodes[uhmmNodeIndex + 1];

        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            Node.m_probMatchEmit[uLetter] =
              ScoreToProb(hmmNode.m_scoreMatchEmit[uLetter] + GetNullEmitScore(uLetter));
        }

// Main model node insert states. Lobster has no insert state in last node.
    for (unsigned uhmmNodeIndex = 0; uhmmNodeIndex + 1 < uhmmNodeCount; ++uhmmNodeIndex)
        {
        const HMMNode &hmmNode = Model.GetNode(uhmmNodeIndex);
        SAMNode &Node = m_Nodes[uhmmNodeIndex + 1];

        for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
            Node.m_probInsertEmit[uLetter] =
              ScoreToProb(hmmNode.m_scoreInsertEmit[uLetter] + GetNullEmitScore(uLetter));
        }

// Last main model node special case.
// Insert state emits like null model
    SAMNode &LastNode = m_Nodes[m_uNodeCount - 2];
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        LastNode.m_probInsertEmit[uLetter] = GetNullEmitProb(uLetter);

// Insert state self-loop appears to be this constant, which
// is different from the Begin node self-loop. Mystifying.
    const PROB SAM_CC = (PROB) 0.769326;
    LastNode.m_probII = SAM_CC;

// Last node (End) special case.
// Only has 3 non-zero parameters, the x->M transitions
// that move into the terminal state.
    SAMNode &EndNode = m_Nodes[m_uNodeCount - 1];
    const HMMNode hmmLastNode = Model.GetNode(uhmmNodeCount - 1);

// The D->I and M->I transitions into the last insert state
// vary considerably in different SAM models. I don't understand
// this, so I'm picking values that look roughly typical.
// Denote last I state by C for C-terminal.
    const PROB SAM_MC = (PROB) 0.012;
    const PROB SAM_DC = (PROB) 0.05;

    LastNode.m_probMI = SAM_MC;
    LastNode.m_probDI = SAM_DC;

// No delete or insert state in End node.
    EndNode.m_probMD = 0;
    EndNode.m_probID = 0;
    EndNode.m_probDD = 0;
    EndNode.m_probDI = 0;
    EndNode.m_probMI = 0;
    EndNode.m_probII = 0;

// Transitions into end node M (i.e., T) determined by normalizing
// exits from M, D and I in last node.
    EndNode.m_probMM = 1 - LastNode.m_probMI;    // = 1 - SAM_MC = 0.98
    EndNode.m_probDM = 1 - LastNode.m_probDI;    // = 1 - SAM_DC = 0.95
    EndNode.m_probIM = 1 - LastNode.m_probII;    // = 1 - SAM_CC = 0.230674

// End node is not a true match state (it's the terminal state)
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        EndNode.m_probMatchEmit[uLetter] = 0;

// No insert state in End node.
    for (unsigned uLetter = 0; uLetter < MAX_ALPHA; ++uLetter)
        EndNode.m_probInsertEmit[uLetter] = 0;

    Validate();
    }
