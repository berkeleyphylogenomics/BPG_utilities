// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWLAM.h"
#include "PWLA.h"
#include "PWAL.h"

SCORE PWLAM::LAMScore(const FCOUNT fcCountsA[MAX_ALPHA],
  const FCOUNT fcCountsB[MAX_ALPHA])
    {
    const SCORE scoreLA = PWLA::LAScore(fcCountsA, fcCountsB);
    if (scoreLA < 0.177)
        return scoreLA;

    const SCORE scoreAL = PWAL::ALScore(fcCountsA, fcCountsB);
    return scoreAL;
    }
