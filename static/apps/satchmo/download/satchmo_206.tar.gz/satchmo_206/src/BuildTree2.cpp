// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

/***
The SATCHMO algorithm builds a binary tree from a set
of input sequences as follows.

A tree node x has a multiple sequence alignment MSAx and a
hidden Markov model HMMx.

The algorithm maintains a forest of trees. 

In the initial state, each tree is composed of one node. 
Each such node has an MSA containing one input sequence
and an HMM generated from that sequence. These nodes will
become the leaves of the final tree.

An iteration joins two trees by making them the children of
a new node. Iterations continue until there is only one tree
in the forest.

An iteration proceeds as follows.

1. Find the closest pair of nodes. Distance between two nodes x
and y is:

    d(x, y) = HMMx(MSAy) + HMMy(MSAx)

Closest pair of nodes (w, z) has maximum value of d over all pairs.
(So d is really a sort of inverse distance). If there are several
pairs with the maximum distance, one is chosen arbitrarily.

2. Decide which of the closest pair is the template node p and
which is the target node g. Mnemonic: temPlate, tarGet.
The template node is the one that will contribute an HMM to
the next step. The target node's HMM is not used again once
the distance has been calculated. The rule is:

    If HMMw(MSAz) >= HMMz(MSAw), p=w and z=g,
    otherwise p=z and g=w.

This rule may be modified slightly to maximise the consensus
region because of special concerns about misidentifying deletes
as inserts when scores are close.

3. Align MSAp and MSAg simultaneously to HMMp, creating MSAj.
In detail, this is done as follows.

3a. MSAg is aligned by finding the most probable path of MSAg
through HMMp, giving MSAgp.

3b. MSAp is aligned by the faster method of remembering the column
number in MSAp that was used to generate a given node in HMMp.
This gives MSApp.

3c. MSAgp and MSApp are merged to create MSAj, adding "dotted"
positions as needed to deal with insertions in one but not the other.

Note that affinities are calculated for MSAg positions only. A column
in MSAj is considered to be aligned iff the positions coming from MSAg
meet the avg affinity threshhold. Unaligned positions are indicated
by lower-case letters.

4. Generate a new model HMMj from MSAj. A column in MSAj is assigned
to a match state in HMMj iff the column contains upper-case letters
and or deletes (dashes) only. All other columns are assigned to
insert states.

5. Assign HMMj and MSAj to a new node j.
***/

#include "lobster.h"
#include "GTree2.h"
#include "GNode2.h"
#include "MSA.h"
#include "SJPM.h"
#include "SeqVect.h"
#include "SatchmoParams.h"
#include "TextFile.h"
#include "HMM.h"
#include "HMMPath.h"
#include "Clust.h"
#include "Bete.h"
#include "PWBase.h"
#include "PPPW.h"
 
#define MAX_SUMMARY_LINE 500
unsigned g_uAvgSeqLength = 100;
FILE *m_pFile;

double GTree2::Distance(GNode2 *ptrDisjointTpl, GNode2 *ptrDisjointTgt)
    {
        
    HMM &modelTpl = ptrDisjointTpl->m_Model;
    MSA &msaTarget = ptrDisjointTgt->m_MSA;

    if (0 == modelTpl.GetNodeCount()){
        return VERY_NEGATIVE_DOUBLE;
    }

    HMMPath MPP;
    SCORE Score;
    double s1, s2, dScore;
    if (! g_strAlignStyle ||  0 == strcmp(g_strAlignStyle, "global" ) )
        dScore = ScoreToDouble(modelTpl.ViterbiAln(msaTarget, MPP));
    else if (! g_strAlignStyle || 0 == strcmp(g_strAlignStyle, "select")){
        // Choose the higher scoring one
        s1 =  ScoreToDouble(modelTpl.ViterbiAln(msaTarget, MPP));
        s2 =  ScoreToDouble(modelTpl.ViterbiAlnLL(msaTarget, MPP));
        if (s1 > s2)
            dScore = s1;
        else dScore=s2;
    }
    else
        dScore = ScoreToDouble(modelTpl.ViterbiAlnLL(msaTarget, MPP));
    
    double dModelLength = (double) modelTpl.GetNodeCount();


//// @@TODO
//    {
//    const MSA &a = ptrDisjointTpl->m_MSA;
//    const MSA &b = ptrDisjointTgt->m_MSA;
//    for (unsigned n = 0; n < a.GetSeqCount(); ++n)
//        List("%s", a.GetSeqName(n));
//    List(" >> ");
//    for (unsigned n = 0; n < b.GetSeqCount(); ++n)
//        List("%s", b.GetSeqName(n));
//    List(" Raw score %g Length %g Dist %g\n",
//      dScore, dModelLength, dScore / dModelLength);
//    }
  //  printf("dScore %g, dModelLength %u.  \n", dScore, dModelLength);
    return dScore / dModelLength;
    }

void GTree2::ScoreDisjointPair(GNode2 *ptrDisjointA, GNode2 *ptrDisjointB)
    {
    double DistA_B = Distance(ptrDisjointA, ptrDisjointB);
    unsigned uBIndex = ptrDisjointB->m_uNodeIndex;
    ptrDisjointA->m_Dist[uBIndex] = DistA_B;
   // printf ("uBIndex %u, DistA_B %g .\n", uBIndex,DistA_B);
    }

void GTree2::Join2(MSA &msaTarget, HMM &modelTpl, MSA &msaJoined,
  HMM &modelJoined, HMMPath &MPP, double &dRawNIC)
    {
// Run target alignment against template HMM.
        if (! g_strAlignStyle ||  0 == strcmp(g_strAlignStyle, "global" ) )
        modelTpl.ViterbiAln(msaTarget, MPP);
    else if (! g_strAlignStyle || 0 == strcmp(g_strAlignStyle, "select")) {
    // Try to choose the best alignment style for joining...
    HMMPath localPath, globalPath;
    double localScore, globalScore;
    globalScore = ScoreToDouble(modelTpl.ViterbiAln(msaTarget, globalPath));
    localScore = ScoreToDouble(modelTpl.ViterbiAln(msaTarget, localPath));
    if (globalScore > localScore)
        MPP.Copy(globalPath);
    else MPP.Copy(localPath);
    } else
        modelTpl.ViterbiAlnLL(msaTarget, MPP);
   
// Create combined alignment of template and target.
    modelTpl.Align(MPP, msaJoined, msaTarget);
    dRawNIC = msaJoined.GetRawNIC();
    msaJoined.BuildPillars();

//    msaJoined.ValidateBreakMatrices();

// Build HMMj from MSAj.
//    modelJoined.FromAln(msaJoined);
    //modelJoined.FromAlnBitSave(msaJoined, 0.5, 5, 10);
   modelJoined.FromAlnBitSave(msaJoined, 0.5, 3, 10);
   
    }

bool GTree2::Iterate()
    {
    fprintf(stderr, "Iterating...\n");
    Validate();
// Find closest pair
    GNode2 *ptrClosestTpl = 0;
    GNode2 *ptrClosestTgt = 0;
    double distClosest = VERY_NEGATIVE_DOUBLE;

    for (GNode2 *pA = m_ptrDisjoints; pA; pA = pA->m_ptrNext)
        for (GNode2 *pB = pA->m_ptrNext; pB; pB = pB->m_ptrNext)
            {
            assert(pA != pB);
#if    1
            double Dist = pA->m_Dist[pB->m_uNodeIndex] +
              pB->m_Dist[pA->m_uNodeIndex];
#else
            double d1 = pA->m_Dist[pB->m_uNodeIndex];
            double d2 = pB->m_Dist[pA->m_uNodeIndex];
            double Dist = Max2(d1, d2);
#endif
        //// TODO@@
        //    {
        //    const MSA &a = pA->m_MSA;
        //    const MSA &b = pB->m_MSA;
        //    for (unsigned n = 0; n < a.GetSeqCount(); ++n)
        //        List("%s", a.GetSeqName(n));
        //    List("--");
        //    for (unsigned n = 0; n < b.GetSeqCount(); ++n)
        //        List("%s", b.GetSeqName(n));
        //    List("= %g\n", Dist);
        //    }
            if (Dist > distClosest)
                {
                distClosest = Dist;
       //     fprintf(stderr, "%s", g_strJoinMethod);
                if(g_strJoinMethod && 0 == strcmp(g_strJoinMethod, "longer")){
               //     fprintf(stderr, "using longer hmm\n");
                    if (pA->m_Model.GetNodeCount() > pB->m_Model.GetNodeCount()){
                        ptrClosestTpl = pA;
                        ptrClosestTgt = pB;
                    } else {
                        ptrClosestTpl = pB;
                        ptrClosestTgt = pA;    
                    }
                } else {
                
                if (pA->m_Dist[pB->m_uNodeIndex] > pB->m_Dist[pA->m_uNodeIndex])
                    {
                    ptrClosestTpl = pA;
                    ptrClosestTgt = pB;
                    }
                else
                    {
                    ptrClosestTpl = pB;
                    ptrClosestTgt = pA;
                    }
                    
                }
                }
            }
//// TODO@@
//    {
//    List("\nClosest: ");
//    const MSA &a = ptrClosestTpl->m_MSA;
//    const MSA &b = ptrClosestTgt->m_MSA;
//    for (unsigned n = 0; n < a.GetSeqCount(); ++n)
//        List("%s", a.GetSeqName(n));
//    List("--");
//    for (unsigned n = 0; n < b.GetSeqCount(); ++n)
//        List("%s", b.GetSeqName(n));
//    List(" dist = %g\n", distClosest);
//    }

    GNode2 *ptrJoin = m_ptrJoins;
fprintf(stderr, "closest distance %f\n", distClosest);
// If no distances, all HMMs are of zero length
    if (VERY_NEGATIVE_DOUBLE == distClosest)
        return false;
// for satchmo_pw only -- xia
//    assert(0 != ptrClosestTpl);
//    assert(0 != ptrClosestTgt);
//    assert(0 != ptrJoin);

// Update forest data structures
    ptrClosestTpl->DeleteFromList(m_ptrDisjoints);
    ptrClosestTgt->DeleteFromList(m_ptrDisjoints);
    ptrJoin->DeleteFromList(m_ptrJoins);
    ptrJoin->AddToList(m_ptrDisjoints);

    ptrClosestTpl->m_ptrParent = ptrJoin;
    ptrClosestTgt->m_ptrParent = ptrJoin;

    ptrJoin->m_ptrLeft = ptrClosestTpl;
    ptrJoin->m_ptrRight = ptrClosestTgt;

// Sanity check
    Validate();

// Join the chosen nodes.
    HMM &modelTpl = ptrClosestTpl->m_Model;
    MSA &msaTarget = ptrClosestTgt->m_MSA;
    MSA &msaJoin = ptrJoin->m_MSA;
    printf("Now Joining node %u and %u together.\n",ptrClosestTpl->m_uNodeIndex, ptrClosestTgt->m_uNodeIndex );
    if (g_strBSPath !=0 ) //bootstrapping 
    {
        Join2(msaTarget, modelTpl, msaJoin, ptrJoin->m_Model, ptrJoin->m_MPP,ptrJoin->m_dRawNIC);
	ptrJoin->m_ptrLeft->m_MSA.SetSeqName(0,msaJoin.GetSeqName(0));  
	ptrJoin->m_ptrRight->m_MSA.SetSeqName(0,msaJoin.GetSeqName(1));  
	
   } else {
        Join2(msaTarget, modelTpl, msaJoin, ptrJoin->m_Model, ptrJoin->m_MPP,ptrJoin->m_dRawNIC);
    }
      

// Don't need child leaves any more, free resources
    if (0 != g_ptrSmoFile)
        {
        WriteNodeToSmoFile(*g_ptrSmoFile, *ptrClosestTgt, g_bSaveHMMs, g_bSaveMSS);
        WriteNodeToSmoFile(*g_ptrSmoFile, *ptrClosestTpl, g_bSaveHMMs, g_bSaveMSS);
        }
    //    ptrClosestTpl->Clear();
    //   ptrClosestTgt->Clear();

// Score the new join against all other disjoints
    for (GNode2 *pA = m_ptrDisjoints; pA; pA = pA->m_ptrNext)
        {
        if (pA == ptrJoin)
            continue;
        ScoreDisjointPair(pA, ptrJoin);
        ScoreDisjointPair(ptrJoin, pA);
        }
    //    fprintf (stderr, "Join %u node\n", ptrJoin->m_uNodeIndex);
    Validate();
    return true;
    }




int GTree2::Iterate2(int tgt_index, int tpt_index) //only for pairwise joining satchmo
    {
    fprintf(stderr, "Iterating 2 ...\n");
    Validate();
// Find closest pair
    GNode2 *ptrClosestTpl = 0;
    GNode2 *ptrClosestTgt = 0;
    double distClosest = VERY_NEGATIVE_DOUBLE;

    for (GNode2 *pA = m_ptrDisjoints; pA; pA = pA->m_ptrNext)
        for (GNode2 *pB = pA->m_ptrNext; pB; pB = pB->m_ptrNext)
            {
            assert(pA != pB);
#if    1
            double Dist = pA->m_Dist[pB->m_uNodeIndex] +
              pB->m_Dist[pA->m_uNodeIndex];
#else
            double d1 = pA->m_Dist[pB->m_uNodeIndex];
            double d2 = pB->m_Dist[pA->m_uNodeIndex];
            double Dist = Max2(d1, d2);
#endif
              if (Dist > distClosest)
                {
                distClosest = Dist;
       //     fprintf(stderr, "%s", g_strJoinMethod);
                if(g_strJoinMethod && 0 == strcmp(g_strJoinMethod, "longer")){
                    fprintf(stderr, "using longer hmm\n");
                    if (pA->m_Model.GetNodeCount() > pB->m_Model.GetNodeCount()){
                        ptrClosestTpl = pA;
                        ptrClosestTgt = pB;
                    } else {
                        ptrClosestTpl = pB;
                        ptrClosestTgt = pA;    
                    }
                } else {
                
                if (pA->m_Dist[pB->m_uNodeIndex] > pB->m_Dist[pA->m_uNodeIndex])
                    {
                    ptrClosestTpl = pA;
                    ptrClosestTgt = pB;
                    }
                else
                    {
                    ptrClosestTpl = pB;
                    ptrClosestTgt = pA;
                    }
                    
                }
                }
            }

    GNode2 *ptrJoin = m_ptrJoins;
  fprintf(stderr, "closest distance %f\n", distClosest);
// If no distances, all HMMs are of zero length
    if (VERY_NEGATIVE_DOUBLE == distClosest)
        return 2;
    assert(0 != ptrClosestTpl);
    assert(0 != ptrClosestTgt);
    assert(0 != ptrJoin);

// Update forest data structures
    ptrClosestTpl->DeleteFromList(m_ptrDisjoints);
    ptrClosestTgt->DeleteFromList(m_ptrDisjoints);
    ptrJoin->DeleteFromList(m_ptrJoins);
    ptrJoin->AddToList(m_ptrDisjoints);

    ptrClosestTpl->m_ptrParent = ptrJoin;

    ptrJoin->m_ptrLeft = ptrClosestTpl;
    ptrJoin->m_ptrRight = ptrClosestTgt;

// Sanity check
    Validate();

// Join the chosen nodes.
    HMM &modelTpl = ptrClosestTpl->m_Model;
    MSA &msaTarget = ptrClosestTgt->m_MSA;
    MSA &msaJoin = ptrJoin->m_MSA;

    printf("Now Joining node %u and %u together.\n",ptrClosestTpl->m_uNodeIndex, ptrClosestTgt->m_uNodeIndex );
  
    printf("Root of tgt and tmpt: %u and %u .\n",tgt_index,tpt_index);
    int matches=0;
    if (ptrClosestTpl->m_uNodeIndex == tgt_index)
      {
	matches=1;
      }
    if (ptrClosestTpl->m_uNodeIndex == tpt_index)
      {
	matches=2;
      }
    if (ptrClosestTgt->m_uNodeIndex == tgt_index)
      {
	matches=1;
      }
    if (ptrClosestTgt->m_uNodeIndex == tpt_index)
      {
	matches=2;
      }
    if ((ptrClosestTgt->m_uNodeIndex == tpt_index) &&  (ptrClosestTpl->m_uNodeIndex == tgt_index))
      {
	matches=3;
      }
    if ((ptrClosestTgt->m_uNodeIndex == tpt_index) &&  (ptrClosestTgt->m_uNodeIndex == tgt_index))
      {
	matches=3;
      }
    if ((ptrClosestTgt->m_uNodeIndex == tgt_index) &&  (ptrClosestTpl->m_uNodeIndex == tpt_index))
      {
	matches=3;
      }

    if ((ptrClosestTpl->m_uNodeIndex == tgt_index) &&  (ptrClosestTpl->m_uNodeIndex == tpt_index))
      {
	matches=3;
      }
      if (g_strBSPath !=0 ) //bootstrapping 
    {
        
        Join2(msaTarget, modelTpl, msaJoin, ptrJoin->m_Model, ptrJoin->m_MPP,ptrJoin->m_dRawNIC);
        
    } else {
        Join2(msaTarget, modelTpl, msaJoin, ptrJoin->m_Model, ptrJoin->m_MPP,ptrJoin->m_dRawNIC);
    }
      

// Don't need child leaves any more, free resources
    if (0 != g_ptrSmoFile)
        {
        WriteNodeToSmoFile(*g_ptrSmoFile, *ptrClosestTgt, g_bSaveHMMs, g_bSaveMSS);
        WriteNodeToSmoFile(*g_ptrSmoFile, *ptrClosestTpl, g_bSaveHMMs, g_bSaveMSS);
        }
    ptrClosestTpl->Clear();
    ptrClosestTgt->Clear();

// Score the new join against all other disjoints
    for (GNode2 *pA = m_ptrDisjoints; pA; pA = pA->m_ptrNext)
        {
        if (pA == ptrJoin)
            continue;
        ScoreDisjointPair(pA, ptrJoin);
        ScoreDisjointPair(ptrJoin, pA);
        }
    //    fprintf (stderr, "Join %u node\n", ptrJoin->m_uNodeIndex);
    Validate();
    // return 0;
    return matches;
    }


void GTree2::Build(const SatchmoParams &SP, SJPM *ptrMonitor)
    {
    m_SatchmoParams = SP;
    m_ptrSJPM = ptrMonitor;

    unsigned uSeqCount = 0;
    unsigned uJoinCount = 0;
#ifdef PARALLEL
if (g_my_rank == 0){
#endif
    m_InputSeqs.StripGaps(); 
    m_InputSeqs.ToUpper();
    uSeqCount = m_InputSeqs.Length();
    assert(uSeqCount > 0);

// There are 2N-1 nodes in binary tree with N leaves.
    m_uNodeCount = 2*uSeqCount - 1;
    m_Nodes = new GNode2*[m_uNodeCount];

    if (0 != g_ptrSmoFile)
        g_ptrSmoFile->PutFormat("nodes %u\n", m_uNodeCount);

// Create Nodes        
    unsigned uNodeIndex;
    for (uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        GNode2 *ptrNode = new GNode2;
        m_Nodes[uNodeIndex] = ptrNode;
        ptrNode->m_Model.SetSatchmoParams(&m_SatchmoParams);

        }
    for (uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex){
        m_Nodes[uNodeIndex]->AllocDistVector(m_uNodeCount);
        m_Nodes[uNodeIndex]->m_uNodeIndex = uNodeIndex;
    }    




        
// Initialize NodeList with sequences and MSAs
    unsigned uTotalLength = 0;
    for (unsigned uSeqIndex = 0; uSeqIndex < uSeqCount; ++uSeqIndex)
        {
        Seq *ptrSeq = m_InputSeqs[uSeqIndex];
        MSA &msa = m_Nodes[uSeqIndex]->m_MSA;
        msa.SetAlphabet(ALPHABET_Amino);
        ptrSeq->ExtractUngapped(msa);
        uTotalLength += ptrSeq->GetUngappedLength();
        msa.SetAllAligned();
        msa.BuildPillars();
//        msa.ValidateBreakMatrices();
        }
        
    if (uSeqCount > 0)
        g_uAvgSeqLength = uTotalLength / uSeqCount;

    for (uNodeIndex = uSeqCount; uNodeIndex < m_uNodeCount; ++uNodeIndex)
        {
        if (uNodeIndex > uSeqCount)
            m_Nodes[uNodeIndex]->m_ptrPrev = m_Nodes[uNodeIndex-1];
        if (uNodeIndex != m_uNodeCount - 1)
            m_Nodes[uNodeIndex]->m_ptrNext = m_Nodes[uNodeIndex+1];
        }
    
//    for (uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
//        m_Nodes[uNodeIndex]->m_uNodeIndex = uNodeIndex;

    for (uNodeIndex = 0; uNodeIndex < uSeqCount; ++uNodeIndex)
        {
        GNode2 *ptrLeaf = m_Nodes[uNodeIndex];
        MSA &a = ptrLeaf->m_MSA;
        HMM &Model = ptrLeaf->m_Model;
        ptrLeaf->SetName(a.GetSeqName(0));

        if (0 != ptrMonitor)
            ptrMonitor->OnBuildLeaf(uNodeIndex+1, uSeqCount);

        Model.FromAln(a);
        if (uNodeIndex > 0)
            ptrLeaf->m_ptrPrev = m_Nodes[uNodeIndex-1];
        if (uNodeIndex != uSeqCount - 1)
            ptrLeaf->m_ptrNext = m_Nodes[uNodeIndex+1];
        }
        
// N-1 non-leaf nodes in a binary tree with N leaves, so perform N-1 joins.
    uJoinCount = uSeqCount - 1;

    m_ptrDisjoints = m_Nodes[0];
    m_ptrJoins = m_Nodes[uSeqCount];

#ifdef PARALLEL
} //end root activities
#endif

   InitializeDist(ptrMonitor, uSeqCount);

#ifdef PARALLEL
if (g_my_rank == 0){
#endif
    for (unsigned uJoinIndex = 0; uJoinIndex < uJoinCount; ++uJoinIndex)
        {
        
        if (0 != ptrMonitor)
            ptrMonitor->OnIteration2(uJoinIndex+1, uJoinCount);
        bool bContinue = Iterate();
        if (!bContinue)
            {
            fprintf(stderr, "All HMMs have zero length, quitting.\n");
            List("All HMMs have zero length, quitting.\n");
            return;
            }
        //if (HomHack())//todo
        //    {
        //    m_ptrRoot = m_ptrDisjoints;
        //    return;//todo
        //    }
        }

    assert(0 != m_ptrDisjoints);
    assert(0 == m_ptrJoins);
    assert(0 == m_ptrDisjoints->m_ptrNext);

    m_ptrRoot = m_ptrDisjoints;

    if (0 != g_ptrSmoFile)
        {
        WriteNodeToSmoFile(*g_ptrSmoFile, *m_ptrRoot, g_bSaveHMMs, g_bSaveMSS);
        g_ptrSmoFile->PutString(".\n");
        }
        #ifdef PARALLEL        
}
#endif
    }

static bool IsRefSeqName(const char *ptrName)
    {
    return !strchr(ptrName, '@');
    }

static bool HasRefSeqs(const MSA &a)
    {
    for (unsigned n = 0; n < a.GetSeqCount(); ++n)
        {
        const char *ptrName = a.GetSeqName(n);
        if (IsRefSeqName(ptrName))
            return true;
        }
    return false;
    }

//bool GTree2::HomHack()
//    {
//    GNode2 *ptrRefSeqs = 0;
//
//    const MSA *ptrMSA = 0;
//    const MSA *ptrRefSeqsMSA = 0;
//    for (GNode2 *ptrCluster = m_ptrDisjoints; ptrCluster;
//      ptrCluster = ptrCluster->m_ptrNext)
//        {
//        ptrMSA = &ptrCluster->m_MSA;
//        if (HasRefSeqs(*ptrMSA))
//            {
//            if (0 != ptrRefSeqs)
//                return false;
//            ptrRefSeqs = ptrCluster;
//            ptrRefSeqsMSA = ptrMSA;
//            }
//        }
//    TextFile File("c:\\tmp\\homhack.fasta", true);
//    assert(0 != ptrRefSeqsMSA);
//    ptrRefSeqsMSA->ToFASTAFile(File);
//    return true;
//    }
