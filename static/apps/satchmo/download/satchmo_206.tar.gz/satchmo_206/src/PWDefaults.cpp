// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWBase.h"

struct DefaultValues
    {
    PWCLASS Class;
    SCORE scoreGapOpen;
    SCORE scoreGapExtend;
    SCORE scoreShift;
    };

static DefaultValues Table[] =
    {

#define    DEF(c, op, ex, sh)    { PWCLASS_##c, (SCORE) (op), (SCORE) (ex), (SCORE) (sh) },

//    Class        Open        Extend        Shift
DEF(YL,            -0.2,        -0.02,        0.45)
DEF(YLD,        -0.2,        -0.02,        0.45)
DEF(YLDF,        -0.2,        -0.02,        0.45)
DEF(LA,            -3.587,        -0.055,        0)
DEF(AL,            -1.9,        -0.8,        0)
DEF(MdotF,        -1.5,        -0.1,        0)
DEF(MdotM,        -1.5,        -0.1,        0)
DEF(MdotP,        -1.5,        -0.1,        0)
DEF(FdotF,        -0.23,        -0.00115,    0)
DEF(GdotG,        -0.23,        -0.00115,    0)
DEF(PdotP,        -0.23,        -0.00115,    0)
DEF(FdotP,        -0.23,        -0.00115,    0)
DEF(MM,            -10,        -1,            0)
DEF(RE,            -2,            -0.02,        0)
DEF(REF,        -2,            -0.02,        0)
DEF(YLF,        -0.3,        -0.02,        0)
DEF(Dir,        -0.23,        -0.00115,    0)
DEF(EuclidP,    0,            0,            0)
DEF(EuclidF,    0,            0,            0)
DEF(CorrelP,    0,            0,            0)
DEF(CorrelF,    0,            0,            0)
DEF(RankP,        0,            0,            0)
DEF(RankF,        0,            0,            0)
#undef DEF

    };
const unsigned uClassCount = sizeof(Table)/sizeof(Table[0]);

SCORE PWBase::GetDefaultGapOpen() const
    {
    const PWCLASS c = GetClass();
    for (unsigned n = 0; n < uClassCount; ++n)
        if (Table[n].Class == c)
            return Table[n].scoreGapOpen;
    Quit("Unknown PW class %u", c);
    return 0;
    }

SCORE PWBase::GetDefaultGapExtend() const
    {
    const PWCLASS c = GetClass();
    for (unsigned n = 0; n < uClassCount; ++n)
        if (Table[n].Class == c)
            return Table[n].scoreGapExtend;
    Quit("Unknown PW class %u", c);
    return 0;
    }

SCORE PWBase::GetDefaultShift() const
    {
    const PWCLASS c = GetClass();
    for (unsigned n = 0; n < uClassCount; ++n)
        if (Table[n].Class == c)
            return Table[n].scoreShift;
    Quit("Unknown PW class %u", c);
    return 0;
    }
