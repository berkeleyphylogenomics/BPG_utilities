// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Phylip.h"
#include "PhylipNode.h"
#include "Clust.h"

void Phylip::FromClust(const Clust &C)
    {
    Clear();

    const unsigned uRootNodeIndex = C.GetRootNodeIndex();
    PhylipNode *ptrRoot = FromClustNode(C, uRootNodeIndex);
    m_ptrRoot = ptrRoot;

// If clustering is unrooted, then C has a (pseudo-)root node;
// the two edges from the root should be considered as a single
// edge whose length is the sum of the two lengths.
// The pseudo-root has no parent.
// The Phylip class represents unrooted trees by arbitrarily
// designating a node as the root; but the root does have a parent.
// The Clust class therefore has one extra node versus
// Phylip when the tree is unrooted.
// We arbitrarily designate the left child of the Clust root
// as the Phylip root.
    if (C.IsRooted())
        {
    // This is defensive, it probably isn't necessary;
    // ensures there is no branch length out of the root,
    // which is invalid in a Phylip tree file.
        m_ptrRoot->ClearLength();
        return;
        }

    //List("Before unrooting...\n");
    //ListMe();

    PhylipNode *ptrLeft = ptrRoot->GetLeft();
    PhylipNode *ptrRight = ptrRoot->GetRight();
    if (0 == ptrLeft || 0 == ptrRight)
        Quit("Phylip::FromClust, root node is leaf");

    const double dLength = ptrLeft->GetLength() + ptrRight->GetLength();

    m_ptrRoot = ptrLeft;
    m_ptrRoot->SetParent(ptrRight);
    ptrRight->SetParent(m_ptrRoot);
    m_ptrRoot->ClearLength();
    ptrRight->SetLength(dLength);
    delete ptrRoot;

    //List("After unrooting...\n");
    //ListMe();
    }

PhylipNode *Phylip::FromClustNode(const Clust &C, unsigned uNodeIndex)
    {
    PhylipNode *ptrNode = new PhylipNode(uNodeIndex, this);

    const double dLength = C.GetLength(uNodeIndex);
    ptrNode->SetLength(dLength);

    if (C.IsLeaf(uNodeIndex))
        {
        const char *ptrName = C.GetNodeName(uNodeIndex);
        ptrNode->SetName(ptrName);
        return ptrNode;
        }

    const unsigned uLeftIndex = C.GetLeftIndex(uNodeIndex);
    const unsigned uRightIndex = C.GetRightIndex(uNodeIndex);

    PhylipNode *ptrLeft = FromClustNode(C, uLeftIndex);
    PhylipNode *ptrRight = FromClustNode(C, uRightIndex);

    ptrNode->SetLeft(ptrLeft);
    ptrNode->SetRight(ptrRight);

    ptrLeft->SetParent(ptrNode);
    ptrRight->SetParent(ptrNode);

    return ptrNode;
    }
