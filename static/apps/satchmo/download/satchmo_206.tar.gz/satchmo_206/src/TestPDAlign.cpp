// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "HMM.h"
#include "HMMPath.h"
#include "Seq.h"
#include "TextFile.h"
#include "EnumPaths.h"

#define    VERBOSE        0
#define ADD_NULL    0

#define    P(NodeIndex, Pos)    m_Probs[m_uLength*(NodeIndex) + (Pos)]

class EPS_TestPD : public EnumPathsSink
    {
public:
    EPS_TestPD()
        {
        m_Probs = 0;
        m_uLength = 0;
        m_uNodeCount = 0;
        m_uPathCount = 0;
        m_scoreSimpleNull = MINUS_INFINITY;
        }

    virtual ~EPS_TestPD()
        {
        delete[] m_Probs;
        }

    void Init(Seq &s, HMM &Model)
        {
        m_ptrSeq = &s;
        m_ptrModel = &Model;
        m_uLength = s.Length();
        m_uNodeCount = Model.GetNodeCount();
        size_t LM = m_uLength*m_uNodeCount;
        m_Probs = new PROB[LM];
        for (unsigned i = 0; i < LM; ++i)
            m_Probs[i] = 0;
        m_probTotal = 0;
        m_scoreSimpleNull = m_ptrModel->ScoreSimpleNullSeq(*m_ptrSeq);
        }

    virtual void OnPath(const HMMPath &Path)
        {
        ++m_uPathCount;

        SCORE scorePath = m_ptrModel->ScorePathSeq(Path, *m_ptrSeq);
#if    !ADD_NULL
        scorePath += m_scoreSimpleNull;
#endif
        PROB probPath = ScoreToProb(scorePath);
        assert(probPath > 0 && probPath <= 1);

#if    VERBOSE
        List("Path prob %-10.3g ", probPath);
        Path.ListMe();
#endif
        m_probTotal += probPath;
        const unsigned uEdgeCount = Path.GetEdgeCount();
        for (unsigned uEdgeIndex = 0; uEdgeIndex < uEdgeCount; ++uEdgeIndex)
            {
            const HMMEdge &Edge = Path.GetEdge(uEdgeIndex);
            if (Edge.cState != 'M')
                continue;
            assert(Edge.uPrefixLength > 0);
            const unsigned uPos = Edge.uPrefixLength - 1;
            P(Edge.uNodeIndex, uPos) += probPath;
            }
        }

    void ListMe()
        {
        List("\nBrute force posterior probs:\n");
        List("Path count %u probTotal=%g\n", m_uPathCount, m_probTotal);
        double dPathCount = m_uPathCount;
        for (unsigned uNodeIndex = 0; uNodeIndex < m_uNodeCount; ++uNodeIndex)
            {
            List("%5u ", uNodeIndex);
            for (unsigned uPos = 0; uPos < m_uLength; ++uPos)
                List(" %10.3g", P(uNodeIndex, uPos));
            List("\n");
            }
        }

public:
    unsigned m_uPathCount;
    PROB m_probTotal;
    Seq *m_ptrSeq;
    HMM *m_ptrModel;
    PROB *m_Probs;
    SCORE m_scoreSimpleNull;
    unsigned m_uNodeCount;
    unsigned m_uLength;
    };

void TestPDAlign(int argc, char *argv[])
    {
    TextFile SeqFile("c:\\tmp\\seq.fasta");
    Seq s;
    s.FromFASTAFile(SeqFile);

    TextFile ModelFile("c:\\tmp\\test.hmm");
    HMM Model;
    Model.FromFile(ModelFile);

    HMMPath pathViterbi;
    SCORE scoreViterbi = Model.ViterbiSeq(s, GLOBAL_MODEL, GLOBAL_SEQ, pathViterbi);

#if    ADD_NULL
    Model.AddSimpleNull();
#else
    SCORE scoreSimpleNull = Model.ScoreSimpleNullSeq(s);
#endif

#if    VERBOSE
    Model.ListMe();
    List("\n");
#endif

    List("Forward:\n");
    SCORE *DPMFwd;
    SCORE scoreFwd = Model.ForwardSeq(s, &DPMFwd);
#if    !ADD_NULL
    scoreFwd += scoreSimpleNull;
#endif
    List("Forward score %s prob %.3g\n\n", ScoreToStr(scoreFwd), ScoreToProb(scoreFwd));

    List("Backward:\n");
    SCORE *DPMBwd;
    SCORE scoreBwd = Model.BackwardSeq(s, &DPMBwd);
#if    !ADD_NULL
    scoreBwd += scoreSimpleNull;
#endif
    List("Backward score %s prob %.3g\n", ScoreToStr(scoreBwd), ScoreToProb(scoreBwd));

    assert(BTEq(scoreFwd, scoreBwd));

    const unsigned uNodeCount = Model.GetNodeCount();
    const unsigned uLength = s.Length();

    PROB *P = new PROB[uNodeCount*uLength];
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        for (unsigned uPos = 0; uPos < uLength; ++uPos)
            {
            SCORE f = DPMFwd[uNodeIndex*(uLength + 1) + uPos + 1];
            SCORE b = DPMBwd[uNodeIndex*(uLength + 1) + uPos + 1];
            SCORE scorePD = f + b;
#if    !ADD_NULL
            scorePD += scoreSimpleNull;
#endif
            PROB p = ScoreToProb(scorePD);
            assert(p >= 0 && p <= 1);
            P[uNodeIndex*uLength + uPos] = p;
            }

    List("\nPosterior probs from Fwd/Bwd DP matrices=\n");
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        for (unsigned uPos = 0; uPos < uLength; ++uPos)
            List("%10.3g ", P[uNodeIndex*uLength + uPos]);
        List("\n");
        }

    HMMPath pathPD;
    Model.PDAlign(P, uLength, pathPD);

    delete[] DPMFwd;
    delete[] DPMBwd;

    {
    EPS_TestPD e;
    e.Init(s, Model);
    EnumPaths(Model.GetNodeCount(), s.Length(), GLOBAL_MODEL, GLOBAL_SEQ, e);
    e.ListMe();
    }

    List("\nViterbi path:\n");
    pathViterbi.ListMe();

    List("\nPosterior decoded path:\n");
    pathPD.ListMe();
    }
