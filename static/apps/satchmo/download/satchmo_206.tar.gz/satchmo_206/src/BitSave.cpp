// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

/***
Bit savings (Karplus, personal communication):

    1/n sum_{1<=i<n} sum_a P_i(a) log_2 ( P_i(a)/P_0(a) )

where a varies over the 20 amino acids, P_i(a) is the regularized
probability of a in the ith column, and P_0(a) is the background
probability (which we get by applying the Dirichlet mixture regularizer
to the all-zero count vector).

0.5 bits/column was chosen to approximately optimize the results on
fold recognition for a test set in which no two sequences had more
than 20% identity.  I suspect that dropping much below 0.5 bits will
never be very useful (there isn't enough signal left in the typical
length sequences) and going above 1.0 bits will not help much either.

One can plot the entropy of a traditional subsitution matrix
regularizer as a function of PAM distance, and also the %identity as a
function of PAM distance, to get an idea how the entropy and %identity
are related.
***/

#include "lobster.h"
#include "HMM.h"
#include "DirMix.h"
#include <math.h>    // needed for log2 on Linux

// CalcPriorBackgroud calculates P_0(a) (see above).
static void CalcPriorBackground(PROB Probs[])
    {
    WCOUNT wCounts[MAX_ALPHA];
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        wCounts[n] = 0;

    g_ptrdirmixMatchEmitPrior->CountsToProbs(wCounts, Probs);
    }

// GetPriorBackgroud returns P_0(a) (see above) with a cache-on-
// first-use for efficiency (AddDirichletPrior is relatively slow).
void GetPriorBackground(PROB Prob[])
    {
    static bool bCached = false;
    static PROB probBack[MAX_ALPHA];

    if (!bCached)
        {
        CalcPriorBackground(probBack);
        bCached = true;
        }
    memcpy(Prob, probBack, MAX_ALPHA*sizeof(PROB));
    }

void AssertNormalized(const double p[])
    {
    double dSum = 0.0;
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        {
        assert(p[n] >= 0);
        assert(p[n] <= 1.0);
        dSum += p[n];
        }
    if (dSum < 0.99 || dSum > 1.01)
        Quit("Not normalized");
    }

void AssertNormalized(const PROB p[])
    {
    double dSum = 0.0;
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        {
        assert(p[n] >= 0);
        assert(p[n] <= 1.0);
        dSum += p[n];
        }
    if (dSum < 0.99 || dSum > 1.01)
        Quit("Not normalized");
    }

void AssertNormalizedOrZero(const PROB p[])
    {
    double dSum = 0.0;
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        {
        assert(p[n] >= 0.0);
        assert(p[n] <= 1.0);
        dSum += p[n];
        }
    if (0.0 == dSum)
        return;
    if (dSum < 0.99 || dSum > 1.01)
        Quit("Not normalized");
    }

// Calculates relative entropy of two probability
// distributions A and B. Also known as the Kullback-
// Liebler divergence.
double RelativeEntropy(const PROB probA[], const PROB probB[])
    {
#if    _DEBUG
    AssertNormalized(probA);
    AssertNormalized(probB);
#endif

    double dEntropy = 0.0;
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        {
        if (0.0 == probB[n])
            continue;
        dEntropy += probA[n]*log2(probA[n]/probB[n]);
        }
    return dEntropy;
    }

double HMM::BitsSaved() const
    {
    PROB probBack[MAX_ALPHA];
    GetPriorBackground(probBack);

    const unsigned uNodeCount = GetNodeCount();
    double dTotal = 0.0;
    for (unsigned uNodeIndex = 0; uNodeIndex < uNodeCount; ++uNodeIndex)
        {
        const HMMNode &Node = GetNode(uNodeIndex);
        PROB Probs[MAX_ALPHA];
        for (unsigned n = 0; n < MAX_ALPHA; ++n)
            Probs[n] = ScoreToProb(Node.m_scoreMatchEmit[n] + GetNullEmitScore(n));
        double dRE = RelativeEntropy(Probs, probBack);
        dTotal += dRE;
        }
    double dEntropyPerNode = dTotal/uNodeCount;
    return dEntropyPerNode;
    }
