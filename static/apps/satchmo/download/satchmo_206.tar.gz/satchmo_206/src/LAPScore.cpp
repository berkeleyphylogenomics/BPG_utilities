// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "PWLAP.h"
#include "PWLA.h"
#include <math.h>

// Log average score, probability version
SCORE PWLAP::LAPScore(const PROB probA[MAX_ALPHA], const PROB probB[MAX_ALPHA])
    {
    FCOUNT fcCountsA[MAX_ALPHA];
    FCOUNT fcCountsB[MAX_ALPHA];

    double dSumA = 0.0;
    double dSumB = 0.0;
    for (unsigned n = 0; n < MAX_ALPHA; ++n)
        {
        PROB a = probA[n];
        PROB b = probB[n];
        fcCountsA[n] = a;
        fcCountsB[n] = b;
        dSumA += a;
        dSumB += b;
        }

    return PWLA::LAScore(fcCountsA, fcCountsB);
    }
