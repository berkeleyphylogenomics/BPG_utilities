// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "Seq.h"
#include "MSA.h"

#define VERBOSE    0

static void ListSeq(const MSA &a, unsigned uSeq)
    {
    const unsigned uColsPerLine = 60;
    unsigned uColCount = a.GetColCount();
    if (0 == uColCount)
        {
        List("Empty alignment\n");
        return;
        }
    unsigned uLineCount = (uColCount - 1)/uColsPerLine + 1;
    for (unsigned uLineIndex = 0; uLineIndex < uLineCount; ++uLineIndex)
        {
        unsigned uFirstColIndex = uLineIndex*uColsPerLine;
        unsigned uCols = uColCount - uFirstColIndex;
        if (uCols > uColsPerLine)
            uCols = uColsPerLine;
        unsigned uLastColIndex = uFirstColIndex + uCols - 1;
        List("                ");
        for (unsigned uColIndex = uFirstColIndex; uColIndex <= uLastColIndex; uColIndex += 10)
            List("%10u", uColIndex/10);
        List("\n");
        List("                ");
        for (unsigned uColIndex = uFirstColIndex; uColIndex <= uLastColIndex; ++uColIndex)
            List("%u", uColIndex%10);
        List("\n");
        List("%15s ", a.GetSeqName(uSeq));
        for (unsigned uColIndex = uFirstColIndex; uColIndex <= uLastColIndex; ++uColIndex)
            List("%c", a.GetChar(uSeq, uColIndex));
        List("\n\n");
        }
    }

static void ListSeq2(const MSA &a, unsigned uSeq)
    {
    ListSeq(a, uSeq);

    MSA msaSeq;
    a.ExtractUnaligned(uSeq, msaSeq);
    ListSeq(msaSeq, 0);
    }

void BaliScore(const MSA &msaRef, const MSA &msaTest, double *ptrdSP,
  double *ptrdTC, double *ptrdPS)
    {
#if    VERBOSE
    List("Test:\n");
    msaTest.ListMe();
    List("\nRef:\n");
    msaRef.ListMe();
#endif

    const unsigned uRefSeqCount = msaRef.GetSeqCount();
    if (0 == uRefSeqCount)
        Quit("BaliScore: No sequences in reference alignment");

    unsigned *RefSeqIndexToTestSeqIndex = new unsigned[uRefSeqCount];
    for (unsigned uRefSeqIndex = 0; uRefSeqIndex < uRefSeqCount; ++uRefSeqIndex)
        {
        const char *ptrName = msaRef.GetSeqName(uRefSeqIndex);
        unsigned uTestSeqIndex;
        bool bFound = msaTest.GetSeqIndex(ptrName, &uTestSeqIndex);
        if (!bFound)
            Quit("BaliScore: Seq %s not found in test alignment", ptrName);
        RefSeqIndexToTestSeqIndex[uRefSeqIndex] = uTestSeqIndex;
        }

// Count aligned pairs in test alignment
    unsigned uTestAlignedPairCount = 0;
    const unsigned uTestColCount = msaTest.GetColCount();
    for (unsigned uTestColIndex = 0; uTestColIndex < uTestColCount; ++uTestColIndex)
        {
        const COLINFO &CI = msaTest.GetColInfo(uTestColIndex);
        if (!CI.m_bAligned)
            continue;
        for (unsigned uRefSeqIndex1 = 0; uRefSeqIndex1 < uRefSeqCount; ++uRefSeqIndex1)
            for (unsigned uRefSeqIndex2 = uRefSeqIndex1 + 1; uRefSeqIndex2 < uRefSeqCount;
              ++uRefSeqIndex2)
                {
                const unsigned uTestSeqIndex1 = RefSeqIndexToTestSeqIndex[uRefSeqIndex1];
                const unsigned uTestSeqIndex2 = RefSeqIndexToTestSeqIndex[uRefSeqIndex2];
                if (!msaTest.IsGap(uTestSeqIndex1, uTestColIndex) &&
                  !msaTest.IsGap(uTestSeqIndex2, uTestColIndex))
                    ++uTestAlignedPairCount;
                }
        }

    unsigned uRefAlignedColCount = 0;
    unsigned uCorrectlyAlignedColCount = 0;
    unsigned uRefAlignedPairCount = 0;
    unsigned uCorrectlyAlignedPairCount = 0;
    unsigned uRefColCount = msaRef.GetColCount();
    for (unsigned uRefColIndex = 0; uRefColIndex < uRefColCount; ++uRefColIndex)
        {
        const COLINFO &CI = msaRef.GetColInfo(uRefColIndex);
        if (!CI.m_bAligned)
            continue;
        bool bAllAlignedCorrectly = true;
        bool bAllGaps = true;
    // Iterate over all pairs
        for (unsigned uRefSeqIndex1 = 0; uRefSeqIndex1 < uRefSeqCount;
          ++uRefSeqIndex1)
            {
            char cRef1 = msaRef.GetChar(uRefSeqIndex1, uRefColIndex);
            if (IsGap(cRef1))
                continue;
            assert(isupper(cRef1));
            unsigned uRefUngappedColIndex1 =
              msaRef.GetUngappedColIndex(uRefSeqIndex1, uRefColIndex);
            unsigned uTestSeqIndex1 = RefSeqIndexToTestSeqIndex[uRefSeqIndex1];
            unsigned uTestGappedColIndex1 = msaTest.
              GetGappedColIndex(uTestSeqIndex1, uRefUngappedColIndex1);
            char cTest1 = msaTest.GetChar(uTestSeqIndex1, uTestGappedColIndex1);
            if (cRef1 != toupper(cTest1))
                {
                fprintf(stderr, "\n*** Error cRef1 != toupper(cTest1)\n\n");
                List("cRef1=%c != toupper(cTest1=%c)=%c\n",
                  cRef1, cTest1, toupper(cTest1));
                List("Test col index=%u, ref col index=%u\n",
                  uTestGappedColIndex1,
                  uRefColIndex);
                List("Seq in test alignment:\n");
                ListSeq2(msaTest, uTestSeqIndex1);
                List("\nSeq in ref alignment:\n");
                ListSeq2(msaRef, uRefSeqIndex1);
                List("\n");
                exit(0);
                }
            for (unsigned uRefSeqIndex2 = uRefSeqIndex1 + 1; uRefSeqIndex2 < uRefSeqCount;
              ++uRefSeqIndex2)
                {
                char cRef2 = msaRef.GetChar(uRefSeqIndex2, uRefColIndex);
                if (IsGap(cRef2))
                    continue;
                bAllGaps = false;
                assert(isupper(cRef2));
                ++uRefAlignedPairCount;

                unsigned uRefUngappedColIndex2 =
                  msaRef.GetUngappedColIndex(uRefSeqIndex2, uRefColIndex);
                unsigned uTestSeqIndex2 = RefSeqIndexToTestSeqIndex[uRefSeqIndex2];
                unsigned uTestGappedColIndex2 = msaTest.
                  GetGappedColIndex(uTestSeqIndex2, uRefUngappedColIndex2);

                char cTest2 = msaTest.GetChar(uTestSeqIndex2, uTestGappedColIndex2);
                //List(" %c%c%c%c", cRef1, cRef2, cTest1, cTest2);
                if (isupper(cTest1) && isupper(cTest2) &&
                  uTestGappedColIndex1 == uTestGappedColIndex2)
                    {
                    ++uCorrectlyAlignedPairCount;
                    //List("+");
                    }
                else
                    {
                    bAllAlignedCorrectly = false;
                    //List("-");
                    }
                }
            }
        //List("\n");

        if (!bAllGaps)
            {
            ++uRefAlignedColCount;
            if (bAllAlignedCorrectly)
                ++uCorrectlyAlignedColCount;
            }
        }
    delete[] RefSeqIndexToTestSeqIndex;

    if (0 == uRefAlignedPairCount)
        Quit("BaliScore: no aligned pairs in ref alignment");
    if (0 == uRefAlignedColCount)
        Quit("BaliScore: no aligned columns in ref alignment");

    *ptrdSP = (double) uCorrectlyAlignedPairCount / (double) uRefAlignedPairCount;
    *ptrdTC = (double) uCorrectlyAlignedColCount / (double) uRefAlignedColCount;

// Can happen that there are no aligned pairs in test alignment
    if (0 == uTestAlignedPairCount)
        *ptrdPS = 0.0;
    else
        *ptrdPS = (double) uCorrectlyAlignedPairCount / (double) uTestAlignedPairCount;
    }
