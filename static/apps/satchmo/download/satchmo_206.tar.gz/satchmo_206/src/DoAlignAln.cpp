// Lobster: tools for biological sequence analysis
// (C) Copyright 2002-2003 Robert C. Edgar
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; either version 2 of
// the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANT-
// ABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
// Public License for more details.

#include "lobster.h"
#include "TextFile.h"
#include "MSA.h"
#include "HMM.h"
#include "HMMPath.h"
#include "Seq.h"

void DoAlignAln(const char *in, const char *hmm, const char *tpl, const char *out)
    {
    const char *strInputFileName = in;
    const char *strModelFileName = hmm;
    const char *strTemplateFileName = tpl;
    const char *strOutputFastaFileName = out;

    TextFile ModelFile(hmm);
    HMM Model;
    Model.FromFile(ModelFile);

    TextFile InputFile(in);
    MSA msaInput;
    msaInput.FromFASTAFile(InputFile);
    msaInput.AlignByCase();
    msaInput.BuildPillars();
//    msaInput.ValidateBreakMatrices();
    msaInput.SanityCheckPillarCount();

    TextFile TemplateFile(tpl);
    MSA msaTemplate;
    msaTemplate.FromFASTAFile(TemplateFile);
    msaTemplate.AlignByCase();
    msaTemplate.BuildPillars();
//    msaTemplate.ValidateBreakMatrices();
    msaTemplate.SanityCheckPillarCount();

    HMMPath Path;
//    Path.SetTarget(msaInput);
    SCORE Score = Model.ViterbiAln(msaInput, Path);
    printf("Model=%s;Target=%s;Viterbi=%s\n", 
      strModelFileName,
      strInputFileName,
      ScoreToStrL(Score));
    List("Model=%s;Target=%s;Viterbi=%s\n", 
      strModelFileName,
      strInputFileName,
      ScoreToStrL(Score));

    MSA msaCombined;
    Model.SetTemplate(msaTemplate);
    Model.Align(Path, msaCombined, msaInput);

    TextFile OutFile(strOutputFastaFileName, true);
    msaCombined.ToFASTAFile(OutFile);
    }
